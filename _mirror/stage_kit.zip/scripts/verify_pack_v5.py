#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Самопроверка распакованного handoff-пака v5.

Запуск ИЗ КОРНЯ распакованного пака (рядом с 00_ПРОЧТИ_ПЕРВЫМ.md):
    python3 scripts/verify_pack_v5.py

Проверяет:
1. наличие всех заявленных файлов (доки, скрипты, материалы, база знаний);
2. согласованность версий: 00_ПРОЧТИ ↔ state.md ↔ CHANGELOG ↔ info.xml
   выпущенного пакета (version-guard, [S8]);
3. целость выпущенного пакета: testzip, 63 записи (v1.5.20), 39 ESP,
   3 превью-картинки, Readme нет, PoE_RU_KID.ini на месте;
4. отсутствие известного кладбища (07_/11_/13_, дубли 05_/09_);
4b. исключение отозванной темы Этапа 121 (директива игрока, Этап 122):
   report_121.md / check121_ald.py в паке быть не должно;
5. 06_симптомы_и_декодер: секции, коды уроков из lessons.md, пути.
Аналитический: НИЧЕГО не правит. Выход: код 0 = всё зелёное.
"""
import os, re, sys, zipfile

ROOT = os.getcwd()

DOC_NAMES = ['00_ПРОЧТИ_ПЕРВЫМ.md', '01_состояние_и_история.md',
             '02_конвейер_и_сборка.md', '03_техбаза_ESP_PEX.md',
             '04_каноны_и_санкции.md', '05_карта_файлов.md',
             '06_симптомы_и_декодер.md', 'CHANGELOG.md',
             'Paths of Empyrean RU 1.5.zip',
             'report_99.md', 'report_100.md', 'report_101.md',
             'report_102.md', 'report_103.md', 'report_104.md',
             'report_105.md', 'report_106.md', 'report_107.md',
             'report_108.md', 'report_109.md', 'report_110.md',
             'report_111.md', 'report_112.md', 'report_113.md',
             'report_114.md', 'report_115.md', 'report_116.md',
             'report_117.md', 'report_118.md', 'report_119.md',
             'report_120.md', 'report_122.md',
             'work/qa94/fixlist.jsonl', 'work/qa94/dump_v155.jsonl',
             'work/qa95/inventory_records.txt',
             'work/qa95/inventory_subsystems.txt',
             'work/qa95/inventory_taxonomy.txt', 'work/qa95/avif_stars.txt',
             'work/qa96/perkdump.jsonl',
             'work/qa100/dump_v157.jsonl',
             'work/qa100/case_report.txt', 'work/qa100/case_report2.txt',
             'work/qa100/case_report3.txt',
             'work/qa101/drift_report.txt',
             'work/qa102/fixlist_v158.jsonl', 'work/qa102/README.md',
             'work/qa103/dump_v158.jsonl',
             'work/qa104/fixlist_v159.jsonl',
             'work/qa104/dump_v159_full.jsonl',
             'work/qa105/audit105_report.txt', 'work/qa105/findings.jsonl',
             'work/qa106/audit106_report.txt',
             'work/qa106/formula_violations.tsv', 'work/qa106/aliens.tsv',
             'work/qa106/lore.tsv', 'work/qa106/summon_family.tsv',
             'work/qa106/lint.tsv', 'work/qa106/fixlist_106.jsonl',
             'work/qa107/inventory_107.txt', 'work/qa107/espdiff_107.txt',
             'work/qa107/kid_name_dep_107.txt', 'work/qa107/layers_107.txt',
             'work/qa107/candidates_pt_ru.tsv', 'work/qa107/dump_en14.jsonl',
             'work/qa107/dump_pt.jsonl',
             'work/qa108/fomod_ru.txt', 'work/qa108/fomod_ptbr.txt',
             'work/qa108/fomod_new.txt', 'work/qa108/build_log.txt',
             'work/qa111/fixlist_v112.jsonl',
             'work/qa111/canon_scan_report.txt',
             'work/qa111/findings_111.jsonl',
             'work/qa111/layers_111.txt',
             'work/qa111/dump_v112_full.jsonl',
             'work/qa112/fixlist_v113.jsonl',
             'work/qa112/dump_v113_full.jsonl',
             'work/qa113/fixlist_v114.jsonl',
             'work/qa113/dump_v114_full.jsonl',
             'work/qa114/fixlist_v115.jsonl',
             'work/qa114/dump_v115_full.jsonl',
             'work/qa115/fixlist_v116.jsonl',
             'work/qa115/dump_v116_full.jsonl',
             'work/qa116/fixlist_v117.jsonl',
             'work/qa116/dump_v117_full.jsonl',
             'work/qa117/fixlist_v118.jsonl',
             'work/qa118/dump_en14.jsonl',
             'work/qa118/aligned.json',
             'work/qa118/audit_report.txt',
             'work/qa118/audit_b.txt',
             'work/qa118/fixlist_project_118.jsonl',
             'work/qa117/dump_v118_full.jsonl',
             'work/qa119/fixlist_v119.jsonl',
             'work/qa119/dump_v119_full.jsonl',
             'work/qa120/fixlist_v120.jsonl',
             'work/qa120/dump_v120_full.jsonl']
SCRIPTS = ['parse_tes4.py', 'dump150.py', 'espdiff88.py', 'qa94_scan.py',
           'master91.py', 'master94.py', 'build_package94.py', 'verify94.py',
           'build_handoff_pack_v5.py', 'verify_pack_v5.py',
           'inventory95.py', 'inventory95b.py', 'inventory95c.py',
           'perkdump96.py', 'perkdump96b.py', 'perkdump96c.py',
           'perkdump96d.py', 'perkdump96e.py',
           'extract_spid.py', 'spid_strings.py', 'pdb_symbols.py',
           'pdb_msf.py', 'pdb_filter_enum.py', 'pdb_tpi_walk.py',
           'pdb_datamodel.py',
           'extract_kid.py', 'kid_strings.py', 'kid_symbols.py',
           'kid_datamodel.py', 'kid_poe_analysis.py',
           'kid_kwda_check.py', 'kid_clone_kwda.py',
           'kid_spear_audit.py', 'kid_perk_conds.py',
           'kid_name_dep_use.py', 'kid_impact_audit.py',
           'kid_fix_build99.py', 'verify99.py', 'build_package99.py',
           'dump157.py', 'case_scan100.py', 'case_scan100b.py',
           'case_scan100c.py', 'drift101.py', 'gen101.py',
           'poe_verdict102.py', 'verify102.py',
           'dump103.py', 'master103.py', 'build_package103.py',
           'verify103.py', 'gen103.py',
           'master104.py', 'build_package104.py', 'verify104.py',
           'gen104.py', 'audit105.py', 'audit106.py',
           'ptbr107_dump.py', 'ptbr107_inventory.py',
           'ptbr107_layers.py', 'ptbr107_layers2.py',
           'ptbr107_espdiff.py',
           'fomod_struct.py', 'build_package108.py',
           'canon111_scan.py', 'canon111_layers.py', 'master111.py',
           'build_package111.py', 'verify111.py', 'gen111.py',
           'diff_zip_112.py', 'master112.py', 'build_package112.py',
           'verify112.py', 'gen112.py',
           'diff_zip_113.py', 'master113.py', 'build_package113.py',
           'verify113.py', 'gen113.py',
           'diff_zip_114.py', 'master114.py', 'build_package114.py',
           'verify114.py', 'gen114.py',
           'query115.py', 'scan115.py', 'probe115b.py', 'probe115c.py',
           'probe115d.py', 'probe115e.py', 'probe115f.py', 'probe115g.py',
           'probe115h.py', 'master115.py', 'build_package115.py',
           'verify115.py', 'gen115.py',
           'diff_zip_116.py', 'master116.py', 'build_package116.py',
           'verify116.py', 'gen116.py',
           'master117.py', 'build_package117.py',
           'verify117.py', 'gen117.py',
           'dump118_en.py', 'tier118_explore.py', 'tier118_explore2.py',
           'tier118_explore3.py', 'tier118_explore4.py',
           'tier118_explore5.py', 'audit118.py', 'audit118b.py',
           'fixproj118.py',
           'fixproj119.py', 'master119.py', 'build_package119.py',
           'verify119.py', 'gen119.py',
           'check120_armorclass.py', 'fixproj120.py', 'master120.py',
           'build_package120.py', 'verify120.py', 'gen120.py']
HANDOFF_DIRS = ['01_документация', '02_хелпер_SoftClub', '03_агентская_память',
                '04_эталоны_игрока', '05_стринги_ESP', '06_код-истина_перевода',
                '08_оригинал_1.4_EN', '09_канон_официальной_локализации',
                '10_наш_перевод_CC_патчей', '12_отчёты_этапов',
                '14_деревья_перков', '15_передача', '16_SPID_реверс',
                '17_KID_реверс', '18_FOMOD_установщик']
CEMETERY = ['handoff/handoff',
            'handoff/07_конвейер_scripts', 'handoff/11_валидация',
            'handoff/13_текущий_пакет_RU_v1.34',
            'handoff/05_стринги_ESP/ru_main.json',
            'handoff/05_стринги_ESP/ru1313_master.json',
            'handoff/05_стринги_ESP/EN_orig.json',
            'handoff/09_канон_официальной_локализации/official_strings.json',
            'handoff/03_агентская_память/memory_export.md']

fails = []


def ok(msg):
    print(f'  PASS  {msg}')


def bad(msg):
    fails.append(msg)
    print(f'  FAIL  {msg}')


def read(p):
    with open(os.path.join(ROOT, p), encoding='utf-8') as f:
        return f.read()


print('1) Наличие файлов')
for p in DOC_NAMES:
    (ok if os.path.isfile(os.path.join(ROOT, p)) else bad)(p)
for s in SCRIPTS:
    (ok if os.path.isfile(os.path.join(ROOT, 'scripts', s)) else
     bad)(f'scripts/{s}')
for d in HANDOFF_DIRS:
    (ok if os.path.isdir(os.path.join(ROOT, 'handoff', d)) else
     bad)(f'handoff/{d}/')
for extra in ('handoff/02_хелпер_SoftClub/work/softclub/db.jsonl',
              'handoff/04_эталоны_игрока/perks_v149.jsonl',
              'handoff/04_эталоны_игрока/perks_v150.jsonl',
              'handoff/04_эталоны_игрока/perks_v151.jsonl',
              'handoff/04_эталоны_игрока/perks_v152.jsonl',
              'handoff/04_эталоны_игрока/perks_v153.jsonl',
              'handoff/04_эталоны_игрока/perks_v154.jsonl',
              'handoff/04_эталоны_игрока/perks_v155.jsonl',
              'handoff/06_код-истина_перевода/corpus57.json',
              'handoff/06_код-истина_перевода/README.md',
              'handoff/06_код-истина_перевода/_архив_мастер-эры/README.md',
              'handoff/12_отчёты_этапов/INDEX.md',
              'handoff/12_отчёты_этапов/report_96.md',
              'handoff/12_отчёты_этапов/report_97.md',
              'handoff/12_отчёты_этапов/report_98.md',
              'handoff/12_отчёты_этапов/report_99.md',
              'handoff/12_отчёты_этапов/report_100.md',
              'handoff/12_отчёты_этапов/report_101.md',
              'handoff/12_отчёты_этапов/report_102.md',
              'handoff/12_отчёты_этапов/report_103.md',
              'handoff/12_отчёты_этапов/report_104.md',
              'handoff/12_отчёты_этапов/report_105.md',
              'handoff/12_отчёты_этапов/report_106.md',
              'handoff/12_отчёты_этапов/report_107.md',
              'handoff/12_отчёты_этапов/report_108.md',
              'handoff/12_отчёты_этапов/report_109.md',
              'handoff/12_отчёты_этапов/report_110.md',
              'handoff/12_отчёты_этапов/report_111.md',
              'handoff/12_отчёты_этапов/report_112.md',
              'handoff/12_отчёты_этапов/report_113.md',
              'handoff/12_отчёты_этапов/report_114.md',
              'handoff/14_деревья_перков/PoE_Перки_156_полный_дамп.md',
              'handoff/16_SPID_реверс/README.md',
              'handoff/16_SPID_реверс/SPID_7.3.3_реверс-отчёт.md',
              'handoff/16_SPID_реверс/datamodel.txt',
              'handoff/16_SPID_реверс/spid_strings_all.txt',
              'handoff/16_SPID_реверс/pdb_spid_funcs.txt',
              'handoff/17_KID_реверс/README.md',
              'handoff/17_KID_реверс/KID_4.1.0_реверс-отчёт.md',
              'handoff/17_KID_реверс/datamodel.txt',
              'handoff/17_KID_реверс/kid_strings_all.txt',
              'handoff/17_KID_реверс/pdb_kid_funcs.txt',
              'handoff/18_FOMOD_установщик/README.md',
              'handoff/18_FOMOD_установщик/FOMOD_установщик_опыт.md'):
    (ok if os.path.isfile(os.path.join(ROOT, extra)) else bad)(extra)

print('2) Согласованность версий (version-guard)')
v_doc = re.search(r'ВЕРСИЯ ПЕРЕДАЧИ:\s*v(\d+\.\d+\.\d+)', read(DOC_NAMES[0]))
v_state = re.search(r'СБОРКА\s+\*\*v(\d+\.\d+\.\d+)\*\*',
                    read('handoff/03_агентская_память/state.md'))
v_log = re.search(r'^##\s*v(\d+\.\d+\.\d+)', read('CHANGELOG.md'), re.M)
ru = os.path.join(ROOT, 'Paths of Empyrean RU 1.5.zip')
with zipfile.ZipFile(ru) as z:
    v_zip = re.search(r'<Version>(\d+\.\d+\.\d+)</Version>',
                      z.read('fomod/info.xml').decode('utf-8'))
    print('3) Целость выпущенного пакета')
    (ok if z.testzip() is None else bad)('testzip')
    names = z.namelist()
    (ok if len(names) == 63 else bad)(f'записей в пакете: {len(names)} (ожидалось 63)')
    esps = [n for n in names if n.endswith('.esp')]
    (ok if len(esps) == 39 else bad)(f'ESP: {len(esps)} (ожидалось 39)')
    for img in ('ModImage1.png', 'PreviewSpears.jpg',
                'PreviewMissingShields.png'):
        (ok if img in names else bad)(f'превью {img} в корне архива')
    (ok if not any('eadme' in n for n in names) else bad)('Readme в пакете нет')
    (ok if '00 Core/PoE_RU_KID.ini' in names else bad)('PoE_RU_KID.ini в 00 Core')
    (ok if z.read('fomod/ModuleConfig.xml') else bad)('ModuleConfig.xml читается')
src = {'00_ПРОЧТИ': v_doc, 'state.md': v_state, 'CHANGELOG': v_log,
       'info.xml': v_zip}
for k, m in src.items():
    (ok if m else bad)(f'версия в {k}' + (f' = v{m.group(1)}' if m else ' НЕ НАЙДЕНА'))
vals = {m.group(1) for m in src.values() if m}
(ok if len(vals) == 1 else bad)(f'все версии совпадают: {vals or "—"}')

print('4) Кладбище отсутствует')
for p in CEMETERY:
    (ok if not os.path.exists(os.path.join(ROOT, p)) else bad)(f'нет: {p}')

print('4b) Отозванная тема Этапа 121 исключена (директива игрока, Этап 122)')
for p in ('report_121.md', 'handoff/12_отчёты_этапов/report_121.md',
          'scripts/check121_ald.py'):
    (ok if not os.path.exists(os.path.join(ROOT, p)) else bad)(f'нет: {p}')

print('5) 06_симптомы_и_декодер: секции, коды уроков, пути')
m06 = read('06_симптомы_и_декодер.md')
for h in ('Диагностическая матрица', 'Декодер фраз', 'Жаргон'):
    (ok if h in m06 else bad)(f'06: секция «{h}»')
lessons = read('handoff/03_агентская_память/lessons.md')
miss_codes = [c for c in sorted(set(re.findall(r'\[([STDAM]\d+)\]', m06)))
              if f'[{c}]' not in lessons]
(ok if not miss_codes else bad)('06: коды уроков есть в lessons.md' if
                                not miss_codes else
                                f'06: кодов нет в lessons.md: {miss_codes}')
toks = sorted(set(re.findall(r'`([^`\n]+)`', m06)))
paths = [t for t in toks
         if ('/' in t or t.endswith(('.py', '.md', '.jsonl')))
         and not t.startswith(('fomod/', 'download', 'upload'))]
hang = [p for p in paths
        if not any(os.path.exists(os.path.join(ROOT, x))
                   for x in (p, f'handoff/{p}', f'scripts/{p}'))]
(ok if not hang else bad)('06: все пути резолвятся' if not hang else
                          f'06: висячие пути: {hang}')

print()
if fails:
    print(f'ИТОГ: {len(fails)} FAIL — пак дефектен, см. выше')
    sys.exit(1)
print(f'ИТОГ: все проверки зелёные — пак цел и согласован '
      f'(версия пакета v{list(vals)[0] if vals else "?"})')
