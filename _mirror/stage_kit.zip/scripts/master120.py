#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 120 (v1.5.20): вердикт игрока по 112-а — «Разделять».

Два SPEL Material Mastery «- Драконий» разведены по материям своей
серии: тяжёлая 061A81DD → «Железный человек - Драконий панцирный»
(Dragonplate, BOD2 Heavy, гейт SF_K_MaterialMasteryDragonHeavy), лёгкая
06394B42 → «Вторая кожа - Драконий чешуйчатый» (Dragonscale, BOD2 Light,
гейт SF_K_MaterialMasteryDragonLight).

База: наш выпуск v1.5.19 = download/Paths of Empyrean RU 1.5.zip
(md5 d87317dc79bf1025bf6a38f2625520fd; корневая копия идентична).
Приёмник: work/qa120/v120 (свежая распаковка). Фикслист:
work/qa120/fixlist_v120.jsonl (2 поля main ESP; old сверены байт-в-байт
генератором scripts/fixproj120.py по дампу истины v1.5.19).
"""
import struct, zlib, os, json, zipfile, hashlib, shutil

BASE_ZIP = '/home/z/my-project/download/Paths of Empyrean RU 1.5.zip'
V119_ZIP_MD5 = 'd87317dc79bf1025bf6a38f2625520fd'
DST = '/home/z/my-project/work/qa120/v120'
FIX = '/home/z/my-project/work/qa120/fixlist_v120.jsonl'

FILEMAP = {
    'main': '00 Core/PathsOfEmpyrean.esp',
}
EXPECT = {'main': 2}

REC_HDR = 24


class Node:
    __slots__ = ('kind', 'label', 'tail', 'formid', 'data', 'children')


def parse(buf):
    root = []

    def walk(off, end, out):
        while off < end:
            t = buf[off:off+4]
            size = struct.unpack_from('<I', buf, off+4)[0]
            if t == b'GRUP':
                node = Node()
                node.kind = 'grup'
                node.label = None
                node.tail = bytes(buf[off+8:off+24])
                node.children = []
                walk(off + REC_HDR, off + size, node.children)
                out.append(node)
                off += size
            else:
                node = Node()
                node.kind = 'rec'
                node.label = t
                node.tail = bytes(buf[off+8:off+24])
                node.formid = struct.unpack_from('<I', buf, off+12)[0]
                node.data = bytes(buf[off+REC_HDR:off+REC_HDR+size])
                out.append(node)
                off += REC_HDR + size
    walk(0, len(buf), root)
    return root


def serialize_node(n, parts):
    if n.kind == 'grup':
        sub = []
        for c in n.children:
            serialize_node(c, sub)
        s = b''.join(sub)
        parts.append(b'GRUP' + struct.pack('<I', 24 + len(s)) + n.tail)
        parts.append(s)
    else:
        parts.append(n.label + struct.pack('<I', len(n.data)) + n.tail)
        parts.append(n.data)


def find_rec(nodes, formid):
    for n in nodes:
        if n.kind == 'grup':
            r = find_rec(n.children, formid)
            if r is not None:
                return r
        elif n.formid == formid:
            return n
    return None


def rec_flags(rec):
    return struct.unpack_from('<I', rec.tail, 0)[0]


def decode_body(rec):
    if rec_flags(rec) & 0x00040000:
        usz = struct.unpack_from('<I', rec.data, 0)[0]
        dec = zlib.decompress(rec.data[4:])
        assert len(dec) == usz
        return bytearray(dec), True
    return bytearray(rec.data), False


def encode_body(body, was_c):
    if was_c:
        return struct.pack('<I', len(body)) + zlib.compress(bytes(body))
    return bytes(body)


def patch_strings(path, patches):
    buf = open(path, 'rb').read()
    root = parse(buf)
    out = []
    for n in root:
        serialize_node(n, out)
    assert b''.join(out) == buf, f'самотест сериализации: {path}'
    applied = 0
    for formid, field, occ, old, new in patches:
        rec = find_rec(root, formid)
        assert rec is not None, f'{formid:08X} не найдена'
        body, was_c = decode_body(rec)
        off, seen, done = 0, 0, False
        while off < len(body):
            if off + 6 > len(body):
                break
            st = body[off:off+4].decode('ascii', 'replace')
            ssz = struct.unpack_from('<H', body, off+4)[0]
            if st == 'XXXX':
                real = struct.unpack_from('<I', body, off+6)[0]
                off += 6 + ssz + 6 + real
                continue
            cur_sz = ssz
            if st == field:
                seen += 1
                cur = bytes(body[off+6:off+6+ssz]).rstrip(b'\x00').decode(
                    'utf-8', 'replace')
                if seen == occ:
                    assert cur == old, (
                        f'{formid:08X} {field}#{occ}: {cur[:80]!r} != {old[:80]!r}')
                    newb = new.encode('utf-8') + b'\x00'
                    body[off+6:off+6+ssz] = newb
                    struct.pack_into('<H', body, off+4, len(newb))
                    done = True
                    applied += 1
                    cur_sz = len(newb)
            off += 6 + cur_sz
        assert done, f'{formid:08X} {field}#{occ} не применён'
        rec.data = encode_body(body, was_c)
    out = []
    for n in root:
        serialize_node(n, out)
    data = b''.join(out)
    open(path, 'wb').write(data)
    print(f'  строки {os.path.basename(path)}: патчей {applied}, '
          f'файл {len(buf)} -> {len(data)} Б')
    return applied


def main():
    assert hashlib.md5(open(BASE_ZIP, 'rb').read()).hexdigest() == V119_ZIP_MD5, \
        'база не равна выпуску v1.5.19!'
    if os.path.isdir(DST):
        shutil.rmtree(DST)
    with zipfile.ZipFile(BASE_ZIP) as z:
        assert z.testzip() is None
        info = z.read('fomod/info.xml').decode('utf-8')
        assert '<Version>1.5.19</Version>' in info, 'база не v1.5.19!'
        z.extractall(DST)
    print('база: наш выпуск v1.5.19 (md5 сверен), свежая распаковка '
          'в work/qa120/v120')

    esp = [json.loads(l) for l in open(FIX, encoding='utf-8')]
    assert len(esp) == 2 and all(r['kind'] == 'esp' for r in esp)

    total = 0
    for scope in ['main']:
        patches = [(int(r['formid'], 16), r['field'], r['occ'], r['old'],
                    r['new']) for r in esp if r['file'] == scope]
        assert len(patches) == EXPECT[scope], (scope, len(patches))
        print(f'[{scope}] {FILEMAP[scope]}')
        total += patch_strings(os.path.join(DST, FILEMAP[scope]), patches)
    assert total == 2, total

    print()
    full = os.path.join(DST, FILEMAP['main'])
    print(f'md5 {os.path.basename(full)}: '
          f'{hashlib.md5(open(full, "rb").read()).hexdigest()} '
          f'({os.path.getsize(full)} Б)')
    print(f'ИТОГО применено: {total} патча ESP (112-а: «Разделять»)')


if __name__ == '__main__':
    main()
