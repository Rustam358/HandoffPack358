#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 114, шаг: независимая верификация v1.5.15 (вердикт 111-б, 1 правка).
1) Дамп release-ESP == 8914 полей; ключи == v1.5.14; дифф == РОВНО 1 == fixlist.
2) Серия маскировок: «под талморца.» = 1, «под талмора» = 0 (main + весь пак),
   остальные MESG серии не тронуты, DNAM/FULL/PERK на месте.
3) Регресс 113: «ламелляр» = ровно 9 полей fixlist 113; «чешуйчатые и
   пластинчатые» = 0; «чешуйчат» main = 31 канон-поле.
4) Гигиена + пак-скан + пробы 111/104/102 + ALD/MCM/ShortbowNames/info.xml.
"""
import sys, json, zipfile, re, os, io, hashlib
sys.path.insert(0, '/home/z/my-project/work/handoff510/scripts')
from dump150 import dump_esp

ZIP = '/home/z/my-project/download/Paths of Empyrean RU 1.5.zip'
DUMP_NEW = '/home/z/my-project/work/qa114/dump_v115_release.jsonl'
DUMP_OLD = '/home/z/my-project/work/qa113/dump_v114_release.jsonl'
FIX = '/home/z/my-project/work/qa114/fixlist_v115.jsonl'
V115_ESP = '/home/z/my-project/work/qa114/v115/00 Core/PathsOfEmpyrean.esp'

fails = []


def check(cond, msg):
    print(('  [OK] ' if cond else '  [FAIL] ') + msg)
    if not cond:
        fails.append(msg)


def dump_main(esp_path, out_path):
    with io.open(out_path, 'w', encoding='utf-8') as f:
        dump_esp(esp_path, 'main', f)
    return [json.loads(l) for l in io.open(out_path, encoding='utf-8')]


def main():
    z = zipfile.ZipFile(ZIP)
    esp_bytes = z.read('00 Core/PathsOfEmpyrean.esp')
    open('/home/z/my-project/work/qa114/_release_esp.bin', 'wb').write(esp_bytes)

    got = hashlib.md5(esp_bytes).hexdigest()
    ref = hashlib.md5(open(V115_ESP, 'rb').read()).hexdigest()
    check(got == ref, 'ESP релиза == work/qa114/v115 (md5 %s)' % got)

    fresh = dump_main('/home/z/my-project/work/qa114/_release_esp.bin', DUMP_NEW)
    old = [json.loads(l) for l in io.open(DUMP_OLD, encoding='utf-8')]
    print('1) дампы: new %d полей, old (v1.5.14) %d полей' % (len(fresh), len(old)))
    check(len(fresh) == 8914 and len(old) == 8914, 'полей ровно 8914 в обоих дампах')

    fk = {(r['formid'], r['rtype'], r['field'], r.get('occ', 1)): r['text'] for r in fresh}
    ok_ = {(r['formid'], r['rtype'], r['field'], r.get('occ', 1)): r['text'] for r in old}
    check(set(fk) == set(ok_), 'множество ключей идентично v1.5.14')

    fixes = [json.loads(l) for l in io.open(FIX, encoding='utf-8')]
    expected = {(int(f['formid'], 16), f['field'], f['occ']): f for f in fixes}
    diffs = [(k, ok_[k], fk[k]) for k in ok_ if ok_[k] != fk[k]]
    print('2) дифф полей vs v1.5.14: %d (ожидается %d)' % (len(diffs), len(expected)))
    okn, bad = 0, []
    for (formid, rtype, field, occ), old_t, new_t in diffs:
        f = expected.get((int(formid, 16), field, occ))
        if f and old_t == f['old'] and new_t == f['new']:
            okn += 1
        else:
            bad.append((formid, field, old_t[:60], new_t[:60]))
    check(okn == len(expected) and len(diffs) == len(expected) and not bad,
          'дифф == fixlist (%d/%d); лишних: %d %s' % (okn, len(expected), len(bad), bad[:3]))

    print('3) серия маскировок:')
    cnt_new = sum(1 for t in fk.values() if t and 'Вы замаскированы под талморца.' in t)
    check(cnt_new == 1, 'MESG «Вы замаскированы под талморца.» = 1 (факт %d)' % cnt_new)
    cnt_old = sum(1 for t in fk.values() if t and 'под талмора' in t)
    check(cnt_old == 0, '«под талмора» в main = 0 (факт %d)' % cnt_old)
    for sub, n in [
        ('Маскировка - талморца', 1), ('Талмор примет вас за своего.', 1),
        ('Вы замаскированы под Изгоя.', 1), ('Вы замаскированы под Брата Бури.', 1),
        ('Вы замаскированы под бандита.', 1), ('Вы замаскированы под имперца.', 1),
        ('Вы замаскированы под культиста.', 1), ('Вы замаскированы под некроманта.', 1),
        ('Вы замаскированы под драугра.', 1), ('Вы замаскированы под фалмера.', 1),
        ('Вы замаскированы под вампира.', 1),
        ('Вы замаскированы под двемерского автоматона.', 1),
        ('Вы замаскированы под члена Стражи Рассвета.', 1),
        ('Имперцев, Талмора, культистов', 1),
        ('Ваша маскировка сорвалась...', 1),
    ]:
        hits = [k for k, t in fk.items() if t and sub in t]
        check(len(hits) == n, '«%s» = %d (факт %d)' % (sub, n, len(hits)))

    print('4) регресс 113:')
    lam = {k: t for k, t in fk.items() if 'ламелляр' in (t or '').lower()}
    exp_lam = {}
    for x in [json.loads(l) for l in
              io.open('/home/z/my-project/work/qa113/fixlist_v114.jsonl', encoding='utf-8')]:
        exp_lam[(int(x['formid'], 16), x['field'], x['occ'])] = x['new']
    lam3 = {(int(k[0], 16), k[2], k[3]): t for k, t in lam.items()}
    check(lam3 == exp_lam, '«ламелляр» = ровно 9 полей отката 113 с точными значениями (факт %d)' % len(lam))
    cnt1 = sum(1 for t in fk.values() if t and 'чешуйчатые и пластинчатые' in t)
    cnt2 = sum(1 for t in fk.values() if t and 'стальные пластинчатые и чешуйчатые' in t)
    check(cnt1 == 0 and cnt2 == 0, '«чешуйчатые и пластинчатые»/«стальные…чешуйчатые» = 0 (факт %d/%d)' % (cnt1, cnt2))
    che = [t for t in fk.values() if t and 'чешуйчат' in t.lower()]
    alien = [t for t in che if not (
        ('дракон' in t.lower() and t.startswith('Мастерск')) or
        'Чешуйчатый кокон' in t or 'Чешуйчатка' in t)]
    check(len(che) == 31 and not alien,
          '«чешуйчат» main = ровно 31 канон-поле (факт %d); чужих %d %s' % (len(che), len(alien), alien[:2]))
    for sub, n, kw in [
        ('Мастерский ламеллярный шлем', 1, 'FULL'),
        ('Мастерские ламеллярные наручи', 1, 'FULL'),
        ('Мастерская ламеллярная броня', 2, 'FULL'),
        ('Мастерские ламеллярные сапоги', 1, 'FULL'),
        ('Мастерская ламеллярная броня с рогами', 1, 'FULL'),
        ('Железный человек - Ламеллярный', 1, 'FULL'),
        ('Вторая кожа - Ламеллярный', 1, 'FULL'),
        ('ламеллярные и пластинчатые доспехи', 1, 'DESC'),
        ('стальные пластинчатые и ламеллярные доспехи', 1, 'DESC'),
        ('Мастерский драконий чешуйчатый щит', 1, 'FULL'),
        ('Мастерский драконий чешуйчатый шлем', 1, 'FULL'),
        ('Мастерские драконьи чешуйчатые перчатки', 1, 'FULL'),
        ('Мастерская драконья чешуйчатая броня', 1, 'FULL'),
        ('Мастерские драконьи чешуйчатые сапоги', 1, 'FULL'),
        ('Чешуйчатый кокон', 23, None), ('Чешуйчатка', 3, None),
        ('- Драконий', 2, 'FULL'),
        ('Грозовой атронах', 2, None), ('Маскировка - Брата Бури', 1, 'FULL'),
        ('Маскировка - Изгоя', 1, 'FULL'), ('Маскировка - бандита', 1, 'FULL'),
        ('Дикая форма - волк', 1, None), ('Сокрушительный набег', 3, 'FULL'),
        ('Мастерские сыромятные сапоги', 1, 'FULL'),
        ('Мастерские драконьи панцирные сапоги', 1, 'FULL'),
        ('Мастерский имперский офицерский шлем', 1, 'FULL'),
        ('Маска члена культа', 1, 'FULL'), ('Мастерская маска члена культа', 1, 'FULL'),
        ('Счастливая стрела нордского героя (жетон)', 1, 'FULL'),
        ('Мастерская древняя нордская броня', 1, 'FULL'),
        ('Мастерская эльфийская золоченая броня', 1, 'FULL'),
        ('Мастерская эльфийская позолоченная броня', 0, 'FULL'),
        ('Мастерские офицерские сапоги Братьев Бури', 1, 'FULL'),
        ('создает двемерскую сферу-убийцу', 1, 'DNAM'),
        ('Позволяет ковать стальное и костяное снаряжение', 1, 'DESC'),
    ]:
        hits = [k for k, t in fk.items() if t and sub in t
                and (kw is None or k[2] == kw)]
        check(len(hits) == n, '«%s» = %d (факт %d)' % (sub, n, len(hits)))

    print('5) гигиена:')
    hy = {'%%': 0, 'ё': 0, 'рейтинг': 0, 'укр.': 0, '  ': 0}
    lone = 0
    dq = []
    for k, t in fk.items():
        hy['%%'] += (t or '').count('%%')
        hy['ё'] += (t or '').count('ё')
        hy['рейтинг'] += len(re.findall(r'[Рр]ейтинг', t or ''))
        hy['укр.'] += (t or '').count('укр.')
        hy['  '] += (t or '').count('  ')
        if re.search(r'(?<!\r)\n', t or ''):
            lone += 1
        if '"' in t and 'font' not in t:
            dq.append((k, t[:60]))
    for m, v in hy.items():
        check(v == 0, '%s = 0 (факт %d)' % (repr(m), v))
    check(lone == 0, 'lone \\n = 0 (факт %d)' % lone)
    check(len(dq) == 0, 'прямые кавычки вне font-книг = 0 (факт %d)' % len(dq))
    over = [(k, len(t)) for k, t in fk.items()
            if k[1] == 'PERK' and k[2] == 'DESC' and t and len(t) > 290]
    check(len(over) == 0, 'PERK DESC <= 290 (превышений %d)' % len(over))

    print('6) пак-скан (63 записи, 3 кодировки):')
    names = z.namelist()
    assert z.testzip() is None
    assert len(names) == 63
    bad_pack, lam_out = [], 0
    decs = 0
    for n in names:
        raw = z.read(n)
        for enc in ('utf-8', 'utf-16le', 'cp1251'):
            try:
                s = raw.decode(enc)
            except (UnicodeDecodeError, UnicodeError):
                continue
            decs += 1
            low = s.lower()
            if 'под талмора' in low:
                bad_pack.append((n, enc, 'под талмора'))
            if ('чешуйчатые и пластинчатые' in low or
                    'стальные пластинчатые и чешуйчатые' in low):
                bad_pack.append((n, enc, 'чешуйчат-тир 112'))
            if 'ламелляр' in low and n != '00 Core/PathsOfEmpyrean.esp':
                lam_out += 1
    check(len(bad_pack) == 0, '«под талмора»/«чешуйчатые и пластинчатые» по паку = 0 (декодов %d; факты %s)' % (decs, bad_pack[:2]))
    check(lam_out == 0, '«ламелляр» вне main ESP = 0 (факт %d)' % lam_out)
    cc_names = [n for n in names if n.endswith('.esp') and n != '00 Core/PathsOfEmpyrean.esp']
    cc_texts = []
    for n in cc_names:
        raw = z.read(n)
        p = '/home/z/my-project/work/qa114/_cc_esp.bin'
        open(p, 'wb').write(raw)
        cc_texts += [r['text'] for r in dump_main(p, '/home/z/my-project/work/qa114/_cc_dump.jsonl')]
    cc_ok = sum(1 for t in cc_texts if 'Орочья чешуйчатая броня' in t)
    cc_ok2 = sum(1 for t in cc_texts if 'Клепаная драконья чешуйчатая броня' in t)
    cc_ok3 = sum(1 for t in cc_texts if 'Драконьи чешуйчатые перчатки драчуна' in t)
    check(cc_ok == 1 and cc_ok2 == 1 and cc_ok3 == 2,
          'CC-серии не тронуты (орочья %d, клепаная %d, драчуна %d)' % (cc_ok, cc_ok2, cc_ok3))
    sbn = z.read('00 Core/SKSE/Plugins/POE/Weapon/PathsOfEmpyrean_ShortbowNames.ini').decode('utf-8')
    check(sbn.count('Короткий лук Изгоев') == 1, 'ShortbowNames: «Короткий лук Изгоев» = 1')
    mcm = z.read('00 Core/Interface/Translations/PathsOfEmpyrean_RUSSIAN.txt').decode('utf-16le')
    check('$Forsworn\tИзгои' in mcm and 'Изгнанники' not in mcm, 'MCM: $Forsworn<tab>Изгои')
    ald = z.read('00 Core/SKSE/Plugins/ArcheryLocationalDamage.ini').decode('utf-8')
    check(ald.count('Message = В яблочко!') == 2 and ald.count('Message = Травма руки!') == 2
          and ald.count('Message = Травма ноги!') == 2, 'ALD ini: 2/2/2')
    ver = z.read('fomod/info.xml').decode('utf-8')
    check('<Version>1.5.15</Version>' in ver and '1.5.14' not in ver, 'info.xml = 1.5.15')

    print()
    if fails:
        print('ВЕРИФИКАЦИЯ ПРОВАЛЕНА (%d):' % len(fails))
        for f in fails:
            print('  -', f)
        raise SystemExit(1)
    print('ВЕРИФИКАЦИЯ ЗЕЛЁНАЯ: все группы проверок пройдены')


if __name__ == '__main__':
    main()
