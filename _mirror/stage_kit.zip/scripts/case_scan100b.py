# -*- coding: utf-8 -*-
"""Скан регистра по ИСТИНЕ (dump_v157.jsonl) + сверка слоёв v149 / desc_ru / v1.5.7.

Вопросы: (1) какой слой совпадает с выпущенным ESP; (2) где в ESP нарушены
вердикты регистра (именное употребление навыков/школ с прописной, родовые
со строчной); (3) лейбл-значения «X: Y»; (4) фокус «изменени*».
"""
import json
import re
from pathlib import Path
from collections import defaultdict, Counter

ROOT = Path("/home/z/my-project")
DUMP = ROOT / "work/qa100/dump_v157.jsonl"
V149 = ROOT / "handoff/04_эталоны_игрока/perks_v149.jsonl"
DESC_RU = ROOT / "handoff/06_код-истина_перевода/desc_ru.py"
OUT = ROOT / "work/qa100/case_report2.txt"
OUT.parent.mkdir(parents=True, exist_ok=True)

out = []
def emit(s=""):
    out.append(s)

recs = [json.loads(l) for l in open(DUMP, encoding="utf-8") if l.strip()]
perks = [r for r in recs if r["rtype"] == "PERK"]
v149 = [json.loads(l) for l in open(V149, encoding="utf-8") if l.strip()]
v149_by = {r["formid"]: r for r in v149}

dru_txt = DESC_RU.read_text(encoding="utf-8")
desc_ru = {}
m = re.search(r"DESC_RU\s*=\s*\{(.*?)\n\}", dru_txt, re.S)
for k, v in re.findall(r"'([^']+)'\s*:\s*'((?:[^'\\]|\\.)*)'", m.group(1)):
    desc_ru[k] = v.replace("\\'", "'")

def join_perk(fs):
    full = next((x["text"] for x in fs if x["field"] == "FULL" and x["occ"] == 1), "")
    descs = [x["text"] for x in fs if x["field"] == "DESC"]
    desc = max(descs, key=len) if descs else ""
    return full, desc

by_rec = defaultdict(list)
for r in perks:
    by_rec[(r["file"], r["formid"])].append(r)

TOKENS = ["колдовств", "иллюзи", "изменени", "разрушени", "восстановлени",
          "зачарован", "алхими", "красноречи", "кузнечн", "скрытност",
          "взлом", "карманных краж", "карманной кражи", "блокирован",
          "стрельб", "легкой брони", "тяжелой брони", "одноручн", "двуручн"]

def toks(text):
    res = []
    for t in TOKENS:
        for mo in re.finditer(t, text, re.I):
            a, b = max(0, mo.start() - 55), min(len(text), mo.end() + 55)
            res.append((mo.group(0), text[a:b].replace("\r", "").replace("\n", "⏎")))
    return res

# --- A. какой слой совпадает с ESP? --------------------------------------
emit("=" * 76)
emit("A. СВЕРКА СЛОЁВ ПО 562 PERK ЭТАЛОНА (main ESP)")
emit("=" * 76)
main_perks = {(f, i): fs for (f, i), fs in by_rec.items() if f == "main"}
full_same = full_diff = 0
desc_same = desc_diff = 0
desc_diff_case = []
full_diff_list = []
for formid, r in v149_by.items():
    fs = main_perks.get(("main", formid))
    if not fs:
        continue
    full, desc = join_perk(fs)
    if full == r.get("full"):
        full_same += 1
    else:
        full_diff += 1
        full_diff_list.append((formid, r.get("full"), full))
    if desc == r.get("desc"):
        desc_same += 1
    else:
        desc_diff += 1

# desc_ru: сопоставление EDID
dru_by_edid = {}
for formid, r in v149_by.items():
    dru_by_edid[r["edid"]] = formid
dru_same = dru_diff = 0
dru_diff_case = []
for (f, formid), fs in main_perks.items():
    full, desc = join_perk(fs)
    edid = next((r["edid"] for r in v149 if r["formid"] == formid), None)
    if edid and edid in desc_ru:
        if desc == desc_ru[edid]:
            dru_same += 1
        else:
            dru_diff += 1
            sig = lambda t: tuple((h[0], h[0][0].isupper()) for h in toks(t))
            if edid in v149_by and sig(desc_ru[edid]) != sig(desc):
                dru_diff_case.append((edid, desc, desc_ru[edid]))

emit(f"ESP full == эталон v149: {full_same}; != : {full_diff}")
emit(f"ESP desc == эталон v149: {desc_same}; != : {desc_diff}")
emit(f"ESP desc == desc_ru.py:  {dru_same}; != : {dru_diff} (из них расхождение РЕГИСТРА: {len(dru_diff_case)})")

# --- B. регистр в настоящем ESP ------------------------------------------
emit()
emit("=" * 76)
emit("B. РЕГИСТР В ИМЕНАХ ПЕРКОВ (все ESP, main + CC)")
emit("=" * 76)
midcap = []
for (f, formid), fs in by_rec.items():
    full, _ = join_perk(fs)
    if not full:
        continue
    tks = full.split()
    for i, t in enumerate(tks[1:], 1):
        core = t.strip("«»(),.!?…0-9%")
        if re.fullmatch(r"[А-ЯЁ][а-яё-]*|[А-ЯЁ]{2,}", core) and not tks[i-1].endswith(":"):
            midcap.append((f, formid, full, core))
emit(f"FULL с прописной не на 1-й позиции (не после двоеточия): {len(midcap)}")
for f, formid, full, core in midcap:
    emit(f"  [{f}] {formid}  {full}   <- {core}")

emit()
emit("--- лейбл-значения «X: Y» со строчной после двоеточия:")
n_ok = n_bad = 0
for (f, formid), fs in by_rec.items():
    full, _ = join_perk(fs)
    if not full:
        continue
    mo = re.search(r":\s*(\S+)", full)
    if mo and mo.group(1)[:1].isalpha() and not mo.group(1)[:1].isupper():
        n_bad += 1
        emit(f"  [{f}] {formid}  {full}")
    elif mo:
        n_ok += 1
emit(f"  итог: с прописной {n_ok} (норма), со строчной {n_bad}.")

# --- C. регистр навыков/школ в DESC истины -------------------------------
emit()
emit("=" * 76)
emit("C. НАВЫКИ/ШКОЛЫ В DESC ИСТИНЫ (main, все строчные вхождения)")
emit("=" * 76)
low = defaultdict(list)
up = Counter()
for (f, formid), fs in by_rec.items():
    if f != "main":
        continue
    _, desc = join_perk(fs)
    if not desc:
        continue
    for w, frag in toks(desc):
        if w[0].isupper():
            up[w.lower()] += 1
        else:
            low[w.lower()].append((formid, frag))
emit(f"с прописной: {sum(up.values())} — " + ", ".join(f"{k}×{n}" for k, n in sorted(up.items(), key=lambda x: -x[1])))
emit(f"со строчной: {sum(len(v) for v in low.values())}")
for tok in sorted(low, key=lambda k: -len(low[k])):
    emit(f"  [{tok}] — {len(low[tok])} шт.")
    for formid, frag in low[tok]:
        emit(f"     {formid} | …{frag}…")

# --- D. фокус: «изменени*» в PERK-текстах истины -------------------------
emit()
emit("=" * 76)
emit("D. ФОКУС «изменени*» + ветка Изменения в ИСТИНЕ")
emit("=" * 76)
for (f, formid), fs in by_rec.items():
    if f != "main":
        continue
    full, desc = join_perk(fs)
    blob = full + " " + desc
    if re.search("изменени", blob, re.I):
        for mo in re.finditer("изменени", blob, re.I):
            w = mo.group(0)
            a, b = max(0, mo.start() - 60), min(len(blob), mo.end() + 60)
            emit(f"  [{'ПРОПИС' if w[0].isupper() else 'строчн'}] {formid} ({full[:24]}) | …{blob[a:b]}…")

# в CC-патчах тоже
emit("--- в CC-патчах:")
n_cc = 0
for (f, formid), fs in by_rec.items():
    if f == "main" or not f.startswith("cc:"):
        continue
    full, desc = join_perk(fs)
    blob = full + " " + desc
    for mo in re.finditer("изменени", blob, re.I):
        w = mo.group(0)
        a, b = max(0, mo.start() - 60), min(len(blob), mo.end() + 60)
        n_cc += 1
        emit(f"  [{'ПРОПИС' if w[0].isupper() else 'строчн'}] [{f}] {formid} | …{blob[a:b]}…")
if n_cc == 0:
    emit("  (пусто)")

# --- E. поле FULL «GRIM: …» — источник и EN -------------------------------
emit()
emit("=" * 76)
emit("E. ЛЕЙБЛ «GRIM: …» — где живет и что в EN")
emit("=" * 76)
en14 = json.loads((ROOT / "handoff/05_стринги_ESP/v14_en.json").read_text(encoding="utf-8"))
en_full = {}
for rec in en14.get("records", []):
    s = rec.get("s") or {}
    if rec.get("t") == "PERK" and isinstance(s.get("FULL"), list) and s["FULL"]:
        en_full[rec.get("fid", "").upper().zfill(8)] = s["FULL"][0]
for (f, formid), fs in by_rec.items():
    full, _ = join_perk(fs)
    if full.startswith("GRIM") or "GRIM:" in full:
        emit(f"  [{f}] {formid}  {full}  | EN 1.4: {en_full.get(formid, 'нет в базе 1.4 (поле из базы 1.5?)')}")

OUT.write_text("\n".join(out), encoding="utf-8")
print(f"отчёт: {OUT} ({len(out)} строк)")
