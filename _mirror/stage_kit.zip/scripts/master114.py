#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 114 (v1.5.15): вердикт игрока по 111-б — MESG «под талмора.» →
«под талморца.» (06060EA0), вин. одуш. как во всей серии маскировок.

Источник: user zip «Paths of Empyrean RU 1.5 (6).zip» = байт-в-байт наш
v1.5.14 (63/63 CRC). Приемник: work/qa114/v115.
Машина ESP байт-в-байт как в master113.
"""
import struct, zlib, os, json, zipfile

SRC_ZIP = '/home/z/my-project/upload/Paths of Empyrean RU 1.5 (6).zip'
DST = '/home/z/my-project/work/qa114/v115/00 Core/PathsOfEmpyrean.esp'
FIX = '/home/z/my-project/work/qa114/fixlist_v115.jsonl'

REC_HDR = 24


class Node:
    __slots__ = ('kind', 'label', 'tail', 'formid', 'data', 'children')


def parse(buf):
    root = []

    def walk(off, end, out):
        while off < end:
            t = buf[off:off+4]
            size = struct.unpack_from('<I', buf, off+4)[0]
            if t == b'GRUP':
                node = Node()
                node.kind = 'grup'
                node.tail = bytes(buf[off+8:off+24])
                node.children = []
                walk(off + REC_HDR, off + size, node.children)
                out.append(node)
                off += size
            else:
                node = Node()
                node.kind = 'rec'
                node.label = t
                node.tail = bytes(buf[off+8:off+24])
                node.formid = struct.unpack_from('<I', buf, off+12)[0]
                node.data = bytes(buf[off+REC_HDR:off+REC_HDR+size])
                out.append(node)
                off += REC_HDR + size
    walk(0, len(buf), root)
    return root


def serialize_node(n, parts):
    if n.kind == 'grup':
        sub = []
        for c in n.children:
            serialize_node(c, sub)
        s = b''.join(sub)
        parts.append(b'GRUP' + struct.pack('<I', 24 + len(s)) + n.tail)
        parts.append(s)
    else:
        parts.append(n.label + struct.pack('<I', len(n.data)) + n.tail)
        parts.append(n.data)


def find_rec(nodes, formid):
    for n in nodes:
        if n.kind == 'grup':
            r = find_rec(n.children, formid)
            if r is not None:
                return r
        elif n.formid == formid:
            return n
    return None


def rec_flags(rec):
    return struct.unpack_from('<I', rec.tail, 0)[0]


def decode_body(rec):
    if rec_flags(rec) & 0x00040000:
        usz = struct.unpack_from('<I', rec.data, 0)[0]
        dec = zlib.decompress(rec.data[4:])
        assert len(dec) == usz
        return bytearray(dec), True
    return bytearray(rec.data), False


def encode_body(body, was_c):
    if was_c:
        return struct.pack('<I', len(body)) + zlib.compress(bytes(body))
    return bytes(body)


def main():
    esp_patches = []
    for line in open(FIX, encoding='utf-8'):
        r = json.loads(line)
        assert r['kind'] == 'esp' and r['scope'] == 'main', r
        esp_patches.append((int(r['formid'], 16), r['field'], r['occ'], r['old'], r['new']))
    assert len(esp_patches) == 1, len(esp_patches)
    with zipfile.ZipFile(SRC_ZIP) as z:
        info = z.read('fomod/info.xml').decode('utf-8')
        assert '<Version>1.5.14</Version>' in info, 'база не v1.5.14!'
        esp_src = z.read('00 Core/PathsOfEmpyrean.esp')
    print(f'база: user zip (6) = v1.5.14, ESP {len(esp_src)} Б')

    buf = esp_src
    root = parse(buf)
    out = []
    for n in root:
        serialize_node(n, out)
    assert b''.join(out) == buf, 'САМОТЕСТ ПРОВАЛЕН'
    print(f'  самотест OK ({len(buf)} Б)')
    applied = 0
    for formid, field, occ, old, new in esp_patches:
        rec = find_rec(root, formid)
        assert rec is not None, f'{formid:08X} не найдена'
        body, was_c = decode_body(rec)
        off, seen, done = 0, 0, False
        while off < len(body):
            if off + 6 > len(body):
                break
            st = body[off:off+4].decode('ascii', 'replace')
            ssz = struct.unpack_from('<H', body, off+4)[0]
            if st == 'XXXX':
                real = struct.unpack_from('<I', body, off+6)[0]
                off += 6 + ssz + 6 + real
                continue
            cur_sz = ssz
            if st == field:
                seen += 1
                cur = bytes(body[off+6:off+6+ssz]).rstrip(b'\x00').decode('utf-8', 'replace')
                if seen == occ:
                    assert cur == old, f'{formid:08X} {field}#{occ}: {cur[:80]!r} != {old[:80]!r}'
                    newb = new.encode('utf-8') + b'\x00'
                    body[off+6:off+6+ssz] = newb
                    struct.pack_into('<H', body, off+4, len(newb))
                    done = True
                    applied += 1
                    cur_sz = len(newb)
            off += 6 + cur_sz
        assert done, f'{formid:08X} {field}#{occ} не применён'
        rec.data = encode_body(body, was_c)
    out = []
    for n in root:
        serialize_node(n, out)
    os.makedirs(os.path.dirname(DST), exist_ok=True)
    open(DST, 'wb').write(b''.join(out))
    print(f'  -> {DST} ({os.path.getsize(DST)} Б), патчей: {applied}')
    assert applied == 1
    import hashlib
    print('md5 ESP v1.5.15:', hashlib.md5(open(DST, 'rb').read()).hexdigest())


if __name__ == '__main__':
    main()
