#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 118: разведка #4 — точечные кандидаты + магия/свитки/GMST/ShortbowNames."""
import json
from collections import defaultdict, Counter

A = json.load(open('/home/z/my-project/work/qa118/aligned.json', encoding='utf-8'))

print('=== 1. Masterwork-записи, где RU не начинается с Мастерск- ===')
for r in A:
    if r['rtype'] in ('WEAP', 'ARMO') and r['field'] == 'FULL' and r['en_text'] and 'Masterwork' in r['en_text']:
        if not r['ru_text'].startswith(('Мастерск')):
            print(f"  [{r['file']} {r['formid']}] {r['edid'][:44]:44} EN: {r['en_text'][:50]:50} RU: {r['ru_text'][:60]}")

print('\n=== 2. Dwarven WEAP -> RU начинается с Арбалет ===')
for r in A:
    if r['rtype'] == 'WEAP' and r['field'] == 'FULL' and r['en_text'] and r['en_text'].startswith('Dwarven'):
        if r['ru_text'].startswith(('Арбалет', 'Длинный', 'Лук')):
            print(f"  [{r['file']} {r['formid']}] {r['edid'][:44]:44} EN: {r['en_text'][:50]:50} RU: {r['ru_text'][:60]}")

print('\n=== 3. Mystic-яды: лестница ===')
for r in A:
    if r['rtype'] == 'ALCH' and r['field'] == 'FULL' and r['en_text'] and 'Mystic' in r['en_text']:
        print(f"  [{r['file']} {r['formid']}] {r['edid'][:40]:40} EN: {r['en_text'][:44]:44} RU: {r['ru_text'][:60]}")

print('\n=== 4. GMST истины v1.5.18 (все) ===')
for r in A:
    if r['rtype'] == 'GMST':
        print(f"  {r['formid']} {r['edid'][:30]:30} RU: {r['ru_text'][:50]:50} EN: {str(r['en_text'])[:40]}")

print('\n=== 5. SCRL FULL EN первые слова ===')
c = Counter()
for r in A:
    if r['rtype'] == 'SCRL' and r['field'] == 'FULL' and r['en_text']:
        w = r['en_text'].split()
        c[w[0] + (' ' + w[1] if len(w) > 1 and w[1].lower() in ('of', 'tome', 'the') else '')] += 1
for k, n in c.most_common(40):
    print(f'  {k}: {n}')

print('\n=== 6. SLGM (камни душ) ===')
for r in A:
    if r['rtype'] == 'SLGM' and r['field'] == 'FULL':
        print(f"  [{r['file']}] {r['edid'][:32]:32} RU: {r['ru_text'][:40]:40} EN: {str(r['en_text'])[:40]}")

print('\n=== 7. AMMO первые слова ===')
c = Counter()
for r in A:
    if r['rtype'] == 'AMMO' and r['field'] == 'FULL' and r['en_text']:
        w = r['en_text'].split()
        c[w[0]] += 1
for k, n in c.most_common(30):
    print(f'  {k}: {n}')
