#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 119: сборка fixlist_v119.jsonl из одобренного игроком проекта 118.

Вердикт игрока (07.11.2026): «согласен со всеми пунктами + 118-е. Делай» —
приняты 118-а (24), 118-б (5), 118-в (7), 118-г (6) = 42 поля проекта
work/qa118/fixlist_project_118.jsonl ПЛЮС 118-е (порядок слов составных имён
PoE-вариантов: «нордского героя»/«Соловья») — 16 полей ESP + 6 строк
ShortbowNames.ini (2 замены). 118-д (унификация кузнечной лестницы перков)
БЕЗ явных целевых имён НЕ утверждён — эталон v150 не трогаем (правило 92–94).

Целевые имена 118-е собраны по доктрине 111 из офиц. баз:
  Nord Hero Bow «Нордский лук героя» skyrim#41664; Sword #7829; War Axe #51282;
  Battle Axe (секира) #7958; Greatsword «Нордский двуручный меч героя» #62917
  (PoE-корпус Masterwork-гроссмессеров «двуручник» ×13 — термин семьи сохранён,
  исправлен только порядок слов); Arrow «Нордская стрела героя» #65494;
  CC Fishing: Warhammer ccbgssse001-fish#898, Mace #903, Dagger #904;
  Nightingale Bow «Соловьиный лук» skyrim#55238. Паттерны соседей:
  «Двемерский длинный лук»/«Мастерский двемерский длинный лук» (_L, _L_M),
  «Нордский короткий лук изгнания» (ShortbowNames DLC2Nordic),
  «Древний нордский короткий лук» (прил. + «короткий лук»).
Не тронуты: «Нордское копье героя»/«Мастерское нордское копье героя» (sp — уже
верный порядок), «Короткий лук Карлии» (EN "Karliah's Shortbow" — отдельное
имя автора, не семья), possessive-имена («лук Анги/Фроки/Ауриэля»).

Каждое old сверяется байт-в-байт с дампом истины v1.5.18
(work/qa117/dump_v118_full.jsonl) и с INI (распаковка аплоада work/ru118).
Выход: work/qa119/fixlist_v119.jsonl (58 esp + 2 ini).
"""
import io, json, os

DUMP = '/home/z/my-project/work/qa117/dump_v118_full.jsonl'
PROJ = '/home/z/my-project/work/qa118/fixlist_project_118.jsonl'
INI = ('/home/z/my-project/work/ru118/00 Core/SKSE/Plugins/POE/Weapon/'
       'PathsOfEmpyrean_ShortbowNames.ini')
OUT = '/home/z/my-project/work/qa119/fixlist_v119.jsonl'

E_WHY_BASE = ('118-е (вердикт игрока «+118-е»): порядок слов составного имени '
              'PoE-варианта выровнен по офиц. базе')
E_WHY_NIGHT = ('118-е: офиц. база Nightingale Bow = «Соловьиный лук» '
               '(skyrim#55238); паттерн соседей «Эбонитовый длинный лук»')
E_WHY_INI = ('118-е: DLL-слой переименования коротких луков (EDID-фильтр, '
             'fullName = целевое имя; механика = правка 111 в том же слое)')


def main():
    dump = {}
    for line in io.open(DUMP, encoding='utf-8'):
        r = json.loads(line)
        dump[(r['file'], r['formid'], r['rtype'], r['field'],
              r.get('occ', 1))] = r['text']
    print(f'дамп истины v1.5.18: {len(dump)} ключей')

    out = []
    # --- 42 поля одобренного проекта (118-а/б/в/г) ---
    for line in io.open(PROJ, encoding='utf-8'):
        r = json.loads(line)
        key = (r['file'], r['formid'], r['rtype'], r['field'], r['occ'])
        cur = dump.get(key)
        assert cur == r['old'], f'old не совпал с дампом: {key}: {cur!r}'
        out.append({'kind': 'esp', 'project': r['project'], 'file': r['file'],
                    'formid': r['formid'], 'rtype': r['rtype'],
                    'field': r['field'], 'occ': r['occ'], 'edid': r['edid'],
                    'old': r['old'], 'new': r['new'], 'why': r['why']})
    print(f'проект 118 (а/б/в/г): {len(out)} полей, old сверены байт-в-байт')

    # --- 118-е: 16 полей ESP ---
    e_esp = [
        # Nord Hero: Masterwork-семья main (офиц. базы + «Мастерский/ая»)
        ('main', '0608A199', 'WEAP', 'NordHeroBow_M',
         'Мастерский лук нордского героя', 'Мастерский нордский лук героя',
         f'{E_WHY_BASE} «Нордский лук героя» (skyrim#41664)'),
        ('main', '0608A1E3', 'WEAP', 'NordHeroWarAxe_M',
         'Мастерский боевой топор нордского героя',
         'Мастерский нордский боевой топор героя',
         f'{E_WHY_BASE} «Нордский боевой топор героя» (skyrim#51282)'),
        ('main', '0608A1E8', 'WEAP', 'NordHeroSword_M',
         'Мастерский меч нордского героя', 'Мастерский нордский меч героя',
         f'{E_WHY_BASE} «Нордский меч героя» (skyrim#7829)'),
        ('main', '0608A1ED', 'WEAP', 'NordHeroGreatsword_M',
         'Мастерский двуручник нордского героя',
         'Мастерский нордский двуручник героя',
         f'{E_WHY_BASE} «Нордский двуручный меч героя» (skyrim#62917); '
         'термин PoE-семьи Masterwork-гроссмессеров «двуручник» (×13 в корпусе) '
         'сохранён — исправлен только порядок слов'),
        ('main', '0608A1F2', 'WEAP', 'NordHeroBattleAxe_M',
         'Мастерская секира нордского героя', 'Мастерская нордская секира героя',
         f'{E_WHY_BASE} «Нордская секира героя» (skyrim#7958)'),
        # Nord Hero: длинные луки (EN "Nord Hero Longbow"/"Masterwork … Longbow")
        ('main', '062D4161', 'WEAP', 'NordHeroBow_L',
         'Длинный лук нордского героя', 'Нордский длинный лук героя',
         f'{E_WHY_BASE} «Нордский лук героя»; паттерн соседей '
         '«Двемерский длинный лук» (DwarvenBow_L)'),
        ('main', '062D4166', 'WEAP', 'NordHeroBow_L_M',
         'Мастерский длинный лук нордского героя',
         'Мастерский нордский длинный лук героя',
         f'{E_WHY_BASE} «Нордский лук героя»; паттерн соседей '
         '«Мастерский двемерский длинный лук» (DwarvenBow_L_M)'),
        # Nightingale: длинные луки ×5 (EN-источника 1.4 нет — база 1.5 автора)
        ('main', '0656C13F', 'WEAP', 'NightingaleBow01_L',
         'Длинный лук Соловья', 'Соловьиный длинный лук', E_WHY_NIGHT),
        ('main', '0656C141', 'WEAP', 'NightingaleBow02_L',
         'Длинный лук Соловья', 'Соловьиный длинный лук', E_WHY_NIGHT),
        ('main', '0656C143', 'WEAP', 'NightingaleBow03_L',
         'Длинный лук Соловья', 'Соловьиный длинный лук', E_WHY_NIGHT),
        ('main', '0656C145', 'WEAP', 'NightingaleBow04_L',
         'Длинный лук Соловья', 'Соловьиный длинный лук', E_WHY_NIGHT),
        ('main', '0656C147', 'WEAP', 'NightingaleBow05_L',
         'Длинный лук Соловья', 'Соловьиный длинный лук', E_WHY_NIGHT),
        # Жетон Lucky-стрелы (паритет с 118-г: AMMO/PROJ уже чинятся,
        # жетоны Sunhallowed/Bloodcursed уже по офиц. базам)
        ('main', '06193D34', 'MISC', 'PoE_MISC_LuckyArrowToken_NordHeroArrow',
         'Счастливая стрела нордского героя (жетон)',
         'Счастливая нордская стрела героя (жетон)',
         '118-е/г: жетон Lucky-стрелы выровнен с парой AMMO 06193D32 + PROJ '
         '06193D33 (118-г → «Счастливая нордская стрела героя»); жетоны '
         'Sunhallowed/Bloodcursed (06193D43/06193D40) уже по офиц. базам'),
        # CC Fishing: Nord Hero Dagger/Mace/Warhammer (офиц. базы CC)
        ('cc:Fishing', '0500088E', 'WEAP', 'PoE_ccBGSSSE001_NordHeroDagger_M',
         'Мастерский кинжал нордского героя', 'Мастерский нордский кинжал героя',
         f'{E_WHY_BASE} «Нордский кинжал героя» (ccbgssse001-fish#904)'),
        ('cc:Fishing', '05000893', 'WEAP', 'PoE_ccBGSSSE001_NordHeroMace_M',
         'Мастерская булава нордского героя', 'Мастерская нордская булава героя',
         f'{E_WHY_BASE} «Нордская булава героя» (ccbgssse001-fish#903)'),
        ('cc:Fishing', '05000898', 'WEAP',
         'PoE_ccBGSSSE001_NordHeroWarhammer_M',
         'Мастерский боевой молот нордского героя',
         'Мастерский нордский боевой молот героя',
         f'{E_WHY_BASE} «Нордский боевой молот героя» (ccbgssse001-fish#898)'),
    ]
    for file_, fid, rtype, edid, old, new, why in e_esp:
        key = (file_, fid, rtype, 'FULL', 1)
        cur = dump.get(key)
        assert cur == old, f'118-е old не совпал с дампом: {key}: {cur!r}'
        out.append({'kind': 'esp', 'project': '118-е', 'file': file_,
                    'formid': fid, 'rtype': rtype, 'field': 'FULL', 'occ': 1,
                    'edid': edid, 'old': old, 'new': new, 'why': why})
    print(f'118-е ESP: {len(e_esp)} полей, old сверены байт-в-байт')

    # --- 118-е: 2 замены в ShortbowNames.ini (6 строк) ---
    raw = open(INI, 'rb').read()
    ini_fixes = [
        ('00 Core/SKSE/Plugins/POE/Weapon/PathsOfEmpyrean_ShortbowNames.ini',
         'fullName=~Короткий лук нордского героя~',
         'fullName=~Нордский короткий лук героя~', 1,
         f'{E_WHY_INI}; офиц. база «Нордский лук героя» + паттерн соседей '
         '«Нордский короткий лук изгнания» (DLC2EnchNordicBow*)'),
        ('00 Core/SKSE/Plugins/POE/Weapon/PathsOfEmpyrean_ShortbowNames.ini',
         'fullName=~Короткий лук Соловья~',
         'fullName=~Соловьиный короткий лук~', 5,
         f'{E_WHY_INI}; офиц. база «Соловьиный лук» + паттерн «прил. + '
         'короткий лук» («Древний нордский короткий лук», «Орочий короткий '
         'лук»); ×5 строк NightingaleBow01–05; «Короткий лук Карлии» '
         '(EN "Karliah\'s Shortbow") — отдельное имя автора, не трогается'),
    ]
    for scope, old, new, expect, why in ini_fixes:
        n = raw.count(old.encode('utf-8'))
        assert n == expect, f'INI: {old!r}: ожидалось {expect}, найдено {n}'
        assert raw.count(new.encode('utf-8')) == 0
        out.append({'kind': 'ini', 'project': '118-е', 'scope': scope,
                    'old': old, 'new': new, 'expect': expect, 'why': why})
    print('118-е INI: 2 замены (1 + 5 строк), вхождения сверены')

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with io.open(OUT, 'w', encoding='utf-8') as f:
        for r in out:
            f.write(json.dumps(r, ensure_ascii=False) + '\n')
    n_esp = sum(1 for r in out if r['kind'] == 'esp')
    n_ini = sum(1 for r in out if r['kind'] == 'ini')
    by_proj = {}
    for r in out:
        by_proj[r['project']] = by_proj.get(r['project'], 0) + 1
    print(f'ИТОГО: {len(out)} записей (esp {n_esp} + ini {n_ini}); '
          f'по проектам: {by_proj}')
    print(f'выход: {OUT}')


if __name__ == '__main__':
    main()
