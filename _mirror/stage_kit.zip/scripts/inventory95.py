#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 95: инвентаризация контента PoE v1.5.6 — что мод содержит и что меняет в ванили.
Анализ: состав записей по типам, новые записи vs правки мастеров (по formid), GMST, деревья перков.
"""
import sys, json, re, struct
from collections import defaultdict

sys.path.insert(0, '/home/z/my-project/upload/poe_pack/scripts')
from parse_tes4 import Plugin

BASE = '/home/z/my-project/work/v156'
FILES = [
    ('Core', f'{BASE}/00 Core/PathsOfEmpyrean.esp'),
    ('Spears', f'{BASE}/20 Spears/PoE-Addon-Spears.esp'),
    ('MissingShields', f'{BASE}/10 Missing Shields/PoE-Addon-MissingShields.esp'),
]

def idx_master(formid, masters):
    idx = formid >> 24
    if idx < len(masters):
        return 'override'
    return 'new'

for name, path in FILES:
    p = Plugin(path)
    print('=' * 100)
    print(f'### {name}: {path.split("/")[-1]}')
    print(f'masters ({len(p.masters)}): {p.masters}')
    total = sum(len(v) for v in p.by_type.values())
    print(f'всего записей: {total}')
    counts = sorted(((k, len(v)) for k, v in p.by_type.items()), key=lambda x: -x[1])
    print('по типам:', ', '.join(f'{k}={v}' for k, v in counts))
    split = defaultdict(lambda: defaultdict(int))
    for rtype, fids in p.by_type.items():
        for fid in fids:
            split[rtype][idx_master(fid, p.masters)] += 1
    print(f"{'тип':8} {'всего':>6} {'новых':>6} {'правок':>6}")
    for t, _ in counts:
        s = split[t]
        if s['override'] > 0 or t in ('PERK', 'SPEL', 'MGEF', 'WEAP', 'ARMO', 'ENCH', 'GMST', 'NPC_', 'RACE', 'LVLI', 'FLST', 'KYWD', 'BOOK', 'SCRL', 'ALCH', 'MISC', 'AMMO'):
            print(f'{t:8} {len(p.by_type[t]):>6} {s["new"]:>6} {s["override"]:>6}')
    per_master = defaultdict(int)
    for rtype, fids in p.by_type.items():
        for fid in fids:
            if idx_master(fid, p.masters) == 'override':
                per_master[p.masters[fid >> 24]] += 1
    print('правки по мастерам:', dict(sorted(per_master.items(), key=lambda x: -x[1])))

# ============ Core: детали ============
print('=' * 100)
p = Plugin(FILES[0][1])

gmsts = [p.records[f]['edid'] for f in p.by_type.get('GMST', [])]
print('### GMST (игровые настройки):', len(gmsts))
print(', '.join(gmsts))

perk_fulls = [p.records[f]['full'] for f in p.by_type.get('PERK', []) if p.records[f]['full']]
print()
print('### PERK всего:', len(p.by_type.get('PERK', [])), '| с FULL:', len(perk_fulls))
series = defaultdict(int)
for f in perk_fulls:
    m = re.match(r'^([А-ЯA-ZЁ][а-яa-zё]+(?: [А-ЯA-ZЁ][а-яa-zё]+)?): ', f)
    if m:
        series[m.group(1)] += 1
print('серии имён перков (префикс «X: …»):')
for k, v in sorted(series.items(), key=lambda x: -x[1]):
    print(f'  {k}: {v}')

spit_names = {0: 'заклинание', 2: 'сила', 3: 'низшая сила', 4: 'способность'}
spit_cnt = defaultdict(int)
for fid in p.by_type.get('SPEL', []):
    r = p.records[fid]
    sp = next((struct.unpack_from('<i', sd)[0] for st, sd in r['subs'] if st == 'SPIT'), None)
    spit_cnt[spit_names.get(sp, f'type{sp}')] += 1
print()
print('### SPEL по типам:', dict(spit_cnt))

wt_names = {0: 'клинок 1H', 1: 'кинжал', 2: 'топор 1H', 3: 'булава 1H', 4: 'двуруч 2H', 5: 'посох', 6: 'лук', 7: 'молот 2H', 8: 'секира 2H', 9: 'арбалет', 10: 'кастет', 11: 'прочее'}
wt_cnt = defaultdict(int)
for fid in p.by_type.get('WEAP', []):
    r = p.records[fid]
    wt = None
    for st, sd in r['subs']:
        if st == 'DNAM' and len(sd) > 32:
            wt = struct.unpack_from('<B', sd, 32)[0]
            break
    wt_cnt[wt_names.get(wt, f'?{wt}')] += 1
print('### WEAP по типам:', dict(sorted(wt_cnt.items(), key=lambda x: -x[1])))

new_npc = [p.records[f] for f in p.by_type.get('NPC_', []) if (f >> 24) >= len(p.masters)]
print()
print('### NPC_ новых:', len(new_npc), '| правок ванильных:', len(p.by_type.get('NPC_', [])) - len(new_npc))

pref = defaultdict(int)
for fid, r in p.records.items():
    if (fid >> 24) >= len(p.masters) and r['edid']:
        pref[r['edid'].split('_')[0]] += 1
print('### EDID-префиксы новых записей (топ-30):')
for k, v in sorted(pref.items(), key=lambda x: -x[1])[:30]:
    print(f'  {k}: {v}')
