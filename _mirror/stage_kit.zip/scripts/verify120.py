#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 120: независимая верификация v1.5.20 (вердикт 112-а — «Разделять»).

1) Регресс zip: v1.5.20 vs реконструкция v1.5.19 (аплоад v1.5.18 + 4 файла
qa119/v119 + info.xml 1.5.19) — изменены ровно 2 записи (main ESP, info.xml);
2) побайтовый регресс main ESP: изменены ровно 2 формы (061A81DD, 06394B42),
   у каждой — ТОЛЬКО поле FULL (гейты CTDA/VMAD байт-в-байт);
3) dump-дифф v1.5.19 → v1.5.20: ровно 2 поля == fixlist_v120;
4) спот-чеки 112-а (новые имена, серия, соседи-«Драконий», scaled-серия,
   INI не тронут) + гигиена + FOMOD + zip.
"""
import struct, zlib, os, sys, json, zipfile, hashlib, io, glob
import xml.dom.minidom

sys.path.insert(0, '/home/z/my-project/scripts')
from dump150 import dump_esp

SRC_ZIP = '/home/z/my-project/upload/Paths of Empyrean RU 1.5 (10).zip'
V119_TREE = '/home/z/my-project/work/qa119/v119'
NEW = '/home/z/my-project/work/qa120/v120'
FIX = '/home/z/my-project/work/qa120/fixlist_v120.jsonl'
DL = '/home/z/my-project/download/Paths of Empyrean RU 1.5.zip'
DUMP_OLD = '/home/z/my-project/work/qa119/dump_v119_full.jsonl'
DUMP_NEW = '/home/z/my-project/work/qa120/dump_v120_full.jsonl'

MAIN = '00 Core/PathsOfEmpyrean.esp'
ECP = ('30 CC Patches/Expanded Crossbow Pack/'
       'PoE-CCExpandedCrossbowPack-Patch.esp')
FISH = '30 CC Patches/Fishing/PoE-CCFishing-Patch.esp'
INI_REL = ('00 Core/SKSE/Plugins/POE/Weapon/'
           'PathsOfEmpyrean_ShortbowNames.ini')

FAILED = []


def check(cond, msg):
    if cond:
        print(f'  ✓ {msg}')
    else:
        print(f'  ✗ {msg}')
        FAILED.append(msg)


class Node:
    __slots__ = ('kind', 'label', 'tail', 'formid', 'data', 'children')


def parse(buf):
    root = []

    def walk(off, end, out):
        while off < end:
            t = buf[off:off+4]
            size = struct.unpack_from('<I', buf, off+4)[0]
            if t == b'GRUP':
                node = Node()
                node.kind = 'grup'
                node.label = None
                node.tail = bytes(buf[off+8:off+24])
                node.children = []
                walk(off + 24, off + size, node.children)
                out.append(node)
                off += size
            else:
                node = Node()
                node.kind = 'rec'
                node.label = t
                node.tail = bytes(buf[off+8:off+24])
                node.formid = struct.unpack_from('<I', buf, off+12)[0]
                node.data = bytes(buf[off+24:off+24+size])
                out.append(node)
                off += 24 + size
    walk(0, len(buf), root)
    return root


def walk_recs(nodes):
    for n in nodes:
        if n.kind == 'grup':
            yield from walk_recs(n.children)
        else:
            yield n


def subrecords(rec):
    body = rec.data
    if struct.unpack_from('<I', rec.tail, 0)[0] & 0x00040000:
        usz = struct.unpack_from('<I', body, 0)[0]
        body = zlib.decompress(body[4:])
        assert len(body) == usz
    out = []
    off = 0
    while off < len(body):
        st = body[off:off+4].decode('ascii', 'replace')
        ssz = struct.unpack_from('<H', body, off+4)[0]
        out.append((st, bytes(body[off+6:off+6+ssz])))
        if st == 'XXXX':
            real = struct.unpack_from('<I', body, off+6)[0]
            off += 6 + ssz + 6 + real
            continue
        off += 6 + ssz
    return out


def main():
    fixes = [json.loads(l) for l in io.open(FIX, encoding='utf-8')]
    assert len(fixes) == 2 and all(f['kind'] == 'esp' for f in fixes)
    patch_ids = {int(f['formid'], 16) for f in fixes}

    print('=== 1) Регресс zip: v1.5.20 vs реконструкция v1.5.19 ===')
    with zipfile.ZipFile(SRC_ZIP) as z:
        old_names = set(z.namelist())
        base_bytes = {n: z.read(n) for n in old_names}
    # реконструкция v1.5.19: 4 файла qa119/v119 + info.xml с 1.5.19
    ref = dict(base_bytes)
    for rel in (MAIN, ECP, FISH, INI_REL):
        ref[rel] = open(f'{V119_TREE}/{rel}', 'rb').read()
    info_v119 = base_bytes['fomod/info.xml'].decode('utf-8')
    assert '<Version>1.5.18</Version>' in info_v119
    ref['fomod/info.xml'] = info_v119.replace(
        '<Version>1.5.18</Version>', '<Version>1.5.19</Version>').encode(
            'utf-8')
    check(hashlib.md5(ref[MAIN]).hexdigest()
          == '5014d127db81b3889d6b1bb512f34aca',
          'main ESP v1.5.19 (qa119/v119) = записи выпуска v1.5.19 '
          '(report_119 §10)')
    with zipfile.ZipFile(DL) as z:
        check(z.testzip() is None and set(z.namelist()) == old_names,
              'download zip: testzip OK, 63 записи, набор совпадает')
        new_bytes = {n: z.read(n) for n in old_names}
    diff = sorted(n for n in old_names
                  if hashlib.md5(new_bytes[n]).hexdigest()
                  != hashlib.md5(ref[n]).hexdigest())
    check(diff == sorted([MAIN, 'fomod/info.xml']),
          f'изменены ровно 2 записи (main ESP, info.xml), '
          f'остальные {len(old_names) - 2} байт-в-байт v1.5.19')
    info_v120 = new_bytes['fomod/info.xml'].decode('utf-8')
    check('<Version>1.5.20</Version>' in info_v120
          and '1.5.19' not in info_v120,
          'info.xml: 1.5.19 -> 1.5.20 (только версия)')
    for rel in (ECP, FISH, INI_REL):
        check(new_bytes[rel] == ref[rel],
              f'{os.path.basename(rel)} байт-в-байт v1.5.19 (не тронут)')

    print('=== 2) Побайтовый регресс main ESP (только 2 формы, только FULL) ===')
    old_root = parse(ref[MAIN])
    new_root = parse(new_bytes[MAIN])
    old_map = {r.formid: r for r in walk_recs(old_root)}
    new_map = {r.formid: r for r in walk_recs(new_root)}
    check(len(old_map) == len(new_map) == 17017,
          f'записей: {len(old_map)} == {len(new_map)} (17 017)')
    extra = []
    for fid, old_r in old_map.items():
        new_r = new_map.get(fid)
        if new_r is None:
            extra.append((fid, 'ИСЧЕЗЛА'))
        elif (old_r.data != new_r.data
              or old_r.tail[:4] != new_r.tail[:4]):
            if fid not in patch_ids:
                extra.append((fid, 'ПОСТОРОННЕЕ ИЗМЕНЕНИЕ'))
    check(not extra, f'посторонних изменений нет ({len(extra)})')
    for fid, why in extra[:10]:
        print(f'    ! {fid:08X} {why}')
    check(all(f in new_map for f in patch_ids),
          'обе patched-формы существуют')
    only_full = all(
        [(s, v) for s, v in subrecords(old_map[fid]) if s != 'FULL']
        == [(s, v) for s, v in subrecords(new_map[fid]) if s != 'FULL']
        for fid in patch_ids)
    check(only_full,
          'у обеих форм изменено ТОЛЬКО FULL '
          '(EDID/VMAD/CTDA-гейты байт-в-байт)')

    # гейты драконьих SPEL — печать для протокола
    for fid, want_kw in [(0x061A81DD, 'SF_K_MaterialMasteryDragonHeavy'),
                         (0x06394B42, 'SF_K_MaterialMasteryDragonLight')]:
        kws = set()
        for st, sd in subrecords(new_map[fid]):
            if st == 'CTDA' and len(sd) >= 16:
                kws.add(struct.unpack_from('<I', sd, 12)[0])
        print(f'    {fid:08X}: CTDA-ключей {len(kws)} '
              f'(0x{min(kws):08X}…) — гейт {want_kw} не тронут')

    print('=== 3) dump-дифф v1.5.19 -> v1.5.20 ===')
    if os.path.isfile(DUMP_NEW):
        os.remove(DUMP_NEW)
    with io.open(DUMP_NEW, 'w', encoding='utf-8') as out:
        jobs = [(f'{NEW}/00 Core/PathsOfEmpyrean.esp', 'main'),
                (f'{NEW}/10 Missing Shields/PoE-Addon-MissingShields.esp', 'ms'),
                (f'{NEW}/20 Spears/PoE-Addon-Spears.esp', 'sp')]
        for dp, _, fns in os.walk(f'{NEW}/30 CC Patches'):
            for fn in sorted(fns):
                if fn.lower().endswith('.esp'):
                    tag = 'cc:' + fn.replace('PoE-CC', '').replace(
                        '-Patch.esp', '')
                    jobs.append((os.path.join(dp, fn), tag))
        for path, tag in jobs:
            dump_esp(path, tag, out)
    fields = [json.loads(l) for l in io.open(DUMP_NEW, encoding='utf-8')]
    old_fields = [json.loads(l) for l in io.open(DUMP_OLD, encoding='utf-8')]
    check(len(fields) == 12338, f'полей: {len(fields)} (ожидается 12 338)')
    om = {(r['file'], r['formid'], r['rtype'], r['field'], r.get('occ', 1)):
          r['text'] for r in old_fields}
    nm = {(r['file'], r['formid'], r['rtype'], r['field'], r.get('occ', 1)):
          r['text'] for r in fields}
    removed = [k for k in om if k not in nm]
    added = [k for k in nm if k not in om]
    check(not removed, f'ключей пропало: {len(removed)}')
    check(not added, f'ключей добавилось: {len(added)}')
    expect = {(f['file'], f['formid'], f['rtype'], f['field'], f['occ']):
              (f['old'], f['new']) for f in fixes}
    changed_keys = [k for k in om if k in nm and om[k] != nm[k]]
    ok_changed = 0
    for k in changed_keys:
        exp = expect.get(k)
        if exp and om[k] == exp[0] and nm[k] == exp[1]:
            ok_changed += 1
        else:
            check(False, f'вне fixlist: {k}: {om[k]!r} -> {nm[k]!r}')
    check(ok_changed == 2 == len(changed_keys),
          f'изменённых полей ровно 2 == fixlist 120 ({ok_changed})')
    texts_new = [r['text'] for r in fields]
    texts_old = [r['text'] for r in old_fields]
    by_fid = {}
    for r in fields:
        by_fid.setdefault((r['file'], r['formid'], r['field']),
                          []).append(r['text'])

    print('=== 4) спот-чеки 112-а ===')
    for fid, want in [
        ('061A81DD', 'Железный человек - Драконий панцирный'),
        ('06394B42', 'Вторая кожа - Драконий чешуйчатый')]:
        got = by_fid.get(('main', fid, 'FULL'), [None])[0]
        check(got == want, f'SPEL {fid}: {got!r}')
    check(sum(t == 'Железный человек - Драконий' for t in texts_new) == 0
          and sum(t == 'Вторая кожа - Драконий' for t in texts_new) == 0,
          'слитой формы «- Драконий» = 0 (было ×2)')
    check(sum('Драконий панцирный' in t for t in texts_new) == 1
          and sum('Драконий чешуйчатый' in t for t in texts_new) == 1,
          'новые прилагательные ×1 каждое (только SPEL)')
    check(sum('панцирн' in t for t in texts_new)
          == sum('панцирн' in t for t in texts_old) + 1,
          '«панцирн»: +1 вхождение (SPEL), ARPO-серия не тронута')
    check(sum('чешуйчат' in t for t in texts_new)
          == sum('чешуйчат' in t for t in texts_old) + 1,
          '«чешуйчат»: +1 вхождение (SPEL), Dragonscale-серия не тронута')
    for fid, want in [
        ('0608A224', 'Мастерская драконья панцирная броня'),
        ('0608A2B5', 'Мастерская драконья чешуйчатая броня')]:
        got = by_fid.get(('main', fid, 'FULL'), [None])[0]
        check(got == want, f'ARMO {fid}: {got!r} (не тронута)')
    check(by_fid.get(('main', '051EEA79', 'FULL'), [None])[0]
          == 'Драконий огонь',
          'MGEF «Драконий огонь» (GRIM) не тронут')
    check(by_fid.get(('main', '06170538', 'FULL'), [None])[0]
          == 'Драконий костяной длинный лук',
          'WEAP «Драконий костяной длинный лук» не тронут')
    for fid, want in [
        ('06394B83', 'Железный человек - Ламеллярный'),
        ('06394B85', 'Вторая кожа - Ламеллярный')]:
        got = by_fid.get(('main', fid, 'FULL'), [None])[0]
        check(got == want, f'scaled-SPEL {fid}: {got!r} (не тронут)')
    for pref in ['Железный человек - ', 'Вторая кожа - ']:
        n_new = sum(t.startswith(pref) for t in texts_new)
        n_old = sum(t.startswith(pref) for t in texts_old)
        check(n_new == n_old,
              f'серия «{pref.rstrip(" - ")}…»: {n_new} == {n_old} '
              f'(ни один тир не потерян)')
    ini_new = new_bytes[INI_REL]
    check(ini_new == ref[INI_REL],
          'ShortbowNames.ini: байт-в-байт v1.5.19')

    print('=== 5) гигиена ===')
    for frag in ['%%', 'ё', '—']:
        check(sum(t.count(frag) for t in texts_new)
              == sum(t.count(frag) for t in texts_old) == 0,
              f'паритет «{frag}» = 0 (как в v1.5.19)')
    check(sum(t.count('«') for t in texts_new)
          == sum(t.count('»') for t in texts_new),
          'ёлочки сбалансированы')
    lone_new = sum(t.count('\n') - t.count('\r\n') for t in texts_new)
    lone_old = sum(t.count('\n') - t.count('\r\n') for t in texts_old)
    check(lone_new == lone_old, f'lone \\n: {lone_new} == {lone_old}')
    perk_desc = [r['text'] for r in fields
                 if r['rtype'] == 'PERK' and r['field'] == 'DESC']
    check(len(perk_desc) == 566 and max(map(len, perk_desc)) <= 290,
          f'PERK DESC: {len(perk_desc)} шт, max {max(map(len, perk_desc))} '
          f'<= 290')

    print('=== 6) FOMOD и zip ===')
    check(new_bytes['fomod/ModuleConfig.xml']
          == base_bytes['fomod/ModuleConfig.xml'],
          'ModuleConfig.xml байт-в-байт (изменений установщика нет)')
    for arc in ('fomod/ModuleConfig.xml', 'fomod/info.xml'):
        try:
            xml.dom.minidom.parseString(new_bytes[arc])
            ok = True
        except Exception:
            ok = False
        check(ok, f'{arc}: валидный XML')
    with zipfile.ZipFile(DL) as z:
        esps = [n for n in z.namelist() if n.endswith('.esp')]
        check(len(esps) == 39, f'ESP в пакете: {len(esps)} (39)')
        for img in ('ModImage1.png', 'PreviewSpears.jpg',
                    'PreviewMissingShields.png'):
            check(img in z.namelist(), f'превью {img} в корне архива')
        check(not any('eadme' in n for n in z.namelist()),
              'Readme в пакете нет')
        check('00 Core/PoE_RU_KID.ini' in z.namelist(),
              'PoE_RU_KID.ini в 00 Core')

    print('=== 7) итоговые md5 ===')
    print(f'  main ESP: {hashlib.md5(new_bytes[MAIN]).hexdigest()} '
          f'({len(new_bytes[MAIN])} Б)')
    print(f'  пакет v1.5.20: '
          f'{hashlib.md5(open(DL, "rb").read()).hexdigest()}')

    print()
    if FAILED:
        print(f'ПРОВАЛОВ: {len(FAILED)}')
        for m in FAILED:
            print(f'  - {m}')
        sys.exit(1)
    print('ВСЕ ПРОВЕРКИ ПРОЙДЕНЫ')


if __name__ == '__main__':
    main()
