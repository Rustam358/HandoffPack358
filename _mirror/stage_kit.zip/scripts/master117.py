#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 117 (v1.5.18): вердикт 116-а — регистр серии MGEF FULL «Маскировка - …»
стандартизирован по вердикту 115-а (имена фракций с заглавной).

13 строковых патча MGEF/FULL в main ESP (fixlist_v118.jsonl):
  9 оригиналов (0602456F/74/75/76, 06060E75/8E/9B/A1/A7) + 4 клона 115
  (065D69DC/DE/DF/E0). Уже с заглавной (не тронуты): «- Стража Рассвета»
  (06024561), «- Изгоя» (06060E87), «- Брата Бури» (06060E95 + клон 065D69DD).
Скан имени-зависимых слоёв ([98]): KID-правила маскировок — EDID/формид-маски,
SkyPatcher/MCM/DESC.ini/RUSSIAN.txt — «Маскировка» не упоминают → регистр FULL
безопасен. Серии MGEF FULL с прочими RU-префиксами — родовые существительные
(строчные корректны) — не входят в вердикт.

База: НЕТ аплоада игрока в этом заходе — истина = наш релиз v1.5.17
(download-пакет, md5 344e699a76f44d3c6bd69c0870dbcab4, main ESP
fc18932bb4c059c8b2881e7d07c639dd). Снапшот базы: work/qa117/base_v117.zip.
Приёмник: work/qa117/v118 (свежая распаковка).
"""
import struct, zlib, os, json, zipfile, hashlib, shutil

DL = '/home/z/my-project/download/Paths of Empyrean RU 1.5.zip'
BASE_SNAP = '/home/z/my-project/work/qa117/base_v117.zip'
V117_ZIP_MD5 = '344e699a76f44d3c6bd69c0870dbcab4'
V117_ESP_MD5 = 'fc18932bb4c059c8b2881e7d07c639dd'
DST = '/home/z/my-project/work/qa117/v118'
FIX = '/home/z/my-project/work/qa117/fixlist_v118.jsonl'
MAIN = '00 Core/PathsOfEmpyrean.esp'

REC_HDR = 24


class Node:
    __slots__ = ('kind', 'label', 'tail', 'formid', 'data', 'children')


def parse(buf):
    root = []

    def walk(off, end, out):
        while off < end:
            t = buf[off:off+4]
            size = struct.unpack_from('<I', buf, off+4)[0]
            if t == b'GRUP':
                node = Node()
                node.kind = 'grup'
                node.label = None
                node.tail = bytes(buf[off+8:off+24])
                node.children = []
                walk(off + REC_HDR, off + size, node.children)
                out.append(node)
                off += size
            else:
                node = Node()
                node.kind = 'rec'
                node.label = t
                node.tail = bytes(buf[off+8:off+24])
                node.formid = struct.unpack_from('<I', buf, off+12)[0]
                node.data = bytes(buf[off+REC_HDR:off+REC_HDR+size])
                out.append(node)
                off += REC_HDR + size
    walk(0, len(buf), root)
    return root


def serialize_node(n, parts):
    if n.kind == 'grup':
        sub = []
        for c in n.children:
            serialize_node(c, sub)
        s = b''.join(sub)
        parts.append(b'GRUP' + struct.pack('<I', 24 + len(s)) + n.tail)
        parts.append(s)
    else:
        parts.append(n.label + struct.pack('<I', len(n.data)) + n.tail)
        parts.append(n.data)


def find_rec(nodes, formid):
    for n in nodes:
        if n.kind == 'grup':
            r = find_rec(n.children, formid)
            if r is not None:
                return r
        elif n.formid == formid:
            return n
    return None


def rec_flags(rec):
    return struct.unpack_from('<I', rec.tail, 0)[0]


def decode_body(rec):
    if rec_flags(rec) & 0x00040000:
        usz = struct.unpack_from('<I', rec.data, 0)[0]
        dec = zlib.decompress(rec.data[4:])
        assert len(dec) == usz
        return bytearray(dec), True
    return bytearray(rec.data), False


def encode_body(body, was_c):
    if was_c:
        return struct.pack('<I', len(body)) + zlib.compress(bytes(body))
    return bytes(body)


def patch_strings(path, patches):
    buf = open(path, 'rb').read()
    root = parse(buf)
    out = []
    for n in root:
        serialize_node(n, out)
    assert b''.join(out) == buf, f'самотест сериализации: {path}'
    applied = 0
    for formid, field, occ, old, new in patches:
        rec = find_rec(root, formid)
        assert rec is not None, f'{formid:08X} не найдена'
        body, was_c = decode_body(rec)
        off, seen, done = 0, 0, False
        while off < len(body):
            if off + 6 > len(body):
                break
            st = body[off:off+4].decode('ascii', 'replace')
            ssz = struct.unpack_from('<H', body, off+4)[0]
            if st == 'XXXX':
                real = struct.unpack_from('<I', body, off+6)[0]
                off += 6 + ssz + 6 + real
                continue
            cur_sz = ssz
            if st == field:
                seen += 1
                cur = bytes(body[off+6:off+6+ssz]).rstrip(b'\x00').decode(
                    'utf-8', 'replace')
                if seen == occ:
                    assert cur == old, (
                        f'{formid:08X} {field}#{occ}: {cur[:80]!r} != {old[:80]!r}')
                    newb = new.encode('utf-8') + b'\x00'
                    body[off+6:off+6+ssz] = newb
                    struct.pack_into('<H', body, off+4, len(newb))
                    done = True
                    applied += 1
                    cur_sz = len(newb)
            off += 6 + cur_sz
        assert done, f'{formid:08X} {field}#{occ} не применён'
        rec.data = encode_body(body, was_c)
    out = []
    for n in root:
        serialize_node(n, out)
    data = b''.join(out)
    open(path, 'wb').write(data)
    print(f'  строки {path}: патчей {applied}, файл {len(buf)} -> {len(data)} Б')
    return applied


def main():
    assert hashlib.md5(open(DL, 'rb').read()).hexdigest() == V117_ZIP_MD5, \
        'download-пакет не v1.5.17!'
    shutil.copyfile(DL, BASE_SNAP)
    if os.path.isdir(DST):
        shutil.rmtree(DST)
    with zipfile.ZipFile(DL) as z:
        assert z.testzip() is None
        info = z.read('fomod/info.xml').decode('utf-8')
        assert '<Version>1.5.17</Version>' in info, 'база не v1.5.17!'
        z.extractall(DST)
    esp_md5 = hashlib.md5(open(os.path.join(DST, MAIN), 'rb').read()).hexdigest()
    assert esp_md5 == V117_ESP_MD5, f'ESP базы {esp_md5} != запись v1.5.17!'
    print('база: наш релиз v1.5.17 (аплоада игрока в заходе нет), '
          'снапшот -> base_v117.zip, свежая распаковка в v118')

    patches = []
    for line in open(FIX, encoding='utf-8'):
        r = json.loads(line)
        assert r['scope'] == 'main' and r['field'] == 'FULL'
        patches.append((int(r['formid'], 16), r['field'], r['occ'],
                        r['old'], r['new']))
    assert len(patches) == 13, f'ожидается 13 патчей, в фикс-листе {len(patches)}'

    n = patch_strings(os.path.join(DST, MAIN), patches)
    assert n == 13

    full = os.path.join(DST, MAIN)
    md5 = hashlib.md5(open(full, 'rb').read()).hexdigest()
    print(f'md5 {MAIN}: {md5} ({os.path.getsize(full)} Б)')


if __name__ == '__main__':
    main()
