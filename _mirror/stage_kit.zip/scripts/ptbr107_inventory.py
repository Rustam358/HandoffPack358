# -*- coding: utf-8 -*-
"""Этап 107: инвентаризация пакета PT-BR (Nexus 196271) против RU v1.5.9 и EN 1.4.
Декомпозиция «в 12 раз тяжелее» + раскладка состава. Артефакты: work/qa107/."""
import os, json, hashlib

PT = '/home/z/my-project/work/ptbr/PathsOfEmpyrean_FOMODSetup'
RU = '/home/z/my-project/work/ru15'
EN14 = '/home/z/my-project/work/handoff/handoff/08_оригинал_1.4_EN'
OUT = '/home/z/my-project/work/handoff/work/qa107'
os.makedirs(OUT, exist_ok=True)

RAR = '/home/z/my-project/upload/Paths Of Empyrean (PTBR) 196271 1.4 2026-11-01T16-31Z tSBIchrme.rar'
ZIP_RU = '/home/z/my-project/work/handoff/Paths of Empyrean RU 1.5.zip'

def walk(root):
    out = {}
    for dp, _, fns in os.walk(root):
        for fn in fns:
            p = os.path.join(dp, fn)
            rel = os.path.relpath(p, root).replace('\\', '/')
            out[rel] = os.path.getsize(p)
    return out

def cat(name):
    n = name.lower()
    if n.endswith('.esp'): return 'esp'
    if n.endswith(('.png', '.jpg', '.jpeg', '.avif')): return 'image'
    if n.endswith('.nif'): return 'mesh'
    if n.endswith('.pex') or n.endswith('.psc'): return 'script'
    if n.endswith('.xml'): return 'xml'
    if n.endswith('.txt'): return 'txt'
    if n.endswith('.json'): return 'json'
    if n.endswith(('.ini', '.bsa')): return n.split('.')[-1]
    return 'other'

pt, ru = walk(PT), walk(RU)
en14d = walk(os.path.join(EN14, 'дистрибутив_1.4'))
en14r = walk(os.path.join(EN14, 'полный_разбор_1.4', 'PoE 1.4'))

def summary(files):
    s = {}
    for f, sz in files.items():
        s.setdefault(cat(f), [0, 0])
        s[cat(f)][0] += 1; s[cat(f)][1] += sz
    return s

def fmt_summary(s):
    lines = []
    for k in sorted(s, key=lambda k: -s[k][1]):
        lines.append(f'    {k:8} {s[k][0]:3} шт  {s[k][1]:>12,} B')
    return '\n'.join(lines)

rep = []
rep.append('=== Этап 107: инвентаризация PT-BR vs RU v1.5.9 vs EN 1.4 ===')
rep.append('')
r_rar, r_zip = os.path.getsize(RAR), os.path.getsize(ZIP_RU)
rep.append(f'Архив PT-BR (rar, Nexus 196271):      {r_rar:>12,} B')
rep.append(f'Архив RU (zip, Nexus 197444):         {r_zip:>12,} B')
rep.append(f'Отношение архивов:                    {r_rar/r_zip:.2f}x')
u_pt, u_ru = sum(pt.values()), sum(ru.values())
rep.append(f'Распакованный PT-BR:                  {u_pt:>12,} B  ({len(pt)} файлов)')
rep.append(f'Распакованный RU:                     {u_ru:>12,} B  ({len(ru)} файлов)')
rep.append(f'Отношение распакованных:              {u_pt/u_ru:.2f}x')
rep.append('')
rep.append('--- Состав PT-BR (по типам) ---'); rep.append(fmt_summary(summary(pt)))
rep.append('')
rep.append('--- Состав RU v1.5.9 (по типам) ---'); rep.append(fmt_summary(summary(ru)))
rep.append('')
rep.append('--- Файлы PT-BR, которых нет в RU (с размером) ---')
for f in sorted(set(pt) - set(ru)):
    rep.append(f'    {pt[f]:>10,}  {f}')
rep.append('')
rep.append('--- Файлы RU, которых нет в PT-BR (с размером) ---')
for f in sorted(set(ru) - set(pt)):
    rep.append(f'    {ru[f]:>10,}  {f}')
rep.append('')
rep.append('--- Совпадающие пути PT/RU: байт-в-байт? ---')
same = diff = 0
for f in sorted(set(pt) & set(ru)):
    if pt[f] == ru[f]: same += 1
    else: diff += 1
rep.append(f'    совпавших путей: {same + diff}, одинаковый размер: {same}, разный: {diff}')
rep.append('')
esp_pt = {f: sz for f, sz in pt.items() if f.endswith('.esp')}
esp_ru = {f: sz for f, sz in ru.items() if f.endswith('.esp')}
esp_en = {f: sz for f, sz in en14r.items() if f.endswith('.esp')}
rep.append(f'ESP: PT {len(esp_pt)} шт / {sum(esp_pt.values()):,} B | RU {len(esp_ru)} шт / {sum(esp_ru.values()):,} B | EN14 {len(esp_en)} шт / {sum(esp_en.values()):,} B')
rep.append(f'Отношение суммы ESP PT/RU:            {sum(esp_pt.values())/sum(esp_ru.values()):.3f}x')
rep.append('')
rep.append('--- Образы превью PT-BR (FOMOD-косметика) ---')
for f in sorted(pt):
    if cat(f) == 'image':
        rep.append(f'    {pt[f]:>10,}  {f}')
rep.append('--- Меши PT-BR ---')
for f in sorted(pt):
    if cat(f) == 'mesh':
        rep.append(f'    {pt[f]:>10,}  {f}')

# md5 перекрытие ESP-множеств (по именам файлов)
def esp_set(files): return set(os.path.basename(f).lower() for f in files if f.endswith('.esp'))
rep.append('')
a, b, c = esp_set(pt), esp_set(ru), esp_set(en14r)
rep.append(f'ESP-множества: PT={len(a)}, RU={len(b)}, EN14={len(c)}')
rep.append(f'    PT-RU (есть в PT, нет в RU): {sorted(a-b) or "∅"}')
rep.append(f'    RU-PT (есть в RU, нет в PT): {sorted(b-a) or "∅"}')
rep.append(f'    PT-EN14: {sorted(a-c) or "∅"} | EN14-PT: {sorted(c-a) or "∅"}')

with open(f'{OUT}/inventory_107.txt', 'w', encoding='utf-8') as f:
    f.write('\n'.join(rep))
print('\n'.join(rep))
