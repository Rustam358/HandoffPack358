#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 116, шаг: сборка пакета v1.5.17.
База = user zip «Paths of Empyrean RU 1.5 (9).zip» = байт-в-байт наш v1.5.16
(md5 687c057356f4ebd5b519dee0712c0ddd). Замены ровно 2 записи:
main ESP (регистр мужских маскировочных форм, вердикт 115-а),
info.xml 1.5.16→1.5.17. CC-патчи не тронуты (115 в них не входил).
"""
import zipfile, os, hashlib, shutil

SRC_ZIP = '/home/z/my-project/upload/Paths of Empyrean RU 1.5 (9).zip'
DST = '/home/z/my-project/download/Paths of Empyrean RU 1.5.zip'
V117 = '/home/z/my-project/work/qa116/v117'
MAIN = '00 Core/PathsOfEmpyrean.esp'
RU15 = '/home/z/my-project/work/ru15'


def main():
    esp = open(f'{V117}/{MAIN}', 'rb').read()
    md5_esp = hashlib.md5(esp).hexdigest()

    zsrc = zipfile.ZipFile(SRC_ZIP)
    names = zsrc.namelist()
    orig_crc = {i.filename: i.CRC for i in zsrc.infolist()}
    print('источник: user zip (9) v1.5.16 (%d записей)' % len(names))

    info_src = zsrc.read('fomod/info.xml').decode('utf-8')
    assert '<Version>1.5.16</Version>' in info_src
    info_new = info_src.replace('<Version>1.5.16</Version>', '<Version>1.5.17</Version>')
    assert '<Version>1.5.17</Version>' in info_new and '1.5.16' not in info_new
    print('info.xml: Version 1.5.16 -> 1.5.17')

    repl = {MAIN: esp, 'fomod/info.xml': info_new.encode('utf-8')}
    zout = zipfile.ZipFile(DST, 'w')
    for item in zsrc.infolist():
        arc = item.filename
        zout.writestr(item, repl[arc] if arc in repl else zsrc.read(arc))
    zout.close()
    print('zip собран')

    print()
    print('=== ВЕРИФИКАЦИЯ ПАКЕТА v1.5.17 ===')
    z2 = zipfile.ZipFile(DST)
    names2 = z2.namelist()
    assert z2.testzip() is None
    assert len(names2) == 63 and set(names2) == set(names)
    print('testzip: OK, записей: %d (набор совпадает)' % len(names2))

    diff = [n for n in names if orig_crc[n] != z2.getinfo(n).CRC]
    assert set(diff) == set(repl), 'CRC-дифф: %s' % diff
    print('CRC vs v1.5.16: изменены ровно 2 записи (main ESP, info.xml), '
          'остальные %d байт-в-байт' % (len(names) - 2))

    assert hashlib.md5(z2.read(MAIN)).hexdigest() == md5_esp
    print('ESP md5 == work/qa116/v117: %s' % md5_esp)

    ver = z2.read('fomod/info.xml').decode('utf-8')
    assert '<Version>1.5.17</Version>' in ver
    print('версия пакета: 1.5.17')

    shutil.copyfile(f'{V117}/{MAIN}', os.path.join(RU15, '00 Core', 'PathsOfEmpyrean.esp'))
    open(os.path.join(RU15, 'fomod', 'info.xml'), 'w', encoding='utf-8', newline='').write(info_new)
    print('зеркало work/ru15: main ESP, info.xml обновлены')

    print()
    print('ПАКЕТ:', DST, '(%d Б)' % os.path.getsize(DST))
    print('md5 пакета: %s' % hashlib.md5(open(DST, 'rb').read()).hexdigest())


if __name__ == '__main__':
    main()
