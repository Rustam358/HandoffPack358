#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 96, разведка C: финальная валидация VMAD-парсера (строки = u16 len + chars)."""
import sys, struct
from collections import Counter

sys.path.insert(0, '/home/z/my-project/upload/poe_pack/scripts')
from parse_tes4 import Plugin

p = Plugin('/home/z/my-project/work/v156/00 Core/PathsOfEmpyrean.esp')

def u32(sd, o=0): return struct.unpack_from('<I', sd, o)[0]
def i32(sd, o=0): return struct.unpack_from('<i', sd, o)[0]
def f32(sd, o=0): return struct.unpack_from('<f', sd, o)[0]
def u16(sd, o=0): return struct.unpack_from('<H', sd, o)[0]

def parse_vmad(sd, trace=False):
    out = {'scripts': []}
    off = 0
    ver, objfmt = struct.unpack_from('<HH', sd, off); off += 4
    scount = u16(sd, off); off += 2
    for si in range(scount):
        nlen = u16(sd, off); off += 2
        name = sd[off:off + nlen].decode('ascii', 'replace'); off += nlen
        status = sd[off]; off += 1
        pcount = u16(sd, off); off += 2
        props = []
        for pi in range(pcount):
            plen = u16(sd, off); off += 2
            pn = sd[off:off + plen].decode('ascii', 'replace'); off += plen
            ptype = sd[off]; off += 1
            pstat = sd[off]; off += 1
            if ptype == 1:      # object: 8B
                val = ('obj', p.label(u32(sd, off + 4)))
                off += 8
            elif ptype == 2:    # string: u16 len + chars
                slen = u16(sd, off); off += 2
                val = ('str', sd[off:off + slen].decode('utf-8', 'replace')); off += slen
            elif ptype == 3:
                val = ('int', i32(sd, off)); off += 4
            elif ptype == 4:
                val = ('float', round(f32(sd, off), 6)); off += 4
            elif ptype == 5:
                val = ('bool', sd[off]); off += 1
            elif ptype == 11:   # object array
                cnt = u32(sd, off); off += 4
                arr = [p.label(u32(sd, off + 4 + i * 8)) for i in range(cnt)]
                off += 8 * cnt
                val = ('objarr', arr)
            elif ptype == 12:   # string array?
                cnt = u32(sd, off); off += 4
                arr = []
                for _ in range(cnt):
                    slen = u16(sd, off); off += 2
                    arr.append(sd[off:off + slen].decode('utf-8', 'replace')); off += slen
                val = ('strarr', arr)
            elif ptype == 13:
                cnt = u32(sd, off); off += 4
                val = ('intarr', list(struct.unpack_from(f'<{cnt}i', sd, off))); off += 4 * cnt
            elif ptype == 14:
                cnt = u32(sd, off); off += 4
                val = ('floatarr', [round(x, 6) for x in struct.unpack_from(f'<{cnt}f', sd, off)]); off += 4 * cnt
            elif ptype == 15:
                cnt = u32(sd, off); off += 4
                val = ('boolarr', list(sd[off:off + cnt])); off += cnt
            else:
                raise ValueError(f'ptype {ptype} @{off}')
            props.append((pn, ptype, val))
            if trace:
                print(f'    prop[{pi}] {pn!r} type={ptype} val={val}')
        out['scripts'].append({'name': name, 'status': status, 'props': props})
    if off != len(sd):
        raise ValueError(f'off={off} != len={len(sd)} (осталось {len(sd)-off}: {sd[off:off+20].hex()})')
    return out

ok = fail = 0
fails = Counter()
fail_recs = []
for t in ('PERK', 'SPEL', 'MGEF', 'QUST', 'ACTI', 'NPC_', 'WEAP', 'ARMO', 'ALCH', 'SCRL', 'ENCH', 'HAZD', 'PROJ', 'FLST', 'MISC', 'BOOK', 'CONT', 'TACT', 'TERM', 'LIGH', 'IPCT'):
    for f in p.by_type.get(t, []):
        for st, sd in p.records[f]['subs']:
            if st == 'VMAD':
                try:
                    parse_vmad(sd)
                    ok += 1
                except Exception as e:
                    fail += 1
                    fails[f'{t}: {str(e)[:70]}'] += 1
                    fail_recs.append((t, p.records[f]['edid']))
print(f'VMAD: ok={ok} fail={fail}')
for k, v in fails.most_common(15):
    print('  FAIL:', k, 'x', v)

# trace первого фейла
if fail_recs:
    t, edid = fail_recs[0]
    print(f'\nTRACE {t} {edid}:')
    for f in p.by_type[t]:
        r = p.records[f]
        if r['edid'] == edid:
            for st, sd in r['subs']:
                if st == 'VMAD':
                    print('hex:', sd.hex())
                    try:
                        parse_vmad(sd, trace=True)
                    except Exception as e:
                        print('FAIL:', e)
            break

# trace проблемного IMP_DelicateTouchScript
print('\nTRACE IMP_DelicateTouchScript:')
for f in p.by_type['MGEF']:
    r = p.records[f]
    if r['edid'] == 'PoE_MGEF_ENCH_DelicateTouch':
        for st, sd in r['subs']:
            if st == 'VMAD':
                try:
                    d = parse_vmad(sd, trace=True)
                    print('OK, scripts:', [s['name'] for s in d['scripts']])
                except Exception as e:
                    print('FAIL:', e)
        break
