#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""TES4/TES5 plugin parser for PoE x OM patch analysis. Part 1: structure dump."""
import struct, sys, zlib, json, re
from collections import defaultdict

def rec_header(buf, off):
    t = buf[off:off+4].decode('ascii', 'replace')
    size, flags, formid, rev = struct.unpack_from('<IIII', buf, off+4)
    ver, unk = struct.unpack_from('<HH', buf, off+20)
    return t, size, flags, formid, ver

def subrecords(buf, off, end):
    subs = []
    while off < end:
        st = buf[off:off+4].decode('ascii', 'replace')
        ssz = struct.unpack_from('<H', buf, off+4)[0]
        data = buf[off+6:off+6+ssz]
        if st == 'XXXX':
            real = struct.unpack_from('<I', data, 0)[0]
            off += 6 + ssz
            st2 = buf[off:off+4].decode('ascii', 'replace')
            data2 = buf[off+6:off+6+real]
            subs.append((st2, data2))
            off += 6 + real
            continue
        subs.append((st, data))
        off += 6 + ssz
    return subs

class Plugin:
    def __init__(self, path):
        self.path = path
        self.buf = open(path, 'rb').read()
        self.masters = []
        self.records = {}
        self.by_type = defaultdict(list)
        self._parse()

    def _parse(self):
        buf = self.buf
        t, size, flags, formid, ver = rec_header(buf, 0)
        assert t == 'TES4', t
        subs = subrecords(buf, 24, 24 + size)
        for st, sd in subs:
            if st == 'MAST':
                self.masters.append(sd.rstrip(b'\x00').decode('ascii', 'replace'))
        self._walk(24 + size, len(buf))

    def _walk(self, off, end, depth=0):
        buf = self.buf
        while off < end:
            t, size, flags, formid, ver = rec_header(buf, off)
            if t == 'GRUP':
                gsize = size
                self._walk(off + 24, off + gsize, depth + 1)
                off += gsize
            else:
                data_start = off + 24
                if flags & 0x00040000:
                    raw = buf[data_start:data_start+size]
                    dec = zlib.decompress(raw[4:])  # first 4 bytes = uncompressed size
                    self._record(t, flags, formid, dec)
                else:
                    self._record(t, flags, formid, buf[data_start:data_start+size])
                off += 24 + size

    def _record(self, rtype, flags, formid, data):
        subs = subrecords(data, 0, len(data))
        edid = full = None
        for st, sd in subs:
            if st == 'EDID':
                edid = sd.rstrip(b'\x00').decode('ascii', 'replace')
            elif st == 'FULL':
                try:
                    full = sd.rstrip(b'\x00').decode('utf-8', 'replace')
                except Exception:
                    full = repr(sd)
        self.records[formid] = {'type': rtype, 'edid': edid, 'full': full, 'subs': subs, 'formid': formid}
        self.by_type[rtype].append(formid)

    def label(self, formid):
        if formid in self.records:
            r = self.records[formid]
            return f"{r['type']}:{r['edid'] or '?'}"
        idx = formid >> 24
        rest = formid & 0xFFFFFF
        if 0 <= idx < len(self.masters):
            return f"{self.masters[idx]}#0x{rest:06X}"
        if formid == 0:
            return "NULL"
        return f"?0x{formid:08X}"

def fmt_subs(r, keep=None, maxhex=72):
    out = []
    for st, sd in r['subs']:
        if keep and st not in keep:
            continue
        h = sd.hex()
        if len(h) > maxhex:
            h = h[:maxhex] + f'...({len(sd)}B)'
        out.append(f"    {st}[{len(sd)}] {h}")
    return '\n'.join(out)

if __name__ == '__main__':
    import sys
    print("=" * 80)
    om = Plugin('/home/z/my-project/upload/KittySpellPack01.esl')
    poe = Plugin('/home/z/my-project/upload/PathsOfEmpyrean.esp')

    for name, p in (('OM (KittySpellPack01.esl)', om), ('PoE (PathsOfEmpyrean.esp)', poe)):
        print(f"### {name}")
        print(f"masters: {p.masters}")
        print(f"record types: {dict(sorted(((k, len(v)) for k, v in p.by_type.items()), key=lambda x: -x[1])[:18])}")
        print()

    print("=" * 80)
    print("### OM: все KYWD")
    for fid in om.by_type['KYWD']:
        r = om.records[fid]
        print(f"  0x{fid:08X} {r['edid']}")
    print()
    print("### PoE: KYWD (PoE_K_* / MAG_* / *bound*)")
    for fid in poe.by_type['KYWD']:
        r = poe.records[fid]
        e = r['edid'] or ''
        if e.startswith(('PoE_K_', 'MAG_', 'SF_')) or 'bound' in e.lower():
            print(f"  0x{fid:08X} {e}")
    print()

    print("=" * 80)
    print("### OM: SPEL Aedric/Scepter")
    for fid in om.by_type['SPEL']:
        r = om.records[fid]
        if (r['edid'] and re.search(r'aedric|scept', r['edid'], re.I)) or (r['full'] and re.search(r'aedric|scept', r['full'], re.I)):
            print(f"  0x{fid:08X} {r['edid']} | FULL={r['full']!r}")
            print(fmt_subs(r, keep={'SPIT', 'EFID', 'EFIT', 'SCIT', 'CTDA', 'CIS1', 'CIS2'}))
    print()
    print("### OM: все MGEF EDID")
    for fid in om.by_type['MGEF']:
        r = om.records[fid]
        print(f"  0x{fid:08X} {r['edid']} | FULL={r['full']!r}")
    print()
    print("### OM: MGEF с ANAM (associated item = bound-weapon)")
    for fid in om.by_type['MGEF']:
        r = om.records[fid]
        anam = next((struct.unpack_from('<I', sd)[0] for st, sd in r['subs'] if st == 'ANAM'), None)
        if anam:
            print(f"  0x{fid:08X} {r['edid']} -> ANAM {om.label(anam)}")
            print(fmt_subs(r, keep={'DATA', 'ANAM'}))
    print()
    print("### OM: WEAP")
    for fid in om.by_type['WEAP']:
        r = om.records[fid]
        kwda = []
        for st, sd in r['subs']:
            if st == 'KWDA':
                for i in range(0, len(sd), 4):
                    kwda.append(struct.unpack_from('<I', sd, i)[0])
        anam = next((struct.unpack_from('<B', sd)[0] for st, sd in r['subs'] if st == 'ANAM'), None)
        eitm = next((struct.unpack_from('<I', sd)[0] for st, sd in r['subs'] if st == 'EITM'), None)
        print(f"  0x{fid:08X} {r['edid']} | FULL={r['full']!r} equipType={anam} ench={om.label(eitm) if eitm else '-'}")
        for k in kwda:
            print(f"      kw: {om.label(k)}")
    print()
