#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап-разведка 115b.
1) Полный разбор VMAD у MGEF 06060E75 (bandit): скрипты/свойства.
2) Носители MGEF-маскировок в main ESP (кто их применяет: SPEL/PERK/ENCH).
3) Структура SPEL-носителя: поля-эффекты (SNAM/EFIT?).
"""
import struct, zlib, io

ESP = '/home/z/my-project/work/qa114/release115/00 Core/PathsOfEmpyrean.esp'
REC_HDR = 24
MGEF_IDS = {0x06060E72, 0x06060EA7, 0x06060E9B, 0x06060E8E, 0x06060E95,
            0x06060EA1, 0x06060E7D, 0x06060E82, 0x06060E75, 0x06024561,
            0x0602456F, 0x06024574, 0x06024575, 0x06060E87, 0x06024576}


class Node:
    __slots__ = ('kind', 'label', 'tail', 'formid', 'data', 'children')


def parse(buf):
    root = []

    def walk(off, end, out):
        while off < end:
            t = buf[off:off+4]
            size = struct.unpack_from('<I', buf, off+4)[0]
            if t == b'GRUP':
                node = Node(); node.kind = 'grup'; node.children = []
                walk(off + REC_HDR, off + size, node.children)
                out.append(node); off += size
            else:
                node = Node(); node.kind = 'rec'
                node.label = t
                node.tail = bytes(buf[off+8:off+24])
                node.formid = struct.unpack_from('<I', buf, off+12)[0]
                node.data = bytes(buf[off+REC_HDR:off+REC_HDR+size])
                out.append(node); off += REC_HDR + size
    walk(0, len(buf), root)
    return root


def walk_recs(nodes):
    for n in nodes:
        if n.kind == 'grup':
            yield from walk_recs(n.children)
        else:
            yield n


def subrecords(rec):
    body = rec.data
    if struct.unpack_from('<I', rec.tail, 0)[0] & 0x00040000:
        usz = struct.unpack_from('<I', body, 0)[0]
        body = zlib.decompress(body[4:])
        assert len(body) == usz
    out = []
    off = 0
    while off < len(body):
        st = body[off:off+4].decode('ascii', 'replace')
        ssz = struct.unpack_from('<H', body, off+4)[0]
        val = bytes(body[off+6:off+6+ssz])
        out.append((st, val))
        if st == 'XXXX':
            real = struct.unpack_from('<I', body, off+6)[0]
            off += 6 + ssz + 6 + real
            continue
        off += 6 + ssz
    return out


def edid_of(rec):
    for st, v in subrecords(rec):
        if st == 'EDID':
            return v.rstrip(b'\x00').decode('utf-8', 'replace')
    return ''


def read_str(b, off):
    n = struct.unpack_from('<H', b, off)[0]
    s = b[off+2:off+2+n].decode('utf-8', 'replace')
    return s, off + 2 + n


def parse_vmad(v):
    """TES5 VMAD: u16 ver, u16 objFmt, u16 nScripts, scripts.
    script: u16 len, name, u16 nProps, props.
    prop: u16 len, name, u8 type, u8 flags; object: u8 unk,u32 formid?
    Типы: 1=int32,2=float,3=bool,5=?(bool),0b=object array, 5? Формы.
    Разбор по фактическим байтам с ручной сверкой."""
    off = 0
    ver, objfmt, nscripts = struct.unpack_from('<HHH', v, off); off += 6
    out = [f'VMAD ver={ver} objFmt={objfmt} scripts={nscripts}']
    for si in range(nscripts):
        name, off = read_str(v, off)
        nprops = struct.unpack_from('<H', v, off)[0]; off += 2
        out.append(f'  script[{si}] {name!r} props={nprops}')
        for pi in range(nprops):
            pname, off = read_str(v, off)
            ptype = v[off]; pflags = v[off+1]; off += 2
            desc = f'type={ptype} flags={pflags:#04x}'
            if ptype in (0x01, 0x02, 0x03, 0x05):
                # scalar: int/float/bool — u32 значение
                val = struct.unpack_from('<I', v, off)[0]; off += 4
                if ptype == 0x02:
                    desc += f' val={struct.unpack_from("<f", v, off-4)[0]:g}'
                else:
                    desc += f' val={val}'
            elif ptype == 0x0b:
                cnt = struct.unpack_from('<I', v, off)[0]; off += 4
                desc += f' array[{cnt}]:'
                for k in range(cnt):
                    a = v[off]; f1 = struct.unpack_from('<I', v, off+1)[0]
                    off += 5
                    desc += f' [unk={a}, form={f1:08X}]'
            elif ptype == 0x05:
                desc += '?'
            else:
                desc += f' RAW={v[off:off+12].hex()} (осталось {len(v)-off}Б)'
                out.append(f'    {pname!r} {desc}')
                return out
            out.append(f'    {pname!r} {desc}')
    out.append(f'  consumed={off}/{len(v)}')
    return out


def main():
    buf = open(ESP, 'rb').read()
    root = parse(buf)
    index = {}
    recs = list(walk_recs(root))
    for rec in recs:
        index[rec.formid] = (rec.label.decode('ascii', 'replace'), edid_of(rec))

    # 1) VMAD bandit
    print('=== 1) VMAD 06060E75 (bandit) ===')
    for rec in recs:
        if rec.formid == 0x06060E75:
            for st, v in subrecords(rec):
                if st == 'VMAD':
                    print('\n'.join(parse_vmad(v)))
            break

    # 2) носители MGEF в main ESP
    print()
    print('=== 2) носители MGEF-маскировок в main ESP ===')
    pats = {i: struct.pack('<I', i) for i in MGEF_IDS}
    carriers = {}
    for rec in recs:
        rl = rec.label.decode('ascii', 'replace')
        if rec.formid in MGEF_IDS:
            continue
        subs = subrecords(rec)
        for st, v in subs:
            for fid, pat in pats.items():
                if pat in v:
                    key = rec.formid
                    carriers.setdefault(key, (rl, edid_of(rec), {}))
                    carriers[key][2].setdefault(st, set()).add(f'{fid:08X}')
    for fid, (rl, edid, fields) in sorted(carriers.items()):
        fl = '; '.join(f'{st}: {", ".join(sorted(v))}' for st, v in fields.items())
        print(f'{rl} {fid:08X} {edid} | {fl}')


if __name__ == '__main__':
    main()
