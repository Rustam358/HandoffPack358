#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 108: FOMOD установщика как у бразильской раздачи / оригинала PoE.

Директива игрока (вход Этапа 108):
  «Я хочу чтобы в нашей локализации было так же, без бразильского текста,
  разумеется. И убедись что на вкладке CC Patches все галочки стоят по
  умолчанию, особенно на Lord's Mail».

Что делается (v1.5.9 -> v1.5.10, без правок ESP):
  1. ModuleConfig.xml перестроен по скелету PT-BR (копии оригинального
     установщика PoE): 3 шага Core -> Official Addons -> Patches - Creation
     Club, moduleImage + превью-картинки на аддонах, имена опций EN (канон).
  2. Описания — русские (наши канонные формулировки, продолжение стиля v1.5.9).
  3. Копируются 3 картинки оригинала: ModImage1.png, PreviewSpears.jpg,
     PreviewMissingShields.png (взятые из PT-BR, у автора — из оригинала PoE).
  4. ФИКС: у патча Lord's Mail условие Recommended смотрело
     ccbgssse021-lordsmail.ESM (несуществующее расширение) -> .ESL.
     Именно из-за этого опция не получала тип Recommended и не была
     отмечена по умолчанию (у остальных 35 галочки стояли).
  5. Переименования опций под оригинальный установщик: "The Lords Mail" ->
     "Lord's Mail", "Vigil Enforcer" -> "Vigil Enforcer Armor".
     ("Steel Solider" у оригинала — опечатка, у нас остается корректное
     "Steel Soldier").
  6. requiredInstallFiles упразднен: Core стал обычным шагом установщика
     (SelectExactlyOne, радиокнопка не снимается — гарантия установки та же).
  7. info.xml: Version 1.5.9 -> 1.5.10. Имя файла пакета не меняется.

Условия Recommended (fileDependency Or Active/Inactive) переносятся из
текущего конфига программно — не перепечатываются. Структура сверяется с
PT-BR поплагинно.
"""
import zipfile, os, re, hashlib, sys
import xml.etree.ElementTree as ET

SRC = '/home/z/my-project/work/handoff/Paths of Empyrean RU 1.5.zip'
PTBR_CFG = '/home/z/my-project/work/ptbr/PathsOfEmpyrean_FOMODSetup/fomod/ModuleConfig.xml'
PTBR_DIR = '/home/z/my-project/work/ptbr/PathsOfEmpyrean_FOMODSetup'
DST = '/home/z/my-project/download/Paths of Empyrean RU 1.5.zip'

IMAGES = ['ModImage1.png', 'PreviewSpears.jpg', 'PreviewMissingShields.png']
RENAMES = {'The Lords Mail': "Lord's Mail", 'Vigil Enforcer': 'Vigil Enforcer Armor'}
CC_ORDER = [
    'Survival Mode', 'Fishing', 'Curios', 'Saints and Seducers',
    'Alternative Armors - Daedric Mail', 'Alternative Armors - Daedric Plate',
    'Alternative Armors - Dragon Plate', 'Alternative Armors - Dragonscale',
    'Alternative Armors - Dwarven Mail', 'Alternative Armors - Dwarven Plate',
    'Alternative Armors - Ebony Plate', 'Alternative Armors - Elven Hunter',
    'Alternative Armors - Iron', 'Alternative Armors - Leather',
    'Alternative Armors - Orcish Plate', 'Alternative Armors - Orcish Scaled',
    'Alternative Armors - Silver', 'Alternative Armors - Stalhrim Fur',
    'Alternative Armors - Steel Soldier',
    'Advanced Crossbows', 'Arcane Accessories', 'The Cause',
    'Civil War Champions', "Dead Man's Dread", 'Divine Crusader',
    'Expanded Crossbow Pack', 'Fearsome Fists', 'Forgotten Seasons',
    'Ghosts of the Tribunal', "Lord's Mail", 'Necromantic Grimoire',
    'Netch Leather Armor', 'Plague of the Dead', 'Redguard Elite Armaments',
    'Spell Knight Armor', 'Vigil Enforcer Armor',
]

ES = {}

# ---------- утилиты ----------
def esc(s):
    """Экранирование текстовых узлов XML (у нас нет & < >; проверяем жестко)."""
    assert not any(c in s for c in '&<>'), 'опасные символы в тексте: %r' % s
    return s


def indent(n):
    return ' ' * n


def td_simple(i):
    return (indent(i) + '<typeDescriptor>\n' +
            indent(i + 2) + '<type name="Optional" />\n' +
            indent(i) + '</typeDescriptor>')


def td_recommended(i, dep_file):
    return (
        indent(i) + '<typeDescriptor>\n' +
        indent(i + 2) + '<dependencyType>\n' +
        indent(i + 4) + '<defaultType name="Optional" />\n' +
        indent(i + 4) + '<patterns>\n' +
        indent(i + 6) + '<pattern>\n' +
        indent(i + 8) + '<dependencies operator="Or">\n' +
        indent(i + 10) + '<fileDependency file="%s" state="Active" />\n' % esc(dep_file) +
        indent(i + 10) + '<fileDependency file="%s" state="Inactive" />\n' % esc(dep_file) +
        indent(i + 8) + '</dependencies>\n' +
        indent(i + 8) + '<type name="Recommended" />\n' +
        indent(i + 6) + '</pattern>\n' +
        indent(i + 4) + '</patterns>\n' +
        indent(i + 2) + '</dependencyType>\n' +
        indent(i) + '</typeDescriptor>')


def plugin_block(i, name, desc, image, files_lines, td):
    out = [indent(i) + '<plugin name="%s">' % esc(name)]
    out.append(indent(i + 2) + '<description>%s</description>' % desc)
    if image:
        out.append(indent(i + 2) + '<image path="%s" />' % esc(image))
    if files_lines:
        out.append(indent(i + 2) + '<files>')
        out += files_lines
        out.append(indent(i + 2) + '</files>')
    else:
        out.append(indent(i + 2) + '<files />')
    out.append(td)
    out.append(indent(i) + '</plugin>')
    return out


def folder_line(i, source):
    return indent(i) + '<folder source="%s" destination="" priority="0" />' % esc(source)


# ---------- разбор старого конфига ----------
def extract_old(zip_path):
    z = zipfile.ZipFile(zip_path)
    raw = z.read('fomod/ModuleConfig.xml').decode('utf-8')
    root = ET.fromstring(raw)
    data = {'addons': {}, 'cc': {}, 'raw': raw}
    for step in root.findall('./installSteps/installStep'):
        for grp in step.findall('./optionalFileGroups/group'):
            for pl in grp.findall('./plugins/plugin'):
                name = pl.get('name')
                folder = None
                fl = pl.find('./files/folder')
                if fl is not None:
                    folder = fl.get('source')
                deps = [(d.get('file'), d.get('state'))
                        for d in pl.findall('./typeDescriptor/dependencyType/patterns/pattern/dependencies/fileDependency')]
                rec = {'folder': folder, 'deps': deps,
                       'desc': (pl.findtext('description') or '').strip()}
                if grp.get('name').startswith('Переводы патчей CC'):
                    data['cc'][name] = rec
                else:
                    data['addons'][name] = rec
    return data


# ---------- разбор PT-BR (паритет структуры) ----------
def extract_ptbr():
    raw = open(PTBR_CFG, 'rb').read().decode('utf-16')
    if raw.startswith('\ufeff'):
        raw = raw[1:]
    root = ET.fromstring(raw)
    struct = {'moduleName': root.findtext('moduleName').strip(),
              'moduleImage': root.find('moduleImage').get('path'),
              'steps': []}
    for step in root.findall('./installSteps/installStep'):
        s = {'name': step.get('name'), 'groups': []}
        for grp in step.findall('./optionalFileGroups/group'):
            g = {'name': grp.get('name'), 'type': grp.get('type'), 'plugins': []}
            for pl in grp.findall('./plugins/plugin'):
                img = pl.find('image')
                g['plugins'].append({'name': pl.get('name'),
                                     'image': img.get('path') if img is not None else None})
            s['groups'].append(g)
        struct['steps'].append(s)
    return struct


def main():
    old = extract_old(SRC)
    ptbr = extract_ptbr()

    zsrc = zipfile.ZipFile(SRC)
    names = zsrc.namelist()
    orig_crc = {i.filename: i.CRC for i in zsrc.infolist()}
    print('источник: %s (%d записей)' % (SRC, len(names)))

    # --- санити источника ---
    info_src = zsrc.read('fomod/info.xml').decode('utf-8')
    assert '<Version>1.5.9</Version>' in info_src
    assert 'v1.5.9' in old['raw']
    print('санити: исходник = v1.5.9 (info.xml + moduleName)')

    # --- CC: паритет имен ---
    old_cc_names = set(old['cc'])
    new_cc_names = set(CC_ORDER)
    expected_new = (old_cc_names - set(RENAMES)) | set(RENAMES.values())
    assert new_cc_names == expected_new, 'расхождение CC-имен: %s' % (new_cc_names ^ expected_new)
    assert len(CC_ORDER) == 36
    print('CC-имена: 36, переименования: %s' % RENAMES)

    # --- генерация нового ModuleConfig ---
    L = []
    L.append('<?xml version="1.0" encoding="utf-8"?>')
    L.append('<config xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="http://qconsulting.ca/fo3/ModConfig5.0.xsd">')
    L.append('  <moduleName>Paths of Empyrean</moduleName>')
    L.append('  <moduleImage path="ModImage1.png" />')
    L.append('  <installSteps order="Explicit">')

    # ШАГ 1: Core
    L.append('    <installStep name="Core">')
    L.append('      <optionalFileGroups order="Explicit">')
    L.append('        <group name="Core" type="SelectExactlyOne">')
    L.append('          <plugins order="Explicit">')
    core_desc = ('Этот установщик проведет вас через установку русской локализации мода '
                 'Paths of Empyrean, ее аддонов и патчей Creation Club.&#13;&#10;\n'
                 'Патчи совместимости с другими модами ищите на официальной странице patch hub.')
    L += plugin_block(12, 'Paths of Empyrean', core_desc, 'ModImage1.png',
                      [folder_line(16, '00 Core')], td_simple(14))
    L.append('          </plugins>')
    L.append('        </group>')
    L.append('      </optionalFileGroups>')
    L.append('    </installStep>')

    # ШАГ 2: Official Addons
    ms = old['addons']['Missing Shields']
    sp = old['addons']['Spears']
    assert ms['folder'] == '10 Missing Shields' and sp['folder'] == '20 Spears'
    L.append('    <installStep name="Official Addons">')
    L.append('      <optionalFileGroups order="Explicit">')
    L.append('        <group name="Addon - Spears" type="SelectExactlyOne">')
    L.append('          <plugins order="Explicit">')
    L += plugin_block(12, 'None',
                      'Пропустить перевод аддона PoE Spears. Выберите, если аддон Spears не установлен.',
                      None, [], td_simple(14))
    L += plugin_block(12, 'Spears (OAR)',
                      'Перевод аддона PoE Spears. Выберите, если при установке оригинального мода выбрали вариант Spears (OAR).',
                      'PreviewSpears.jpg', [folder_line(16, '20 Spears')],
                      td_recommended(14, sp['deps'][0][0]))
    L += plugin_block(12, 'Spears (No OAR)',
                      'Перевод аддона PoE Spears. Выберите, если при установке оригинального мода выбрали вариант Spears (No OAR).',
                      'PreviewSpears.jpg', [folder_line(16, '20 Spears')], td_simple(14))
    L.append('          </plugins>')
    L.append('        </group>')
    L.append('        <group name="Addon - Missing Shields" type="SelectExactlyOne">')
    L.append('          <plugins order="Explicit">')
    L += plugin_block(12, 'None',
                      'Пропустить перевод аддона PoE Missing Shields. Выберите, если аддон Missing Shields не установлен.',
                      None, [], td_simple(14))
    L += plugin_block(12, 'Missing Shields',
                      'Перевод аддона PoE Missing Shields. Выберите, если при установке оригинального мода выбрали вариант Missing Shields.',
                      'PreviewMissingShields.png', [folder_line(16, '10 Missing Shields')],
                      td_recommended(14, ms['deps'][0][0]))
    L.append('          </plugins>')
    L.append('        </group>')
    L.append('      </optionalFileGroups>')
    L.append('    </installStep>')

    # ШАГ 3: Patches - Creation Club
    L.append('    <installStep name="Patches - Creation Club">')
    L.append('      <optionalFileGroups order="Explicit">')
    L.append('        <group name="Creation Club" type="SelectAny">')
    L.append('          <plugins order="Explicit">')
    fixed_deps, desc_parity = {}, []
    for name in CC_ORDER:
        old_name = name
        for o, n in RENAMES.items():
            if n == name:
                old_name = o
        rec = old['cc'][old_name]
        files = [f for f, st in rec['deps']]
        assert len(set(files)) == 1 and len(rec['deps']) == 2, name
        dep = files[0]
        if old_name == 'The Lords Mail':
            assert dep == 'ccbgssse021-lordsmail.esm'
            dep = 'ccbgssse021-lordsmail.esl'
            print('  ФИКС Lord\'s Mail: ccbgssse021-lordsmail.esm -> .esl (Active+Inactive)')
        fixed_deps[name] = dep
        desc = 'Перевод патча для творения «%s». Рекомендуется, если установлено творение %s.' % (name, dep)
        if name not in RENAMES.values():
            assert desc == rec['desc'], 'desc-паритет сломан у %s:\n  new: %s\n  old: %s' % (name, desc, rec['desc'])
            desc_parity.append(name)
        L += plugin_block(12, name, desc, None, [folder_line(16, rec['folder'])],
                          td_recommended(14, dep))
    L.append('          </plugins>')
    L.append('        </group>')
    L.append('      </optionalFileGroups>')
    L.append('    </installStep>')
    L.append('  </installSteps>')
    L.append('</config>')
    cfg_new = '\n'.join(L) + '\n'
    ET.fromstring(cfg_new)  # well-formed
    print('новый ModuleConfig: well-formed, desc-паритет 34/34 неизменных имен')

    # --- паритет зависимостей со старым конфигом ---
    inv_renames = {v: k for k, v in RENAMES.items()}
    for name, dep in fixed_deps.items():
        old_name = inv_renames.get(name, name)
        old_files = sorted(set(f for f, st in old['cc'][old_name]['deps']))
        expect = ['ccbgssse021-lordsmail.esl'] if name == "Lord's Mail" else old_files
        assert sorted([dep]) == expect, 'deps-паритет: %s' % name
    print('зависимости CC: 36/36 перенесены (1 исправлен: lordsmail .esl)')

    # --- паритет структуры с PT-BR ---
    our_root = ET.fromstring(cfg_new)
    our_steps = []
    for step in our_root.findall('./installSteps/installStep'):
        s = {'name': step.get('name'), 'groups': []}
        for grp in step.findall('./optionalFileGroups/group'):
            g = {'name': grp.get('name'), 'type': grp.get('type'), 'plugins': []}
            for pl in grp.findall('./plugins/plugin'):
                img = pl.find('image')
                g['plugins'].append({'name': pl.get('name'),
                                     'image': img.get('path') if img is not None else None})
            s['groups'].append(g)
        our_steps.append(s)
    ours_flat = [(s['name'], [(g['name'], g['type'], [p['name'] for p in g['plugins']]) for g in s['groups']]) for s in our_steps]
    ptbr_flat = [(s['name'], [(g['name'], g['type'], [p['name'] for p in g['plugins']]) for g in s['groups']]) for s in ptbr['steps']]
    assert [s['name'] for s in our_steps] == [s['name'] for s in ptbr['steps']], 'шаги не совпали'
    for (on, og), (pn, pg) in zip(ours_flat, ptbr_flat):
        for (gon, gtype, gpl), (pgon, pgtype, pgpl) in zip(og, pg):
            assert gon == pgon and gtype == pgtype, 'группа: %r vs %r' % (gon, pgon)
            assert len(gpl) == len(pgpl), 'число опций в %r' % gon
            for a, b in zip(gpl, pgpl):
                assert a == b or {a, b} == {'Alternative Armors - Steel Soldier',
                                            'Alternative Armors - Steel Solider'}, \
                    'опция: %r vs %r' % (a, b)
    assert our_root.findtext('moduleName').strip() == ptbr['moduleName'] == 'Paths of Empyrean'
    assert our_root.find('moduleImage').get('path') == ptbr['moduleImage'] == 'ModImage1.png'

    def image_map(steps):
        m = {}
        for s in steps:
            for g in s['groups']:
                for p in g['plugins']:
                    m[p['name']] = p['image']
        return m
    im_ours, im_ptbr = image_map(our_steps), image_map(ptbr['steps'])
    im_ptbr['Alternative Armors - Steel Soldier'] = im_ptbr.pop('Alternative Armors - Steel Solider')
    for k in im_ours:
        assert im_ours[k] == im_ptbr.get(k), 'image: %r ours=%r ptbr=%r' % (k, im_ours[k], im_ptbr.get(k))
    print('паритет с PT-BR: шаги/группы/типы/опции/картинки OK (единственное имя-различие: Steel Soldier)')

    # --- info.xml ---
    info_new = info_src.replace('<Version>1.5.9</Version>', '<Version>1.5.10</Version>')
    assert '<Version>1.5.10</Version>' in info_new and '1.5.9' not in info_new
    print('info.xml: Version 1.5.9 -> 1.5.10')

    # --- сборка zip ---
    os.makedirs(os.path.dirname(DST), exist_ok=True)
    zout = zipfile.ZipFile(DST, 'w')
    changed = []
    for item in zsrc.infolist():
        arc = item.filename
        if arc == 'fomod/ModuleConfig.xml':
            zout.writestr(item, cfg_new.encode('utf-8'))
            changed.append(arc)
        elif arc == 'fomod/info.xml':
            zout.writestr(item, info_new.encode('utf-8'))
            changed.append(arc)
        else:
            zout.writestr(item, zsrc.read(arc))
    ref_info = zsrc.getinfo('fomod/info.xml')
    for img in IMAGES:
        src_path = os.path.join(PTBR_DIR, img)
        zi = zipfile.ZipInfo(img, date_time=ref_info.date_time)
        zi.compress_type = zipfile.ZIP_DEFLATED
        zi.external_attr = 0o644 << 16
        zout.writestr(zi, open(src_path, 'rb').read())
    zout.close()
    print('zip собран: заменено %d, добавлено %d картинок' % (len(changed), len(IMAGES)))

    # ================= ВЕРИФИКАЦИЯ =================
    print()
    print('=== ВЕРИФИКАЦИЯ ПАКЕТА v1.5.10 ===')
    z2 = zipfile.ZipFile(DST)
    names2 = z2.namelist()
    assert z2.testzip() is None
    print('testzip: OK, записей: %d (было %d, +3 картинки)' % (len(names2), len(names)))
    assert set(names2) == set(names) | set(IMAGES)

    diff = [n for n in names if orig_crc[n] != z2.getinfo(n).CRC]
    expected = {'fomod/ModuleConfig.xml', 'fomod/info.xml'}
    assert set(diff) == expected, 'CRC-дифф: %s' % (set(diff) ^ expected)
    print('CRC: изменены ровно 2 (fomod/*.xml), остальные %d байт-в-байт' % (len(names) - 2))

    cfg_txt = z2.read('fomod/ModuleConfig.xml').decode('utf-8')
    srcs = set(re.findall(r'<folder source="([^"]+)"', cfg_txt))
    missing = [s for s in srcs if not any(n == s or n.startswith(s + '/') for n in names2)]
    assert not missing, 'висячие source: %r' % missing
    print('source-ссылки: %d, все существуют' % len(srcs))
    assert not re.search(r'<file\s+source=', cfg_txt), 'обнаружены file-источники!'
    assert '<fileDependency' in cfg_txt
    print('file-источников: 0 (только folder)')

    root2 = ET.fromstring(cfg_txt)
    assert root2.findtext('moduleName').strip() == 'Paths of Empyrean'
    imgs = [i.filename for i in z2.infolist() if i.filename in IMAGES]
    for img in imgs:
        h1 = hashlib.md5(z2.read(img)).hexdigest()
        h2 = hashlib.md5(open(os.path.join(PTBR_DIR, img), 'rb').read()).hexdigest()
        assert h1 == h2, img
    print('картинки: %d/3 в корне архива, md5 == исходникам PT-BR' % len(imgs))

    cc_grp = [g for s in root2.findall('./installSteps/installStep')
              for g in s.findall('./optionalFileGroups/group') if g.get('name') == 'Creation Club'][0]
    lm = [p for p in cc_grp.findall('./plugins/plugin') if p.get('name') == "Lord's Mail"]
    assert len(lm) == 1
    deps_lm = [d.get('file') for d in lm[0].findall('./typeDescriptor/dependencyType/patterns/pattern/dependencies/fileDependency')]
    assert deps_lm == ['ccbgssse021-lordsmail.esl'] * 2, deps_lm
    n_cc = len(cc_grp.findall('./plugins/plugin'))
    print("CC-группа: 36 опций, SelectAny; 'Lord's Mail' deps = ccbgssse021-lordsmail.esl (Active+Inactive)")

    ver = z2.read('fomod/info.xml').decode('utf-8')
    assert '<Version>1.5.10</Version>' in ver
    print('версии: moduleName = "Paths of Empyrean" (как у оригинала), info.xml = 1.5.10')

    print()
    print('ПАКЕТ:', DST, '(%d B)' % os.path.getsize(DST))
    print('ГОТОВ К ПЕРЕЗАЛИВКЕ НА NEXUS')


if __name__ == '__main__':
    main()
