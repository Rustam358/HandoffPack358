#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 115: независимая верификация v1.5.16.
1) CRC-регресс 61 файла; 2) побайтовый регресс записей main ESP
   (изменены ровно 5 MESG/5 MGEF/5 SPEL); 3) dump-дифф текстов (11+15 полей);
4) байтовые проверки CTDA/VMAD/EFID клонов; 5) гигиена «чешуйчат/ламелляр».
"""
import struct, zlib, os, sys, json, zipfile, hashlib, io

sys.path.insert(0, '/home/z/my-project/work/handoff510/scripts')
from dump150 import dump_esp

SRC_ZIP = '/home/z/my-project/upload/Paths of Empyrean RU 1.5 (8).zip'
NEW = '/home/z/my-project/work/qa115/v116'
FIX = '/home/z/my-project/work/qa115/fixlist_v116.jsonl'
DUMP_OLD = '/home/z/my-project/work/qa114/dump_v115_full.jsonl'
DUMP_NEW = '/home/z/my-project/work/qa115/dump_v116_full.jsonl'
MAIN = '00 Core/PathsOfEmpyrean.esp'
CC = ('30 CC Patches/Alternative Armors - Orcish Scaled/'
      'PoE-CCAltArmorOrcishScaled-Patch.esp')
REC_HDR = 24

END_MESG = 0x06060E79
CTDA_MALE = bytes.fromhex('00000000' '0000803f' '46000000' '00000000'
                          '00000000' '0000' '000000000000' 'ffffffff')
CTDA_FEMALE = CTDA_MALE[:12] + b'\x01\x00\x00\x00' + CTDA_MALE[16:]
DISG = [
    ('bandit', 0x06060E75, 0x06060E78, 0x06060E76, 0x065D69D7, 0x065D69DC,
     'ISP_MGEF_SPEECH_Disguise_bandit_F', 'ISP_MSG_SPEECH_Disguise_bandit_F',
     'Вы замаскированы под Бандитку.'),
    ('Stormcloak', 0x06060E95, 0x06060E93, 0x06060E96, 0x065D69D8, 0x065D69DD,
     'ISP_MGEF_SPEECH_Disguise_Stormcloak_F',
     'ISP_MSG_SPEECH_Disguise_Stormcloak_F', 'Вы замаскированы под Сестру Бури.'),
    ('Imperial', 0x06060E9B, 0x06060E9A, 0x06060E9C, 0x065D69D9, 0x065D69DE,
     'ISP_MGEF_SPEECH_Disguise_Imperial_F', 'ISP_MSG_SPEECH_Disguise_Imperial_F',
     'Вы замаскированы под Имперку.'),
    ('Cultist', 0x06060EA7, 0x06060EA6, 0x06060EA8, 0x065D69DA, 0x065D69DF,
     'ISP_MGEF_SPEECH_Disguise_Cultist_F', 'ISP_MSG_SPEECH_Disguise_Cultist_F',
     'Вы замаскированы под Культистку.'),
    ('vampire', 0x06024576, 0x06024573, 0x0602457B, 0x065D69DB, 0x065D69E0,
     'ISP_MGEF_SPEECH_Disguise_vampire_F', 'ISP_MSG_SPEECH_Disguise_vampire_F',
     'Вы замаскированы под Вампирессу.'),
]
STR_DISG = {  # оба пола / мужские MESG — точные строки после 115
    0x06060EA0: 'Вы замаскированы под Талмор.',
    0x06060E8B: 'Вы замаскированы под Некроманта.',
    0x06024570: 'Вы замаскированы под Драугра.',
    0x06024571: 'Вы замаскированы под Фалмера.',
    0x06024572: 'Вы замаскированы под Двемерского автоматона.',
    0x06060E88: 'Вы замаскированы под Изгоя.',
    0x06024563: 'Вы замаскированы под члена Стражи Рассвета.',
    0x06060E78: 'Вы замаскированы под бандита.',
    0x06060E93: 'Вы замаскированы под Брата Бури.',
    0x06060E9A: 'Вы замаскированы под имперца.',
    0x06060EA6: 'Вы замаскированы под культиста.',
    0x06024573: 'Вы замаскированы под вампира.',
}

FAILED = []


def check(cond, msg):
    if cond:
        print(f'  ✓ {msg}')
    else:
        print(f'  ✗ {msg}')
        FAILED.append(msg)


class Node:
    __slots__ = ('kind', 'label', 'tail', 'formid', 'data', 'children')


def parse(buf):
    root = []

    def walk(off, end, out):
        while off < end:
            t = buf[off:off+4]
            size = struct.unpack_from('<I', buf, off+4)[0]
            if t == b'GRUP':
                node = Node()
                node.kind = 'grup'
                node.tail = bytes(buf[off+8:off+24])
                node.children = []
                walk(off + REC_HDR, off + size, node.children)
                out.append(node)
                off += size
            else:
                node = Node()
                node.kind = 'rec'
                node.label = t
                node.tail = bytes(buf[off+8:off+24])
                node.formid = struct.unpack_from('<I', buf, off+12)[0]
                node.data = bytes(buf[off+REC_HDR:off+REC_HDR+size])
                out.append(node)
                off += REC_HDR + size
    walk(0, len(buf), root)
    return root


def walk_recs(nodes):
    for n in nodes:
        if n.kind == 'grup':
            yield from walk_recs(n.children)
        else:
            yield n


def subrecords(rec):
    body = rec.data
    if struct.unpack_from('<I', rec.tail, 0)[0] & 0x00040000:
        usz = struct.unpack_from('<I', body, 0)[0]
        body = zlib.decompress(body[4:])
        assert len(body) == usz
    out = []
    off = 0
    while off < len(body):
        st = body[off:off+4].decode('ascii', 'replace')
        ssz = struct.unpack_from('<H', body, off+4)[0]
        val = bytes(body[off+6:off+6+ssz])
        out.append((st, val))
        if st == 'XXXX':
            real = struct.unpack_from('<I', body, off+6)[0]
            off += 6 + ssz + 6 + real
            continue
        off += 6 + ssz
    return out


def edid_of(rec):
    for st, v in subrecords(rec):
        if st == 'EDID':
            return v.rstrip(b'\x00').decode('utf-8', 'replace')
    return ''


def text_of(rec, sig):
    return next((v.rstrip(b'\x00').decode('utf-8', 'replace')
                 for st, v in subrecords(rec) if st == sig), '')


def main():
    print('=== 1) CRC-регресс 61 файла ===')
    with zipfile.ZipFile(SRC_ZIP) as z:
        old_names = set(z.namelist())
        new_files = {}
        for dp, _, fns in os.walk(NEW):
            for fn in fns:
                rel = os.path.relpath(os.path.join(dp, fn), NEW).replace(os.sep, '/')
                new_files[rel] = open(os.path.join(dp, fn), 'rb').read()
        old_bytes = {n: z.read(n) for n in old_names}
    check(set(new_files) == old_names, f'состав: 63 файла, совпадение имён '
          f'({len(new_files)}/63)')
    changed = [n for n in old_names
               if hashlib.md5(new_files[n]).hexdigest()
               != hashlib.md5(old_bytes[n]).hexdigest()]
    check(sorted(changed) == sorted([MAIN, CC]), f'изменены ровно 2 ESP: {changed}')
    for n in old_names - {MAIN, CC}:
        if new_files[n] != old_bytes[n]:
            check(False, f'НЕИЗВЕСТНОЕ ИЗМЕНЕНИЕ: {n}')
    print('  ✓ 61 файл байт-в-байт идентичны v1.5.15')

    print('=== 2) побайтовый регресс записей main ESP ===')
    old_esp = old_bytes[MAIN]
    new_esp = new_files[MAIN]
    old_root = parse(old_esp)
    new_root = parse(new_esp)
    old_map = {r.formid: r for r in walk_recs(old_root)}
    new_map = {r.formid: r for r in walk_recs(new_root)}
    check(len(old_map) == 17007 and len(new_map) == 17017,
          f'записей: old {len(old_map)}, new {len(new_map)} (+10)')
    touched = {0x06060EA0, 0x06060E8B, 0x06024570, 0x06024571, 0x06024572}  # MESG
    mgef_o = {d[1] for d in DISG}
    spel_o = {d[3] for d in DISG}
    new_ids = {d[4] for d in DISG} | {d[5] for d in DISG}
    expect_touch = touched | mgef_o | spel_o
    diffs = []
    for fid, old_r in old_map.items():
        new_r = new_map.get(fid)
        if new_r is None:
            diffs.append((fid, 'ИСЧЕЗЛА'))
            continue
        if old_r.data != new_r.data or old_r.tail[:4] != new_r.tail[:4]:
            want = expect_touch if fid in expect_touch else None
            if want is None:
                diffs.append((fid, 'ПОСТОРОННЕЕ ИЗМЕНЕНИЕ'))
    check(not diffs, f'посторонних изменений нет ({len(diffs)})')
    for fid, why in diffs[:10]:
        print(f'    ! {fid:08X} {why}')
    for d in DISG:
        check(d[4] in new_map and d[5] in new_map,
              f'{d[0]}: новые {d[4]:08X}/{d[5]:08X} существуют')

    print('=== 3) dump-дифф текстов ===')
    with io.open(DUMP_NEW, 'w', encoding='utf-8') as out:
        jobs = [(f'{NEW}/00 Core/PathsOfEmpyrean.esp', 'main'),
                (f'{NEW}/10 Missing Shields/PoE-Addon-MissingShields.esp', 'ms'),
                (f'{NEW}/20 Spears/PoE-Addon-Spears.esp', 'sp')]
        for dp, _, fns in os.walk(f'{NEW}/30 CC Patches'):
            for fn in sorted(fns):
                if fn.lower().endswith('.esp'):
                    tag = 'cc:' + fn.replace('PoE-CC', '').replace('-Patch.esp', '')
                    jobs.append((os.path.join(dp, fn), tag))
        for path, tag in jobs:
            dump_esp(path, tag, out)
    fields = [json.loads(l) for l in io.open(DUMP_NEW, encoding='utf-8')]
    old_fields = [json.loads(l) for l in io.open(DUMP_OLD, encoding='utf-8')]
    om = {(r['file'], r['formid'], r['rtype'], r['field'], r.get('occ', 1)): r['text']
          for r in old_fields}
    nm = {(r['file'], r['formid'], r['rtype'], r['field'], r.get('occ', 1)): r['text']
          for r in fields}
    fixes = [json.loads(l) for l in io.open(FIX, encoding='utf-8')]
    expect = {}
    for f in fixes:
        tag = 'main' if f['scope'] == 'main' else 'cc:AltArmorOrcishScaled'
        expect[(tag, f['formid'], 'ARMO' if f['field'] == 'FULL' else 'MESG',
                f['field'], f['occ'])] = (f['old'], f['new'])
    changed_keys = []
    new_keys = []
    for k in om:
        if k not in nm:
            check(False, f'ключ пропал: {k}')
            continue
        if om[k] != nm[k]:
            changed_keys.append(k)
    for k in nm:
        if k not in om:
            new_keys.append(k)
    ok_changed = []
    for k in changed_keys:
        exp = None
        for ek, ev in expect.items():
            if ek[1:] == k[1:]:
                exp = ev
                break
        if exp and om[k] == exp[0] and nm[k] == exp[1]:
            ok_changed.append(k)
    check(len(ok_changed) == 11 == len(changed_keys),
          f'изменённых полей ровно 11 == fixlist ({len(ok_changed)})')
    fem_descs = {d[4]: d[8] for d in DISG}
    mgef_f2orig = {d[5]: d[1] for d in DISG}
    ok_new = 0
    for k in sorted(new_keys):
        fid = int(k[1], 16)
        if k[3] == 'DESC' and fid in fem_descs and nm[k] == fem_descs[fid]:
            ok_new += 1
        elif k[3] in ('FULL', 'DNAM') and fid in mgef_f2orig:
            orig_fid = mgef_f2orig[fid]
            old_val = om.get(('main', f'{orig_fid:08X}', 'MGEF', k[3], 1))
            if old_val is not None and nm[k] == old_val:
                ok_new += 1
            else:
                check(False, f'клон MGEF {k[3]} != оригинал: {nm[k]!r}')
        else:
            check(False, f'НЕОЖИДАННОЕ НОВОЕ ПОЛЕ: {k} = {nm[k]!r}')
    check(ok_new == 15, f'новых полей ровно 15 ({ok_new}): '
          '5 MESG_F DESC + 5 MGEF_F FULL + 5 MGEF_F DNAM')

    print('=== 4) байтовые проверки CTDA/VMAD/EFID ===')
    for key, mgef_id, mesg_id, spel_id, mf, gf, gef_edid, msg_edid, fem in DISG:
        orig_mgef = new_map[mgef_id]
        clone_mgef = new_map[gf]
        clone_mesg = new_map[mf]
        orig_spel = new_map[spel_id]
        ctdas_o = [v for st, v in subrecords(orig_mgef) if st == 'CTDA']
        ctdas_c = [v for st, v in subrecords(clone_mgef) if st == 'CTDA']
        check(ctdas_o == [CTDA_MALE], f'{key}: orig MGEF CTDA == male-шаблон')
        check(ctdas_c == [CTDA_FEMALE], f'{key}: clone MGEF CTDA == female-шаблон')
        check(text_of(orig_mgef, 'DNAM') == text_of(clone_mgef, 'DNAM')
              and text_of(orig_mgef, 'FULL') == text_of(clone_mgef, 'FULL'),
              f'{key}: клон MGEF FULL/DNAM скопированы')
        check(edid_of(clone_mgef) == gef_edid and edid_of(clone_mesg) == msg_edid,
              f'{key}: EDID клонов верны')
        # VMAD клонов
        vm_c = next(v for st, v in subrecords(clone_mgef) if st == 'VMAD')
        pat_s = b'\x00\x00\xff\xff' + struct.pack('<I', mf)
        pat_e = b'\x00\x00\xff\xff' + struct.pack('<I', END_MESG)
        check(vm_c.count(pat_s) == 1 and vm_c.count(pat_e) == 1,
              f'{key}: VMAD клона msgStart→{mf:08X}, msgEnd→{END_MESG:08X}')
        # VMAD оригиналов не тронуты
        old_mgef = old_map[mgef_id]
        vm_o_old = next(v for st, v in subrecords(old_mgef) if st == 'VMAD')
        vm_o_new = next(v for st, v in subrecords(orig_mgef) if st == 'VMAD')
        check(vm_o_old == vm_o_new, f'{key}: VMAD оригинала байт-в-байт прежний')
        # MESG_F остальные поля копия
        for sig in ('INAM', 'DNAM', 'TNAM'):
            a = next(v for st, v in subrecords(old_map[mesg_id]) if st == sig)
            b = next(v for st, v in subrecords(clone_mesg) if st == sig)
            check(a == b, f'{key}: MESG_F {sig} скопирован')
        check(text_of(clone_mesg, 'DESC') == fem, f'{key}: MESG_F DESC = {fem!r}')
        # SPEL
        efids = [v for st, v in subrecords(orig_spel) if st == 'EFID']
        efits = [v for st, v in subrecords(orig_spel) if st == 'EFIT']
        check(len(efids) == 2 and len(efits) == 2, f'{key}: SPEL 2×EFID/EFIT')
        check(efids[0] == struct.pack('<I', mgef_id)
              and efids[1] == struct.pack('<I', gf),
              f'{key}: EFID[0]={mgef_id:08X}, EFID[1]={gf:08X}')
        check(efits[0] == efits[1], f'{key}: EFIT клон == оригинал')
        n_ct = sum(1 for st, v in subrecords(orig_spel) if st == 'CTDA')
        check(n_ct == 3, f'{key}: CTDA SPEL не тронуты (3)')

    print('=== 5) гигиена и строки ===')
    cc_bin = new_files[CC]
    check('чешуйчат'.encode() not in cc_bin, 'CC OrcishScaled: «чешуйчат» исчез')
    for s in ('Орочьи ламеллярные сапоги', 'Орочья ламеллярная броня',
              'Орочьи ламеллярные перчатки', 'Мастерские орочьи ламеллярные сапоги',
              'Мастерские орочьи ламеллярные перчатки',
              'Мастерская орочья ламеллярная броня'):
        check(s.encode() in cc_bin, f'CC: {s!r} на месте')
    cc_other = [n for n in old_names if n.endswith('.esp')
                and n not in (MAIN, CC)]
    hit1 = hit2 = 0
    for n in cc_other:
        if 'чешуйчат'.encode() in new_files[n]:
            hit1 += 1
        if 'Драконьи чешуйчатые перчатки драчуна'.encode() in new_files[n]:
            hit2 += 1
    check(hit1 >= 1, f'драконья серия «чешуйчат» не тронута ({hit1} файлов)')
    check(hit2 >= 1, f'«перчатки драчуна» на месте ({hit2} файлов)')
    for fid, want in STR_DISG.items():
        got = text_of(new_map[fid], 'DESC')
        check(got == want, f'MESG {fid:08X}: {got!r}')

    print('=== 6) итоговые md5 ===')
    for p in (MAIN, CC):
        print(f'  {p}: {hashlib.md5(new_files[p]).hexdigest()} '
              f'({len(new_files[p])} Б)')

    print()
    if FAILED:
        print(f'ПРОВАЛОВ: {len(FAILED)}')
        for m in FAILED:
            print(f'  - {m}')
        sys.exit(1)
    print('ВСЕ ПРОВЕРКИ ПРОЙДЕНЫ')


if __name__ == '__main__':
    main()
