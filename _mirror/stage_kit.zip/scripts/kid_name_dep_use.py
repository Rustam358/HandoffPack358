#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 98 (доп.): кто в PoE использует имя-зависимые ключевики KID.

Имя-правила PathsOfEmpyrean_KID.ini выдают 25 клон-записям ключи
SF_K_ArmorClothingIntimidating(+_Head), WAF_ArmorMaterialDraugr,
SF_K_ConcealsFace, WAF_MaterialFaction, SF_K_DisguiseImperial,
WAF_WeapMaterialFaction, OCF_WeapTypeWarhammer2H. Вопрос: на что эти
ключи завязаны в геймплее (PERK/SPEL/MGEF CTDA HasKeyword), чтобы
оценить цену потери ключей при переводе FULL-имён предметов.
"""
import struct
import sys

sys.path.insert(0, "/home/z/my-project/scripts")
from parse_tes4 import Plugin

CORE = "/home/z/my-project/work/v156/00 Core/PathsOfEmpyrean.esp"
SPEARS = "/home/z/my-project/work/v156/20 Spears/PoE-Addon-Spears.esp"

TARGET_SUBSTR = (
    "SF_K_ArmorClothingIntimidating", "SF_K_ConcealsFace",
    "SF_K_Disguise", "WAF_MaterialFaction", "WAF_WeapMaterialFaction",
    "WAF_ArmorMaterialDraugr", "OCF_WeapTypeWarhammer",
    "SF_K_MaterialMastery",
)

# 1. карта EDID -> formID для KYWD core (вкл. Update-namespace инъекции)
core = Plugin(CORE)
spears = Plugin(SPEARS)
kw_by_edid = {}
for p, tag in ((core, "core"), (spears, "spears")):
    for fid, r in p.records.items():
        if r["type"] == "KYWD" and r["edid"]:
            kw_by_edid[r["edid"]] = (fid, tag)
targets = {edid: v for edid, v in kw_by_edid.items()
           if any(s in edid for s in TARGET_SUBSTR)}
print(f"целевых KYWD в PoE: {len(targets)}")
for edid, (fid, tag) in sorted(targets.items()):
    print(f"  {edid:45s} {fid:#010x} ({tag})")

# глобальная карта: formID(raw, в терминах core idx) -> EDID
fid_to_edid = {}
for fid, r in core.records.items():
    if r["type"] == "KYWD" and r["edid"]:
        fid_to_edid[fid] = r["edid"]
# + ваниль/Update-namespace (idx 0/1) — резолвим через targets
vanilla_map = {}
for edid, (fid, tag) in targets.items():
    if tag == "core" and (fid >> 24) in (0, 1):
        vanilla_map[fid] = edid

def ctda_params(r):
    """все CTDA: (oper, func, p1, p2) — раскладка Этапа 96 (perkdump96.py)."""
    out = []
    for st, sd in r["subs"]:
        if st != "CTDA" or len(sd) < 24:
            continue
        oper = sd[0]
        func = struct.unpack_from("<I", sd, 8)[0]
        p1 = struct.unpack_from("<I", sd, 12)[0]
        p2 = struct.unpack_from("<I", sd, 16)[0]
        out.append((oper, func, p1, p2))
    return out

def name_of(kw):
    if kw in fid_to_edid:
        return fid_to_edid[kw]
    if kw in vanilla_map:
        return vanilla_map[kw]
    kwr = core.records.get(kw) or spears.records.get(kw)
    if kwr and kwr["type"] == "KYWD" and kwr["edid"]:
        return kwr["edid"]
    return None

# 2. скан всех записей core+spears на CTDA с целевыми ключами
# раскладка CTDA (проверена Этапом 96): oper@0, value@4(f32), func@8(u32),
# p1@12, p2@16. HasKeyword в старой нумерации SE = 448; сканим ВСЕ функции,
# у которых p1/p1 резолвится в целевой KYWD — покрывает и другие ф-и.
print("\n=== использование в условиях (CTDA, любой func, p1/p2 = целевой KYWD) ===")
users = {}
for p, tag in ((core, "core"), (spears, "spears")):
    for fid, r in p.records.items():
        if r["type"] in ("KYWD",):
            continue
        cts = ctda_params(r)
        if not cts:
            continue
        for oper, func, p1, p2 in cts:
            for prm in (p1, p2):
                nm = name_of(prm)
                if nm and any(s in nm for s in TARGET_SUBSTR):
                    users.setdefault(nm, []).append(
                        (tag, r["type"], fid, r["edid"], r.get("full"), func))
if not users:
    print("НИЧЕГО: условия на целевые ключи не найдены (PERK/SPEL/MGEF и др.)")

for nm in sorted(users):
    lst = users[nm]
    print(f"\n-- {nm}: {len(lst)} записей-пользователей")
    for tag, t, fid, edid, full, func in lst[:10]:
        print(f"   [{tag}] {t} {fid:#010x} [{edid}] «{full}» func={func}")
    if len(lst) > 10:
        print(f"   … ещё {len(lst)-10}")

# 3. где ещё ключевик упоминается: BGSReferenceEffect? PERK эффекты?
# сканщипаем только CTDA (основной канал) + KFFZ/WKMZ не бывает у ключей.
# Дополнительно: Conditions в AVIF/MGEF лежат так же в CTDA — покрыто.

# 4. а что даёт KID-ини самим 25 записям — таблица соответствия уже в
# kid_poe_analysis.py; здесь фиксируем итоговую связку.
print("\n=== сводка ===")
print(f"KYWD-целей: {len(targets)}; записей с CTDA на них: "
      f"{sum(len(v) for v in users.values())}")
