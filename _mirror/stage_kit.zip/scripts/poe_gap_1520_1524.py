#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Характеризация разрыва v1.5.20 (пак истины) -> v1.5.24 (аплоад игрока).

Дамп текстовых полей всех ESP обоих zip + пофайловый дифф.
Пути:
  /home/z/my-project/poe/handoff/Paths of Empyrean RU 1.5.zip  (v1.5.20)
  /home/z/my-project/upload/Paths of Empyrean RU 1.5 (1).zip   (v1.5.24)
"""
import sys, os, json, zipfile
sys.path.insert(0, '/home/z/my-project/poe/handoff/scripts')

TEXT_FIELDS = {'FULL', 'DESC', 'ITXT', 'NNAM'}

def decode(b):
    return b.rstrip(b'\x00').decode('utf-8', 'replace')

def dump_esp(path, tag, out):
    from parse_tes4 import Plugin
    p = Plugin(path)
    for formid, r in p.records.items():
        rtype = r['type']
        edid = r.get('edid') or ''
        occ = {}
        for st, sd in r['subs']:
            text = None
            if st in TEXT_FIELDS:
                if st == 'NNAM' and rtype == 'PERK':
                    continue
                text = decode(sd)
            elif st == 'DNAM' and rtype == 'MGEF':
                try:
                    cand = sd.rstrip(b'\x00').decode('utf-8')
                except UnicodeDecodeError:
                    cand = None
                if cand:
                    ctrl = sum(1 for c in cand if ord(c) < 32 and c != '\n')
                    letters = sum(1 for c in cand if c.isalpha())
                    spaces = cand.count(' ')
                    if ctrl == 0 and letters >= 4 and (spaces >= 1 or len(cand) <= 64):
                        text = cand
            elif st == 'DATA' and rtype == 'GMST':
                if edid.startswith('s'):
                    text = decode(sd)
            if text is None:
                continue
            key = (rtype, formid, st)
            occ[key] = occ.get(key, 0) + 1
            rec = {'file': tag, 'rtype': rtype, 'formid': f'{formid:08X}',
                   'edid': edid, 'field': st, 'occ': occ[key], 'text': text}
            out.write(json.dumps(rec, ensure_ascii=False) + '\n')

def dump_zip(zippath, outpath):
    z = zipfile.ZipFile(zippath)
    esp_list = []
    with open(outpath, 'w', encoding='utf-8') as out:
        for info in z.infolist():
            n = info.filename
            if n.lower().endswith('.esp'):
                esp_list.append(n)
                tag = os.path.basename(os.path.dirname(n)) + '/' + os.path.basename(n)
                tmp = '/tmp/_esp_extract.esp'
                with open(tmp, 'wb') as f:
                    f.write(z.read(n))
                dump_esp(tmp, tag, out)
    return esp_list

def main():
    os.makedirs('/tmp/poe_gap', exist_ok=True)
    p20 = '/home/z/my-project/poe/handoff/Paths of Empyrean RU 1.5.zip'
    p24 = '/home/z/my-project/upload/Paths of Empyrean RU 1.5 (1).zip'
    esp20 = dump_zip(p20, '/tmp/poe_gap/dump_v1520.jsonl')
    esp24 = dump_zip(p24, '/tmp/poe_gap/dump_v1524.jsonl')

    def load(fp):
        d = {}
        for line in open(fp, encoding='utf-8'):
            r = json.loads(line)
            k = (r['file'], r['rtype'], r['formid'], r['field'], r['occ'])
            d[k] = r['text']
        return d

    d20, d24 = load('/tmp/poe_gap/dump_v1520.jsonl'), load('/tmp/poe_gap/dump_v1524.jsonl')
    keys20, keys24 = set(d20), set(d24)
    added = keys24 - keys20
    removed = keys20 - keys24
    changed = [k for k in keys20 & keys24 if d20[k] != d24[k]]
    print('ESP 20:', len(esp20), 'ESP 24:', len(esp24))
    print('полей 20:', len(d20), 'полей 24:', len(d24))
    print('добавлено полей:', len(added), '| удалено:', len(removed), '| изменено:', len(changed))
    byfile = {}
    for k in changed:
        byfile[k[0]] = byfile.get(k[0], 0) + 1
    print('изменения по файлам:')
    for f, c in sorted(byfile.items()):
        print(f'  {f}: {c}')
    with open('/tmp/poe_gap/changed.jsonl', 'w', encoding='utf-8') as fo:
        for k in sorted(changed):
            fo.write(json.dumps({'key': list(k), 'old': d20[k], 'new': d24[k]}, ensure_ascii=False) + '\n')
    if added:
        with open('/tmp/poe_gap/added.jsonl', 'w', encoding='utf-8') as fo:
            for k in sorted(added):
                fo.write(json.dumps({'key': list(k), 'text': d24[k]}, ensure_ascii=False) + '\n')
    if removed:
        with open('/tmp/poe_gap/removed.jsonl', 'w', encoding='utf-8') as fo:
            for k in sorted(removed):
                fo.write(json.dumps({'key': list(k), 'text': d20[k]}, ensure_ascii=False) + '\n')

    # дифф INI/TXT-файлов
    z20, z24 = zipfile.ZipFile(p20), zipfile.ZipFile(p24)
    names20 = set(z20.namelist()); names24 = set(z24.namelist())
    print('\nфайлы только в 20:', sorted(names20 - names24))
    print('файлы только в 24:', sorted(names24 - names20))
    for n in sorted(names20 & names24):
        if n.lower().endswith(('.ini', '.txt')):
            b20, b24 = z20.read(n), z24.read(n)
            if b20 != b24:
                l20, l24 = b20.decode('utf-8', 'replace').splitlines(), b24.decode('utf-8', 'replace').splitlines()
                import difflib
                dl = [l for l in difflib.unified_diff(l20, l24, lineterm='', n=0)]
                print(f'\n=== INI diff {n} ({len(dl)} строк) ===')
                for l in dl[:80]:
                    print(l)

if __name__ == '__main__':
    main()
