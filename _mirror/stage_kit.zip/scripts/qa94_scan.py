#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 94: атомарный QA/QC-скан ВЫСОКОГО РАЗРЕШЕНИЯ по дампу v1.5.5 (текущий мастер).

Вход:  work/qa94/dump_v155.jsonl (13 146 текстовых полей всего пакета)
       work/qa89/dump_ru149.jsonl (RU 1.4.9 — эталон имён перков)
Выход: work/qa94/scan_report.txt + выборочные TSV.

Аналитический скрипт: НИЧЕГО не правит.
"""
import json, re, os

QA = '/home/z/my-project/work/qa94'
DUMP = os.path.join(QA, 'dump_v155.jsonl')
R149 = '/home/z/my-project/work/qa89/dump_ru149.jsonl'

# Санкции и политики (не репортить как ошибку):
SANCTION_EN_FIELDS = {('MGEF', 'FULL'), ('SPEL', 'FULL'), ('QUST', 'FULL'),
                      ('ENCH', 'FULL'), ('RACE', 'FULL')}
NO_TRANSLATE_RTYPES = {'CLAS', 'FACT', 'HDPT', 'WOOP'}

TOKEN_RE = re.compile(r'<[^<>]*>|%[sdf0-9.\-]*|\[[^\[\]]*\]')

recs = [json.loads(l) for l in open(DUMP, encoding='utf-8')]
print('загружено полей:', len(recs))

out = open(os.path.join(QA, 'scan_report.txt'), 'w', encoding='utf-8')
tsv = {}


def w(s=''):
    out.write(s + '\n')


def open_tsv(name, header):
    f = open(os.path.join(QA, name), 'w', encoding='utf-8')
    f.write(header + '\n')
    tsv[name] = f
    return f


def key_of(r):
    return (r['file'], r['rtype'], r['formid'], r['field'], r['occ'])


# ---------------------------------------------------------------- 1. ЛИНТ
def lint_problems(text, rtype, field):
    p = []
    if '  ' in text:
        p.append('двойной пробел')
    if re.search(r' [,.;:!?)]', text) or re.search(r'[(] ', text):
        p.append('пробел у пунктуации')
    if 'ё' in text or 'Ё' in text:
        p.append('буква ё')
    if '"' in text:
        p.append('прямые кавычки')
    if '—' in text or '–' in text:
        p.append('длинное тире')
    tl = text.lower()
    if 'рейтинг брони' in tl:
        p.append('рейтинг брони (запрет)')
    if 'при вступлении в бой' in tl:
        p.append('при вступлении в бой')
    if '..' in text or ',,' in text or ';;' in text:
        p.append('двойная пунктуация')
    if text.count('«') != text.count('»'):
        p.append('некруг ёлочек')
    if text != text.rstrip(' '):
        p.append('пробел в конце')
    if '\r' in text:
        p.append('CR в тексте')
    if re.search(r'(?<!\n)\n(?!\n)', text):
        p.append('одиночный \\n')
    if rtype == 'PERK' and field == 'DESC' and len(text) > 290:
        p.append(f'PERK DESC длиннее 290 ({len(text)})')
    return p


w('=' * 72)
w('1. ЛИНТ СТИЛЯ (весь корпус, включая INI/iface)')
w('=' * 72)
lint_f = open_tsv('lint.tsv', 'file\trtype\tformid\tfield\tocc\tproblems\ttext')
n_lint = 0
for r in recs:
    if r['file'] == 'main' and r['rtype'] == 'GMST':
        continue  # GMST с токенами % — отдельно
    probs = lint_problems(r['text'], r['rtype'], r['field'])
    if probs:
        n_lint += 1
        lint_f.write('%s\t%s\t%s\t%s\t%d\t%s\t%s\n' % (
            r['file'], r['rtype'], r['formid'], r['field'], r['occ'],
            ';'.join(probs), r['text'].replace('\n', '\\n')[:200]))
w(f'полей с проблемами линта: {n_lint} (детали: lint.tsv)')

# GMST-линт отдельно, без '\n'-проверок (там плейсхолдеры)
w()
w('-- GMST (s*) с проблемами (кроме одиночного \\n):')
for r in recs:
    if r['file'] == 'main' and r['rtype'] == 'GMST':
        t = r['text']
        probs = []
        if '  ' in t:
            probs.append('двойной пробел')
        if 'ё' in t or 'Ё' in t:
            probs.append('ё')
        if t.count('«') != t.count('»'):
            probs.append('некруг ёлочек')
        if probs:
            w(f"  {r['formid']} {probs}: {t[:120]}")

# ---------------------------------------------------- 2. EN-ОСТАТКИ
w()
w('=' * 72)
w('2. EN-ОСТАТКИ (латиница вне санкций 586/605 и токенов)')
w('=' * 72)
en_f = open_tsv('en_residuals.tsv', 'file\trtype\tformid\tedid\tfield\tocc\tlatin\ttext')
n_en = 0
for r in recs:
    if (r['rtype'], r['field']) in SANCTION_EN_FIELDS:
        continue
    if r['rtype'] in NO_TRANSLATE_RTYPES:
        continue
    if r['file'] == 'main' and r['rtype'] == 'QUST' and r['field'] == 'NNAM':
        continue  # 9 «спящих» NNAM — санкция этапа 92
    t = TOKEN_RE.sub(' ', r['text'])
    words = re.findall(r"[A-Za-z][A-Za-z'.\-]*", t)
    if words:
        n_en += 1
        en_f.write('%s\t%s\t%s\t%s\t%s\t%d\t%s\t%s\n' % (
            r['file'], r['rtype'], r['formid'], r.get('edid', ''), r['field'], r['occ'],
            ' '.join(words), r['text'].replace('\n', '\\n')[:160]))
w(f'полей с латиницей вне санкций: {n_en} (детали: en_residuals.tsv)')

# ------------------------------------- 3. ОСТАТКИ ПЕРЕИМЕНОВАНИЙ 93/94
w()
w('=' * 72)
w('3. ОСТАТКИ СТАРЫХ ТЕРМИНОВ (переименования этапов 93/94 должны быть полными)')
w('=' * 72)
term_f = open_tsv('term_leftovers.tsv', 'search\tfile\trtype\tformid\tfield\tocc\ttext')
TERMS = [
    ('психическая связь', lambda t: 'психическ' in t.lower()),
    ('Сложить оружие', lambda t: 'Сложить оружие' in t),
    ('Беззвучный взмах', lambda t: 'Беззвучный взмах' in t),
    ('Сигилы', lambda t: 'Сигилы' in t),
    ('Вызов метели', lambda t: 'Вызов метели' in t),
    ('чародейка', lambda t: 'чародейк' in t.lower()),
    ('питомец-лошадь', lambda t: re.search(r'питомец[- ]?лошад', t, re.I) is not None),
    ('злоби', lambda t: 'злоби' in t.lower()),
    ('изнеможение', lambda t: 'изнеможени' in t.lower()),
    ('Сильный искатель', lambda t: re.search(r'сильн\w* искател', t, re.I) is not None),
    ('сильная стаада', lambda t: re.search(r'сильн\w* стаада', t, re.I) is not None),
    ('анимус', lambda t: 'анимус' in t.lower()),
]
for name, fn in TERMS:
    hits = [r for r in recs if fn(r['text'])]
    w(f'{name}: {len(hits)}')
    for r in hits:
        term_f.write('%s\t%s\t%s\t%s\t%s\t%d\t%s\n' % (
            name, r['file'], r['rtype'], r['formid'], r['field'], r['occ'],
            r['text'].replace('\n', '\\n')[:160]))
        w(f"  {r['file']} {r['rtype']} {r['formid']} {r['field']}: "
          f"{r['text'][:120].replace(chr(10), ' | ')}")

# ------------------------------------------------ 4. СЕМЬИ ТЕРМИНОВ
w()
w('=' * 72)
w('4. СЕМЬИ ТЕРМИНОВ (консистентность после вердиктов)')
w('=' * 72)
fam_f = open_tsv('families.tsv', 'family\tfile\trtype\tformid\tedid\tfield\ttext')
for fam_name, pat in [
        ('сумрак', re.compile(r'умра', re.I)),
        ('искатель', re.compile(r'скат', re.I)),
        ('стаада', re.compile(r'[сС]таада')),
        ('дремор', re.compile(r'дремор', re.I)),
        ('ментальн', re.compile(r'ентальн', re.I))]:
    hits = [r for r in recs if pat.search(r['text'])]
    w(f'-- {fam_name}: {len(hits)} вхождений')
    for r in hits:
        fam_f.write('%s\t%s\t%s\t%s\t%s\t%s\t%d\t%s\n' % (
            fam_name, r['file'], r['rtype'], r['formid'], r.get('edid', ''), r['field'], r['occ'],
            r['text'].replace('\n', '\\n')[:160]))

# --------------------------- 5. ТИРЫ ЗАЧАРОВАНИЙ (консистентность по EDID)
w()
w('=' * 72)
w('5. ТИРЫ ЗАЧАРОВАНИЙ: группы (семейство, номер) с РАЗНЫМИ словами тира')
w('=' * 72)
FAM_RE = re.compile(
    r'(AbsorbHealth|AbsorbMagicka|AbsorbStamina|SoulTrap|Magicka|Stamina|Fear|Banish|Chaos|Frost|Shock|Turn)(\d{1,2})')
groups = {}
for r in recs:
    if r['field'] != 'FULL':
        continue
    if not (r['rtype'] == 'WEAP' or r['file'] == 'ShortbowNames'):
        continue
    m = FAM_RE.search(r.get('edid') or r['formid'])
    if not m:
        continue
    fam, num = m.group(1), int(m.group(2))
    tail = r['text'].split()[-1] if r['text'].split() else ''
    groups.setdefault((fam, num), set()).add(tail)
n_conf = 0
tier_f = open_tsv('tier_conflicts.tsv', 'fam\tnum\ttails\tfiles')
for (fam, num), tails in sorted(groups.items()):
    if len(tails) > 1:
        n_conf += 1
        tier_f.write('%s\t%d\t%s\t\n' % (fam, num, ' | '.join(sorted(tails))))
        w(f'КОНФЛИКТ {fam}#{num}: {sorted(tails)}')
w(f'групп всего: {len(groups)}, конфликтов: {n_conf}')
w()
w('-- полная карта (fam#num -> слово):')
for (fam, num) in sorted(groups):
    w(f'  {fam}#{num}: {sorted(groups[(fam, num)])}')

# ------------------------------------------- 6. СЛИТКИ / КАТЕГОРИИ / КАПКАН
w()
w('=' * 72)
w('6. GMST / слитки / руда / категории / капкан / «Заучить:»')
w('=' * 72)
for label, pat in [('слиток', re.compile(r'слит', re.I)),
                   ('сталгрим', re.compile(r'сталгрим', re.I)),
                   ('руда', re.compile(r'руд', re.I)),
                   ('жвалы/капкан', re.compile(r'[жЖ]валы|схлопыв', re.I)),
                   ('заучить', re.compile(r'аучить', re.I))]:
    hits = [r for r in recs if pat.search(r['text'])]
    w(f'-- {label}: {len(hits)}')
    for r in hits:
        w(f"  [{r['file']} {r['rtype']} {r['formid']} {r['field']}#{r['occ']}] "
          f"{r['text'][:150].replace(chr(10), ' | ')}")

# ------------------------------------------------ 7. ПЕРКИ: v155 vs 1.4.9
w()
w('=' * 72)
w('7. ПЕРКИ: расхождения имён v1.5.5 vs 1.4.9 (ТОЛЬКО рекомендации, не патчить)')
w('=' * 72)
r149 = {}
for line in open(R149, encoding='utf-8'):
    r = json.loads(line)
    if r['rtype'] == 'PERK' and r['field'] == 'FULL':
        r149[r['formid']] = (r['edid'], r['text'])
perk_f = open_tsv('perk_diff_v149.tsv', 'formid\tedid\tv155\tv149\tstatus')
n_diff = n_new = 0
for r in recs:
    if r['file'] == 'main' and r['rtype'] == 'PERK' and r['field'] == 'FULL':
        cur = r['text']
        old = r149.get(r['formid'])
        if old is None:
            n_new += 1
            perk_f.write('%s\t%s\t%s\t%s\tNEW\n' % (r['formid'], r.get('edid', ''), cur, ''))
        elif old[1] != cur:
            n_diff += 1
            perk_f.write('%s\t%s\t%s\t%s\tDIFF\n' % (r['formid'], r.get('edid', ''), cur, old[1]))
            w(f"  {r['formid']} {r.get('edid', '')}: «{cur}»  (1.4.9: «{old[1]}»)")
w(f'перков v155: расхождений с 1.4.9: {n_diff}, новых (нет в 1.4.9): {n_new}')

# ------------------------------------------------------------- 8. ДВОЙНИКИ
w()
w('=' * 72)
w('8. ТОЧНЫЕ ДУБЛИ FULL в ESP (инвентарные коллизии не ловим — только одинаковые имена)')
w('=' * 72)
seen_names = {}
for r in recs:
    if r['field'] == 'FULL' and r['rtype'] in ('WEAP', 'ARMO', 'AMMO', 'MISC', 'INGR', 'ALCH', 'SCRL', 'SLGM', 'BOOK'):
        seen_names.setdefault((r['file'], r['text']), []).append(r['formid'])
dups = {k: v for k, v in seen_names.items() if len(v) > 1}
w(f'дублирующихся имён предметов: {len(dups)}')
for (f, t), ids in sorted(dups.items()):
    w(f'  {f}: «{t[:80]}» x{len(ids)}: {ids[:8]}')

w()
w('scan_report.txt готов.')
out.close()
for f in tsv.values():
    f.close()
print('OK ->', QA)
