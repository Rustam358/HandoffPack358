#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 116: входной CRC-контроль базы игрока [T43].
user zip «Paths of Empyrean RU 1.5 (9).zip» против нашей записи выпуска v1.5.16:
1) md5 АРХИВА == md5 из report_115 (687c057356f4ebd5b519dee0712c0ddd);
2) 63 записи, testzip, info.xml = 1.5.16;
3) пофайловая CRC против download-пакета (текущий = v1.5.16; после сборки
   v1.5.17 download уедет — потому сверка выполняется ДО сборки);
4) артефакт [T49]: референс-дерево work/qa115/release116 частично протухло
   (info.xml остался 1.5.15 при свежих ESP) — деревом больше не сверяемся,
   сверка по md5-архива + пофайлово с текущим download-zip.
"""
import zipfile, hashlib, os

USER = "/home/z/my-project/upload/Paths of Empyrean RU 1.5 (9).zip"
DL = "/home/z/my-project/download/Paths of Empyrean RU 1.5.zip"
V116_MD5 = "687c057356f4ebd5b519dee0712c0ddd"  # запись выпуска v1.5.16 (report_115)

user_md5 = hashlib.md5(open(USER, 'rb').read()).hexdigest()
print(f"md5 user zip (9): {user_md5}")
print(f"md5 v1.5.16 (запись выпуска): {V116_MD5}")
assert user_md5 == V116_MD5, "md5 не совпал — база (9) НЕ байт-в-байт v1.5.16!"
print("md5 АРХИВА совпал с записью выпуска — база = наш v1.5.16.")

bad = {}
with zipfile.ZipFile(USER) as zu, zipfile.ZipFile(DL) as zd:
    assert zu.testzip() is None
    nu = [i for i in zu.infolist() if not i.is_dir()]
    print(f"USER zip(9): {len(nu)} записей, testzip OK")
    assert len(nu) == 63, f"записей {len(nu)} != 63"
    info = zu.read('fomod/info.xml').decode('utf-8')
    assert '<Version>1.5.16</Version>' in info, "в базе info.xml не 1.5.16"
    print("info.xml базы: 1.5.16 — OK")
    zd_crc = {i.filename: i.CRC for i in zd.infolist() if not i.is_dir()}
    for i in nu:
        if zd_crc.get(i.filename) != i.CRC:
            bad[i.filename] = (zd_crc.get(i.filename), i.CRC)

print(f"-- пофайловая CRC vs download-zip (v1.5.16): "
      f"{63 - len(bad)}/63 совпали")
if bad:
    for k, v in sorted(bad.items()):
        print(f"   РАСХОЖДЕНИЕ: {k} (наша {v[0]}, игрок {v[1]})")
print("ВЕРДИКТ:", "база чистая (md5-архива = запись выпуска, 63/63)"
      if not bad else "ЕСТЬ РАСХОЖДЕНИЯ!")
assert not bad
