#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Компактный структурный дамп ModuleConfig.xml (любая кодировка) для сравнения RU и PT-BR FOMOD."""
import sys
import xml.etree.ElementTree as ET


def load(path):
    raw = open(path, 'rb').read()
    enc = 'utf-16' if raw[:2] in (b'\xff\xfe', b'\xfe\xff') else 'utf-8'
    txt = raw.decode(enc)
    if txt.startswith('\ufeff'):
        txt = txt[1:]
    return ET.fromstring(txt)


def esc(s, n=110):
    s = ' '.join((s or '').split())
    return (s[:n] + '…') if len(s) > n else s


def files_of(node):
    out = []
    for f in node:
        out.append('%s %r->%r' % (f.tag, f.get('source'), f.get('destination')))
    return '; '.join(out)


def td_of(plugin):
    td = plugin.find('typeDescriptor')
    if td is None:
        return '-'
    if td.get('type'):
        return 'type=' + td.get('type')
    dt = td.find('./dependencyType/defaultType')
    pats = []
    for p in td.findall('./dependencyType/patterns/pattern'):
        deps = p.find('dependencies')
        dep_s = ''
        if deps is not None:
            parts = ['%s %s=%s' % (d.tag, 'file' if d.get('file') else 'game', d.get('file') or d.get('attribute'))
                     for d in deps]
            dep_s = '%s{%s}' % (deps.get('operator', 'And'), ', '.join(parts))
        t = p.find('type')
        pats.append('%s => %s' % (dep_s, t.get('name') if t is not None else '?'))
    return 'default=%s | %s' % (dt.get('name') if dt is not None else '?', ' ;; '.join(pats))


def flags_of(plugin):
    cf = plugin.find('conditionFlags')
    if cf is None:
        return ''
    return ' [flags: ' + ', '.join('%s=%s' % (f.get('name'), (f.text or '').strip()) for f in cf) + ']'


def dump(path, label):
    root = load(path)
    print('=' * 100)
    print('%s : %s' % (label, path))
    print('moduleName   = %r' % (root.findtext('moduleName', '').strip()))
    mi = root.find('moduleImage')
    print('moduleImage  = %r' % (mi.get('path') if mi is not None else None))
    rif = root.find('requiredInstallFiles')
    print('requiredInst = %s' % (files_of(rif) if rif is not None else 'NONE'))
    steps = root.findall('./installSteps/installStep')
    print('installSteps = %d, order=%s' % (len(steps), root.find('installSteps').get('order')))
    for step in steps:
        print('STEP %r' % step.get('name'))
        grps = step.findall('./optionalFileGroups/group')
        print('  groups: %d (order=%s)' % (len(grps), step.find('optionalFileGroups').get('order')))
        for grp in grps:
            print('  GROUP %r type=%s' % (grp.get('name'), grp.get('type')))
            for pl in grp.findall('./plugins/plugin'):
                img = pl.find('image')
                print('    PLUGIN %r%s' % (pl.get('name'), flags_of(pl)))
                print('      image  = %r' % (img.get('path') if img is not None else None))
                print('      files  = %s' % (files_of(pl.find('files')) if pl.find('files') is not None else '(none)'))
                print('      typeD  = %s' % td_of(pl))
                print('      desc   = %s' % esc(pl.findtext('description', '')))
    print()


if __name__ == '__main__':
    dump(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else 'CFG')
