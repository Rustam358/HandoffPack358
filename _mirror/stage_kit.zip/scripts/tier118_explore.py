#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 118: разведка тиражных лестниц в EN 1.4 vs RU v1.5.18.

Выравнивание по (file, formid, rtype, field, occ). Аналитика: ничего не правит.
"""
import json
from collections import defaultdict, Counter

RU = [json.loads(l) for l in open('/home/z/my-project/work/qa117/dump_v118_full.jsonl', encoding='utf-8')]
EN = [json.loads(l) for l in open('/home/z/my-project/work/qa118/dump_en14.jsonl', encoding='utf-8')]

ru_map = {}
for r in RU:
    ru_map[(r['file'], r['formid'], r['rtype'], r['field'], r.get('occ', 1))] = r
en_map = {}
for r in EN:
    en_map[(r['file'], r['formid'], r['rtype'], r['field'], r.get('occ', 1))] = r

aligned = []
ru_only = 0
en_only = 0
for k, r in ru_map.items():
    e = en_map.get(k)
    if e is None:
        ru_only += 1
    aligned.append((r, e))
for k in en_map:
    if k not in ru_map:
        en_only += 1
print(f'выравнено: {len(aligned)}, RU без EN: {ru_only}, EN без RU: {en_only}')

json.dump([{**{'ru_text': r['text'], 'edid': r.get('edid', ''), 'en_text': (e['text'] if e else None)},
            **{kk: r[kk] for kk in ('file', 'rtype', 'formid', 'field', 'occ')}} for r, e in aligned],
           open('/home/z/my-project/work/qa118/aligned.json', 'w', encoding='utf-8'),
           ensure_ascii=False)
print('OK -> work/qa118/aligned.json')

# ---- разведка WEAP FULL: префикс имени (первое слово) ----
print('\n=== WEAP FULL: первые слова EN (топ-40) ===')
first = Counter()
for r, e in aligned:
    if r['rtype'] == 'WEAP' and r['field'] == 'FULL' and e:
        w = e['text'].split()
        if w:
            first[w[0]] += 1
for w, n in first.most_common(40):
    print(f'  {w}: {n}')

print('\n=== ARMO FULL: первые слова EN (топ-40) ===')
first = Counter()
for r, e in aligned:
    if r['rtype'] == 'ARMO' and r['field'] == 'FULL' and e:
        w = e['text'].split()
        if w:
            first[w[0]] += 1
for w, n in first.most_common(40):
    print(f'  {w}: {n}')
