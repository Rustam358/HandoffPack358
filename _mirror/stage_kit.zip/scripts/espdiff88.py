#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 88: байтовый диф EN-оригинала vs нашего RU ESP.
Доказательство для пункта 1 директивы: наши правки НЕ трогают ничего,
кроме текстовых субрекордов (=> PEX-хуки/FormID-ссылки/VMAD целы).
Канон текстовых полей: FULL, DESC, ITXT, NNAM (кроме PERK), DNAM (MGEF), DATA (GMST s*).
"""
import sys, struct, zlib
sys.path.insert(0, '/home/z/my-project/scripts')
from parse_tes4 import Plugin  # noqa

TEXT_FIELDS = {'FULL', 'DESC', 'ITXT'}
ALLOWED = {
    ('MGEF', 'DNAM'), ('GMST', 'DATA'),
}

def is_text_field(rtype, st):
    if st in TEXT_FIELDS:
        return not (st == 'NNAM' and rtype == 'PERK')  # PERK NNAM = бинарная ссылка
    if (rtype, st) in ALLOWED:
        # GMST DATA текстовый только для строковых GMST (EDID начинается с 's')
        if rtype == 'GMST':
            return True  # проверка EDID ниже
    return False

def rec_map(p):
    out = {}
    for fid, r in p.records.items():
        subs = []
        for st, sd in r['subs']:
            subs.append((st, bytes(sd)))
        out[fid] = (r['type'], r.get('edid') or '', subs)
    return out

def diff(en_path, ru_path, name):
    en = Plugin(en_path)
    ru = Plugin(ru_path)
    em, rm = rec_map(en), rec_map(ru)
    print(f'=== {name}: EN records={len(em)} RU records={len(rm)}')
    only_en = set(em) - set(rm)
    only_ru = set(rm) - set(em)
    if only_en:
        print(f'  !! записей только в EN: {len(only_en)}: ' + ', '.join(f'{f:08X}' for f in sorted(only_en)[:8]))
    if only_ru:
        print(f'  !! записей только в RU: {len(only_ru)}: ' + ', '.join(f'{f:08X}' for f in sorted(only_ru)[:8]))
    # субрекордный диф
    diff_kinds = {}
    n_recs_changed = 0
    for fid in set(em) & set(rm):
        te, ee, se = em[fid]
        tr, er, sr = rm[fid]
        if te != tr:
            diff_kinds.setdefault('RTYPE', []).append(fid)
        if ee != er:
            diff_kinds.setdefault('EDID', []).append(fid)
        # сравнение субрекордов: EN-подпоследовательность -> RU (по порядку, с выравниванием замен)
        if se == sr:
            continue
        n_recs_changed += 1
        # быстрая карта: multiset субтипов
        from collections import Counter
        ce, cr = Counter(s for s, _ in se), Counter(s for s, _ in sr)
        if ce != cr:
            # изменился НАБОР субрекордов (не только содержимое) — внести в отчёт
            de = ce - cr
            dr = cr - ce
            diff_kinds.setdefault('SUBSET', []).append((fid, dict(de), dict(dr)))
            continue
        # сравнение payload по типам: уникальные типы сравним напрямую; повторяющиеся — выравнивание по порядку
        seen = {}
        i = j = 0
        while i < len(se) and j < len(sr):
            st1, d1 = se[i]
            st2, d2 = sr[j]
            if st1 != st2:
                # сдвиг выравнивания
                diff_kinds.setdefault(f'ORDER:{st1}->{st2}', []).append(fid)
                i += 1; j += 1
                continue
            is_text = is_text_field(te, st1)
            if is_text or d1 != d2:
                key = st1 if is_text else f'BIN:{st1}'
                if d1 != d2:
                    diff_kinds.setdefault(key, []).append(fid)
            i += 1; j += 1
    print(f'  записей с изменённым содержимым: {n_recs_changed}')
    for k in sorted(diff_kinds):
        v = diff_kinds[k]
        mark = '' if (k in ('FULL', 'DESC', 'ITXT', 'NNAM') or k.startswith('BIN:DNAM') or k == 'BIN:DATA') else '   <-- НЕ-ТЕКСТОВОЕ'
        print(f'  {k:22} x{len(v):5} {mark}')
        if mark and len(v) <= 6:
            for fid in v[:6]:
                print(f'      {fid:08X}')
    return diff_kinds

if __name__ == '__main__':
    base_en = '/home/z/my-project/work/handoff/08_оригинал_1.4_EN/полный_разбор_1.4/PoE 1.4'
    base_ru = '/home/z/my-project/work/v148'
    diff(f'{base_en}/PathsOfEmpyrean.esp', f'{base_ru}/00 Core/PathsOfEmpyrean.esp', 'main ESP')
    diff(f'{base_en}/PoE-Addon-MissingShields.esp', f'{base_ru}/10 Missing Shields/PoE-Addon-MissingShields.esp', 'MissingShields')
    diff(f'{base_en}/PoE-Addon-Spears.esp', f'{base_ru}/20 Spears/PoE-Addon-Spears.esp', 'Spears')
