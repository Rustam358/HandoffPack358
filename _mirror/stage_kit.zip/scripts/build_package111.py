#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 111, шаг 2: сборка пакета v1.5.12.

База = user zip (upload/Paths of Empyrean RU 1.5 (3).zip) — наш v1.5.11 с
правкой игрока в MCM ($Forsworn: «Изгнанники» -> «Изгои», tab -> пробел).

Замены (ровно 4 записи):
  1. 00 Core/PathsOfEmpyrean.esp             <- work/qa111/v112 (31 патч, master111)
  2. .../PathsOfEmpyrean_ShortbowNames.ini   <- work/qa111/v112 (1 патч: Короткий лук Изгоев)
  3. 00 Core/Interface/Translations/PathsOfEmpyrean_RUSSIAN.txt
     = правка игрока ПОГЛОЩЕНА: сохраняем слово «Изгои», восстанавливаем
     tab-разделитель (\x20 -> \x09) как во всех остальных строках файла (UTF-16LE).
  4. fomod/info.xml: Version 1.5.11 -> 1.5.12.

Выход: download/Paths of Empyrean RU 1.5.zip + зеркало work/ru15.
"""
import zipfile, os, hashlib, shutil

SRC_ZIP = '/home/z/my-project/upload/Paths of Empyrean RU 1.5 (3).zip'
DST = '/home/z/my-project/download/Paths of Empyrean RU 1.5.zip'
V112 = '/home/z/my-project/work/qa111/v112'
ARC_ESP = '00 Core/PathsOfEmpyrean.esp'
ARC_SBN = '00 Core/SKSE/Plugins/POE/Weapon/PathsOfEmpyrean_ShortbowNames.ini'
ARC_MCM = '00 Core/Interface/Translations/PathsOfEmpyrean_RUSSIAN.txt'
RU15 = '/home/z/my-project/work/ru15'

KEY = '$Forsworn'.encode('utf-16le')          # 9 символов = 18 байт
OLD_SP = b'\x20\x00'                          # пробел после ключа (правка игрока)
NEW_TAB = b'\x09\x00'                         # tab (формат остальных строк)
GOI = 'Изгои'.encode('utf-16le')
LEGACY = 'Изгнанники'.encode('utf-16le')


def main():
    esp = open(f'{V112}/00 Core/PathsOfEmpyrean.esp', 'rb').read()
    sbn = open(f'{V112}/{ARC_SBN}', 'rb').read()
    md5_esp = hashlib.md5(esp).hexdigest()
    md5_sbn = hashlib.md5(sbn).hexdigest()

    zsrc = zipfile.ZipFile(SRC_ZIP)
    names = zsrc.namelist()
    orig_crc = {i.filename: i.CRC for i in zsrc.infolist()}
    print('источник: user zip v1.5.11 (%d записей, md5 4f2c39d9...)' % len(names))

    # --- санити источника ---
    raw_mcm = zsrc.read(ARC_MCM)
    assert raw_mcm.count(KEY + OLD_SP + GOI) == 1, 'правка игрока $Forsworn не найдена'
    assert LEGACY not in raw_mcm, 'в MCM ещё есть Изгнанники?'
    info_src = zsrc.read('fomod/info.xml').decode('utf-8')
    assert '<Version>1.5.11</Version>' in info_src
    print('санити: MCM содержит $Forsworn<пробел>Изгои (правка игрока); info = 1.5.11')

    mcm_new = raw_mcm.replace(KEY + OLD_SP + GOI, KEY + NEW_TAB + GOI, 1)
    assert mcm_new.count(KEY + NEW_TAB + GOI) == 1
    assert KEY + OLD_SP + GOI not in mcm_new
    # остальные строки файла — с tab: правка не задела ничего больше
    assert len(mcm_new) == len(raw_mcm), 'длина MCM изменилась?!'
    print('MCM: tab восстановлен байт-в-байт (длина файла неизменна)')

    info_new = info_src.replace('<Version>1.5.11</Version>', '<Version>1.5.12</Version>')
    assert '<Version>1.5.12</Version>' in info_new and '1.5.11' not in info_new
    print('info.xml: Version 1.5.11 -> 1.5.12')

    # --- сборка zip ---
    ref_info = zsrc.getinfo('fomod/info.xml')
    repl = {ARC_ESP: esp, ARC_SBN: sbn, ARC_MCM: mcm_new, 'fomod/info.xml': info_new.encode('utf-8')}
    zout = zipfile.ZipFile(DST, 'w')
    for item in zsrc.infolist():
        arc = item.filename
        if arc in repl:
            zout.writestr(item, repl[arc])
        else:
            zout.writestr(item, zsrc.read(arc))
    zout.close()
    print('zip собран')

    # ================= ВЕРИФИКАЦИЯ =================
    print()
    print('=== ВЕРИФИКАЦИЯ ПАКЕТА v1.5.12 ===')
    z2 = zipfile.ZipFile(DST)
    names2 = z2.namelist()
    assert z2.testzip() is None
    assert len(names2) == 63 and set(names2) == set(names)
    print('testzip: OK, записей: %d (набор совпадает)' % len(names2))

    diff = [n for n in names if orig_crc[n] != z2.getinfo(n).CRC]
    assert set(diff) == set(repl), 'CRC-дифф: %s' % diff
    print('CRC: изменены ровно 4 записи (ESP, ShortbowNames, RUSSIAN.txt, info.xml), '
          'остальные %d байт-в-байт' % (len(names) - 4))

    got_esp = z2.read(ARC_ESP)
    assert hashlib.md5(got_esp).hexdigest() == md5_esp
    got_sbn = z2.read(ARC_SBN)
    assert hashlib.md5(got_sbn).hexdigest() == md5_sbn
    print('ESP/SBN: md5 == work/qa111/v112')

    got_mcm = z2.read(ARC_MCM)
    assert got_mcm.count(KEY + NEW_TAB + GOI) == 1
    assert LEGACY not in got_mcm
    print('MCM: $Forsworn<tab>Изгои — на месте; «Изгнанники» = 0')

    ver = z2.read('fomod/info.xml').decode('utf-8')
    assert '<Version>1.5.12</Version>' in ver
    cfg = z2.read('fomod/ModuleConfig.xml').decode('utf-8')
    assert '<moduleName>Paths of Empyrean</moduleName>' in cfg
    print('версии: info.xml = 1.5.12; moduleName = «Paths of Empyrean»; FOMOD не тронут')

    # --- зеркало work/ru15 ---
    shutil.copyfile(f'{V112}/00 Core/PathsOfEmpyrean.esp', os.path.join(RU15, '00 Core', 'PathsOfEmpyrean.esp'))
    shutil.copyfile(f'{V112}/{ARC_SBN}', os.path.join(RU15, ARC_SBN))
    open(os.path.join(RU15, ARC_MCM), 'wb').write(mcm_new)
    open(os.path.join(RU15, 'fomod', 'info.xml'), 'w', encoding='utf-8', newline='').write(info_new)
    print('зеркало work/ru15: ESP + ShortbowNames + RUSSIAN.txt + info.xml обновлены')

    print()
    print('ПАКЕТ:', DST, '(%d B)' % os.path.getsize(DST))


if __name__ == '__main__':
    main()
