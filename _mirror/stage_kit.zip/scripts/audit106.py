#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 106: аналитический аудит «ванильный стандарт» (НИ ОДНОЙ правки).

Вопрос игрока: «Есть в переводе еще что-то, что можно привести к ванильному
стандарту?» Аудит сверяет перевод v1.5.9 с офиц. локализацией SoftClub:

  1. Регрессия линта стиля (классы qa94) по корпусу + 3 DESC.ini + ShortbowNames + MCM.
  2. EN→RU формульные якоря (~30 механик, где у SoftClub есть устоявшаяся формула).
  3. RU-сканы чужеродных вариантов (мана/выносливость/дварф/Ту'ум/«скрытой атакой»…).
  4. Лор-имена: EN-якоря (боги/места/фракции/материалы) → RU-контекст для сверки с db.
  5. Семья Summon/Conjure (вопрос 94-а) — полная сводка.
  6. Открытые ванильно-зависимые вопросы: 100-б (елочки у имен), 68-б, 71-а.

Вход:  handoff/06_код-истина_перевода/corpus57.json (12 323 полей, en-пары)
       work/qa104/release159/ (байтово-верифицированный релиз v1.5.9)
Выход: work/qa106/audit106_report.txt + *.tsv
"""
import json, os, re, sys

PACK = '/home/z/my-project/upload/poe_pack'
CORPUS = os.path.join(PACK, 'handoff/06_код-истина_перевода/corpus57.json')
REL = os.path.join(PACK, 'work/qa104/release159')
QA = os.path.join(PACK, 'work/qa106')
os.makedirs(QA, exist_ok=True)

recs = json.load(open(CORPUS, encoding='utf-8'))
out = open(os.path.join(QA, 'audit106_report.txt'), 'w', encoding='utf-8')
tsv = {}

def w(s=''):
    print(s[:180])
    out.write(s + '\n')

def open_tsv(name, header):
    f = open(os.path.join(QA, name), 'w', encoding='utf-8')
    f.write(header + '\n')
    tsv[name] = f
    return f

def inis():
    """[(layer, text)] из всех ini-слоев релиза."""
    layers = []
    for p in ['00 Core/PathsOfEmpyrean_DESC.ini',
              '30 CC Patches/Advanced Crossbows/PoE-CCAdvancedCrossbows-Patch_DESC.ini',
              '30 CC Patches/Expanded Crossbow Pack/PoE-CCExpandedCrossbowPack-Patch_DESC.ini']:
        for line in open(os.path.join(REL, p), encoding='utf-8-sig'):
            line = line.rstrip('\n')
            if '|' in line:
                layers.append((p.split('/')[0], line.split('|', 1)[1]))
    for line in open(os.path.join(REL, '00 Core/SKSE/Plugins/POE/Weapon/PathsOfEmpyrean_ShortbowNames.ini'), encoding='utf-8-sig'):
        m = re.search(r'fullName=~(.+)~', line)
        if m:
            layers.append(('ShortbowNames', m.group(1)))
    mcm = open(os.path.join(REL, '00 Core/Interface/Translations/PathsOfEmpyrean_RUSSIAN.txt'),
               encoding='utf-16').read()
    for line in mcm.splitlines():
        if '\t' in line:
            layers.append(('MCM', line.split('\t', 1)[1]))
    return layers

ini_layers = inis()

# ================================================== 1. ЛИНТ (регрессия)
def lint_problems(text):
    p = []
    if '  ' in text:
        p.append('двойной пробел')
    if re.search(r' [,.;:!?)]', text) or re.search(r'[(] ', text):
        p.append('пробел у пунктуации')
    if 'ё' in text or 'Ё' in text:
        p.append('буква ё')
    if '—' in text or '–' in text:
        p.append('длинное тире')
    if text.count('«') != text.count('»'):
        p.append('некруг ёлочек')
    if '..' in text and '...' not in text:
        p.append('двойная точка')
    if text != text.rstrip(' '):
        p.append('пробел в конце')
    if re.search(r'(?<!\n)\n(?!\n)', text):
        p.append('одиночный \\n')
    if 'рейтинг брони' in text.lower():
        p.append('рейтинг брони (запрет)')
    return p

w('=' * 76)
w('1. РЕГРЕССИЯ ЛИНТА СТИЛЯ (корпус + ini-слои)')
w('=' * 76)
lf = open_tsv('lint.tsv', 'layer\tfid\tedid\ttype\tfield\tproblems\ttext')
n = 0
for r in recs:
    if r.get('type') == 'GMST':
        continue
    probs = lint_problems(r['ru'])
    if probs:
        n += 1
        lf.write('corpus\t%s\t%s\t%s\t%s\t%s\t%s\n' % (
            r['fid'], r.get('edid', ''), r['type'], r['field'],
            ';'.join(probs), r['ru'].replace('\n', '\\n')[:160]))
for layer, t in ini_layers:
    probs = [x for x in lint_problems(t) if x != 'одиночный \\n']
    if probs:
        n += 1
        lf.write('%s\t-\t-\t-\t-\t%s\t%s\n' % (layer, ';'.join(probs), t[:160]))
w(f'полей с проблемами линта: {n}')

# PERK DESC <=290
long_desc = [r for r in recs if r['type'] == 'PERK' and r['field'] == 'DESC' and len(r['ru']) > 290]
w(f'PERK DESC длиннее 290: {len(long_desc)}')

# ================================================== 2. EN→RU ФОРМУЛЬНЫЕ ЯКОРЯ
w()
w('=' * 76)
w('2. EN→RU ФОРМУЛЬНЫЕ ЯКОРЯ (нарушения = EN-якорь есть, ожидаемой RU-семьи нет)')
w('=' * 76)
ANCHORS = [
    ('power attack', r'\bpower attacks?\b', r'силов'),
    ('sneak attack (canon 104)', r'sneak attacks?\b', r'скрытн'),
    ('backstab', r'backstab', r'в спину'),
    ('stagger (canon)', r'stagger', r'ошелом'),
    ('knock down (canon)', r'knock(?:ed|s)?\s+(?:them\s+)?down|knock(?:ed|s)?\s+.*?\s+down', r'сбив|опрокид|с ног|валит|повал'),
    ('shield bash (canon)', r'\bbash(?:es|ing)?\b', r'щит|плашмя|Таран|баш'),
    ('resist', r'\bresist', r'сопротивл'),
    ('absorb', r'\babsorb', r'поглощ'),
    ('reflect', r'\breflect', r'отраж'),
    ('bound weapon', r'\bbound\s+(?:sword|bow|battleaxe|dagger|mace|weapon|armor)', r'призван'),
    ('soul trap', r'soul\s*trap', r'ловуш|захват|душ'),
    ('ward', r'\bwards?\b(?!\s*(?:enemies|off))', r'оберег'),
    ('cloak', r'\bcloaks?\b', r'плащ'),
    ('rune', r'\brunes?\b', r'рун'),
    ('paralyze', r'paralyz', r'парализ|оцепенен|окаменен|обездвиж'),
    ('frenzy', r'frenz', r'безум'),
    ('turn undead (canon-дивергент)', r'turn\s+undead|undead[^.]*flee', r'изгнан'),
    ('reanimate', r'reanimate|raise\s+(?:the\s+)?dead|reanimat', r'ожив|подним'),
    ('banish', r'\bbanish', r'изгнан|устран'),
    ('summon (94-а)', r'\bsummon', r'призыв|вызов|призыван'),
    ('conjure (94-а)', r'\bconjur', r'вызов|призыв|колдовств'),
    ('dwarven (canon)', r'\bdwarv', r'двемерск'),
    ('orcish (canon)', r'\borcish\b|\borc\b', r'ороч'),
    ('elven', r'\belven\b', r'эльфийск'),
    ('ebony', r'\bebony\b', r'эбонит'),
    ('daedric', r'\bdaedric\b', r'даэдрическ'),
    ('stalhrim (canon 94)', r'stalhrim', r'сталгримов'),
    ('shout (canon)', r'\bshout', r'Крик|крик'),
    ("thu'um (запрет)", r"thu'?um", r'Крик|криков|Криков'),
    ('spell tome', r'spell\s+tome', r'том заклинаний'),
    ('staff', r'\bstaffs?\b|\bstaves\b', r'посох'),
    ('enchant', r'\benchant', r'зачаров'),
    ('soul gem', r'soul\s+gems?', r'камен|душ'),
    ('dual cast (canon)', r'dual\s+cast', r'двойн'),
    ('critical', r'critical', r'критическ'),
    ('magicka', r'\bmagicka\b', r'маги'),
    ('stamina', r'\bstamina\b', r'запас(а|ом)? сил'),
    ('health', r'\bhealth\b', r'здоровь'),
    ('moonstone', r'moonstone', r'[Лл]унн'),
    ('corundum', r'corundum', r'корунд'),
    ('quicksilver', r'quicksilver', r'ртут'),
    ('orichalcum', r'orichalcum', r'орихалк|орк'),
    ('malachite', r'malachite', r'малахит'),
    ('silver (material)', r'\bsilver\b', r'серебр'),
]
ff = open_tsv('formula_violations.tsv', 'anchor\tfid\tedid\ttype\tfield\tEN\tRU')
for name, en_re, ru_re in ANCHORS:
    hits, viol = 0, 0
    for r in recs:
        en, ru = r.get('en') or '', r.get('ru') or ''
        if re.search(en_re, en, re.I):
            hits += 1
            if not re.search(ru_re, ru, re.I):
                viol += 1
                ff.write('%s\t%s\t%s\t%s\t%s\t%s\t%s\n' % (
                    name, r['fid'], r.get('edid', ''), r['type'], r['field'],
                    en.replace('\n', ' ')[:130], ru.replace('\n', ' ')[:130]))
    w(f'{name}: hits={hits} violations={viol}')

# ================================================== 3. ЧУЖЕРОДНЫЕ RU-ВАРИАНТЫ
w()
w('=' * 76)
w('3. ЧУЖЕРОДНЫЕ RU-ВАРИАНТЫ (корпус + ini-слои; 0 = канон чист)')
w('=' * 76)
ALIENS = [
    ('мана', r'\bман[аыуе]\b'),
    ('выносливость', r'выносливост'),
    ('стамина', r'стамин'),
    ('хп/ХП', r'\bхп\b'),
    ('дварф', r'дварф'),
    ('гном', r'\bгном'),
    ('орский', r'орск'),
    ("Ту'ум", r"т['’]?уум"),
    ('«скрытой атакой»/«скрытый урон» (запрет 104)', r'скрыт[оы][ймх]? (?:атак|урон)'),
    ('«урон скрытой атакой»-семья в ini', r'скрыт[оы][ймх]'),
    ('«в скрытности» (канон: в режиме скрытности)', r'в скрытности'),
    ('чародейка (запрет 94)', r'чародейк'),
    ('питомец-лошадь (запрет 94)', r'питомец[- ]лошад|питомца-лошад'),
    ('«при вступлении в бой» (запрет)', r'при вступлении в бой'),
    ('«ускоренный бег» (запрет)', r'ускоренн\w+ бег'),
    ('«рейтинг брони» (запрет)', r'рейтинг брони'),
    ('Path of Sorcery (старый бренд)', r'Path of Sorcery'),
    ('Сигилы', r'Сигил'),
    ('Сложить оружие (канон: Потерять бдительность?)', r'Сложить оружие'),
]
af = open_tsv('aliens.tsv', 'alien\tlayer\tfid\tedid\ttype\tfield\ttext')
for name, pat in ALIENS:
    total = 0
    for r in recs:
        if re.search(pat, r['ru'], re.I):
            total += 1
            af.write('%s\tcorpus\t%s\t%s\t%s\t%s\t%s\n' % (
                name, r['fid'], r.get('edid', ''), r['type'], r['field'],
                r['ru'].replace('\n', ' ')[:140]))
    for layer, t in ini_layers:
        if re.search(pat, t, re.I):
            total += 1
            af.write('%s\t%s\t-\t-\t-\t-\t%s\n' % (name, layer, t[:140]))
    w(f'{name}: {total}')

# ================================================== 4. ЛОР-ИМЕНА (EN→RU контекст)
w()
w('=' * 76)
w('4. ЛОР-ИМЕНА: EN-якоря и их RU-передача в переводе (для сверки с офиц. корпусом)')
w('=' * 76)
LORE = [
    ('Cyrodiil', r'Cyrodiil'), ('Hammerfell', r'Hammerfell'),
    ('Morrowind', r'Morrowind'), ('Summerset', r'Summerset'),
    ('Valenwood', r'Valenwood'), ('Elsweyr', r'Elsweyr'),
    ('Black Marsh', r'Black\s+Marsh'), ('High Rock', r'High\s+Rock'),
    ('Tamriel', r'Tamriel'), ('Akavir', r'Akavir'), ('Atmora', r'Atmora'),
    ('Yokuda', r'Yokuda'), ('Pyandonea', r'Pyandonea'), ('Solstheim', r'Solstheim'),
    ('Vvardenfell', r'Vvardenfell'), ('Ayleid', r'Ayleid'),
    ('Oblivion (plan)', r'\bOblivion\b'), ('Sovngarde', r'Sovngarde'),
    ('Azura', r'Azura'), ('Boethiah', r'Boethiah'), ('Clavicus', r'Clavicus'),
    ('Hermaeus', r'Hermaeus'), ('Malacath', r'Malacath'), ('Mephala', r'Mephala'),
    ('Mehrunes', r'Mehrunes'), ('Molag', r'Molag'), ('Namira', r'Namira'),
    ('Nocturnal', r'Nocturnal'), ('Peryite', r'Peryite'), ('Sanguine', r'Sanguine'),
    ('Sheogorath', r'Sheogorath'), ('Vaermina', r'Vaermina'), ('Jyggalag', r'Jyggalag'),
    ('Meridia', r'Meridia'), ('Hircine', r'Hircine'), ('Dagon', r'Dagon'),
    ('Julianos', r'Julianos'), ('Arkay', r'Arkay'), ('Dibella', r'Dibella'),
    ('Zenithar', r'Zenithar'), ('Stendarr', r'Stendarr'), ('Talos', r'Talos'),
    ('Kyne', r'\bKyne\b'), ('Kynareth', r'Kynareth'), ('Akatosh', r'Akatosh'),
    ('Mara', r'\bMara\b'), ('Shor', r'\bShor\b'), ('Lorkhan', r'Lorkhan'),
    ('Ysmir', r'Ysmir'), ('Alduin', r'Alduin'), ('Dawnguard', r'Dawnguard'),
    ('Companions', r'\bCompanions\b'), ('College of Winterhold', r'College\s+of\s+Winterhold'),
    ('Dark Brotherhood', r'Dark\s+Brotherhood'), ('Thieves Guild', r'Thieves\s+Guild'),
    ('Nightingale', r'Nightingale'), ('Greybeards', r'Greybeards'),
    ('Vigilant', r'Vigilant'), ('Silver Hand', r'Silver\s+Hand'),
    ('Volkihar', r'Volkihar'), ('Dunmer', r'\bDunmer\b'), ('Chimer', r'\bChimer\b'),
    ('Dwemer race', r'\bDwemer\b'), ('Falmer', r'\bFalmer\b'),
    ('Spriggan', r'Spriggan'), ('Draugr', r'\bDraugr\b'),
    ('Wisp', r'\bWisp\b'), ('Hagraven', r'Hagraven'),
    ('Elder Scroll', r'Elder\s+Scroll'), ('Oghma', r'Oghma'),
    ('Mehrunes Razor', r"Razor\b"), ('Azuras Star', r'Azuras?\s+Star'),
    ('Dragonborn (title)', r'Dragonborn'),
]
lf2 = open_tsv('lore.tsv', 'lore\tfid\tedid\ttype\tfield\tEN\tRU')
for name, en_re in LORE:
    hits = []
    for r in recs:
        en = r.get('en') or ''
        if re.search(en_re, en, re.I):
            hits.append(r)
    if hits:
        for r in hits[:40]:
            lf2.write('%s\t%s\t%s\t%s\t%s\t%s\t%s\n' % (
                name, r['fid'], r.get('edid', ''), r['type'], r['field'],
                re.sub(r'\s+', ' ', (r.get('en') or ''))[:120],
                re.sub(r'\s+', ' ', r['ru'])[:120]))
    w(f'{name}: {len(hits)} полей')

# ================================================== 5. СЕМЬЯ SUMMON/CONJURE (94-а)
w()
w('=' * 76)
w('5. СЕМЬЯ SUMMON/CONJURE (вопрос 94-а): FULL-записи по глаголу и RU-началу')
w('=' * 76)
sf = open_tsv('summon_family.tsv', 'en_verb\tru_verb\tfid\tedid\ttype\tEN\tRU')
cnt = {}
for r in recs:
    if r['field'] != 'FULL':
        continue
    en = (r.get('en') or '').strip()
    m = re.match(r'(Summon|Conjure)\b', en)
    if not m:
        continue
    verb = m.group(1)
    ru = r['ru'].strip()
    ru_v = 'Призыв' if ru.startswith('Призыв') else ('Вызов' if ru.startswith('Вызов') else 'прочее')
    cnt[(verb, ru_v)] = cnt.get((verb, ru_v), 0) + 1
    sf.write('%s\t%s\t%s\t%s\t%s\t%s\t%s\n' % (
        verb, ru_v, r['fid'], r.get('edid', ''), r['type'], en[:90], ru[:90]))
for k in sorted(cnt):
    w(f'  EN {k[0]} -> RU {k[1]}: {cnt[k]}')
w('  (BREAKDOWN «прочее»):')
for r in recs:
    if r['field'] == 'FULL':
        en = (r.get('en') or '').strip()
        m = re.match(r'(Summon|Conjure)\b', en)
        if m:
            ru = r['ru'].strip()
            if not (ru.startswith('Призыв') or ru.startswith('Вызов')):
                w(f"    {r['fid']} {r.get('edid','')}: EN «{en[:60]}» RU «{ru[:60]}»")

# ================================================== 6. ОТКРЫТЫЕ ВОПРОСЫ: 100-б, 68-б, 71-а
w()
w('=' * 76)
w('6. ОТКРЫТЫЕ ВАНИЛЬНО-ЗАВИСИМЫЕ ВОПРОСЫ (без вердикта не трогать)')
w('=' * 76)
# 100-б: имена заклинаний без ёлочек
w('-- 100-б: ссылки на имена заклинаний без ёлочек (эталон: «вроде X и Y»)')
for r in recs:
    if r['type'] == 'PERK' and r['field'] == 'DESC' and 'Трансмогрификации' in r['ru']:
        w(f"   {r['fid']} {r.get('edid','')}: {r['ru'][:160]}")
# 68-б: Аура рока / Погибель
w('-- 68-б: «Аура рока» и семья «Погибель» (Doom)')
n_aura = n_doom = 0
for r in recs:
    if 'Аура рока' in r['ru'] or 'аура рока' in r['ru'].lower():
        n_aura += 1
        w(f"   Аура рока: {r['fid']} {r.get('edid','')}: {r['ru'][:130]}")
    if re.search(r'[Пп]огибел', r['ru']) and r['field'] == 'FULL':
        n_doom += 1
w(f'   «Погибель*» в FULL: {n_doom} записей; «Аура рока»: {n_aura}')
# 71-а: Скорость восстановления Криков
w('-- 71-а: формулы восстановления Криков')
for r in recs:
    if re.search(r'[Вв]осстановлени[ея] Криков|скорость восстановления Криков', r['ru'], re.I):
        w(f"   {r['fid']} {r.get('edid','')} {r['type']}: {r['ru'][:150]}")

# ================================================== 7. ini: скрытн- семья
w()
w('=' * 76)
w('7. INI-СЛОИ: семья «скрытн-» (после Этапа 104 должна быть монолитна)')
w('=' * 76)
n_skry = 0
for layer, t in ini_layers:
    for m in re.finditer(r'.{0,40}скрытн\w*.{0,40}', t, re.I):
        n_skry += 1
        if n_skry <= 8:
            w(f'   [{layer}] …{m.group(0)}…')
w(f'всего вхождений «скрытн-» в ini: {n_skry}')

out.close()
for f in tsv.values():
    f.close()
print('\nOK ->', QA)
