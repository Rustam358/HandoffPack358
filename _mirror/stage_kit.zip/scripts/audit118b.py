#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 118 «Великая» проверка тиров — ЧАСТЬ B: все домены + INI-слои.

Входы:
  work/qa118/aligned.json — RU v1.5.18 <-> EN 1.4 (по file/formid/rtype/field/occ)
  work/ru118/…            — распакованный пакет v1.5.18 (INI/TXT-слои)
  EN 1.4 ini              — handoff/08_оригинал_1.4_EN/…
Выход: work/qa118/audit_b.txt
Аналитический скрипт: НИЧЕГО не правит.
"""
import json
import re
from collections import defaultdict, Counter

A = json.load(open('/home/z/my-project/work/qa118/aligned.json', encoding='utf-8'))
OUT = open('/home/z/my-project/work/qa118/audit_b.txt', 'w', encoding='utf-8')


def w(s=''):
    OUT.write(s + '\n')


w('=' * 76)
w('ЭТАП 118. ВЕЛИКАЯ ПРОВЕРКА ТИРОВ — часть B (домены + INI-слои)')
w('=' * 76)

# ---------------------------------------------------------------- 1. АРБАЛЕТЫ
w()
w('1. АРБАЛЕТЫ: варианты (Silenced/Light-Weight/Spring-Loaded/Recurve/Enhanced/Masterwork)')
XB_MAT = {  # EN-материал -> RU-паттерн (офиц. прилагательное)
    'Dwarven': 'двемерск', 'Elven': 'эльфийск', 'Ebony': 'эбонитов', 'Silver': 'серебр',
    'Orcish': 'орочь|орочи', 'Nordic': 'нордск', 'Imperial': 'имперск', 'Daedric': 'даэдрическ',
    'Dragonbone': 'дракон', 'Glass': 'стеклянн', 'Stalhrim': 'сталгримов',
}
lost_mat = []
xb_mod = defaultdict(Counter)
for r in A:
    if r['rtype'] != 'WEAP' or r['field'] != 'FULL' or not r['en_text'] or 'Crossbow' not in r['en_text']:
        continue
    en = r['en_text']
    for m, ru_pat in XB_MAT.items():
        if f' {m} ' in f' {en} ':
            if not re.search(ru_pat, r['ru_text'], re.I):
                lost_mat.append(r)
            for mod, ru in [('Silenced', 'Бесшумный'), ('Light-Weight', 'Облегченный'),
                            ('Spring-Loaded', 'пружинным'), ('Recurve', 'выгнутой ложей'),
                            ('Enhanced', 'Улучшенный'), ('Masterwork', 'Мастерский')]:
                if mod in en and ru.lower() not in r['ru_text'].lower():
                    xb_mod[mod][r['ru_text'][:40]] += 1
            break
w(f'арбалетов, потерявших слово материала в RU: {len(lost_mat)}')
for r in lost_mat:
    w(f"  [{r['file']} {r['formid']}] {r['edid'][:46]:46} EN: {r['en_text'][:48]:48} RU: {r['ru_text'][:48]}")
w('модификаторы без соответствующего RU-слова (должно быть пусто):')
for mod, c in xb_mod.items():
    for k, v in c.items():
        w(f'  {mod}: «{k}»×{v}')

# ---------------------------------------------------------------- 2. MASTERWORK
w()
w('2. MASTERWORK (812 полей): род и состав')
mw_bad = []
mw_first = Counter()
for r in A:
    if r['rtype'] in ('WEAP', 'ARMO') and r['field'] == 'FULL' and r['en_text'] and r['en_text'].startswith('Masterwork'):
        ru = r['ru_text']
        mw_first[ru.split()[0] if ru.split() else ''] += 1
        if not ru.startswith(('Мастерская ', 'Мастерской ', 'Мастерские ', 'Мастерский ', 'Мастерское ')):
            mw_bad.append(r)
w('первые слова: ' + ', '.join(f'«{k}»×{v}' for k, v in mw_first.most_common()))
w(f'нестандартных: {len(mw_bad)}')
for r in mw_bad:
    w(f"  [{r['file']} {r['formid']}] {r['edid'][:40]:40} EN: {r['en_text'][:44]:44} RU: {r['ru_text'][:48]}")
# Мастерское ×1 — что это?
for r in A:
    if r['rtype'] in ('WEAP', 'ARMO') and r['field'] == 'FULL' and r['ru_text'].startswith('Мастерское '):
        w(f"  «Мастерское»: [{r['formid']}] {r['edid'][:40]} EN: {str(r['en_text'])[:40]} RU: {r['ru_text'][:44]}")

# ---------------------------------------------------------------- 3. SANCTION 113
w()
w('3. ТИР-СЛОВАРЬ БРОНИ (санкция 113): регресс-скан')
cnt = Counter()
for r in A:
    t = r['ru_text']
    if 'ламелляр' in t.lower():
        cnt['ламелляр*'] += 1
    if re.search(r'(?<!драконий )(?<!драконьего )(?<!драконья )чешуйчат', t, re.I) and 'Дракон' not in t and 'дракон' not in t:
        cnt['чешуйчат* БЕЗ дракон'] += 1
    if 'драконий чешуйчат' in t.lower() or 'драконьего чешуйчат' in t.lower() or 'драконья чешуйчат' in t.lower():
        cnt['драконий чешуйчат*'] += 1
    if 'панцирн' in t.lower():
        cnt['*панцирн*'] += 1
    if re.search(r'[Оо]роч\w* чешуйчат', t):
        cnt['Ороч* чешуйчат* (ЗАПРЕТ)'] += 1
for k, v in sorted(cnt.items()):
    w(f'  {k}: {v}')
w('  «чешуйчат* БЕЗ дракон» — детали:')
for r in A:
    t = r['ru_text']
    if re.search(r'(?<!драконий )(?<!драконьего )(?<!драконья )чешуйчат', t, re.I) and 'Дракон' not in t and 'дракон' not in t and r['field'] == 'FULL':
        w(f"    [{r['file']} {r['formid']} {r['rtype']}] {r['edid'][:36]:36} RU: {t[:56]} EN: {str(r['en_text'])[:44]}")

# ---------------------------------------------------------------- 4. МАГИЯ: Novice..Master + Student + Potent
w()
w('4. МАГИЯ: ранги Novice/Apprentice/Adept/Expert/Master + «Студент:» + Potent-семьи')
RANKS = ['Novice', 'Apprentice', 'Adept', 'Expert', 'Master', 'Archmage']
rank_rows = defaultdict(list)
for r in A:
    if not r['en_text'] or r['field'] != 'FULL':
        continue
    if r['rtype'] in ('SPEL', 'SCRL', 'MGEF', 'PERK', 'BOOK'):
        for rk in RANKS:
            if r['en_text'].startswith(rk + ' '):
                rank_rows[rk].append(r)
for rk in RANKS:
    if rank_rows[rk]:
        w(f'  {rk}:')
        for r in rank_rows[rk][:8]:
            w(f"    [{r['file']} {r['formid']} {r['rtype']}] {r['edid'][:34]:34} EN: {r['en_text'][:40]:40} RU: {r['ru_text'][:40]}")
stud = [r for r in A if 'Студент:' in r['ru_text']]
w(f'  «Студент: …» (санкция, не трогать): {len(stud)} полей')
potent_bad = []
for r in A:
    if not r['en_text']:
        continue
    if 'Potent' in r['en_text'] and r['field'] == 'FULL':
        ru = r['ru_text']
        # канон: дремора/искатель = Высший; атронахи/питомцы/прочее = Сильный
        if re.search(r'дремор|искател|искателя', r['en_text'], re.I) or 'Seeker' in r['en_text'] or 'Dremora' in r['en_text']:
            if 'Сильный' in ru or 'сильн' in ru.lower():
                potent_bad.append(('Высший?', r))
        elif re.search(r'атронах|Companion|питомец|Venom|Atronach|Bear|Mammoth|Wolf|Sabre|Troll|Ash', r['en_text'], re.I):
            if 'ысш' in ru:
                potent_bad.append(('Сильный?', r))
w(f'  Potent-утечки (не тот тир по канону 93): {len(potent_bad)}')
for tag, r in potent_bad:
    w(f"    [{tag}] [{r['file']} {r['formid']}] {r['edid'][:34]:34} EN: {r['en_text'][:40]:40} RU: {r['ru_text'][:40]}")
# Seeker-семья
w('  Seeker-семья:')
for r in A:
    if r['en_text'] and 'Seeker' in r['en_text'] and r['field'] == 'FULL' and r['rtype'] in ('MGEF', 'SPEL', 'SCRL', 'RACE', 'ENCH'):
        w(f"    [{r['file']} {r['formid']} {r['rtype']}] {r['edid'][:34]:34} EN: {r['en_text'][:36]:36} RU: {r['ru_text'][:36]}")

# ---------------------------------------------------------------- 5. TURN/REPEL-семья (глагольный разнобой)
w()
w('5. TURN/REPEL UNDEAD: глагольные серии (EN -> RU по типам записей)')
tr = defaultdict(lambda: defaultdict(set))
for r in A:
    if not r['en_text'] or r['field'] != 'FULL':
        continue
    en = r['en_text']
    if re.match(r'^(Turn|Repel) (Lesser |Greater )?Undead$', en) or re.match(r'^Scroll of (Turn|Repel)', en):
        tr[en][r['rtype']].add(r['ru_text'])
for en in sorted(tr):
    parts = []
    for rt, rus in sorted(tr[en].items()):
        parts.append(f'{rt}=' + '|'.join(sorted(rus)))
    w(f'  «{en}»: ' + '  '.join(parts))

# ---------------------------------------------------------------- 6. AMMO
w()
w('6. БОЕПРИПАСЫ: материалы и грамматика')
AMMO_MAT_OFFICIAL = {
    'Iron': 'железн', 'Steel': 'стальн|стальск', 'Dwarven': 'двемерск', 'Orcish': 'орочь',
    'Elven': 'эльфийск', 'Glass': 'стеклянн', 'Ebony': 'эбонитов', 'Daedric': 'даэдрическ',
    'Dragonbone': 'дракон', 'Nordic': 'нордск', 'Stalhrim': 'сталгримов', 'Falmer': 'фалмерск',
    'Ancient Nord': 'древн.*нордск', 'Forsworn': 'Изгоев', 'Nord Hero': 'героя',
    'Sunhallowed': 'солнечн', 'Bloodcursed': 'кровавого проклятья|кровавым проклятьем',
    'Silver': 'серебр', 'Bonemold': 'костян', 'Corkbulb': 'пробков',
    'Golden': 'золот', 'Dark': 'темн', 'Madness': 'безумн', 'Amber': 'янтарн',
}
ammo_bad = []
for r in A:
    if r['rtype'] != 'AMMO' or r['field'] != 'FULL' or not r['en_text']:
        continue
    en = r['en_text']
    for en_m, ru_pat in AMMO_MAT_OFFICIAL.items():
        if en_m in en:
            if not re.search(ru_pat, r['ru_text'], re.I):
                ammo_bad.append((en_m, r))
            break
w(f'AMMO-полей с EN-парой: {sum(1 for r in A if r["rtype"]=="AMMO" and r["en_text"] and r["field"]=="FULL")},'
  f' расхождений с офиц. материалом: {len(ammo_bad)}')
for en_m, r in ammo_bad:
    w(f"  [{en_m}] [{r['file']} {r['formid']}] {r['edid'][:40]:40} EN: {r['en_text'][:40]:40} RU: {r['ru_text'][:44]}")
# нестандартная форма «орочая/орочие»
w('  нестандартные формы «орочая/орочие/орочое» (офиц. — «орочья/орочьи»):')
for r in A:
    if re.search(r'ороч(ая|ие|ое)', r['ru_text']):
        w(f"    [{r['file']} {r['formid']} {r['rtype']}] {r['edid'][:38]:38} RU: {r['ru_text'][:52]}")

# ---------------------------------------------------------------- 7. ALCH
w()
w('7. АЛХИМИЯ: семьи PoE')
for fam, pat in [('Venom (Chaurus/Frostbite/Netch/AshHopper)', re.compile(r'Venom')),
                 ('Automaton Stasis', re.compile(r'Automaton Stasis')),
                 ('Totem', re.compile(r'^Totem of'))]:
    rows = [r for r in A if r['rtype'] == 'ALCH' and r['field'] == 'FULL' and r['en_text'] and pat.search(r['en_text'])]
    w(f'  {fam}: {len(rows)} полей')
    seen = Counter()
    for r in rows:
        seen[(r['en_text'], r['ru_text'])] += 1
    for (en, ru), v in sorted(seen.items()):
        w(f'    {en[:42]:42} -> {ru[:44]}×{v}')

# ---------------------------------------------------------------- 8. SLGM
w()
w('8. КАМНИ ДУШ (PLACEHOLDER-серия): суффиксы размеров')
slgm = Counter()
for r in A:
    if r['rtype'] == 'SLGM' and r['field'] == 'FULL' and r['en_text']:
        m = re.search(r'\((Petty|Lesser|Common|Greater)\)$', r['en_text'])
        if m:
            ru = re.search(r'\(([^)]+)\)$', r['ru_text'])
            slgm[(m.group(1), ru.group(1) if ru else '∅')] += 1
for (en_s, ru_s), v in sorted(slgm.items()):
    w(f'  ({en_s}) -> «({ru_s})» ×{v}')

# ---------------------------------------------------------------- 9. ShortbowNames.ini
w()
w('9. SHORTBOWNAMES.INI: RU vs EN (ключ-в-ключ)')


def parse_sb(path):
    d = {}
    try:
        txt = open(path, encoding='utf-8-sig').read()
    except FileNotFoundError:
        return None
    for line in txt.splitlines():
        m = re.match(r'^filterByWeapons=([^:]+):fullName=~(.*)~\s*$', line.strip())
        if m:
            d[m.group(1)] = m.group(2)
    return d


sb_ru = parse_sb('/home/z/my-project/work/ru118/00 Core/SKSE/Plugins/POE/Weapon/PathsOfEmpyrean_ShortbowNames.ini')
sb_en = parse_sb('/home/z/my-project/handoff/08_оригинал_1.4_EN/дистрибутив_1.4/SKSE/Plugins/SkyPatcher/weapon/PathsOfEmpyrean/PathsOfEmpyrean_ShortbowNames.ini')
w(f'  ключей EN: {len(sb_en)}, ключей RU: {len(sb_ru)}')
missing = [k for k in sb_en if k not in sb_ru]
extra = [k for k in sb_ru if k not in sb_en]
w(f'  ключей нет в RU: {missing}')
w(f'  лишних в RU: {extra}')
# тиры Turn-канон в ini
TURN_MAP = {'Blessed': 'Благословленный', 'Sanctified': 'Освященный', 'Reverent': 'Почитаемый',
            'Hallowed': 'Святой', 'Virtuous': 'Добродетельный', 'Holy': 'Священный'}
bad_turn_ini = []
for k, en in sb_en.items():
    ru = sb_ru.get(k, '')
    for en_t, ru_t in TURN_MAP.items():
        if en.startswith(en_t + ' ') and not ru.startswith(ru_t):
            bad_turn_ini.append((k, en, ru))
w(f'  нарушений Turn-канона в ini: {len(bad_turn_ini)}')
for k, en, ru in bad_turn_ini:
    w(f'    {k}: EN «{en}» RU «{ru}»')
# суффиксы "of X" — единообразие тира по семействам
suf = defaultdict(set)
for k, en in sb_en.items():
    if ' of ' in en:
        fam = re.sub(r'\d+$', '', k)
        ru = sb_ru.get(k, '')
        # хвост RU: последние 1-2 слова
        en_suf = en.split(' of ', 1)[1]
        suf[en_suf].add(ru)
bad_suf = {s: v for s, v in suf.items() if len(v) > 1}
w(f'  «of X»-суффиксов: {len(suf)}, с разнобоем RU: {len(bad_suf)}')

# ---------------------------------------------------------------- 10. MCM + ALD
w()
w('10. MCM (RUSSIAN.txt) + ALD.ini: тиражные слова')
mcm_raw = open('/home/z/my-project/work/ru118/00 Core/Interface/Translations/PathsOfEmpyrean_RUSSIAN.txt', 'rb').read()
mcm = mcm_raw.decode('utf-16-le') if mcm_raw[:2] in (b'\xff\xfe', b'\xfe\xff') else mcm_raw.decode('utf-8-sig')
for tw in ['тир', 'Тир', 'ранг', 'Ранг', 'Novice', 'Apprentice', 'Adept', 'Expert', 'Master',
           ' Благослов', ' Освящен', ' Почита', ' Свят', ' Добродетел', ' Священ',
           'Мастерск', 'Мастерская', 'Мастерские']:
    n = mcm.count(tw)
    if n:
        w(f'  «{tw}» в MCM: {n}')
ald = open('/home/z/my-project/work/ru118/00 Core/SKSE/Plugins/ArcheryLocationalDamage.ini', encoding='utf-8').read()
w(f'  ALD.ini: строк Message = {len(re.findall(chr(34) + "Message", ald))} (кириллица: '
  f'{sum(1 for ch in ald if ord(ch) > 0x400)})')

OUT.close()
print('OK -> work/qa118/audit_b.txt')
