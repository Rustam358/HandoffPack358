#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 120: сборка fixlist_v120.jsonl — вердикт игрока по 112-а: «Разделять».

112-а (наследован из report_112 §9 → report_119 §8): два SPEL Material
Mastery «- Драконий» (тяж. 061A81DD / лёг. 06394B42) слиты в одно
прилагательное, как и в EN ("Dragon"). Вердикт игрока (07.11.2026):
«Разделять» — каждая серия получает прилагательное своей драконьей
материи. Факты (scripts/check120_armorclass.py, v1.5.19):
  - BOD2-класс: Dragonplate «Драконья панцирная броня» = HEAVY;
    Dragonscale «Драконья чешуйчатая броня» = LIGHT; CC «пластинчатая»
    (стальная/железная) = HEAVY; Scaled «ламеллярная» = LIGHT;
  - гейты SPEL уже разведены по ключевым словам: 061A81DD ←
    SF_K_MaterialMasteryDragonHeavy, 06394B42 ← SF_K_MaterialMasteryDragonLight;
  - корпус уже использует прилагательные: «Мастерская драконья панцирная
    броня» (0608A224) / «Мастерская драконья чешуйчатая броня» (0608A2B5).
Правка = ровно 2 поля FULL main ESP. old сверены байт-в-байт с дампом
истины v1.5.19 (work/qa119/dump_v119_full.jsonl). Выход:
work/qa120/fixlist_v120.jsonl.
"""
import io, json, os

DUMP = '/home/z/my-project/work/qa119/dump_v119_full.jsonl'
OUT = '/home/z/my-project/work/qa120/fixlist_v120.jsonl'

WHY_H = ('112-а (вердикт игрока «Разделять»): тяжёлая драконья серия = '
         'Dragonplate («Драконья панцирная броня», BOD2 Heavy); SPEL гейтится '
         'ключом SF_K_MaterialMasteryDragonHeavy; прилагательное корпуса '
         '«драконий панцирный» (ArmorDragonplateCuirass_M 0608A224)')
WHY_L = ('112-а: лёгкая драконья серия = Dragonscale («Драконья чешуйчатая '
         'броня», BOD2 Light); SPEL гейтится ключом '
         'SF_K_MaterialMasteryDragonLight; прилагательное корпуса «драконий '
         'чешуйчатый» (ArmorDragonscaleCuirass_M 0608A2B5)')


def main():
    dump = {}
    for line in io.open(DUMP, encoding='utf-8'):
        r = json.loads(line)
        dump[(r['file'], r['formid'], r['rtype'], r['field'],
              r.get('occ', 1))] = r['text']
    print(f'дамп истины v1.5.19: {len(dump)} ключей')

    fixes = [
        ('main', '061A81DD', 'SPEL', 'IWP_AB_HARM_HeavyMaterialMastery_dragon',
         'Железный человек - Драконий',
         'Железный человек - Драконий панцирный', WHY_H),
        ('main', '06394B42', 'SPEL', 'PoE_AB_LARM_LightMaterialMastery_dragon',
         'Вторая кожа - Драконий',
         'Вторая кожа - Драконий чешуйчатый', WHY_L),
    ]

    out = []
    for file_, fid, rtype, edid, old, new, why in fixes:
        key = (file_, fid, rtype, 'FULL', 1)
        cur = dump.get(key)
        assert cur == old, f'old не совпал с дампом: {key}: {cur!r}'
        out.append({'kind': 'esp', 'project': '112-а', 'file': file_,
                    'formid': fid, 'rtype': rtype, 'field': 'FULL', 'occ': 1,
                    'edid': edid, 'old': old, 'new': new, 'why': why})
        print(f'  {fid} {edid}: {old!r} -> {new!r}')
    print(f'old сверены байт-в-байт: {len(out)} поля')

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with io.open(OUT, 'w', encoding='utf-8') as f:
        for r in out:
            f.write(json.dumps(r, ensure_ascii=False) + '\n')
    print(f'выход: {OUT} ({len(out)} записей)')


if __name__ == '__main__':
    main()
