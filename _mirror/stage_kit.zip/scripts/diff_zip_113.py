#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 113: пофайловая CRC-сверка user zip (5) с нашим релизом v1.5.13."""
import zipfile, hashlib

OURS = "/home/z/my-project/download/Paths of Empyrean RU 1.5.zip"
USER = "/home/z/my-project/upload/Paths of Empyrean RU 1.5 (5).zip"

def load(path):
    d = {}
    with zipfile.ZipFile(path) as z:
        for i in z.infolist():
            if i.is_dir():
                continue
            data = z.read(i.filename)
            d[i.filename] = (i.CRC, hashlib.md5(data).hexdigest(), len(data))
    return d

a = load(OURS)
b = load(USER)
print(f"OUR  v1.5.13: {len(a)} записей")
print(f"USER zip(5) : {len(b)} записей")

only_ours = sorted(set(a) - set(b))
only_user = sorted(set(b) - set(a))
print(f"\n-- только в нашем: {len(only_ours)}")
for f in only_ours: print("   ", f)
print(f"-- только у игрока: {len(only_user)}")
for f in only_user: print("   ", f)

common = sorted(set(a) & set(b))
changed = [f for f in common if a[f][0] != b[f][0]]
same = len(common) - len(changed)
print(f"\n-- идентичны по CRC: {same}/{len(common)}")
print(f"-- ИЗМЕНЕНЫ ({len(changed)}):")
for f in changed:
    print(f"    {f}: ours md5={a[f][1]} ({a[f][2]} Б) | user md5={b[f][1]} ({b[f][2]} Б)")
print(f"\nUSER zip md5: {hashlib.md5(open(USER,'rb').read()).hexdigest()}")
print("ВЕРДИКТ:", "база чистая (63/63)" if same == len(common) == 63 and not changed
      and not only_ours and not only_user else "ЕСТЬ РАСХОЖДЕНИЯ — разбирать!")
