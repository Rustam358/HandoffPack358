#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""115g: все записи PoE-CCAltArmorOrcishScaled-Patch.esp с «чешуйчат»:
formid, EDID, FULL, DESC; плюс полный список записей файла."""
import struct, zlib, sys
sys.path.insert(0, '/home/z/my-project/scripts')
from probe115f import parse, walk_recs, subrecords

P = '/home/z/my-project/work/qa114/release115/30 CC Patches/Alternative Armors - Orcish Scaled/PoE-CCAltArmorOrcishScaled-Patch.esp'

buf = open(P, 'rb').read()
root = parse(buf)
recs = list(walk_recs(root))
print(f'всего записей: {len(recs)}')
from collections import Counter
print('типы:', Counter(r.label.decode('ascii', 'replace') for r in recs))
print()
for rec in recs:
    subs = subrecords(rec)
    edid = ''
    full = ''
    desc = ''
    for st, v in subs:
        if st == 'EDID':
            edid = v.rstrip(b'\x00').decode('utf-8', 'replace')
        elif st == 'FULL':
            full = v.rstrip(b'\x00').decode('utf-8', 'replace')
        elif st == 'DESC':
            desc = v.rstrip(b'\x00').decode('utf-8', 'replace')
    if 'чешуйчат' in full or 'чешуйчат' in desc or 'Orcish' in edid or 'Scaled' in edid or 'BGSSSE055' in edid:
        print(f'{rec.label.decode()} {rec.formid:08X} {edid!r} FULL={full!r} DESC={desc!r}')
