#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 123: структурный скан выпуска v1.5.25 (upload/"(2)" = корневая
истина). Инвентаризация: form version, число записей/полей по ESP,
кириллические строки, кодировки INI/TXT, целостность zip.

Выход: work/qa123/structure_scan_1525.txt
"""
import os, re, sys, zipfile, struct

ROOT = '/home/z/my-project'
QA = f'{ROOT}/work/qa123'
P25 = f'{ROOT}/upload/Paths of Empyrean RU 1.5 (2).zip'

CYR = re.compile(r'[\u0400-\u04FF]')


def form_version(buf):
    # заголовок записи: type(4) size(4) flags(4) formid(4) ver(2) unk(2)
    return struct.unpack_from('<H', buf, 0x14)[0]


def utf8_runs(data):
    return re.findall(rb'[\x20-\x7e\xc0-\xff][\x20-\x7e\x80-\xff]{3,}', data)


def scan():
    z = zipfile.ZipFile(P25)
    names = z.namelist()
    out = []
    out.append(f'записей в zip: {len(names)}')
    esp_files = [n for n in names if n.lower().endswith('.esp')]
    out.append(f'ESP: {len(esp_files)}')
    out.append(f'PEX: {sum(1 for n in names if n.lower().endswith(".pex"))}')
    out.append(f'INI: {sum(1 for n in names if n.lower().endswith(".ini"))}')
    out.append(f'XML: {sum(1 for n in names if n.lower().endswith(".xml"))}')
    out.append(f'картинки: {sum(1 for n in names if n.lower().endswith((".png",".jpg")))}')
    out.append('')
    total_fields = 0
    for n in sorted(esp_files):
        buf = z.read(n)
        fv = form_version(buf[:40])
        # записи: грубый подсчёт TES4+записей верхнего уровня через parse_tes4
        from parse_tes4 import Plugin
        tmp = '/tmp/_scan.esp'
        open(tmp, 'wb').write(buf)
        try:
            p = Plugin(tmp)
            nrec = len(p.records)
            types = {}
            for fid, r in p.records.items():
                types[r['type']] = types.get(r['type'], 0) + 1
        except Exception as e:
            out.append(f'{n}: ОШИБКА РАЗБОРА {e}')
            continue
        # кириллические поля
        cyr = 0
        fields = 0
        for fid, r in p.records.items():
            for st, sd in r['subs']:
                if st in ('FULL', 'DESC', 'ITXT', 'NNAM'):
                    try:
                        t = sd.rstrip(b'\x00').decode('utf-8')
                    except UnicodeDecodeError:
                        continue
                    fields += 1
                    if CYR.search(t):
                        cyr += 1
                elif st == 'DNAM' and r['type'] == 'MGEF':
                    try:
                        t = sd.rstrip(b'\x00').decode('utf-8')
                        if sum(1 for c in t if ord(c) < 32 and c != '\n') == 0 \
                           and sum(1 for c in t if c.isalpha()) >= 4:
                            fields += 1
                            if CYR.search(t):
                                cyr += 1
                    except UnicodeDecodeError:
                        pass
                elif st == 'DATA' and r['type'] == 'GMST':
                    try:
                        t = sd.rstrip(b'\x00').decode('utf-8')
                        if t:
                            fields += 1
                            if CYR.search(t):
                                cyr += 1
                    except UnicodeDecodeError:
                        pass
        total_fields += fields
        top3 = ', '.join(f'{k}:{v}' for k, v in
                         sorted(types.items(), key=lambda kv: -kv[1])[:4])
        out.append(f'{n}: form {fv}, записей {nrec}, текст-полей {fields} '
                   f'(кириллица {cyr}); {top3}')
    out.append('')
    out.append(f'итого текст-полей ESP: {total_fields}')
    out.append('')
    # INI/TXT поверхности
    for n in sorted(names):
        if not n.lower().endswith(('.ini', '.txt')):
            continue
        b = z.read(n)
        enc = ('UTF-16LE' if b[:2] == b'\xff\xfe' else
               'UTF-8 BOM' if b[:3] == b'\xef\xbb\xbf' else 'UTF-8/ASCII')
        lines = len(b.split(b'\n'))
        cyr_lines = 0
        try:
            txt = b.decode('utf-16' if enc == 'UTF-16LE' else 'utf-8-sig',
                           'replace')
            cyr_lines = sum(1 for l in txt.splitlines() if CYR.search(l))
        except Exception:
            pass
        out.append(f'{n}: {len(b):,} Б, {enc}, строк {lines} (кириллица '
                   f'{cyr_lines})')
    # PEX
    pex = [n for n in names if n.lower().endswith('.pex')]
    if pex:
        out.append('')
        out.append(f'PEX-файлы: {len(pex)}')
        for n in sorted(pex):
            b = z.read(n)
            runs = utf8_runs(b)
            cyr = sum(1 for r in runs if CYR.search(r.decode('utf-8', 'replace')))
            out.append(f'  {n}: {len(b):,} Б, кириллических run {cyr}')
    out.append('')
    info = z.read('fomod/info.xml').decode('utf-8')
    out.append('fomod/info.xml: ' + info.strip())
    with open(f'{QA}/structure_scan_1525.txt', 'w', encoding='utf-8') as f:
        f.write('\n'.join(out) + '\n')
    print('\n'.join(out))


if __name__ == '__main__':
    scan()
