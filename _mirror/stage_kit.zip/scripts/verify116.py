#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 116: независимая верификация v1.5.17.
1) CRC-регресс 61 файла; 2) побайтовый регресс записей main ESP
   (изменены ровно 4 MESG, только поле DESC); 3) dump-дифф текстов
   (4 поля == fixlist, 0 новых/пропавших); 4) матрица маскировочных строк
   ×17 + гигиена (MGEF FULL, DNAM, «под талмора»=0, lowercase-фрагменты=0,
   дракон-серия, CC-ламелляр не тронут).
"""
import struct, zlib, os, sys, json, zipfile, hashlib, io

sys.path.insert(0, '/home/z/my-project/work/handoff510/scripts')
from dump150 import dump_esp

SRC_ZIP = '/home/z/my-project/upload/Paths of Empyrean RU 1.5 (9).zip'
NEW = '/home/z/my-project/work/qa116/v117'
FIX = '/home/z/my-project/work/qa116/fixlist_v117.jsonl'
DUMP_OLD = '/home/z/my-project/work/qa115/dump_v116_full.jsonl'
DUMP_NEW = '/home/z/my-project/work/qa116/dump_v117_full.jsonl'
MAIN = '00 Core/PathsOfEmpyrean.esp'
REC_HDR = 24

# записи выпуска v1.5.16 (report_115)
V116_ESP_MD5 = '0ec3b6f6cecb5312ea3ad62d42607299'
V116_CC_ORCSCALED_MD5 = '28debe392b78380a257a1d0339770db7'
CC = ('30 CC Patches/Alternative Armors - Orcish Scaled/'
      'PoE-CCAltArmorOrcishScaled-Patch.esp')

# 12 male/both-строк после этапа 116 (вердикт 115-а)
STR_DISG = {
    0x06060E78: 'Вы замаскированы под Бандита.',
    0x06060E93: 'Вы замаскированы под Брата Бури.',
    0x06060E9A: 'Вы замаскированы под Имперца.',
    0x06060EA6: 'Вы замаскированы под Культиста.',
    0x06024573: 'Вы замаскированы под Вампира.',
    0x06060E88: 'Вы замаскированы под Изгоя.',
    0x06060EA0: 'Вы замаскированы под Талмор.',
    0x06060E8B: 'Вы замаскированы под Некроманта.',
    0x06024563: 'Вы замаскированы под члена Стражи Рассвета.',
    0x06024570: 'Вы замаскированы под Драугра.',
    0x06024571: 'Вы замаскированы под Фалмера.',
    0x06024572: 'Вы замаскированы под Двемерского автоматона.',
}
# 5 женских MESG_F (этап 115, не тронуты)
FEM_DISG = {
    0x065D69D7: 'Вы замаскированы под Бандитку.',
    0x065D69D8: 'Вы замаскированы под Сестру Бури.',
    0x065D69D9: 'Вы замаскированы под Имперку.',
    0x065D69DA: 'Вы замаскированы под Культистку.',
    0x065D69DB: 'Вы замаскированы под Вампирессу.',
}
PATCH_IDS = [0x06060E78, 0x06060E9A, 0x06060EA6, 0x06024573]
LOWERCASE_FRAGS = ['под бандита', 'под имперца', 'под культиста', 'под вампира']

FAILED = []


def check(cond, msg):
    if cond:
        print(f'  ✓ {msg}')
    else:
        print(f'  ✗ {msg}')
        FAILED.append(msg)


class Node:
    __slots__ = ('kind', 'label', 'tail', 'formid', 'data', 'children')


def parse(buf):
    root = []

    def walk(off, end, out):
        while off < end:
            t = buf[off:off+4]
            size = struct.unpack_from('<I', buf, off+4)[0]
            if t == b'GRUP':
                node = Node()
                node.kind = 'grup'
                node.tail = bytes(buf[off+8:off+24])
                node.children = []
                walk(off + REC_HDR, off + size, node.children)
                out.append(node)
                off += size
            else:
                node = Node()
                node.kind = 'rec'
                node.tail = bytes(buf[off+8:off+24])
                node.formid = struct.unpack_from('<I', buf, off+12)[0]
                node.data = bytes(buf[off+REC_HDR:off+REC_HDR+size])
                out.append(node)
                off += REC_HDR + size
    walk(0, len(buf), root)
    return root


def walk_recs(nodes):
    for n in nodes:
        if n.kind == 'grup':
            yield from walk_recs(n.children)
        else:
            yield n


def subrecords(rec):
    body = rec.data
    if struct.unpack_from('<I', rec.tail, 0)[0] & 0x00040000:
        usz = struct.unpack_from('<I', body, 0)[0]
        body = zlib.decompress(body[4:])
        assert len(body) == usz
    out = []
    off = 0
    while off < len(body):
        st = body[off:off+4].decode('ascii', 'replace')
        ssz = struct.unpack_from('<H', body, off+4)[0]
        val = bytes(body[off+6:off+6+ssz])
        out.append((st, val))
        if st == 'XXXX':
            real = struct.unpack_from('<I', body, off+6)[0]
            off += 6 + ssz + 6 + real
            continue
        off += 6 + ssz
    return out


def text_of(rec, sig):
    return next((v.rstrip(b'\x00').decode('utf-8', 'replace')
                 for st, v in subrecords(rec) if st == sig), '')


def main():
    print('=== 1) CRC-регресс 61 файла ===')
    with zipfile.ZipFile(SRC_ZIP) as z:
        old_names = set(z.namelist())
        new_files = {}
        for dp, _, fns in os.walk(NEW):
            for fn in fns:
                rel = os.path.relpath(os.path.join(dp, fn), NEW).replace(os.sep, '/')
                new_files[rel] = open(os.path.join(dp, fn), 'rb').read()
        old_bytes = {n: z.read(n) for n in old_names}
    check(set(new_files) == old_names, f'состав: 63 файла, совпадение имён '
          f'({len(new_files)}/63)')
    changed = [n for n in old_names
               if hashlib.md5(new_files[n]).hexdigest()
               != hashlib.md5(old_bytes[n]).hexdigest()]
    check(sorted(changed) == sorted([MAIN]), f'изменён ровно 1 ESP: {changed}')
    for n in old_names - {MAIN}:
        if new_files[n] != old_bytes[n]:
            check(False, f'НЕИЗВЕСТНОЕ ИЗМЕНЕНИЕ: {n}')
    print('  ✓ 62 файла байт-в-байт идентичны v1.5.16 (вкл. CC-патчи)')
    check(hashlib.md5(old_bytes[MAIN]).hexdigest() == V116_ESP_MD5,
          'старый main ESP == запись выпуска v1.5.16 (md5)')
    check(hashlib.md5(old_bytes[CC]).hexdigest() == V116_CC_ORCSCALED_MD5
          and hashlib.md5(new_files[CC]).hexdigest() == V116_CC_ORCSCALED_MD5,
          'CC OrcishScaled не тронут (md5 байт-в-байт, ламелляр-серия 115 цела)')

    print('=== 2) побайтовый регресс записей main ESP ===')
    old_esp = old_bytes[MAIN]
    new_esp = new_files[MAIN]
    old_root = parse(old_esp)
    new_root = parse(new_esp)
    old_map = {r.formid: r for r in walk_recs(old_root)}
    new_map = {r.formid: r for r in walk_recs(new_root)}
    check(len(old_map) == 17017 and len(new_map) == 17017,
          f'записей: old {len(old_map)}, new {len(new_map)} (+0)')
    diffs = []
    for fid, old_r in old_map.items():
        new_r = new_map.get(fid)
        if new_r is None:
            diffs.append((fid, 'ИСЧЕЗЛА'))
        elif old_r.data != new_r.data or old_r.tail[:4] != new_r.tail[:4]:
            if fid not in PATCH_IDS:
                diffs.append((fid, 'ПОСТОРОННЕЕ ИЗМЕНЕНИЕ'))
    check(not diffs, f'посторонних изменений нет ({len(diffs)})')
    for fid, why in diffs[:10]:
        print(f'    ! {fid:08X} {why}')
    check(all(f in new_map for f in PATCH_IDS),
          'все 4 patched-formid существуют')
    for fid in PATCH_IDS:
        so, sn = subrecords(old_map[fid]), subrecords(new_map[fid])
        only_desc = ([(s, v) for s, v in so if s != 'DESC']
                     == [(s, v) for s, v in sn if s != 'DESC'])
        check(only_desc, f'{fid:08X}: изменено только поле DESC (EDID/INAM/'
              f'DNAM/TNAM байт-в-байт)')

    print('=== 3) dump-дифф текстов ===')
    with io.open(DUMP_NEW, 'w', encoding='utf-8') as out:
        jobs = [(f'{NEW}/00 Core/PathsOfEmpyrean.esp', 'main'),
                (f'{NEW}/10 Missing Shields/PoE-Addon-MissingShields.esp', 'ms'),
                (f'{NEW}/20 Spears/PoE-Addon-Spears.esp', 'sp')]
        for dp, _, fns in os.walk(f'{NEW}/30 CC Patches'):
            for fn in sorted(fns):
                if fn.lower().endswith('.esp'):
                    tag = 'cc:' + fn.replace('PoE-CC', '').replace('-Patch.esp', '')
                    jobs.append((os.path.join(dp, fn), tag))
        for path, tag in jobs:
            dump_esp(path, tag, out)
    fields = [json.loads(l) for l in io.open(DUMP_NEW, encoding='utf-8')]
    old_fields = [json.loads(l) for l in io.open(DUMP_OLD, encoding='utf-8')]
    check(len(fields) == 12338, f'полей: {len(fields)} (ожидается 12 338)')
    om = {(r['file'], r['formid'], r['rtype'], r['field'], r.get('occ', 1)): r['text']
          for r in old_fields}
    nm = {(r['file'], r['formid'], r['rtype'], r['field'], r.get('occ', 1)): r['text']
          for r in fields}
    removed = [k for k in om if k not in nm]
    added = [k for k in nm if k not in om]
    check(not removed, f'ключей пропало: {len(removed)}')
    check(not added, f'ключей добавилось: {len(added)}')
    fixes = [json.loads(l) for l in io.open(FIX, encoding='utf-8')]
    expect = {(('main' if f['scope'] == 'main' else f['scope']), f['formid'],
               'MESG', f['field'], f['occ']): (f['old'], f['new'])
              for f in fixes}
    changed_keys = [k for k in om if k in nm and om[k] != nm[k]]
    ok_changed = 0
    for k in changed_keys:
        exp = expect.get(k)
        if exp and om[k] == exp[0] and nm[k] == exp[1]:
            ok_changed += 1
        else:
            check(False, f'вне fixlist: {k}: {om[k]!r} -> {nm[k]!r}')
    check(ok_changed == 4 == len(changed_keys),
          f'изменённых полей ровно 4 == fixlist ({ok_changed})')

    print('=== 4) матрица маскировочных строк ×17 и гигиена ===')
    for fid, want in STR_DISG.items():
        got = text_of(new_map[fid], 'DESC')
        check(got == want, f'MESG {fid:08X}: {got!r}')
    for fid, want in FEM_DISG.items():
        got = text_of(new_map[fid], 'DESC')
        check(got == want, f'MESG_F {fid:08X}: {got!r} (не тронут)')
    mgef_full = {r['formid']: r['text'] for r in fields
                 if r['rtype'] == 'MGEF' and r['field'] == 'FULL'}
    check(mgef_full.get('06024577') == 'Маскировка - вампира'
          or sum(1 for t in mgef_full.values() if t.startswith('Маскировка - ')) >= 12,
          f'MGEF FULL «Маскировка - …» серия на месте '
          f'({sum(1 for t in mgef_full.values() if t.startswith("Маскировка - "))} шт.)')
    dnam_vals = {r['formid']: r['text'] for r in fields
                 if r['rtype'] == 'MGEF' and r['field'] == 'DNAM'}
    check(dnam_vals.get('06060EA1') == 'Талмор примет вас за своего.'
          and sum(1 for t in dnam_vals.values() if 'примет вас за своего' in t) >= 2,
          f'DNAM MGEF «Талмор примет вас за своего.» на месте '
          f'(организация-субъект; «примет вас за своего» ×'
          f'{sum(1 for t in dnam_vals.values() if "примет вас за своего" in t)})')
    low_hits = []
    for r in fields:
        for frag in LOWERCASE_FRAGS:
            if frag in r['text']:
                low_hits.append((r['file'], r['formid'], r['field'], frag))
    check(not low_hits, f'lowercase-фрагменты ({", ".join(LOWERCASE_FRAGS)}) '
          f'в текстовых полях = 0: {low_hits[:5]}')
    check(not any('под талмора' in r['text'] for r in fields),
          '«под талмора» = 0 (санкция 115 держится)')
    dragon_ok = sum(1 for r in fields
                    if r['text'] == 'Драконьи чешуйчатые перчатки драчуна')
    check(dragon_ok == 2, f'дракон-«чешуйчатая» серия не тронута '
          f'(«перчатки драчуна» ×{dragon_ok}, ожидается 2)')
    orcs_bad = sum(1 for r in fields
                   if 'Орочья чешуйчатая' in r['text']
                   or 'Орочьи чешуйчатые' in r['text'])
    check(orcs_bad == 0, f'«Ороч* чешуйчат*» = 0 (вердикт 113-а держится)')

    print('=== 5) итоговые md5 ===')
    print(f'  {MAIN}: {hashlib.md5(new_files[MAIN]).hexdigest()} '
          f'({len(new_files[MAIN])} Б)')

    print()
    if FAILED:
        print(f'ПРОВАЛОВ: {len(FAILED)}')
        for m in FAILED:
            print(f'  - {m}')
        sys.exit(1)
    print('ВСЕ ПРОВЕРКИ ПРОЙДЕНЫ')


if __name__ == '__main__':
    main()
