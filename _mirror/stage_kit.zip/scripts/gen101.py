#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 101: генерация свежего справочного слоя handoff/06_код-истина_перевода/
из истины — дампа выпущенного пакета v1.5.7 (work/qa100/dump_v157.jsonl).

Директива игрока: «нам не нужны устаревшие данные, только полезные и свежие».

Создаёт:
1. desc_ru.py     — свежее зеркало PERK DESC (566 записей, ключ=EDID,
                    конфликт EDID между файлами -> 'EDID@file');
2. corpus57.json  — зеркало всех 12 323 текстовых полей дампа
                    (+ en-пары из corpus56.json, где совпадает ключ);
3. _архив_мастер-эры/ — сюда переезжают desc_ru.py (старый), full_names_ru.py,
                    corpus56.json, patch_log.json, patch_log14.json + README.md;
4. README.md слоя — что свежее, что архив, что терминология;
5. INI-копии (DESC.ini, ShortbowNames_ru.ini) — обновляются байтами из zip.

НЕ трогает: spell_names_ru.py, official_terms42.py (терминология, не зеркало),
perks_v149.jsonl (эталон v1.4.9, запрет на изменение), выпущенный zip.
"""
import io, json, os, re, shutil, zipfile
from collections import defaultdict

ROOT = '/home/z/my-project'
DIR06 = f'{ROOT}/handoff/06_код-истина_перевода'
DUMP = f'{ROOT}/work/qa100/dump_v157.jsonl'
ARC = f'{DIR06}/_архив_мастер-эры'
RU_ZIP = f'{ROOT}/Paths of Empyrean RU 1.5.zip'

os.makedirs(ARC, exist_ok=True)
fields = [json.loads(l) for l in io.open(DUMP, encoding='utf-8')]
print(f'дамп: {len(fields)} полей')

# ---------- 0) архив мастер-эры (ДО генерации) ----------
moved = []
for name in ['full_names_ru.py', 'corpus56.json', 'patch_log.json',
             'patch_log14.json', 'desc_ru.py']:
    src = f'{DIR06}/{name}'
    if os.path.isfile(src):
        shutil.move(src, f'{ARC}/{name}')
        moved.append(name)
print('заархивировано:', moved)

# ---------- 1) свежий desc_ru.py ----------
perk_desc = [r for r in fields if r['rtype'] == 'PERK' and r['field'] == 'DESC']
# группировка по (file, edid) -> текст
by_file_edid = defaultdict(dict)
for r in perk_desc:
    by_file_edid[r['file']].setdefault(r['edid'], r['text'])
# конфликт EDID между файлами?
edid_files = defaultdict(set)
for f, d in by_file_edid.items():
    for e in d:
        edid_files[e].add(f)
conflict = {e: fs for e, fs in edid_files.items() if len(fs) > 1}
items = []  # (ключ, текст)
for f, d in by_file_edid.items():
    for e, t in d.items():
        key = f'{e}@{f}' if e in conflict else e
        items.append((key, t))
print(f'PERK DESC: {len(perk_desc)} записей -> {len(items)} ключей; '
      f'конфликтов EDID между файлами: {len(conflict)}')

def group(key):
    if key.startswith('PoE_PERK_'):
        return 'PoE: деревья перков'
    if key.startswith('GRIM_PERK_'):
        return 'Grimoire (GRIM): перки'
    if key.startswith(('ISP_', 'IWP_')):
        return 'Надстройки/патчи (ISP/IWP)'
    return 'Ванильные перки (офиц. стиль)'

groups = defaultdict(list)
for k, t in items:
    groups[group(k)].append((k, t))
for g in groups:
    groups[g].sort()

hdr = '''# -*- coding: utf-8 -*-
"""
Свежее зеркало PERK DESC выпущенного пакета v1.5.7 (Этап 101).
Источник: дамп истины work/qa100/dump_v157.jsonl (39 ESP), генератор
scripts/gen101.py; дата: 03.11.2026. Ключ = EDID; для EDID, совпадающих
в разных ESP, ключ = 'EDID@file' (file как в дампе: main/ms/sp/cc:...).
Правило проекта: истина = выпущенный ESP (02_конвейер_и_сборка.md), урок [T37]:
справочные слои мастер-эры этим зеркалам НЕ соответствуют и заархивированы в
_архив_мастер-эры/. При выпуске v1.5.8+ перегенерировать (шаг в 02_конвейере).
Стиль текстов — сам ESP; правки вносятся только через этапный fixlist.
"""

DESC_RU = {
'''
parts = [hdr]
for g in ['PoE: деревья перков', 'Grimoire (GRIM): перки',
          'Надстройки/патчи (ISP/IWP)', 'Ванильные перки (офиц. стиль)']:
    parts.append(f'    # ===== {g} =====\n')
    for k, t in groups[g]:
        parts.append(f'    {k!r}: {t!r},\n')
    parts.append('\n')
parts.append('}\n')
open(f'{DIR06}/desc_ru.py', 'w', encoding='utf-8').write(''.join(parts))
print(f'desc_ru.py перезаписан: {len(items)} ключей')

# ---------- 2) свежий corpus57.json ----------
c56 = json.load(io.open(f'{ARC}/corpus56.json', encoding='utf-8'))
en_map = {}
for e in c56:
    en = e.get('en')
    if en is not None:
        en_map.setdefault((e['fid'], e['type'], e['field']), en)
corpus = []
en_n = 0
for r in fields:
    e = {'fid': r['formid'], 'edid': r['edid'], 'type': r['rtype'],
         'field': r['field'], 'occ': r.get('occ', 1), 'file': r['file'],
         'ru': r['text']}
    en = en_map.get((r['formid'], r['rtype'], r['field']))
    if en is not None:
        e['en'] = en
        en_n += 1
    corpus.append(e)
with io.open(f'{DIR06}/corpus57.json', 'w', encoding='utf-8') as f:
    json.dump(corpus, f, ensure_ascii=False, indent=1)
print(f'corpus57.json: {len(corpus)} записей, en-пар: {en_n}')

# ---------- 3) README архива ----------

arc_readme = '''# Архив мастер-эры (06_код-истина_перевода)

Справочные слои удалённого каскада master47–76 (пересборка «из EN»).
Урок [T37] (Этап 100): слой desc_ru.py мастер-эры совпадал с ESP лишь в
78 из 482 ключей; corpus56.json (корпус Этапа 56, сборка v1.13/14) — в
6 111 из 9 718 записей. Промежуточный доклад по ним даёт ОБРАТНЫЙ результат.

По директиве игрока (Этап 101, 03.11.2026: «нам не нужны устаревшие данные,
только полезные и свежие») слои сняты с активного уровня и оставлены только
как исторический источник решений (вердикты Этапов 39/40/42/43 — в
full_names_ru.py; правила материала/лейблов MAT_LB/LB_*/GENDER — там же).

АКТУАЛЬНЫЕ зеркала истины: `../desc_ru.py` и `../corpus57.json`
(сгенерированы из дампа выпущенного пакета v1.5.7).
Терминология (не зеркало ESP): `../spell_names_ru.py` (род. падежи),
`../official_terms42.py` (офиц. термины SoftClub).

Состав архива:
- desc_ru.py        — снимок PERK DESC до переработок Этапов 62/93/94;
- full_names_ru.py  — 14 данных-слоёв EN→RU + правила стиля лейблов;
- corpus56.json     — корпус Этапа 56 (v1.13/14), 9 718 записей en+ru;
- patch_log.json / patch_log14.json — логи патчей каскада (v1.5.x / v1.4).
'''
io.open(f'{ARC}/README.md', 'w', encoding='utf-8').write(arc_readme)
print(f'README архива записан: {ARC}/README.md')

# ---------- 4) README слоя 06_ ----------
layer_readme = '''# 06_код-истина_перевода — справочный слой (обновлён Этапом 101)

Истина проекта — выпущенный пакет `Paths of Empyrean RU 1.5.zip` (корень пака).
Дамп истины: `work/qa100/dump_v157.jsonl` (39 ESP, 12 323 текстовых поля).

СВЕЖЕЕ (сгенерировано Этапом 101 из дампа v1.5.7, генератор scripts/gen101.py):
- `desc_ru.py`    — зеркало всех 566 PERK DESC (ключ = EDID, конфликты — EDID@file);
- `corpus57.json` — зеркало всех текстовых полей (FULL/DESC/ITXT/NNAM/DNAM/GMST),
                    12 323 записи; en-пары из corpus56 — 8 902
                    (семантика «en is not None»: 2 414 пустых строк +
                    6 488 непустых; в источнике corpus56 en есть во всех
                    9 718 записях, непустых 6 528);
- `PathsOfEmpyrean_DESC.ini`, `ShortbowNames_ru.ini` — байтовые копии файлов
                    выпущенного пакета (00 Core), обновлены из zip;

ТЕРМИНОЛОГИЯ (актуальна, не зеркало ESP):
- `spell_names_ru.py` — род. падежи имён заклинаний («Свиток X»);
- `official_terms42.py` — таблица офиц. терминов SoftClub с доказательствами.

АРХИВ МАСТЕР-ЭРЫ (историческая ценность, НЕ читать как истину — урок [T37]):
- `_архив_мастер-эры/` — desc/corpus/patch-логи каскада master47–76 + README.

Правило: при выпуске v1.5.8+ перегенерировать зеркала из нового дампа
(шаг в 02_конвейер_и_сборка.md).
'''
io.open(f'{DIR06}/README.md', 'w', encoding='utf-8').write(layer_readme)
print(f'README слоя записан: {DIR06}/README.md')

# ---------- 5) INI-копии из zip ----------
with zipfile.ZipFile(RU_ZIP) as z:
    for arc, local in [('00 Core/PathsOfEmpyrean_DESC.ini', 'PathsOfEmpyrean_DESC.ini'),
                       ('00 Core/SKSE/Plugins/POE/Weapon/PathsOfEmpyrean_ShortbowNames.ini',
                        'ShortbowNames_ru.ini')]:
        data = z.read(arc)
        open(f'{DIR06}/{local}', 'wb').write(data)
        print(f'INI обновлён из zip: {local} ({len(data)} Б)')

print('OK')
