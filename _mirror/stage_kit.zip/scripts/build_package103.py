#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 103: сборка пакета v1.5.8 (вербаты 102-а «сильнее» + регистр 100-а).

Источник — выпущенный zip v1.5.7 (корень пака). Замены: 00 Core/PathsOfEmpyrean.esp
(из work/v158) + fomod/*.xml (версия 1.5.7 -> 1.5.8). Все остальные записи
копируются байт-в-байт (ZipInfo: даты/атрибуты/метод сжатия, [D9]).
Выход: download/Paths of Empyrean RU 1.5.zip — имя файла то же (замена на Nexus)."""
import zipfile, re, os

SRC = '/home/z/my-project/upload/poe_pack/Paths of Empyrean RU 1.5.zip'
DST = '/home/z/my-project/download/Paths of Empyrean RU 1.5.zip'
V158 = '/home/z/my-project/upload/poe_pack/work/v158'

REPLACE_FILES = {
    '00 Core/PathsOfEmpyrean.esp': f'{V158}/00 Core/PathsOfEmpyrean.esp',
}


def patch_module_config(xml):
    n = xml.count('v1.5.7')
    assert n == 1, f'moduleName v1.5.7 встречается {n} раз'
    xml2 = xml.replace('v1.5.7', 'v1.5.8')
    assert 'v1.5.7' not in xml2
    print('  ModuleConfig.xml: moduleName -> v1.5.8')
    return xml2


def patch_info(xml):
    assert '<Version>1.5.7</Version>' in xml
    xml2 = xml.replace('<Version>1.5.7</Version>', '<Version>1.5.8</Version>')
    print('  info.xml: Version -> 1.5.8')
    return xml2


def main():
    zin = zipfile.ZipFile(SRC)
    names = zin.namelist()
    print('исходный архив:', len(names), 'записей')

    # Снимок CRC оригинала ДО записи (writestr мутирует ZipInfo, [D9])
    orig_crc = {i.filename: i.CRC for i in zin.infolist()}

    mc = zin.read('fomod/ModuleConfig.xml').decode('utf-8')
    info = zin.read('fomod/info.xml').decode('utf-8')
    mc2 = patch_module_config(mc)
    info2 = patch_info(info)

    replacements = dict(REPLACE_FILES)
    for arc, path in replacements.items():
        assert os.path.exists(path), path
        assert arc in names, arc

    os.makedirs(os.path.dirname(DST), exist_ok=True)
    zout = zipfile.ZipFile(DST, 'w')
    changed = []
    for item in zin.infolist():
        arc = item.filename
        if arc == 'fomod/ModuleConfig.xml':
            zout.writestr(item, mc2.encode('utf-8'))
            changed.append(arc)
        elif arc == 'fomod/info.xml':
            zout.writestr(item, info2.encode('utf-8'))
            changed.append(arc)
        elif arc in replacements:
            zout.writestr(item, open(replacements[arc], 'rb').read())
            changed.append(arc)
        else:
            zout.writestr(item, zin.read(arc))
    zout.close()
    print('заменено записей:', len(changed))
    for c in changed:
        print('  *', c)

    # ---------------- ВЕРИФИКАЦИЯ ----------------
    print()
    print('=== ВЕРИФИКАЦИЯ ПАКЕТА ===')
    z2 = zipfile.ZipFile(DST)
    names2 = z2.namelist()
    assert z2.testzip() is None, 'testzip провален!'
    print('testzip: OK,', len(names2), 'записей')
    assert set(names2) == set(names), 'состав записей изменился (не должно!)'

    diff = []
    for n in names:
        c1 = orig_crc[n]
        c2 = z2.getinfo(n).CRC
        if c1 != c2:
            diff.append(n)
    expected = set(REPLACE_FILES) | {'fomod/ModuleConfig.xml', 'fomod/info.xml'}
    assert set(diff) == expected, f'CRC-дифф не совпал: {set(diff) ^ expected}'
    print(f'CRC: изменены ровно {len(diff)} ожидаемые записи, остальные {len(names) - len(diff)} байт-в-байт')

    xml = z2.read('fomod/ModuleConfig.xml').decode('utf-8')
    assert 'Readme_PoE_Russian.txt' not in xml
    srcs = set(re.findall(r'source="([^"]+)"', xml))
    missing = [s for s in srcs
               if not any(n == s or n.startswith(s + '/') for n in names2)]
    assert not missing, f'висячие source в FOMOD: {missing}'
    print(f'FOMOD: {len(srcs)} source-ссылок, все существуют; ссылок на readme нет')
    assert 'v1.5.8' in xml and 'v1.5.7' not in xml
    ver = z2.read('fomod/info.xml').decode('utf-8')
    assert '<Version>1.5.8</Version>' in ver
    print('версии: moduleName v1.5.8, info.xml 1.5.8')

    print()
    print('ПАКЕТ:', DST, f'({os.path.getsize(DST)} B)')
    print('ГОТОВ К ПЕРЕЗАЛИВКЕ НА NEXUS')


if __name__ == '__main__':
    main()
