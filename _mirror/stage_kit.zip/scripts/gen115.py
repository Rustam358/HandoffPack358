#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 115: перегенерация слоя handoff/06_код-истина_перевода из истины —
выпущенного пакета v1.5.16. Образец — gen114.py.
Контроль: дифф corpus57 == ровно 11 полей fixlist 115 + 15 новых (клоны).
"""
import io, json, os, shutil, zipfile, sys, glob
from collections import defaultdict

sys.path.insert(0, '/home/z/my-project/work/handoff510/scripts')
from dump150 import dump_esp

DL = '/home/z/my-project/download/Paths of Empyrean RU 1.5.zip'
HANDOFF = '/home/z/my-project/work/handoff510/handoff'
DIR06 = f'{HANDOFF}/06_код-истина_перевода'
ARC = f'{DIR06}/_архив_мастер-эры'
REL = '/home/z/my-project/work/qa115/release116'
DUMP = '/home/z/my-project/work/qa115/dump_v116_full.jsonl'
FIX = '/home/z/my-project/work/qa115/fixlist_v116.jsonl'

if not os.path.isfile(f'{REL}/00 Core/PathsOfEmpyrean.esp'):
    with zipfile.ZipFile(DL) as z:
        z.extractall(REL)
if os.path.isfile(DUMP):
    os.remove(DUMP)  # порядок обхода критичен для corpus57 (ключ без file) — пересоздаём
with io.open(DUMP, 'w', encoding='utf-8') as out:
    total = 0
    jobs = [(f'{REL}/00 Core/PathsOfEmpyrean.esp', 'main'),
            (f'{REL}/10 Missing Shields/PoE-Addon-MissingShields.esp', 'ms'),
            (f'{REL}/20 Spears/PoE-Addon-Spears.esp', 'sp')]
    for path in sorted(glob.glob(f'{REL}/30 CC Patches/*/*.esp')):
        tag = 'cc:' + os.path.basename(path).replace('PoE-CC', '').replace('-Patch.esp', '')
        jobs.append((path, tag))
    for path, tag in jobs:
        p = dump_esp(path, tag, out)
        total += len(p.records)
print(f'дамп v1.5.16 (порядок gen114): {DUMP}')
fields = [json.loads(l) for l in io.open(DUMP, encoding='utf-8')]
print(f'полей текста: {len(fields)} (ожидается 12 338)')
assert len(fields) == 12338

old_corpus = json.load(io.open(f'{DIR06}/corpus57.json', encoding='utf-8'))  # истина v1.5.15
fixes = [json.loads(l) for l in io.open(FIX, encoding='utf-8')]
esp_fixes = {(f['formid'], f['field'], f['occ']): (f['old'], f['new']) for f in fixes}
# ПОЛНЫЙ контроль по file-ключам: дамп v1.5.15 -> дамп v1.5.16
# (corpus57 хранит ключ без file и дедуплицирует коллидированные formid
# между cc-патчами — её дифф неполный, контроль ведём по дампам)
old_fields = [json.loads(l) for l in io.open('/home/z/my-project/work/qa114/dump_v115_full.jsonl', encoding='utf-8')]
old_full = {(r['file'], r['formid'], r['rtype'], r['field'], r.get('occ', 1)): r['text'] for r in old_fields}
new_full = {(r['file'], r['formid'], r['rtype'], r['field'], r.get('occ', 1)): r['text'] for r in fields}
tag_fix = {'main': 'main', 'cc:AltArmorOrcishScaled': 'cc:AltArmorOrcishScaled'}
removed = [k for k in old_full if k not in new_full]
added = [k for k in new_full if k not in old_full]
assert not removed, f'ключи дампа исчезли: {removed}'
diff = []
for k in old_full:
    if k in new_full and old_full[k] != new_full[k]:
        exp = esp_fixes.get((k[1], k[3], k[4]))
        assert exp is not None, f'вне fixlist: {k}: {old_full[k]!r} -> {new_full[k]!r}'
        assert old_full[k] == exp[0] and new_full[k] == exp[1], \
            f'несовпадение fixlist: {k}: {old_full[k]!r} -> {new_full[k]!r}'
        diff.append(k)
assert len(diff) == 11, f'file-дифф = {len(diff)} != 11 (5 main + 6 CC)'
n_main = sum(1 for k in diff if k[0] == 'main')
n_cc = sum(1 for k in diff if k[0] == 'cc:AltArmorOrcishScaled')
assert (n_main, n_cc) == (5, 6), f'разбивка диффа: main={n_main}, cc={n_cc}'
assert len(added) == 15, f'новых ключей {len(added)} != 15: {added[:4]}'
print(f'контроль: дифф v1.5.15 -> v1.5.16 = {n_main} main (санкция 115) + '
      f'{n_cc} CC (вердикт 113-а) + {len(added)} новых '
      f'(5 MESG_F DESC + 5 MGEF_F FULL/DNAM)')

moved = []
for name, arcname in [('desc_ru.py', 'desc_ru_v1515.py'),
                      ('corpus57.json', 'corpus57_v1515.json')]:
    src = f'{DIR06}/{name}'
    dst = f'{ARC}/{arcname}'
    if os.path.isfile(src) and not os.path.exists(dst):
        shutil.move(src, dst)
        moved.append(f'{name} -> {arcname}')
print('заархивировано:', moved or 'ничего (guard: уже в архиве)')

perk_desc = [r for r in fields if r['rtype'] == 'PERK' and r['field'] == 'DESC']
by_file_edid = defaultdict(dict)
for r in perk_desc:
    by_file_edid[r['file']].setdefault(r['edid'], r['text'])
edid_files = defaultdict(set)
for f, d in by_file_edid.items():
    for e in d:
        edid_files[e].add(f)
conflict = {e: fs for e, fs in edid_files.items() if len(fs) > 1}
items = []
for f, d in by_file_edid.items():
    for e, t in d.items():
        key = f'{e}@{f}' if e in conflict else e
        items.append((key, t))
print(f'PERK DESC: {len(perk_desc)} записей -> {len(items)} ключей; '
      f'конфликтов EDID: {len(conflict)}')
assert len(perk_desc) == 566


def group(key):
    if key.startswith('PoE_PERK_'):
        return 'PoE: деревья перков'
    if key.startswith('GRIM_PERK_'):
        return 'Grimoire (GRIM): перки'
    if key.startswith(('ISP_', 'IWP_')):
        return 'Надстройки/патчи (ISP/IWP)'
    return 'Ванильные перки (офиц. стиль)'


groups = defaultdict(list)
for k, t in items:
    groups[group(k)].append((k, t))
for g in groups:
    groups[g].sort()

hdr = '''# -*- coding: utf-8 -*-
"""
Свежее зеркало PERK DESC выпущенного пакета v1.5.16 (Этап 115).
Источник: дамп истины work/qa115/dump_v116_full.jsonl (39 ESP), генератор
scripts/gen115.py; дата: 07.11.2026. Ключ = EDID; для EDID, совпадающих
в разных ESP, ключ = 'EDID@file' (file как в дампе: main/ms/sp/cc:...).
Правило проекта: истина = выпущенный ESP (02_конвейер_и_сборка.md), урок [T37]:
предыдущие зеркала заархивированы в _архив_мастер-эры/ под версионированными
именами (desc_ru_v1515.py, corpus57_v1515.json). При выпуске v1.5.17+
перегенерировать (шаг 11 в 02_конвейер_и_сборка.md).
Стиль текстов — сам ESP; правки вносятся только через этапный fixlist.
"""

DESC_RU = {
'''
parts = [hdr]
for g in ['PoE: деревья перков', 'Grimoire (GRIM): перки',
          'Надстройки/патчи (ISP/IWP)', 'Ванильные перки (офиц. стиль)']:
    parts.append(f'    # ===== {g} =====\n')
    for k, t in groups[g]:
        parts.append(f'    {k!r}: {t!r},\n')
    parts.append('\n')
parts.append('}\n')
io.open(f'{DIR06}/desc_ru.py', 'w', encoding='utf-8').write(''.join(parts))
print(f'desc_ru.py перезаписан (v1.5.16): {len(items)} ключей')

c56 = json.load(io.open(f'{ARC}/corpus56.json', encoding='utf-8'))
en_map = {}
for e in c56:
    en = e.get('en')
    if en is not None:
        en_map.setdefault((e['fid'], e['type'], e['field']), en)
corpus = []
en_n = 0
for r in fields:
    e = {'fid': r['formid'], 'edid': r['edid'], 'type': r['rtype'],
         'field': r['field'], 'occ': r.get('occ', 1), 'file': r['file'],
         'ru': r['text']}
    en = en_map.get((r['formid'], r['rtype'], r['field']))
    if en is not None:
        e['en'] = en
        en_n += 1
    corpus.append(e)
with io.open(f'{DIR06}/corpus57.json', 'w', encoding='utf-8') as f:
    json.dump(corpus, f, ensure_ascii=False, indent=1)
print(f'corpus57.json (v1.5.16): {len(corpus)} записей, en-пар: {en_n}')

# байтовые копии файлов пакета (00 Core) — как в gen114
for name, dst in [
    ('00 Core/PathsOfEmpyrean_DESC.ini', 'PathsOfEmpyrean_DESC.ini'),
    ('00 Core/SKSE/Plugins/POE/Weapon/PathsOfEmpyrean_ShortbowNames.ini',
     'ShortbowNames_ru.ini'),
    ('00 Core/SKSE/Plugins/ArcheryLocationalDamage.ini',
     'ArcheryLocationalDamage_ru.ini'),
    ('00 Core/Interface/Translations/PathsOfEmpyrean_RUSSIAN.txt',
     'PathsOfEmpyrean_RUSSIAN.txt'),
]:
    with zipfile.ZipFile(DL) as z:
        open(f'{DIR06}/{dst}', 'wb').write(z.read(name))
print('байтовые копии INI/TXT обновлены из zip v1.5.16')

arc_readme = '''# Архив (06_код-истина_перевода)

Исторические справочные слои. НЕ читать как истину — урок [T37] (Этап 100):
слой desc_ru.py мастер-эры совпадал с ESP лишь в 78 из 482 ключей; corpus56.json
(корпус Этапа 56, сборка v1.13/14) — в 6 111 из 9 718 записей.

АКТУАЛЬНЫЕ зеркала истины: `../desc_ru.py` и `../corpus57.json` (v1.5.16,
Этап 115). Терминология (не зеркало ESP): `../spell_names_ru.py`,
`../official_terms42.py`.

Состав архива:
- desc_ru.py / corpus56.json / full_names_ru.py / patch_log.json / patch_log14.json
  — слои каскада master47–76 (пересборка «из EN») + README данных;
- desc_ru_v157.py / corpus57_v157.json — зеркала выпущенного v1.5.7 (Этап 101);
- desc_ru_v158.py / corpus57_v158.json — зеркала выпущенного v1.5.8 (Этап 103);
- desc_ru_v159.py / corpus57_v159.json — зеркала выпущенного v1.5.9 (Этап 104);
- desc_ru_v1512.py / corpus57_v1512.json — зеркала выпущенного v1.5.12 (Этап 111);
- desc_ru_v1513.py / corpus57_v1513.json — зеркала выпущенного v1.5.13 (Этап 112);
- desc_ru_v1514.py / corpus57_v1514.json — зеркала выпущенного v1.5.14 (Этап 113);
- desc_ru_v1515.py / corpus57_v1515.json — зеркала выпущенного v1.5.15 (Этап 114).
'''
io.open(f'{ARC}/README.md', 'w', encoding='utf-8').write(arc_readme)
print(f'README архива записан: {ARC}/README.md')

layer_readme = '''# 06_код-истина_перевода — справочный слой (обновлён Этапом 115)

Истина проекта — выпущенный пакет `Paths of Empyrean RU 1.5.zip` (корень пака),
с Этапа 115 — **v1.5.16** (вердикт 113-а: CC «Orcish Scaled» → «Орочья
ламеллярная …» по тир-словарю; санкция 115: гендерная система маскировочных
сообщений ISP Speech — 5 женских MESG/MGEF-клонов + CTDA GetIsSex, 5 MESG
«для обоих полов» по списку игрока). Этап 113 — откат 9 правок 112 по
тир-доктрине: EN Scaled = «ламеллярный», «чешуйчатый» = только Dragonscale.
Дамп истины: `work/qa115/dump_v116_full.jsonl` (39 ESP, 12 338 текстовых полей).

СВЕЖЕЕ (сгенерировано Этапом 115 из дампа v1.5.16, генератор scripts/gen115.py):
- `desc_ru.py`    — зеркало всех PERK DESC (ключ = EDID, конфликты — EDID@file);
- `corpus57.json` — зеркало всех текстовых полей (FULL/DESC/ITXT/NNAM/DNAM/GMST),
                    12 338 записей; en-пары из corpus56 (архив);
- `PathsOfEmpyrean_DESC.ini`, `ShortbowNames_ru.ini`,
  `ArcheryLocationalDamage_ru.ini`, `PathsOfEmpyrean_RUSSIAN.txt` — байтовые
                    копии файлов выпущенного пакета (00 Core), из zip v1.5.16.

ГЕНДЕР МАСКИРОВОЧНЫХ СООБЩЕНИЙ (санкция 115): женские строки — «Бандитку»,
«Сестру Бури», «Имперку», «Культистку», «Вампирессу»; «для обоих полов» —
«Изгоя», «Талмор», «Некроманта», «члена Стражи Рассвета», «Драугра»,
«Фалмера», «Двемерского автоматона». Регистр — точный по списку игрока.
Механизм: клоны MGEF + CTDA GetIsSex (func=70), MESG-формы — свойства VMAD
(Utility_ShowMessageMagicEff). Открытые вопросы 115 — в report_115.md.

ТЕРМИНОЛОГИЯ (актуальна, не зеркало ESP):
- `spell_names_ru.py` — род. падежи имён заклинаний («Свиток X»);
- `official_terms42.py` — таблица офиц. терминов SoftClub с доказательствами.
  ТИР-СЛОВАРЬ ИГРОКА (санкции 113/115): EN Scaled = «ламеллярный» (низкий/
  средний тир, включая CC Orcish Scaled), EN Dragonscale = «драконий чешуйчатый»
  (высокий тир), EN Dragonplate = «драконий панцирный» (высокий тир);
  «чешуйчатый» без «драконий» в названиях тиров брони не используется.

АРХИВ (историческая ценность, НЕ читать как истину — урок [T37]):
- `_архив_мастер-эры/` — слои каскада master47–76 + зеркала v1.5.7/v1.5.8/
  v1.5.9/v1.5.12/v1.5.13/v1.5.14/v1.5.15 + README.

Правило: при выпуске v1.5.17+ перегенерировать зеркала из нового дампа
(шаг 11 в 02_конвейер_и_сборка.md).
'''
io.open(f'{DIR06}/README.md', 'w', encoding='utf-8').write(layer_readme)
print(f'README слоя записан: {DIR06}/README.md')
print('gen115: OK')
