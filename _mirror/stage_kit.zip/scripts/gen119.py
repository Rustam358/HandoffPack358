#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 119: перегенерация слоя handoff/06_код-истина_перевода из истины —
выпущенного пакета v1.5.19. Образец — gen117.py (пути адаптированы: дерево
work/handoff510 утрачено при рецикле песочницы, зеркала пишутся прямо
в корневой handoff/06_код-истина_перевода — оно актуально).
Контроль: file-дифф дампов v1.5.18 → v1.5.19 == ровно 58 полей fixlist
(main 31 + cc:ExpandedCrossbowPack 24 + cc:Fishing 3).
"""
import io, json, os, shutil, zipfile, sys, glob, hashlib
from collections import defaultdict

sys.path.insert(0, '/home/z/my-project/scripts')
from dump150 import dump_esp

DL = '/home/z/my-project/download/Paths of Empyrean RU 1.5.zip'
DIR06 = '/home/z/my-project/handoff/06_код-истина_перевода'
ARC = f'{DIR06}/_архив_мастер-эры'
REL = '/home/z/my-project/work/qa119/release119'
DUMP = '/home/z/my-project/work/qa119/dump_v119_full.jsonl'
FIX = '/home/z/my-project/work/qa119/fixlist_v119.jsonl'
DUMP_OLD = '/home/z/my-project/work/qa117/dump_v118_full.jsonl'

if os.path.isdir(REL):
    shutil.rmtree(REL)  # всегда свежая распаковка истины ([T49])
with zipfile.ZipFile(DL) as z:
    assert z.testzip() is None
    info = z.read('fomod/info.xml').decode('utf-8')
    assert '<Version>1.5.19</Version>' in info, 'download-пакет не v1.5.19!'
    z.extractall(REL)
esp_md5 = hashlib.md5(open(f'{REL}/00 Core/PathsOfEmpyrean.esp', 'rb').read()).hexdigest()
print(f'истина: download-пакет v1.5.19 распакован в {REL}; main ESP md5 {esp_md5}')
if os.path.isfile(DUMP):
    os.remove(DUMP)
with io.open(DUMP, 'w', encoding='utf-8') as out:
    total = 0
    jobs = [(f'{REL}/00 Core/PathsOfEmpyrean.esp', 'main'),
            (f'{REL}/10 Missing Shields/PoE-Addon-MissingShields.esp', 'ms'),
            (f'{REL}/20 Spears/PoE-Addon-Spears.esp', 'sp')]
    for path in sorted(glob.glob(f'{REL}/30 CC Patches/*/*.esp')):
        tag = 'cc:' + os.path.basename(path).replace('PoE-CC', '').replace('-Patch.esp', '')
        jobs.append((path, tag))
    for path, tag in jobs:
        p = dump_esp(path, tag, out)
        total += len(p.records)
print(f'дамп v1.5.19 (порядок gen117): {DUMP}')
fields = [json.loads(l) for l in io.open(DUMP, encoding='utf-8')]
print(f'полей текста: {len(fields)} (ожидается 12 338)')
assert len(fields) == 12338

fixes = [json.loads(l) for l in io.open(FIX, encoding='utf-8')]
esp_fixes = {(f['file'], f['formid'], f['field'], f['occ']): (f['old'], f['new'])
             for f in fixes if f['kind'] == 'esp'}
old_fields = [json.loads(l) for l in io.open(DUMP_OLD, encoding='utf-8')]
old_full = {(r['file'], r['formid'], r['rtype'], r['field'], r.get('occ', 1)): r['text']
            for r in old_fields}
new_full = {(r['file'], r['formid'], r['rtype'], r['field'], r.get('occ', 1)): r['text']
            for r in fields}
removed = [k for k in old_full if k not in new_full]
added = [k for k in new_full if k not in old_full]
assert not removed, f'ключи дампа исчезли: {removed}'
assert not added, f'ключи дампа добавились: {added}'
diff = []
for k in old_full:
    if k in new_full and old_full[k] != new_full[k]:
        exp = esp_fixes.get((k[0], k[1], k[3], k[4]))
        assert exp is not None, f'вне fixlist: {k}: {old_full[k]!r} -> {new_full[k]!r}'
        assert old_full[k] == exp[0] and new_full[k] == exp[1], \
            f'несовпадение fixlist: {k}: {old_full[k]!r} -> {new_full[k]!r}'
        diff.append(k)
assert len(diff) == 58, f'file-дифф = {len(diff)} != 58'
by_file = defaultdict(int)
for k in diff:
    by_file[k[0]] += 1
assert dict(by_file) == {'main': 31, 'cc:ExpandedCrossbowPack': 24,
                         'cc:Fishing': 3}, dict(by_file)
print(f'контроль: дифф v1.5.18 -> v1.5.19 = ровно 58 полей == fixlist 119 '
      f'(main 31, ECP 24, Fishing 3)')

moved = []
for name, arcname in [('desc_ru.py', 'desc_ru_v1518.py'),
                      ('corpus57.json', 'corpus57_v1518.json')]:
    src = f'{DIR06}/{name}'
    dst = f'{ARC}/{arcname}'
    if os.path.isfile(src) and not os.path.exists(dst):
        shutil.move(src, dst)
        moved.append(f'{name} -> {arcname}')
print('заархивировано:', moved or 'ничего (guard: уже в архиве)')

perk_desc = [r for r in fields if r['rtype'] == 'PERK' and r['field'] == 'DESC']
by_file_edid = defaultdict(dict)
for r in perk_desc:
    by_file_edid[r['file']].setdefault(r['edid'], r['text'])
edid_files = defaultdict(set)
for f, d in by_file_edid.items():
    for e in d:
        edid_files[e].add(f)
conflict = {e: fs for e, fs in edid_files.items() if len(fs) > 1}
items = []
for f, d in by_file_edid.items():
    for e, t in d.items():
        key = f'{e}@{f}' if e in conflict else e
        items.append((key, t))
print(f'PERK DESC: {len(perk_desc)} записей -> {len(items)} ключей; '
      f'конфликтов EDID: {len(conflict)}')
assert len(perk_desc) == 566


def group(key):
    if key.startswith('PoE_PERK_'):
        return 'PoE: деревья перков'
    if key.startswith('GRIM_PERK_'):
        return 'Grimoire (GRIM): перки'
    if key.startswith(('ISP_', 'IWP_')):
        return 'Надстройки/патчи (ISP/IWP)'
    return 'Ванильные перки (офиц. стиль)'


groups = defaultdict(list)
for k, t in items:
    groups[group(k)].append((k, t))
for g in groups:
    groups[g].sort()

hdr = '''# -*- coding: utf-8 -*-
"""
Свежее зеркало PERK DESC выпущенного пакета v1.5.19 (Этап 119).
Источник: дамп истины work/qa119/dump_v119_full.jsonl (39 ESP), генератор
scripts/gen119.py; дата: 07.11.2026. Ключ = EDID; для EDID, совпадающих
в разных ESP, ключ = 'EDID@file' (file как в дампе: main/ms/sp/cc:...).
Правило проекта: истина = выпущенный ESP (02_конвейер_и_сборка.md), урок [T37]:
предыдущие зеркала заархивированы в _архив_мастер-эры/ под версионированными
именами (desc_ru_v1518.py, corpus57_v1518.json). При выпуске v1.5.20+
перегенерировать (шаг 11 в 02_конвейер_и_сборка.md).
Стиль текстов — сам ESP; правки вносятся только через этапный fixlist.
"""

DESC_RU = {
'''
parts = [hdr]
for g in ['PoE: деревья перков', 'Grimoire (GRIM): перки',
          'Надстройки/патчи (ISP/IWP)', 'Ванильные перки (офиц. стиль)']:
    parts.append(f'    # ===== {g} =====\n')
    for k, t in groups[g]:
        parts.append(f'    {k!r}: {t!r},\n')
    parts.append('\n')
parts.append('}\n')
io.open(f'{DIR06}/desc_ru.py', 'w', encoding='utf-8').write(''.join(parts))
print(f'desc_ru.py перезаписан (v1.5.19): {len(items)} ключей')

c56 = json.load(io.open(f'{ARC}/corpus56.json', encoding='utf-8'))
en_map = {}
for e in c56:
    en = e.get('en')
    if en is not None:
        en_map.setdefault((e['fid'], e['type'], e['field']), en)
corpus = []
en_n = 0
for r in fields:
    e = {'fid': r['formid'], 'edid': r['edid'], 'type': r['rtype'],
         'field': r['field'], 'occ': r.get('occ', 1), 'file': r['file'],
         'ru': r['text']}
    en = en_map.get((r['formid'], r['rtype'], r['field']))
    if en is not None:
        e['en'] = en
        en_n += 1
    corpus.append(e)
with io.open(f'{DIR06}/corpus57.json', 'w', encoding='utf-8') as f:
    json.dump(corpus, f, ensure_ascii=False, indent=1)
print(f'corpus57.json (v1.5.19): {len(corpus)} записей, en-пар: {en_n}')

for name, dst in [
    ('00 Core/PathsOfEmpyrean_DESC.ini', 'PathsOfEmpyrean_DESC.ini'),
    ('00 Core/SKSE/Plugins/POE/Weapon/PathsOfEmpyrean_ShortbowNames.ini',
     'ShortbowNames_ru.ini'),
    ('00 Core/SKSE/Plugins/ArcheryLocationalDamage.ini',
     'ArcheryLocationalDamage_ru.ini'),
    ('00 Core/Interface/Translations/PathsOfEmpyrean_RUSSIAN.txt',
     'PathsOfEmpyrean_RUSSIAN.txt'),
]:
    with zipfile.ZipFile(DL) as z:
        open(f'{DIR06}/{dst}', 'wb').write(z.read(name))
print('байтовые копии INI/TXT обновлены из zip v1.5.19 '
     '(ShortbowNames_ru.ini включает 118-е)')

arc_readme = '''# Архив (06_код-истина_перевода)

Исторические справочные слои. НЕ читать как истину — урок [T37] (Этап 100):
слой desc_ru.py мастер-эры совпадал с ESP лишь в 78 из 482 ключей; corpus56.json
(корпус Этапа 56, сборка v1.13/14) — в 6 111 из 9 718 записей.

АКТУАЛЬНЫЕ зеркала истины: `../desc_ru.py` и `../corpus57.json` (v1.5.19,
Этап 119). Терминология (не зеркало ESP): `../spell_names_ru.py`,
`../official_terms42.py`.

Состав архива:
- desc_ru.py / corpus56.json / full_names_ru.py / patch_log.json / patch_log14.json
  — слои каскада master47–76 (пересборка «из EN») + README данных;
- desc_ru_v157.py / corpus57_v157.json — зеркала выпущенного v1.5.7 (Этап 101);
- desc_ru_v158.py / corpus57_v158.json — зеркала выпущенного v1.5.8 (Этап 103);
- desc_ru_v159.py / corpus57_v159.json — зеркала выпущенного v1.5.9 (Этап 104);
- desc_ru_v1512.py / corpus57_v1512.json — зеркала выпущенного v1.5.12 (Этап 111);
- desc_ru_v1513.py / corpus57_v1513.json — зеркала выпущенного v1.5.13 (Этап 112);
- desc_ru_v1514.py / corpus57_v1514.json — зеркала выпущенного v1.5.14 (Этап 113);
- desc_ru_v1515.py / corpus57_v1515.json — зеркала выпущенного v1.5.15 (Этап 114);
- desc_ru_v1516.py / corpus57_v1516.json — зеркала выпущенного v1.5.16 (Этап 115);
- desc_ru_v1517.py / corpus57_v1517.json — зеркала выпущенного v1.5.17 (Этап 116);
- desc_ru_v1518.py / corpus57_v1518.json — зеркала выпущенного v1.5.18 (Этап 117).
'''
io.open(f'{ARC}/README.md', 'w', encoding='utf-8').write(arc_readme)
print(f'README архива записан: {ARC}/README.md')

layer_readme = '''# 06_код-истина_перевода — справочный слой (обновлён Этапом 119)

Истина проекта — выпущенный пакет `Paths of Empyrean RU 1.5.zip` (корень пака),
с Этапа 119 — **v1.5.19** (вердикт игрока по отчёту 118 «Великая» проверки
тиров: 118-а 24 арбалета ExpandedCrossbowPack с возвращённым материалом;
118-б «орочья/орочьи» ×5; 118-в Turn/Repel → офиц. «Отпугивание/Отталкивание»
×7; 118-г Lucky-стрелы из офиц. баз ×6; 118-е порядок слов «нордского
героя»/«Соловья» — 16 полей ESP + 6 строк ShortbowNames.ini). Этап 117 —
регистр серии MGEF FULL «Маскировка - …» ×13. Этап 115 — гендерная система
маскировочных сообщений ISP Speech + вердикт 113-а («Орочья ламеллярная …»).
Этап 113 — тир-доктрина: EN Scaled = «ламеллярный», «чешуйчатый» = только
Dragonscale.
Дамп истины: `work/qa119/dump_v119_full.jsonl` (39 ESP, 12 338 текстовых полей).

СВЕЖЕЕ (сгенерировано Этапом 119 из дампа v1.5.19, генератор scripts/gen119.py):
- `desc_ru.py`    — зеркало всех PERK DESC (ключ = EDID, конфликты — EDID@file);
- `corpus57.json` — зеркало всех текстовых полей (FULL/DESC/ITXT/NNAM/DNAM/GMST),
                    12 338 записей; en-пары из corpus56 (архив);
- `PathsOfEmpyrean_DESC.ini`, `ShortbowNames_ru.ini`,
  `ArcheryLocationalDamage_ru.ini`, `PathsOfEmpyrean_RUSSIAN.txt` — байтовые
                    копии файлов выпущенного пакета (00 Core), из zip v1.5.19
                    (ShortbowNames_ru.ini — с правками 118-е).

ГЕНДЕР И РЕГИСТР МАСКИРОВОК (санкция 115 + вердикты 115-а/116-а):
- MESG «Вы замаскированы под …» — муж./both ×12 и жен. ×5, все имена фракций
  с заглавной («Бандита/Бандитку», «Талмор» для обоих полов, «члена Стражи
  Рассвета» — «члена» нарицательное строчными);
- MGEF FULL «Маскировка - …» ×17 — имена фракций с заглавной (вердикт 116-а,
  Этап 117), род. ед. лица сохранён («- Талморца»);
- DNAM MGEF «<Фракция> примет/примут вас за своего.» — организация-субъект,
  не менять.
Механизм: клоны MGEF + CTDA GetIsSex (func=70), MESG-формы — свойства VMAD
(Utility_ShowMessageMagicEff). Имя-зависимые слои не задеты (KID-правила
маскировок — EDID/формид-маски, [98]).

СЛОВАРЬ ТИРОВ (санкции 113/115 + вердикты 118): Turn-лестница
«Благословленный…Священный» = офиц.; варианты арбалетов: Silenced=«Бесшумный»,
Light-Weight=«Облегченный», Spring-Loaded=«с пружинным механизмом»,
Recurve=«с выгнутой ложей» — всегда с материалом (118-а); Masterwork-имена —
префикс + офиц. база (118-е: «Мастерский нордский лук героя» …); Lucky-стрелы —
из офиц. баз (118-г); MGEF Turn/Repel = «Отпугивание/Отталкивание <нежити>»
(118-в).

ТЕРМИНОЛОГИЯ (актуальна, не зеркало ESP):
- `spell_names_ru.py` — род. падежи имён заклинаний («Свиток X»);
- `official_terms42.py` — таблица офиц. терминов SoftClub с доказательствами.
  ТИР-СЛОВАРЬ ИГРОКА (санкции 113/115): EN Scaled = «ламеллярный» (низкий/
  средний тир, включая CC Orcish Scaled), EN Dragonscale = «драконий чешуйчатый»
  (высший тир), EN Dragonplate = «драконий панцирный» (высший тир);
  «чешуйчатый» без «драконий» в названиях тиров брони не используется.

АРХИВ (историческая ценность, НЕ читать как истину — урок [T37]):
- `_архив_мастер-эры/` — слои каскада master47–76 + зеркала v1.5.7–v1.5.18 +
  README.

Правило: при выпуске v1.5.20+ перегенерировать зеркала из нового дампа
(шаг 11 в 02_конвейер_и_сборка.md).
'''
io.open(f'{DIR06}/README.md', 'w', encoding='utf-8').write(layer_readme)
print(f'README слоя записан: {DIR06}/README.md')
print('gen119: OK')
