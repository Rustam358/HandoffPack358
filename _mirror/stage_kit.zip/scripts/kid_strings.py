#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 98: извлечение и классификация строк из KID DLL (.rdata/.data).

Адаптация scripts/spid_strings.py (Этап 97) под Keyword Item Distributor 4.1.0.
Вход:  kid_work/kid_extracted/Keyword Item Distributor FOMOD Installer/
       SE/SKSE/Plugins/po3_KeywordItemDistributor.dll
Выход: kid_work/kid_strings_all.txt
"""
import re
import struct

DLL = ("/home/z/my-project/kid_work/kid_extracted/"
       "Keyword Item Distributor FOMOD Installer/SE/SKSE/Plugins/"
       "po3_KeywordItemDistributor.dll")
OUT = "/home/z/my-project/kid_work/kid_strings_all.txt"

with open(DLL, "rb") as f:
    data = f.read()

# section ranges to know where a string lives
pe_off = struct.unpack_from("<I", data, 0x3C)[0]
opt_size = struct.unpack_from("<H", data, pe_off + 20)[0]
num_sections = struct.unpack_from("<H", data, pe_off + 6)[0]
sec_off = pe_off + 24 + opt_size
sections = {}
for i in range(num_sections):
    o = sec_off + i * 40
    name = data[o:o + 8].rstrip(b"\x00").decode()
    vsize, vaddr, rsize, raddr = struct.unpack_from("<IIII", data, o + 8)
    sections[name] = (raddr, rsize)


def section_of(off):
    for name, (raddr, rsize) in sections.items():
        if raddr <= off < raddr + rsize:
            return name
    return "?"


# ASCII strings >= 5 chars
ascii_re = re.compile(rb"[\x20-\x7e]{5,}")
strs = []
for m in ascii_re.finditer(data):
    s = m.group().decode()
    strs.append((m.start(), s))

# UTF-16LE strings
utf16_re = re.compile(rb"(?:[\x20-\x7e]\x00){5,}")
u16 = []
for m in utf16_re.finditer(data):
    try:
        s = m.group().decode("utf-16-le")
    except Exception:
        continue
    u16.append((m.start(), s))

print(f"ASCII strings: {len(strs)}, UTF-16 strings: {len(u16)}")
print("Sections:", {k: (hex(v[0]), v[1]) for k, v in sections.items()})

with open(OUT, "w") as f:
    for off, s in strs:
        f.write(f"{off:#010x} [{section_of(off):8s}] {s}\n")

# KID-specific themes
themes = {
    "INI_KEYWORDS": re.compile(
        r"^(Keyword|Item|Flora|Effect|NPC|DeathItem|FormListMap|LeveledItemMap|"
        r"Inventory|Outfit|Vendor)\b", re.I),
    "LOG_MSGS": re.compile(
        r"(\bDistribut|Keyword|filter|match|log|FormID|EditorID|path|loaded|"
        r"count|Total|error|Error|failed|skipped|invalid|INI|ini|Ammo|Weapon|"
        r"Armor|Misc|Potion|Scroll|Book|Key|Light|Soul|Ingredient|Food|"
        r" flora|Flora)", re.I),
}
seen_log = []
for off, s in strs:
    sec = section_of(off)
    if themes["LOG_MSGS"].search(s) and len(s) > 8:
        seen_log.append((off, sec, s))

print(f"\n=== LOG/DOC STRINGS (first 300 of {len(seen_log)}) ===")
for off, sec, s in seen_log[:300]:
    print(f"{off:#x} [{sec}] {s[:200]}")
