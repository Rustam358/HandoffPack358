#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 112, шаг 6: независимая верификация v1.5.13.
1) Дамп release-ESP (main) == 8914 полей; множество ключей == v1.5.12.
2) Дифф ru vs v1.5.12 == РОВНО 9 полей == fixlist (old->new), 0 лишних.
3) «ламелляр» = 0: 39 ESP дампа + весь пак (3 кодировки).
4) Гигиена: %%/ё/рейтинг/укр./двойные пробелы/lone-\\n/кавычки/PERK DESC <=290.
5) Пак-скан: «изгнанник»=0; ShortbowNames «Изгоев»; MCM $Forsworn<tab>Изгои.
6) Регресс-пробы 111/104/102 + чешуйчатые серии (Dragonscale ×5, кокон 23,
   Чешуйчатка 3, CC-серии, Material Mastery, перки).
"""
import sys, json, zipfile, re, os, glob, io
sys.path.insert(0, '/home/z/my-project/work/handoff510/scripts')
from dump150 import dump_esp

REL = '/home/z/my-project/work/ru15_4'
ZIP = '/home/z/my-project/download/Paths of Empyrean RU 1.5.zip'
DUMP_NEW = '/home/z/my-project/work/qa112/dump_v113_release.jsonl'
DUMP_OLD = '/home/z/my-project/work/qa112/dump_v112_release.jsonl'
FIX = '/home/z/my-project/work/qa112/fixlist_v113.jsonl'

fails = []


def check(cond, msg):
    print(('  [OK] ' if cond else '  [FAIL] ') + msg)
    if not cond:
        fails.append(msg)


def dump_main(esp_path, out_path):
    with io.open(out_path, 'w', encoding='utf-8') as f:
        dump_esp(esp_path, 'main', f)
    return [json.loads(l) for l in io.open(out_path, encoding='utf-8')]


def main():
    # --- 0) распаковка выпускного zip (ESP) ---
    z = zipfile.ZipFile(ZIP)
    esp_bytes = z.read('00 Core/PathsOfEmpyrean.esp')
    open('/home/z/my-project/work/qa112/_release_esp.bin', 'wb').write(esp_bytes)

    # --- 1) дампы ---
    fresh = dump_main('/home/z/my-project/work/qa112/_release_esp.bin', DUMP_NEW)
    old = [json.loads(l) for l in io.open(DUMP_OLD, encoding='utf-8')]
    print('1) дампы: new %d полей, old (v1.5.12) %d полей' % (len(fresh), len(old)))
    check(len(fresh) == 8914 and len(old) == 8914, 'полей ровно 8914 в обоих дампа')

    fk = {(r['formid'], r['rtype'], r['field'], r.get('occ', 1)): r['text'] for r in fresh}
    ok_ = {(r['formid'], r['rtype'], r['field'], r.get('occ', 1)): r['text'] for r in old}
    check(set(fk) == set(ok_), 'множество ключей идентично v1.5.12')

    # --- 2) дифф == fixlist ---
    fixes = [json.loads(l) for l in io.open(FIX, encoding='utf-8')]
    expected = {(int(f['formid'], 16), f['field'], f['occ']): f for f in fixes}
    diffs = []
    for k in ok_:
        if ok_[k] != fk[k]:
            diffs.append((k, ok_[k], fk[k]))
    print('2) дифф полей vs v1.5.12: %d (ожидается %d)' % (len(diffs), len(expected)))
    okn, bad = 0, []
    for (formid, rtype, field, occ), old_t, new_t in diffs:
        f = expected.get((int(formid, 16), field, occ))
        if f and old_t == f['old'] and new_t == f['new']:
            okn += 1
        else:
            bad.append((formid, field, old_t[:60], new_t[:60]))
    check(okn == len(expected) and len(diffs) == len(expected) and not bad,
          'дифф == fixlist (%d/%d); лишних: %d %s' % (okn, len(expected), len(bad), bad[:3]))

    # --- 3) «ламелляр» = 0 ---
    lam = [(k, t) for k, t in fk.items() if 'ламелляр' in t.lower()]
    check(len(lam) == 0, 'main ESP: «ламелляр» = 0 (факт %d %s)' % (len(lam), lam[:3]))
    all_rows = list(fk.items())
    lam2 = [1 for _, t in all_rows if 'ламелляр' in t.lower()]
    check(len(lam2) == 0, 'main ESP (полный список полей): «ламелляр» = 0')

    # --- 4) гигиена ---
    print('4) гигиена:')
    hy = {'%%': 0, 'ё': 0, 'рейтинг': 0, 'укр.': 0, '  ': 0}
    lone = 0
    dq = []
    for k, t in fk.items():
        hy['%%'] += t.count('%%')
        hy['ё'] += t.count('ё')
        hy['рейтинг'] += len(re.findall(r'[Рр]ейтинг', t))
        hy['укр.'] += t.count('укр.')
        hy['  '] += t.count('  ')
        if re.search(r'(?<!\r)\n', t):
            lone += 1
        if '"' in t and '<font' not in t and 'font' not in t:
            dq.append((k, t[:60]))
    for m, v in hy.items():
        check(v == 0, '%s = 0 (факт %d)' % (repr(m), v))
    check(lone == 0, 'lone \\n = 0 (факт %d)' % lone)
    check(len(dq) == 0, 'прямые кавычки вне font-книг = 0 (факт %d)' % len(dq))
    over = [(k, len(t)) for k, t in fk.items()
            if k[1] == 'PERK' and k[2] == 'DESC' and t and len(t) > 290]
    check(len(over) == 0, 'PERK DESC <= 290 (превышений %d)' % len(over))

    # --- 5) пак-скан ---
    print('5) пак-скан (63 записи, 3 кодировки):')
    names = z.namelist()
    assert z.testzip() is None
    assert len(names) == 63
    legacy_hits, decs = [], 0
    for n in names:
        raw = z.read(n)
        for enc in ('utf-8', 'utf-16le', 'cp1251'):
            try:
                s = raw.decode(enc)
            except (UnicodeDecodeError, UnicodeError):
                continue
            decs += 1
            low = s.lower()
            if 'изгнанник' in low:
                legacy_hits.append((n, enc))
            if 'ламелляр' in low:
                legacy_hits.append((n, enc, 'ламелляр'))
    check(len(legacy_hits) == 0, '«изгнанник» и «ламелляр» по всему паку = 0 (декодов %d)' % decs)
    sbn = z.read('00 Core/SKSE/Plugins/POE/Weapon/PathsOfEmpyrean_ShortbowNames.ini').decode('utf-8')
    check(sbn.count('Короткий лук Изгоев') == 1 and 'лук изгоев' not in sbn,
          'ShortbowNames: «Короткий лук Изгоев» = 1')
    mcm = z.read('00 Core/Interface/Translations/PathsOfEmpyrean_RUSSIAN.txt').decode('utf-16le')
    check('$Forsworn\tИзгои' in mcm and 'Изгнанники' not in mcm,
          'MCM: $Forsworn<tab>Изгои, «Изгнанники» = 0')
    ald = z.read('00 Core/SKSE/Plugins/ArcheryLocationalDamage.ini').decode('utf-8')
    check(ald.count('Message = В яблочко!') == 2 and ald.count('Message = Травма руки!') == 2
          and ald.count('Message = Травма ноги!') == 2,
          'ALD ini: «В яблочко!»×2, «Травма руки!»×2, «Травма ноги!»×2')
    ver = z.read('fomod/info.xml').decode('utf-8')
    check('<Version>1.5.13</Version>' in ver and '1.5.12' not in ver,
          'info.xml = 1.5.13')

    # --- 6) регресс-пробы ---
    print('6) регресс-пробы:')
    # main + CC-патчи (для проб CC-серий): дамп ESP из релизного zip
    cc_names = [n for n in names if n.endswith('.esp')]
    cc_texts = []
    for n in cc_names:
        if n == '00 Core/PathsOfEmpyrean.esp':
            continue
        raw = z.read(n)
        p = '/home/z/my-project/work/qa112/_cc_esp.bin'
        open(p, 'wb').write(raw)
        cc_texts += [r['text'] for r in dump_main(p, '/home/z/my-project/work/qa112/_cc_dump.jsonl')]
    cc_join = cc_texts  # список строк CC-патчей
    def find_all(sub):
        return [k for k, t in fk.items() if t and sub in t] + \
               [i for i, t in enumerate(cc_join) if sub in t]
    def find_ru(sub, field=None):
        return [k for k, t in fk.items() if t and sub in t
                and (field is None or k[2] == field)]
    for sub, n, kw in [
        # Новое состояние (v1.5.13): чешуйчатый тир
        ('Мастерский чешуйчатый шлем', 1, 'FULL'),
        ('Мастерские чешуйчатые наручи', 1, 'FULL'),
        ('Мастерская чешуйчатая броня', 2, 'FULL'),
        ('Мастерские чешуйчатые сапоги', 1, 'FULL'),
        ('Железный человек - Чешуйчатый', 1, 'FULL'),
        ('Вторая кожа - Чешуйчатый', 1, 'FULL'),
        ('чешуйчатые и пластинчатые доспехи', 1, 'DESC'),
        ('стальные пластинчатые и чешуйчатые доспехи', 1, 'DESC'),
        # Dragonscale-канон игрока не тронут
        ('Мастерский драконий чешуйчатый щит', 1, 'FULL'),
        ('Мастерский драконий чешуйчатый шлем', 1, 'FULL'),
        ('Мастерские драконьи чешуйчатые перчатки', 1, 'FULL'),
        ('Мастерская драконья чешуйчатая броня', 1, 'FULL'),
        ('Мастерские драконьи чешуйчатые сапоги', 1, 'FULL'),
        # Грим-серия и прочее «чешуйчат» — не тронуто
        ('Чешуйчатый кокон', 23, None),
        ('Чешуйчатка', 3, None),
        # CC-патчи (поиск по main + CC)
        ('Орочья чешуйчатая броня', 1, 'CC'),
        ('Клепаная драконья чешуйчатая броня', 1, 'CC'),
        ('Драконьи чешуйчатые перчатки драчуна', 2, 'CC'),
        # Регресс 111
        ('Грозовой атронах', 2, None), ('Маскировка - Брата Бури', 1, 'FULL'),
        ('Маскировка - Изгоя', 1, 'FULL'), ('Маскировка - бандита', 1, 'FULL'),
        ('Дикая форма - волк', 1, None), ('Сокрушительный набег', 3, 'FULL'),
        ('Мастерские сыромятные сапоги', 1, 'FULL'),
        ('Мастерские драконьи панцирные сапоги', 1, 'FULL'),
        ('Мастерский имперский офицерский шлем', 1, 'FULL'),
        ('Маска члена культа', 1, 'FULL'), ('Мастерская маска члена культа', 1, 'FULL'),
        ('Счастливая стрела нордского героя (жетон)', 1, 'FULL'),
        ('Мастерская древняя нордская броня', 1, 'FULL'),
        ('Мастерская эльфийская золоченая броня', 1, 'FULL'),
        ('Мастерская эльфийская позолоченная броня', 0, 'FULL'),
        ('Мастерские офицерские сапоги Братьев Бури', 1, 'FULL'),
        ('Вы замаскированы под Изгоя.', 1, 'DESC'),
        ('создает двемерскую сферу-убийцу', 1, 'DNAM'),
        ('Позволяет ковать стальное и костяное снаряжение', 1, 'DESC'),
    ]:
        hits = find_all(sub) if kw == 'CC' else find_ru(sub, kw)
        check(len(hits) == n, '«%s» = %d (факт %d)' % (sub, n, len(hits)))

    print()
    if fails:
        print('ВЕРИФИКАЦИЯ ПРОВАЛЕНА (%d):' % len(fails))
        for f in fails:
            print('  -', f)
        raise SystemExit(1)
    print('ВЕРИФИКАЦИЯ ЗЕЛЁНАЯ: 24/24 групп проверок')


if __name__ == '__main__':
    main()
