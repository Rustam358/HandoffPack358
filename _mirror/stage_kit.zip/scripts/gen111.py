#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 111: перегенерация слоя handoff/06_код-истина_перевода из истины —
выпущенного пакета v1.5.12 (download/), + эталон перков v152 + INI/MCM-копии.

Образец — gen104.py. Отличия:
- зеркала v1.5.9 уходят в _архив_мастер-эры/ (desc_ru_v159.py, corpus57_v159.json);
- в 06_ добавлена байтовая копия MCM-слоя PathsOfEmpyrean_RUSSIAN.txt
  (в v1.5.12 поглощена правка игрока $Forsworn «Изгои» + tab);
- эталон perks_v152.jsonl рядом с v151 (v149/v150/v151 не трогаются);
- контроль: дифф corpus57 == ровно 31 поле fixlist 111.
"""
import io, json, os, shutil, zipfile, sys, glob
from collections import defaultdict

sys.path.insert(0, '/home/z/my-project/work/handoff510/scripts')
from dump150 import dump_esp

DL = '/home/z/my-project/download/Paths of Empyrean RU 1.5.zip'
HANDOFF = '/home/z/my-project/work/handoff510/handoff'
DIR06 = f'{HANDOFF}/06_код-истина_перевода'
ARC = f'{DIR06}/_архив_мастер-эры'
PERKS_DIR = f'{HANDOFF}/04_эталоны_игрока'
DIR10 = f'{HANDOFF}/10_наш_перевод_CC_патчей'
REL = '/home/z/my-project/work/qa111/release112'
DUMP = '/home/z/my-project/work/qa111/dump_v112_full.jsonl'

# ---------- 0) распаковка выпускного zip и полный дамп 39 ESP ----------
if not os.path.isdir(REL):
    with zipfile.ZipFile(DL) as z:
        z.extractall(REL)
with io.open(DUMP, 'w', encoding='utf-8') as out:
    total = 0
    jobs = [(f'{REL}/00 Core/PathsOfEmpyrean.esp', 'main'),
            (f'{REL}/10 Missing Shields/PoE-Addon-MissingShields.esp', 'ms'),
            (f'{REL}/20 Spears/PoE-Addon-Spears.esp', 'sp')]
    for path in sorted(glob.glob(f'{REL}/30 CC Patches/*/*.esp')):
        tag = 'cc:' + os.path.basename(path).replace('PoE-CC', '').replace('-Patch.esp', '')
        jobs.append((path, tag))
    for path, tag in jobs:
        p = dump_esp(path, tag, out)
        total += len(p.records)
print(f'дамп v1.5.12: {DUMP}')
fields = [json.loads(l) for l in io.open(DUMP, encoding='utf-8')]
print(f'полей текста: {len(fields)} (ожидалось 12 323)')
assert len(fields) == 12323

# ---------- 0b) контроль: дифф старого corpus57 == ровно 31 поле fixlist ----------
old_corpus = json.load(io.open(f'{ARC}/corpus57_v159.json', encoding='utf-8'))  # истина v1.5.9 (архив)
fixes = [json.loads(l) for l in io.open('/home/z/my-project/work/qa111/fixlist_v112.jsonl', encoding='utf-8')]
esp_fixes = {(f['formid'], f['field'], f['occ']): (f['old'], f['new']) for f in fixes if f['kind'] == 'esp'}
old_map = {(r['fid'], r['type'], r['field'], r['occ']): r.get('ru') for r in old_corpus}
new_map = {(r['formid'], r['rtype'], r['field'], r.get('occ', 1)): r['text'] for r in fields}
assert set(old_map) == set(new_map), 'множество ключей corpus57 vs дамп v112 расходится!'
diff = []
for k in old_map:
    if old_map[k] != new_map[k]:
        exp = esp_fixes.get((k[0], k[2], k[3]))
        assert exp and old_map[k] == exp[0] and new_map[k] == exp[1], f'вне fixlist: {k}: {old_map[k]!r} -> {new_map[k]!r}'
        diff.append(k)
assert len(diff) == len(esp_fixes), f'дифф {len(diff)} != fixlist {len(esp_fixes)}'
print(f'контроль: дифф corpus57 -> v112 = ровно {len(diff)} полей, все == fixlist 111')

# ---------- 1) архив зеркал v1.5.9 (ДО генерации, guard) ----------
moved = []
for name, arcname in [('desc_ru.py', 'desc_ru_v159.py'),
                      ('corpus57.json', 'corpus57_v159.json')]:
    src = f'{DIR06}/{name}'
    dst = f'{ARC}/{arcname}'
    if os.path.isfile(src) and not os.path.exists(dst):
        shutil.move(src, dst)
        moved.append(f'{name} -> {arcname}')
print('заархивировано:', moved or 'ничего (guard: уже в архиве)')

# ---------- 2) свежий desc_ru.py (v1.5.12) ----------
perk_desc = [r for r in fields if r['rtype'] == 'PERK' and r['field'] == 'DESC']
by_file_edid = defaultdict(dict)
for r in perk_desc:
    by_file_edid[r['file']].setdefault(r['edid'], r['text'])
edid_files = defaultdict(set)
for f, d in by_file_edid.items():
    for e in d:
        edid_files[e].add(f)
conflict = {e: fs for e, fs in edid_files.items() if len(fs) > 1}
items = []
for f, d in by_file_edid.items():
    for e, t in d.items():
        key = f'{e}@{f}' if e in conflict else e
        items.append((key, t))
print(f'PERK DESC: {len(perk_desc)} записей -> {len(items)} ключей; конфликтов EDID: {len(conflict)}')


def group(key):
    if key.startswith('PoE_PERK_'):
        return 'PoE: деревья перков'
    if key.startswith('GRIM_PERK_'):
        return 'Grimoire (GRIM): перки'
    if key.startswith(('ISP_', 'IWP_')):
        return 'Надстройки/патчи (ISP/IWP)'
    return 'Ванильные перки (офиц. стиль)'


groups = defaultdict(list)
for k, t in items:
    groups[group(k)].append((k, t))
for g in groups:
    groups[g].sort()

hdr = '''# -*- coding: utf-8 -*-
"""
Свежее зеркало PERK DESC выпущенного пакета v1.5.12 (Этап 111).
Источник: дамп истины work/qa111/dump_v112_full.jsonl (39 ESP), генератор
scripts/gen111.py; дата: 07.11.2026. Ключ = EDID; для EDID, совпадающих
в разных ESP, ключ = 'EDID@file' (file как в дампе: main/ms/sp/cc:...).
Правило проекта: истина = выпущенный ESP (02_конвейер_и_сборка.md), урок [T37]:
предыдущие зеркала заархивированы в _архив_мастер-эры/ под версионированными
именами (desc_ru_v159.py, corpus57_v159.json). При выпуске v1.5.13+ перегенерировать
(шаг 11 в 02_конвейер_и_сборка.md).
Стиль текстов — сам ESP; правки вносятся только через этапный fixlist.
"""

DESC_RU = {
'''
parts = [hdr]
for g in ['PoE: деревья перков', 'Grimoire (GRIM): перки',
          'Надстройки/патчи (ISP/IWP)', 'Ванильные перки (офиц. стиль)']:
    parts.append(f'    # ===== {g} =====\n')
    for k, t in groups[g]:
        parts.append(f'    {k!r}: {t!r},\n')
    parts.append('\n')
parts.append('}\n')
io.open(f'{DIR06}/desc_ru.py', 'w', encoding='utf-8').write(''.join(parts))
print(f'desc_ru.py перезаписан (v1.5.12): {len(items)} ключей')

# ---------- 3) свежий corpus57.json (v1.5.12) ----------
c56 = json.load(io.open(f'{ARC}/corpus56.json', encoding='utf-8'))
en_map = {}
for e in c56:
    en = e.get('en')
    if en is not None:
        en_map.setdefault((e['fid'], e['type'], e['field']), en)
corpus = []
en_n = 0
for r in fields:
    e = {'fid': r['formid'], 'edid': r['edid'], 'type': r['rtype'],
         'field': r['field'], 'occ': r.get('occ', 1), 'file': r['file'],
         'ru': r['text']}
    en = en_map.get((r['formid'], r['rtype'], r['field']))
    if en is not None:
        e['en'] = en
        en_n += 1
    corpus.append(e)
with io.open(f'{DIR06}/corpus57.json', 'w', encoding='utf-8') as f:
    json.dump(corpus, f, ensure_ascii=False, indent=1)
print(f'corpus57.json (v1.5.12): {len(corpus)} записей, en-пар: {en_n}')

# ---------- 4) README архива + слоя ----------
arc_readme = '''# Архив (06_код-истина_перевода)

Исторические справочные слои. НЕ читать как истину — урок [T37] (Этап 100):
слой desc_ru.py мастер-эры совпадал с ESP лишь в 78 из 482 ключей; corpus56.json
(корпус Этапа 56, сборка v1.13/14) — в 6 111 из 9 718 записей.

АКТУАЛЬНЫЕ зеркала истины: `../desc_ru.py` и `../corpus57.json` (v1.5.12,
Этап 111). Терминология (не зеркало ESP): `../spell_names_ru.py`,
`../official_terms42.py`.

Состав архива:
- desc_ru.py / corpus56.json / full_names_ru.py / patch_log.json / patch_log14.json
  — слои каскада master47–76 (пересборка «из EN») + README данных;
- desc_ru_v157.py / corpus57_v157.json — зеркала выпущенного v1.5.7 (Этап 101);
- desc_ru_v158.py / corpus57_v158.json — зеркала выпущенного v1.5.8 (Этап 103);
- desc_ru_v159.py / corpus57_v159.json — зеркала выпущенного v1.5.9 (Этап 104).
'''
io.open(f'{ARC}/README.md', 'w', encoding='utf-8').write(arc_readme)
print(f'README архива записан: {ARC}/README.md')

layer_readme = '''# 06_код-истина_перевода — справочный слой (обновлён Этапом 111)

Истина проекта — выпущенный пакет `Paths of Empyrean RU 1.5.zip` (корень пака),
с Этапа 111 — **v1.5.12** (канон-аудит ванильных терминов по файлу игрока
«All items.txt» + корпус SoftClub: «Изгои» (регистр, директива игрока),
Dragonplate = «панцирный», Scaled = «ламеллярный», Hide = «сыромятный»,
Masterwork-серии; поглощена правка игрока $Forsworn «Изгои» в MCM).
Дамп истины: `work/qa111/dump_v112_full.jsonl` (39 ESP, 12 323 текстовых поля).

СВЕЖЕЕ (сгенерировано Этапом 111 из дампа v1.5.12, генератор scripts/gen111.py):
- `desc_ru.py`    — зеркало всех PERK DESC (ключ = EDID, конфликты — EDID@file);
- `corpus57.json` — зеркало всех текстовых полей (FULL/DESC/ITXT/NNAM/DNAM/GMST),
                    12 323 записи; en-пары из corpus56 (архив);
- `PathsOfEmpyrean_DESC.ini`, `ShortbowNames_ru.ini`,
  `ArcheryLocationalDamage_ru.ini`, `PathsOfEmpyrean_RUSSIAN.txt` — байтовые
                    копии файлов выпущенного пакета (00 Core), из zip v1.5.12.

ТЕРМИНОЛОГИЯ (актуальна, не зеркало ESP):
- `spell_names_ru.py` — род. падежи имён заклинаний («Свиток X»);
- `official_terms42.py` — таблица офиц. терминов SoftClub с доказательствами.

АРХИВ (историческая ценность, НЕ читать как истину — урок [T37]):
- `_архив_мастер-эры/` — слои каскада master47–76 + зеркала v1.5.7/v1.5.8/v1.5.9
  (desc_ru_v157/v158/v159.py, corpus57_v157/v158/v159.json) + README.

Правило: при выпуске v1.5.13+ перегенерировать зеркала из нового дампа
(шаг 11 в 02_конвейер_и_сборка.md).
'''
io.open(f'{DIR06}/README.md', 'w', encoding='utf-8').write(layer_readme)
print(f'README слоя записан: {DIR06}/README.md')

# ---------- 5) INI/MCM-копии 06_ + CC-копии 10_ из zip v1.5.12 ----------
with zipfile.ZipFile(DL) as z:
    for arc, local in [('00 Core/PathsOfEmpyrean_DESC.ini', 'PathsOfEmpyrean_DESC.ini'),
                       ('00 Core/SKSE/Plugins/POE/Weapon/PathsOfEmpyrean_ShortbowNames.ini',
                        'ShortbowNames_ru.ini'),
                       ('00 Core/SKSE/Plugins/ArcheryLocationalDamage.ini',
                        'ArcheryLocationalDamage_ru.ini'),
                       ('00 Core/Interface/Translations/PathsOfEmpyrean_RUSSIAN.txt',
                        'PathsOfEmpyrean_RUSSIAN.txt')]:
        data = z.read(arc)
        io.open(f'{DIR06}/{local}', 'wb').write(data)
        print(f'копия 06_ обновлена из zip: {local} ({len(data)} Б)')
    for arc in ['30 CC Patches/Advanced Crossbows/PoE-CCAdvancedCrossbows-Patch_DESC.ini',
                '30 CC Patches/Expanded Crossbow Pack/PoE-CCExpandedCrossbowPack-Patch_DESC.ini']:
        data = z.read(arc)
        io.open(f'{DIR10}/{os.path.basename(arc)}', 'wb').write(data)
        print(f'CC-копия 10_ обновлена из zip: {os.path.basename(arc)} ({len(data)} Б)')

# ---------- 6) эталон перков v151 -> v152 (v149/v150/v151 не трогаем) ----------
perk = {}
for r in fields:
    if r['rtype'] != 'PERK':
        continue
    key = (r['file'], r['formid'])
    d = perk.setdefault(key, {'file': r['file'], 'formid': r['formid'],
                              'edid': r['edid'], 'full': '', 'desc': ''})
    if r['field'] == 'FULL' and not d['full']:
        d['full'] = r['text']
    elif r['field'] == 'DESC' and not d['desc']:
        d['desc'] = r['text']
rows = list(perk.values())
rows.sort(key=lambda x: (x['file'], x['formid']))
out = f'{PERKS_DIR}/perks_v152.jsonl'
with io.open(out, 'w', encoding='utf-8') as f:
    for d in rows:
        f.write(json.dumps(d, ensure_ascii=False) + '\n')
print(f'эталон: {out}: {len(rows)} перков (v149/v150/v151 не тронуты)')

# контроль: ключевые строки этапа в эталоне
chk = {(d['file'], d['formid']): d for d in rows}
d1 = chk[('main', '000CB414')]
assert 'ламеллярные и пластинчатые' in d1['desc'], d1['desc']
d2 = chk[('main', '060008A6')]
assert 'стальные пластинчатые и ламеллярные доспехи' in d2['desc'], d2['desc']
assert 'смертельной скрытной атаки' in chk[('main', '060C64F9')]['desc']  # регресс 104
assert 'скрытой атаки' not in chk[('main', '060C64F9')]['desc']
assert 'сильнее' in chk[('main', '000D7999')]['desc']  # регресс 102
print('контроль эталона: 111-фиксы + регресс 104/102 на месте')

print()
print('gen111: ГОТОВО')
