#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 102 (аналитический): верификатор фикслиста v1.5.8 (work/qa102/fixlist_v158.jsonl).
НИЧЕГО не правит — только проверки:
1. JSONL валиден, 8 записей, поля master94 на месте;
2. каждая пара (formid, field, occ) существует в зеркале истины corpus57.json
   и old == ru записи БАЙТ-В-БАЙТ (гарантия точного попадания патчера);
3. [T26]: мультимножества чисел old == new (правка не меняет числа);
4. стиль новых текстов: без «ё», «—», прямых кавычек, двойных пробелов; ≤ 290 симв.;
5. 102-а: слово заменено именно по канону («эффективнее» → «сильнее» / «сила»);
   100-а: прописные навыки присутствуют, строчных вхождений нет.
Выход: код 0 = фикслист готов к исполнительскому этапу.
"""
import json, re, sys

ROOT = '/home/z/my-project'
FIX = f'{ROOT}/work/qa102/fixlist_v158.jsonl'
CORP = f'{ROOT}/handoff/06_код-истина_перевода/corpus57.json'

fails = []


def bad(msg):
    fails.append(msg)
    print(f'  FAIL  {msg}')


def ok(msg):
    print(f'  PASS  {msg}')


entries = []
for i, line in enumerate(open(FIX, encoding='utf-8'), 1):
    line = line.strip()
    if not line:
        continue
    try:
        entries.append(json.loads(line))
    except json.JSONDecodeError as e:
        bad(f'строка {i}: JSON невалиден: {e}')

(ok if len(entries) == 8 else bad)(f'записей: {len(entries)} (ожидалось 8)')
for e in entries:
    for k in ('kind', 'scope', 'formid', 'field', 'occ', 'old', 'new', 'why'):
        if k not in e:
            bad(f'{e.get("formid")}: нет поля {k}')

corpus = json.load(open(CORP, encoding='utf-8'))
index = {(r.get('fid'), r.get('field'), r.get('occ')): r for r in corpus}

nums = re.compile(r'\d+(?:[,.]\d+)?')

for e in entries:
    tag = f'{e["formid"]}/{e["field"]}#{e["occ"]}'
    rec = index.get((e['formid'], e['field'], e['occ']))
    if rec is None:
        bad(f'{tag}: записи нет в corpus57.json')
        continue
    if rec.get('ru') != e['old']:
        bad(f'{tag}: old != зеркалу истины (ru изменился?)')
    else:
        ok(f'{tag}: old байт-в-байт == зеркалу v1.5.7')
    if e['field'] == 'DESC' and rec.get('en') and nums.findall(e['old']) and \
            nums.findall(e['old']) != nums.findall(e['new']):
        bad(f'{tag}: [T26] числа изменились {nums.findall(e["old"])} → '
            f'{nums.findall(e["new"])}')
    n = e['new']
    if len(n) > 290:
        bad(f'{tag}: длина {len(n)} > 290')
    for pat, msg in (('ё', 'буква ё'), ('—', 'тире —'), ('"', 'прямая кавычка'),
                     ('  ', 'двойной пробел')):
        if pat in n:
            bad(f'{tag}: стиль — {msg}')
    if e['why'].startswith('102-а'):
        if 'эффективнее' in n or 'эффективность' in n:
            bad(f'{tag}: 102-а — «эффективн-» остался в new')
        if 'сильнее' not in n and 'сила' not in n:
            bad(f'{tag}: 102-а — нет «сильнее/сила» в new')
    if e['why'].startswith('100-а'):
        if re.search(r'навыка (карманной кражи|алхимии|кузнечного дела)', n):
            bad(f'{tag}: 100-а — строчное употребление навыка осталось')

print()
if fails:
    print(f'ИТОГ: {len(fails)} FAIL — фикслист не готов')
    sys.exit(1)
print('ИТОГ: фикслист v1.5.8 цел — готов к исполнительскому этапу (master95)')
