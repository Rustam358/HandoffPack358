#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 99: батарея верификации PoE_RU_KID.ini (мини-фикс KID-потерь).

A. Грамматика и резолв:
   A1 каждая строка = `Keyword = <kw>|<тип>|<фильтры>[|<4-е поле>]`, фильтры
      только EDID-термы через запятую (OR), без wildcard/NOT/пробелов;
   A2 каждый EDID резолвится в запись ядра v1.5.6 ТОЧНЫМ строковым
      совпадением, тип записи == типу правила;
   A3 целевой ключевик: определён ядром (KYWD) / ванильный / внешний
      (зависимость от мода-источника — как у оригинальной ини, паритет).
B. Паритет потерь (независимая пересимуляция):
   B1 множество (EDID, kw) нашей ини == множеству имя-зависимых потерь
      строгой симуляции (37 записей, 100 пар) — в обе стороны;
   B2 паритет групп: (kw, тип, 4-е поле) нашей ини присутствует среди
      правил оригинала; EDID-набор группы == потерям именно этих правил;
   B3 никаких ключей сверх потерь (оверх-реставрация запрещена).
C. Файл:
   C1 чистый ASCII, CRLF, без BOM, без табов;
   C2 14 правил Keyword, суффикс имени _KID.
D. Сводка для отчёта.
"""
import json
import struct
import sys

sys.path.insert(0, "/home/z/my-project/scripts")
from parse_tes4 import Plugin

KID_INI = ("/home/z/my-project/handoff/08_оригинал_1.4_EN/"
           "полный_разбор_1.4/PoE 1.4/PathsOfEmpyrean_KID.ini")
CORE = "/home/z/my-project/work/v156/00 Core/PathsOfEmpyrean.esp"
SPEARS = "/home/z/my-project/work/v156/20 Spears/PoE-Addon-Spears.esp"
SHIELDS = "/home/z/my-project/work/v156/10 Missing Shields/PoE-Addon-MissingShields.esp"
EN_DUMP = "/home/z/my-project/handoff/05_стринги_ESP/v14_en.json"
OUR_INI = "/home/z/my-project/work/v156/00 Core/PoE_RU_KID.ini"

TYPE_MAP = {"WEAP": "Weapon", "ARMO": "Armor", "AMMO": "Ammo"}
VANILLA = {
    "WeapTypeGreatsword": 0x0006D931, "WeapTypeBattleaxe": 0x0006D932,
    "WeapTypeWarhammer": 0x0006D933, "WeapTypeSword": 0x0001E711,
    "WeapTypeBow": 0x0001E712, "WeapTypeDagger": 0x0001E713,
    "WeapTypeCrossbow": 0x01CD10DC, "ArmorShield": 0x000965B2,
    "ArmorJewelry": 0x0008F95B, "VendorItemWeapon": 0x0008F958,
    "ArmorCuirass": 0x0006BBB8, "ArmorGauntlets": 0x0006BBC0,
    "ArmorHelmet": 0x0006BBC1, "ArmorBoots": 0x0006BBBF,
    "ClothingBody": 0x000A8657, "ClothingHead": 0x0010CD11,
    "Clothing": 0x0006BBE8,
}

core = Plugin(CORE)
spears = Plugin(SPEARS)
shields = Plugin(SHIELDS)

fails = []


def check(cond, msg):
    if cond:
        print(f"  OK  {msg}")
    else:
        print(f"  FAIL {msg}")
        fails.append(msg)


# ---------- разбор оригинальной ини ----------
def parse_terms(filt):
    alts = []
    for alt in filt.split(","):
        terms = []
        for part in alt.split("+"):
            part = part.strip()
            if not part:
                continue
            if part.startswith("-"):
                body = part[1:].strip()
                if body.startswith("*"):
                    terms.append(("notname", body.lstrip("*").strip().lower()))
                else:
                    terms.append(("notkw", body))
            elif part.startswith("*"):
                terms.append(("name", part.lstrip("*").strip().lower()))
            else:
                terms.append(("kw", part))
        if terms:
            alts.append(terms)
    return alts


orig_rules = []  # (ln, kw, ftype, alts, field4)
for ln, raw in enumerate(open(KID_INI, encoding="utf-8", errors="ignore"), 1):
    s = raw.strip()
    if not s.startswith("Keyword"):
        continue
    parts = s.split("|")
    if len(parts) < 3:
        continue
    alts = parse_terms(parts[2])
    if any(t[0] == "name" for alt in alts for t in alt):
        orig_rules.append((ln, parts[0].split("=", 1)[1].strip(),
                           parts[1].strip(), alts,
                           parts[3].strip() if len(parts) > 3 else None))

# ---------- разбор нашей ини ----------
raw = open(OUR_INI, "rb").read()
our_rules = []   # (kw, ftype, [edids], field4)
for line in raw.decode("ascii").split("\r\n"):
    s = line.strip()
    if not s or s.startswith(";"):
        continue
    parts = s.split("|")
    assert s.startswith("Keyword = ") and 3 <= len(parts) <= 4, s
    edids = [e.strip() for e in parts[2].split(",") if e.strip()]
    our_rules.append((parts[0].split("=", 1)[1].strip(), parts[1].strip(),
                      edids, parts[3].strip() if len(parts) > 3 else None))

print(f"наша ини: {len(our_rules)} правил")

# ---------- A. грамматика и резолв ----------
print("\n[A] Грамматика и резолв")
kw_fid = {}
for p in (core, spears, shields):
    for fid, r in p.records.items():
        if r["type"] == "KYWD" and r["edid"]:
            kw_fid.setdefault(r["edid"], fid)

edid_rec = {}
for fid, r in core.records.items():
    if r["type"] in TYPE_MAP and r["edid"]:
        edid_rec.setdefault(r["edid"], (fid, r["type"]))

gram_ok = resolve_ok = True
ext_kw = set()
for kw, ftype, edids, field4 in our_rules:
    if ftype not in ("Weapon", "Armor", "Ammo"):
        gram_ok = False
    if kw not in kw_fid and kw not in VANILLA:
        ext_kw.add(kw)
    if field4 is not None and field4 != "NONE" and not (
            field4.isdigit() or field4 in
            ("HEAVY", "LIGHT", "OneHandSword", "TwoHandSword", "TwoHandAxe")):
        gram_ok = False
    for e in edids:
        hit = edid_rec.get(e)
        if hit is None:
            resolve_ok = False
            print(f"    !! EDID не резолвится: {e} ({kw})")
        elif TYPE_MAP[hit[1]] != ftype:
            resolve_ok = False
            print(f"    !! тип не совпал: {e} {hit[1]} vs {ftype}")
check(gram_ok, "A1 грамматика: типы/4-е поля из допустимого множества")
check(resolve_ok, "A2 все EDID резолвятся в ядре с совпадающим типом записи")
for kw in sorted(ext_kw):
    src = "ядро" if kw in kw_fid else "вне ядра (внешний мод/ваниль вне словаря)"
    print(f"    A3 целевой ключ {kw}: {src}")

# ---------- B. паритет потерь ----------
print("\n[B] Паритет потерь (независимая пересимуляция)")


def kwda_set(p, fid):
    r = p.records.get(fid)
    if not r:
        return set()
    out = set()
    for st, sd in r["subs"]:
        if st == "KWDA":
            for i in range(len(sd) // 4):
                out.add(struct.unpack_from("<I", sd, i * 4)[0])
    return out


def kw_in_baked(kw_edid, baked):
    f = kw_fid.get(kw_edid, VANILLA.get(kw_edid))
    if f is None:
        return None
    for cand in (f, 0x01000000 | (f & 0xFFFFFF), 0x06000000 | (f & 0xFFFFFF)):
        if cand in baked:
            return True
    return False


d = json.load(open(EN_DUMP, encoding="utf-8"))
loss_pairs = set()     # (edid, kw)
loss_groups = {}       # (kw, ftype, field4) -> set(edid)
loss_records = set()
for r in d["records"]:
    t = r.get("t")
    if t not in TYPE_MAP:
        continue
    fid_s = r.get("fid", "")
    if len(fid_s) != 8:
        continue
    fid = int(fid_s, 16)
    s = r.get("s", {})
    if "FULL" not in s:
        continue
    full = s["FULL"][0] if isinstance(s["FULL"], list) else s["FULL"]
    if not full:
        continue
    fl = full.lower()
    edid = r.get("e") or ""
    el = edid.lower()
    if core.records.get(fid) is None:
        continue
    baked = kwda_set(core, fid)
    rec_type = TYPE_MAP[t]
    for ln, kw, ftype, alts, field4 in orig_rules:
        if ftype != rec_type:
            continue
        tgt = kw_fid.get(kw)
        if tgt is not None and (tgt in baked or
                                (0x01000000 | (tgt & 0xFFFFFF)) in baked):
            continue
        for alt in alts:
            name_dep = False
            ok = True
            for kind_t, val in alt:
                if kind_t == "name":
                    if val in el:
                        continue
                    if val not in fl:
                        ok = False
                        break
                    name_dep = True
                elif kind_t == "notname":
                    if val in fl or val in el:
                        ok = False
                        break
                elif kind_t == "kw":
                    hit = kw_in_baked(val, baked)
                    if hit is None or not hit:
                        ok = False
                        break
                elif kind_t == "notkw":
                    if kw_in_baked(val, baked):
                        ok = False
                        break
            if ok and name_dep:
                loss_pairs.add((edid, kw))
                loss_records.add(edid)
                loss_groups.setdefault((kw, ftype, field4), set()).add(edid)
                break

our_pairs = set()
our_groups = {}
our_edids = set()
for kw, ftype, edids, field4 in our_rules:
    g = (kw, ftype, field4)
    our_groups[g] = set(edids)
    for e in edids:
        our_pairs.add((e, kw))
        our_edids.add(e)

check(len(loss_records) == 37, f"B0 строгая симуляция: записей-потерь 37 "
      f"(факт {len(loss_records)}), пар {len(loss_pairs)}")
check(our_pairs == loss_pairs, "B1 (EDID,ключ) нашей ини == потерям, "
      "в обе стороны")
missing = loss_pairs - our_pairs
extra = our_pairs - loss_pairs
check(not missing, f"B3a нет непокрытых пар (нет: {sorted(missing)[:4]})")
check(not extra, f"B3b нет лишних пар (нет: {sorted(extra)[:4]})")

# групповой паритет против ИСХОДНЫХ правил оригинала
orig_groups = {}
for ln, kw, ftype, alts, field4 in orig_rules:
    orig_groups.setdefault((kw, ftype, field4), []).append(ln)
grp_ok = True
for g, edids in our_groups.items():
    if g not in orig_groups:
        grp_ok = False
        print(f"    !! группы нет в оригинале: {g}")
    elif edids != loss_groups.get(g, set()):
        grp_ok = False
        print(f"    !! набор EDID группы {g} != потерям правил "
              f"{orig_groups[g]}")
check(grp_ok, "B2 группы (ключ,тип,4-е поле) существуют в оригинале и "
      "EDID-набор == потерям именно этих правил")
check(set(our_groups) == set(loss_groups), "B2b состав групп 1:1 с потерями")

# ---------- C. файл ----------
print("\n[C] Файл")
try:
    raw.decode("ascii")
    ascii_ok = True
except UnicodeDecodeError:
    ascii_ok = False
check(ascii_ok, "C1 чистый ASCII (кодировочная безопасность парсера KID)")
check(raw.count(b"\r\n") == raw.count(b"\n") and not raw.startswith(b"\xef\xbb\xbf")
      and b"\t" not in raw, "C1b CRLF везде, нет BOM, нет табов")
check(OUR_INI.endswith("PoE_RU_KID.ini"), "C2 имя с суффиксом _KID (KID "
      "подхватит из Data\\)")
n_kw_lines = sum(1 for l in raw.decode("ascii").split("\r\n")
                 if l.strip().startswith("Keyword ="))
check(n_kw_lines == 14, f"C2b правил Keyword = 14 (факт {n_kw_lines})")

# ---------- D. сводка ----------
print("\n[D] Сводка")
by_kw = {}
for e, kw in our_pairs:
    by_kw[kw] = by_kw.get(kw, 0) + 1
for kw, n in sorted(by_kw.items(), key=lambda x: -x[1]):
    where = ("ядро " + hex(kw_fid[kw])) if kw in kw_fid else "внешний"
    print(f"  {n:3d} пар  {kw:38s} {where}")
print(f"\nзаписей покрыто: {len(our_edids)}; правило-групп: {len(our_groups)}")

if fails:
    print(f"\n!!! ПРОВАЛЕНО: {len(fails)}")
    sys.exit(1)
print("\nБАТАРЕЯ ПРОЙДЕНА ПОЛНОСТЬЮ")
