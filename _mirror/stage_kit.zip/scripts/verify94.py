#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 94: верификация собранного пакета download/Paths of Empyrean RU 1.5.zip (v1.5.6).

1. Распаковка архива -> work/v156_check
2. Дамп текстов (та же машина, что qa94_chain.collect)
3. Дифф v1.5.5 -> v1.5.6 == fixlist.jsonl (ровно, без лишних/недостающих)
4. Наборы (file, rtype, formid) не изменились
5. Спот-чек ключевых строк
"""
import json, os, sys, zipfile, shutil

sys.path.insert(0, '/home/z/my-project/scripts')
from qa94_chain import collect  # noqa: E402

DST = '/home/z/my-project/download/Paths of Empyrean RU 1.5.zip'
CHECK = '/home/z/my-project/work/v156_check'
QA = '/home/z/my-project/work/qa94'

# --- 1. распаковка ---
if os.path.isdir(CHECK):
    shutil.rmtree(CHECK)
os.makedirs(CHECK)
with zipfile.ZipFile(DST) as z:
    assert z.testzip() is None
    z.extractall(CHECK)
print('распаковано:', len(os.listdir(CHECK)), 'каталогов верхнего уровня')

# --- 2. дамп v156 ---
after = collect(CHECK)
print('текстовых полей v1.5.6:', len(after))

# --- дамп v155 -> тот же формат ---
before = {}
for line in open(os.path.join(QA, 'dump_v155.jsonl'), encoding='utf-8'):
    r = json.loads(line)
    k = (r['file'], r['rtype'], r['formid'], r['field'], r['occ'])
    before[k] = (r['text'], r.get('edid', ''))

# --- 3. дифф ---
diffs = []
for k in sorted(set(before) | set(after)):
    t_old = before.get(k, (None,))[0]
    t_new = after.get(k, (None,))[0]
    if t_old != t_new:
        diffs.append((k, t_old, t_new))
print('изменений текстов v1.5.5 -> v1.5.6:', len(diffs))

# --- ожидания из fixlist ---
SCOPE_FILE = {'main': 'main', 'sp': 'sp', 'PoE-CCNecroGrimoire-Patch': 'PoE-CCNecroGrimoire-Patch'}
expected = {}
for line in open(os.path.join(QA, 'fixlist.jsonl'), encoding='utf-8'):
    r = json.loads(line)
    if r['kind'] == 'esp':
        for k in after:
            if k[0] == SCOPE_FILE[r['scope']] and k[2] == r['formid'] and k[3] == r['field'] and k[4] == r['occ']:
                expected[k] = (r['old'], r['new'])
                break
    else:  # sbow
        for k in after:
            if k[0] == 'ShortbowNames' and k[2] == r['edid']:
                expected[k] = (r['old'], r['new'])
                break
print('ожидаемых правок:', len(expected))
assert len(expected) == 28, f'fixlist развернулся в {len(expected)}'

actual = {k: (o, n) for k, o, n in diffs}
missing = {k: v for k, v in expected.items() if k not in actual}
extra = {k: v for k, v in actual.items() if k not in expected}
assert not missing, f'НЕ ПРИМЕНЕНЫ: {[k for k in missing]}'
assert not extra, f'ЛИШНИЕ ИЗМЕНЕНИЯ: {[k for k in extra]}'
for k, (o, n) in expected.items():
    assert actual[k] == (o, n), f'{k}: {actual[k]!r} != {(o, n)!r}'
print('ДИФФ РОВНО = ФИКС-ЛИСТ: 28/28, 0 лишних, 0 недостающих')

# --- 4. формid-наборы ---
set_before = {(k[0], k[1], k[2]) for k in before}
set_after = {(k[0], k[1], k[2]) for k in after}
assert set_before == set_after, f'наборы записей изменились: +{set_after - set_before} -{set_before - set_after}'
print('наборы (file, rtype, formid) не изменились')

# --- 5. спот-чек ---
print()
print('=== СП0Т-ЧЕК ===')
SPOTS = [
    ('fomod', None, None, None, None, lambda x: 'Readme_PoE_Russian.txt' not in x),
    ('sp', 'WEAP', '0700019E', 'FULL', 'Святое сталгримовое копье'),
    ('sp', 'WEAP', '0700014C', 'FULL', 'Священное даэдрическое копье'),
    ('sp', 'WEAP', '07000030', 'FULL', 'Почитаемое железное копье'),
    ('main', 'WEAP', '0656C169', 'FULL', 'Благословленный охотничий длинный лук'),
    ('main', 'MESG', '06000C54', 'DESC', 'Paths of Empyrean: начинаем возврат очков способностей...'),
    ('main', 'MESG', '06000C55', 'DESC', 'Paths of Empyrean: все очки способностей возвращены, можно перераспределить!'),
    ('main', 'MESG', '06005DE4', 'DESC', 'Paths of Empyrean 1.5 загружается...'),
    ('main', 'MGEF', '063D17F0', 'DNAM', '**Восстановление Урагана**'),
]
for row in SPOTS:
    if row[0] == 'fomod':
        xml = open(f'{CHECK}/fomod/ModuleConfig.xml', encoding='utf-8').read()
        assert row[5](xml) and 'v1.5.6' in xml
        print('  ModuleConfig.xml: без readme, v1.5.6 OK')
        continue
    f, rt, fid, fld, want = row
    hit = [k for k in after if k[0] == f and k[1] == rt and k[2] == fid and k[3] == fld]
    assert hit and after[hit[0]][0] == want, f'{f} {fid}: {after.get(hit[0])!r} != {want!r}'
    print(f'  {f} {rt} {fid} {fld}: {want!r} OK')

# NecroGrimoire: нет хвостового пробела
ng = [k for k in after if k[0] == 'PoE-CCNecroGrimoire-Patch' and k[2] == '05000843' and k[3] == 'DNAM']
assert ng and after[ng[0]][0] == after[ng[0]][0].rstrip(' ') and after[ng[0]][0].endswith('сек.')
print('  NecroGrimoire 05000843 DNAM: без хвостового пробела OK')

# ShortbowNames
for edid, want in [('EnchHuntingBowTurn01', 'Благословленный охотничий короткий лук'),
                   ('EnchImperialBowTurn01', 'Благословленный имперский короткий лук')]:
    hit = [k for k in after if k[0] == 'ShortbowNames' and k[2] == edid]
    assert hit and after[hit[0]][0] == want
    print(f'  ShortbowNames {edid}: OK')

# Регресс-пробы (то, что НЕ должно было измениться)
for f, rt, fid, fld, want in [
        ('main', 'MGEF', '050617EC', 'DNAM', 'Призывает Крылатого сумрака на <dur> сек.: он владеет магией грозы и атакует мощным визгом. При ранении призывает сестер на подмогу.'),
        ('main', 'PERK', '0638FA31', 'FULL', 'Ураган'),
        ('sp', 'WEAP', '0700002E', 'FULL', 'Благословленное железное копье'),
        ('sp', 'WEAP', '07000087', 'FULL', 'Освященное двемерское копье'),
        ('sp', 'WEAP', '0700019F', 'FULL', 'Добродетельное сталгримовое копье'),
        ('main', 'MGEF', '0604CA2C', 'DNAM', 'Жвалы схлопываются, когда на них наступают, и наносят урон. Активируйте, чтобы установить капкан.'),
        ('main', 'MISC', '06245BD5', 'FULL', 'Заучить: ')]:
    hit = [k for k in after if k[0] == f and k[1] == rt and k[2] == fid and k[3] == fld]
    assert hit and after[hit[0]][0] == want, f'РЕГРЕСС: {f} {fid}: {after.get(hit[0])!r}'
print('  регресс-пробы (сумрак/перки/копья 01-02-05/капкан/шаблон): OK')

print()
print('ВЕРИФИКАЦИЯ ЗАВЕРШЕНА: пакет v1.5.6 соответствует фикс-листу')
