#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 96, разведка E: подмножество ванильных MGEF и функций CTDA для перков деревьев."""
import sys, struct
from collections import Counter, defaultdict

sys.path.insert(0, '/home/z/my-project/upload/poe_pack/scripts')
from parse_tes4 import Plugin

p = Plugin('/home/z/my-project/work/v156/00 Core/PathsOfEmpyrean.esp')
NM = len(p.masters)

def u32(sd, o=0): return struct.unpack_from('<I', sd, o)[0]

# деревья -> перки
tree_perks = set()
for f in p.by_type['AVIF']:
    for st, sd in p.records[f]['subs']:
        if st == 'PNAM':
            v = u32(sd)
            if v:
                tree_perks.add(v)
print('перков в деревьях:', len(tree_perks))

# все SPEL, на которые ссылаются перки деревьев (ability-секции, select spell, скрипты)
referenced_spels = set()
for f in tree_perks:
    r = p.records.get(f)
    if not r:
        continue
    in_ep = False
    for st, sd in r['subs']:
        if st == 'PRKE':
            in_ep = (sd[0] == 2)
        elif st == 'DATA' and len(sd) == 4 and not in_ep:
            referenced_spels.add(u32(sd))
        elif st == 'EPFD' and len(sd) == 4:
            v = u32(sd)
            if v in p.records and p.records[v]['type'] == 'SPEL':
                referenced_spels.add(v)
    # VMAD-свойства
    for st, sd in r['subs']:
        if st == 'VMAD':
            off = 4
            scount = struct.unpack_from('<H', sd, off)[0]; off += 2
            for _ in range(scount):
                n = struct.unpack_from('<H', sd, off)[0]; off += 2 + n
                off += 1
                pc = struct.unpack_from('<H', sd, off)[0]; off += 2
                for _ in range(pc):
                    n = struct.unpack_from('<H', sd, off)[0]; off += 2 + n
                    pt = sd[off]; off += 2
                    if pt == 1:
                        v = u32(sd, off + 4)
                        if v in p.records and p.records[v]['type'] == 'SPEL':
                            referenced_spels.add(v)
                        off += 8
                    elif pt == 2:
                        off += 2 + struct.unpack_from('<H', sd, off)[0]
                    elif pt in (3, 4):
                        off += 4
                    elif pt == 5:
                        off += 1
                    elif pt == 11:
                        cnt = u32(sd, off); off += 4
                        for i in range(cnt):
                            v = u32(sd, off + 4)
                            if v in p.records and p.records[v]['type'] == 'SPEL':
                                referenced_spels.add(v)
                            off += 8
                    elif pt == 12:
                        cnt = u32(sd, off); off += 4
                        for _ in range(cnt):
                            off += 2 + struct.unpack_from('<H', sd, off)[0]
                    else:
                        off = len(sd)
print('SPEL-ссылок с перков деревьев:', len(referenced_spels))

# MGEF, используемые этими SPEL (+ 2-й уровень: SPEL из MGEF cloak RelatedID и EquipAbility)
mg_refs = Counter()
spel_frontier = set(referenced_spels)
seen_spels = set()
while spel_frontier:
    nxt = set()
    for sf in spel_frontier:
        if sf not in p.records:
            continue
        seen_spels.add(sf)
        for st, sd in p.records[sf]['subs']:
            if st == 'EFID':
                mg_refs[u32(sd)] += 1
            elif st == 'VMAD':
                # свойства-ссылки на SPEL (рекурсивно: cloak и пр.)
                off = 4
                scount = struct.unpack_from('<H', sd, off)[0]; off += 2
                try:
                    for _ in range(scount):
                        n = struct.unpack_from('<H', sd, off)[0]; off += 2 + n
                        off += 1
                        pc = struct.unpack_from('<H', sd, off)[0]; off += 2
                        for _ in range(pc):
                            n = struct.unpack_from('<H', sd, off)[0]; off += 2 + n
                            pt = sd[off]; off += 2
                            if pt == 1:
                                v = u32(sd, off + 4)
                                if v in p.records and p.records[v]['type'] == 'SPEL' and v not in seen_spels:
                                    nxt.add(v)
                                off += 8
                            elif pt == 2:
                                off += 2 + struct.unpack_from('<H', sd, off)[0]
                            elif pt in (3, 4):
                                off += 4
                            elif pt == 5:
                                off += 1
                            elif pt == 11:
                                cnt = u32(sd, off); off += 4
                                for i in range(cnt):
                                    v = u32(sd, off + 4)
                                    if v in p.records and p.records[v]['type'] == 'SPEL' and v not in seen_spels:
                                        nxt.add(v)
                                    off += 8
                            elif pt == 12:
                                cnt = u32(sd, off); off += 4
                                for _ in range(cnt):
                                    off += 2 + struct.unpack_from('<H', sd, off)[0]
                            else:
                                raise ValueError
                except Exception:
                    pass
    spel_frontier = nxt
print('всего SPEL в замыкании (вкл. скриптовые):', len(seen_spels))

van = Counter()
for v, n in mg_refs.items():
    if v not in p.records:
        van[v] += n
print('ванильных/LG MGEF-ссылок:', len(van), 'использований:', sum(van.values()))
for v, n in van.most_common(40):
    print(f'  {v:#010x} x{n}')

# функции CTDA в условиях перков деревьев
fnh = Counter()
for f in tree_perks:
    r = p.records.get(f)
    if not r:
        continue
    for st, sd in r['subs']:
        if st == 'CTDA':
            fnh[struct.unpack_from('<I', sd, 8)[0]] += 1
print('\nфункции CTDA у перков деревьев:')
for fn, n in fnh.most_common(30):
    print(f'  {fn}: {n}')

# имена KYWD, на которые ссылаются условия (для сжатия вывода пригодится)
