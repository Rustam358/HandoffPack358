#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап-разведка 115e.
1) Истинные носители FIX113: у каждого ESP число мастеров и записи с этими formid.
2) Все CTDA в main ESP: операция, значение, функция, параметры, runOn (для выбора GetSex).
3) Полные записи: SPEL 06060E76 (bandit ability), MESG 06060E78, MGEF 06060E75 — поля и размеры.
"""
import struct, zlib, os

REL = '/home/z/my-project/work/qa114/release115'
REC_HDR = 24
FIX113 = [0x05000800, 0x05000801, 0x05000802, 0x09000910, 0x09000915, 0x0900091A]


class Node:
    __slots__ = ('kind', 'label', 'tail', 'formid', 'data', 'children')


def parse(buf):
    root = []

    def walk(off, end, out):
        while off < end:
            t = buf[off:off+4]
            size = struct.unpack_from('<I', buf, off+4)[0]
            if t == b'GRUP':
                node = Node(); node.kind = 'grup'; node.children = []
                walk(off + REC_HDR, off + size, node.children)
                out.append(node); off += size
            else:
                node = Node(); node.kind = 'rec'
                node.label = t
                node.tail = bytes(buf[off+8:off+24])
                node.formid = struct.unpack_from('<I', buf, off+12)[0]
                node.data = bytes(buf[off+REC_HDR:off+REC_HDR+size])
                out.append(node); off += REC_HDR + size
    walk(0, len(buf), root)
    return root


def walk_recs(nodes):
    for n in nodes:
        if n.kind == 'grup':
            yield from walk_recs(n.children)
        else:
            yield n


def subrecords(rec):
    body = rec.data
    if struct.unpack_from('<I', rec.tail, 0)[0] & 0x00040000:
        usz = struct.unpack_from('<I', body, 0)[0]
        body = zlib.decompress(body[4:])
        assert len(body) == usz
    out = []
    off = 0
    while off < len(body):
        st = body[off:off+4].decode('ascii', 'replace')
        ssz = struct.unpack_from('<H', body, off+4)[0]
        val = bytes(body[off+6:off+6+ssz])
        out.append((st, val))
        if st == 'XXXX':
            real = struct.unpack_from('<I', body, off+6)[0]
            off += 6 + ssz + 6 + real
            continue
        off += 6 + ssz
    return out


def edid_of(rec):
    for st, v in subrecords(rec):
        if st == 'EDID':
            return v.rstrip(b'\x00').decode('utf-8', 'replace')
    return ''


def hdr_info(path):
    buf = open(path, 'rb').read()
    assert buf[:4] == b'TES4' or buf[:4] == b'TES5', buf[:4]
    sig = buf[:4]
    # TES4 header: DATA после EDID/HEDR/MAST/... ищем сабрекорды заголовка
    # заголовок: [size u32 @4][flags @8][formid @12][v @16][ ? @20]
    hsize = struct.unpack_from('<I', buf, 4)[0]
    body = buf[REC_HDR:REC_HDR+hsize]
    masters = []
    off = 0
    hedr_done = False
    while off < len(body):
        st = body[off:off+4]
        ssz = struct.unpack_from('<H', body, off+4)[0]
        val = body[off+6:off+6+ssz]
        if st == b'MAST':
            masters.append(val.rstrip(b'\x00').decode('utf-8', 'replace'))
        if st == b'HEDR':
            hedr_done = True
        off += 6 + ssz
    return sig, len(masters), masters


def iter_esp():
    for dirpath, dirnames, filenames in os.walk(REL):
        for fn in sorted(filenames):
            if fn.lower().endswith('.esp'):
                yield os.path.join(dirpath, fn)


def main():
    print('=== 1) носители FIX113 ===')
    for p in iter_esp():
        sig, nmas, masters = hdr_info(p)
        prefix = nmas  # собственные записи: formid >> 24 == число мастеров
        buf = open(p, 'rb').read()
        root = parse(buf)
        for rec in walk_recs(root):
            if rec.formid in FIX113 and (rec.formid >> 24) == prefix:
                subs = subrecords(rec)
                full = next((v.rstrip(b'\x00').decode('utf-8', 'replace')
                             for st, v in subs if st == 'FULL'), '')
                print(f'{os.path.basename(p)} (masters={nmas}): '
                      f'{rec.label.decode()} {rec.formid:08X} '
                      f'{edid_of(rec)} FULL={full!r}')

    print()
    print('=== 2) CTDA в main ESP (все) ===')
    buf = open(os.path.join(REL, '00 Core/PathsOfEmpyrean.esp'), 'rb').read()
    root = parse(buf)
    recs = list(walk_recs(root))
    index = {}
    for rec in recs:
        index[rec.formid] = (rec.label.decode('ascii', 'replace'), edid_of(rec))
    from collections import Counter
    func_count = Counter()
    samples = {}
    for rec in recs:
        subs = subrecords(rec)
        for st, v in subs:
            if st != 'CTDA' or len(v) < 16:
                continue
            for i in range(0, len(v) - 15, 32):
                c = v[i:i+32]
                op = c[0]
                val = struct.unpack_from('<f', c, 4)[0]
                func = struct.unpack_from('<I', c, 8)[0]
                p1, p2 = struct.unpack_from('<II', c, 12)
                ro = struct.unpack_from('<H', c, 20)[0]
                ref = struct.unpack_from('<I', c, 22)[0] & 0xFFFFFF
                func_count[func] += 1
                if func not in samples:
                    samples[func] = (rec.label.decode('ascii', 'replace'),
                                     rec.formid, edid_of(rec), op, val, p1, p2, ro, ref, c.hex())
    print('функции CTDA в main ESP (func: count):',
          dict(sorted(func_count.items())))
    for func, (rl, fid, edid, op, val, p1, p2, ro, ref, hx) in sorted(samples.items()):
        r1 = index.get(p1, ('', '')) if p1 else ('', '')
        r2 = index.get(p2, ('', '')) if p2 else ('', '')
        print(f'func={func}: {rl} {fid:08X} {edid} op={op:#x} val={val:g} '
              f'p1={p1:08X}/{r1[0]}:{r1[1]} p2={p2:08X}/{r2[0]}:{r2[1]} '
              f'runOn={ro} ref={ref:06X}')

    print()
    print('=== 3) полные записи SPEL/MESG/MGEF bandit ===')
    for want in (0x06060E76, 0x06060E78, 0x06060E75):
        for rec in recs:
            if rec.formid == want:
                print(f'--- {rec.label.decode()} {want:08X} {edid_of(rec)} '
                      f'compressed={bool(struct.unpack_from("<I", rec.tail, 0)[0] & 0x00040000)} ---')
                for st, v in subrecords(rec):
                    if st in ('EDID', 'FULL', 'DESC', 'DNAM'):
                        print(f'  {st} [{len(v)}]: {v.rstrip(chr(0).encode()).decode("utf-8", "replace")!r}')
                    else:
                        print(f'  {st} [{len(v)}]: {v.hex()[:120]}')
                break


if __name__ == '__main__':
    main()
