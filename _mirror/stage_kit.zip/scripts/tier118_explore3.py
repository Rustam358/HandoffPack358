#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 118: разведка #3 — Masterwork, материалы WEAP/ARMO, SCRL/ALCH тиры."""
import json
from collections import defaultdict, Counter

A = json.load(open('/home/z/my-project/work/qa118/aligned.json', encoding='utf-8'))

# --- 1. Masterwork: как переводится Masterwork ---
print('=== Masterwork в EN WEAP/ARMO FULL -> RU первые слова ===')
mw = Counter()
for r in A:
    if r['rtype'] in ('WEAP', 'ARMO') and r['field'] == 'FULL' and r['en_text'] and 'Masterwork' in r['en_text']:
        w = r['ru_text'].split()
        mw[w[0] if w else ''] += 1
for w, n in mw.most_common():
    print(f'  «{w}»: {n}')

# --- 2. Материалы WEAP: EN слово -> RU слово (первое слово имени, немодифицированные) ---
MATS = ['Iron', 'Steel', 'Dwarven', 'Orcish', 'Elven', 'Glass', 'Ebony', 'Daedric',
        'Dragonbone', 'Nordic', 'Stalhrim', 'Ancient', 'Nord', 'Falmer', 'Forsworn',
        'Imperial', 'Silver', 'Hunting', 'Bound']
print('\n=== WEAP: EN-материал -> RU-слово (все вхождения в начале) ===')
mat_map = defaultdict(Counter)
for r in A:
    if r['rtype'] == 'WEAP' and r['field'] == 'FULL' and r['en_text']:
        en = r['en_text'].split()
        if en and en[0] in MATS:
            ru = r['ru_text'].split()
            mat_map[en[0]][ru[0] if ru else '∅'] += 1
for m in MATS:
    if m in mat_map:
        print(f'  {m}: ' + ', '.join(f'«{k}»×{v}' for k, v in mat_map[m].most_common()))

# --- 3. Материалы ARMO ---
MATS_A = ['Hide', 'Leather', 'Studded', 'Scaled', 'Iron', 'Banded', 'Steel', 'Imperial',
          'Orcish', 'Dwarven', 'Elven', 'Gilded', 'Nordic', 'Chitin', 'Bonemold', 'Glass',
          'Ebony', 'Daedric', 'Dragonplate', 'Dragonscale', 'Stalhrim', 'Ancient',
          'Nord', 'Falmer', 'Forsworn', 'Vampire', 'Fine', 'Noble', 'Common']
print('\n=== ARMO: EN-материал -> RU-слово ===')
mat_map = defaultdict(Counter)
for r in A:
    if r['rtype'] == 'ARMO' and r['field'] == 'FULL' and r['en_text']:
        en = r['en_text'].split()
        if en and en[0] in MATS_A:
            ru = r['ru_text'].split()
            mat_map[en[0]][ru[0] if ru else '∅'] += 1
for m in MATS_A:
    if m in mat_map:
        print(f'  {m}: ' + ', '.join(f'«{k}»×{v}' for k, v in mat_map[m].most_common(8)))

# --- 4. ALCH: префиксы зелий/ядов ---
print('\n=== ALCH FULL EN: первые 2 слова (все) ===')
c = Counter()
for r in A:
    if r['rtype'] == 'ALCH' and r['field'] == 'FULL' and r['en_text']:
        w = r['en_text'].split()
        c[' '.join(w[:2])] += 1
for k, n in c.most_common(60):
    print(f'  {k}: {n}')
