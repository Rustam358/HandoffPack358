#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""115h: финальные проверки перед реализацией.
1) max formid main ESP (+ top-level GRUP список).
2) Порядок полей MGEF с CTDA (образцы 065805F0, 06075337).
3) SPEL DisguiseBreakDetection CTDA func=71 — точный hex (шаблон male/female).
4) SPIT у SPEL-маскировок (для контроля).
"""
import struct, sys
sys.path.insert(0, '/home/z/my-project/scripts')
from probe115f import parse, walk_recs, subrecords, edid_of

ESP = '/home/z/my-project/work/qa114/release115/00 Core/PathsOfEmpyrean.esp'
buf = open(ESP, 'rb').read()
root = parse(buf)
recs = list(walk_recs(root))

print('=== 1) max formid / GRUP ===')
mx = max(r.formid for r in recs)
print(f'max formid записи: {mx:08X}')
ids = [r.formid for r in recs]
print(f'всего записей: {len(ids)}, уникальных: {len(set(ids))}')
# свободность окна max+1..max+12
cand = [mx + 1 + i for i in range(12)]
print('кандидаты:', [f'{c:08X}' for c in cand])
# проверить, не встречаются ли байты кандидатов в «ссылочных» полях (VMAD/CTDA/EFID/MDOB/KWDA/CNAM и т.п.) — эвристика
pats = [struct.pack('<I', c) for c in cand]
hits = []
for r in recs:
    for st, v in subrecords(r):
        if st in ('EDID', 'FULL', 'DESC', 'DNAM', 'OBND', 'SPIT', 'DATA', 'KSIZ'):
            continue
        for c, p in zip(cand, pats):
            if p in v:
                hits.append((r.formid, st, f'{c:08X}'))
print('эвристические пересечения:', hits[:10] if hits else 'нет')

def top_grups(nodes, d=0):
    for n in nodes:
        if n.kind == 'grup':
            lb = n.label[4:8] if len(n.label) >= 8 else ''
            print('  ' * d + f'GRUP {lb!r} size={struct.unpack_from("<I", n.label, 0)[0] if False else ""} children={len(n.children)}')
            if d < 1:
                top_grups(n.children, d + 1)
print()
print('=== топ-группы ===')
for n in root:
    if n.kind == 'grup':
        lb = bytes(n.label[4:8]).decode('ascii', 'replace')
        print(f'GRUP {lb}: children={len(n.children)}')
        sub = {}
        for c in n.children:
            if c.kind == 'grup':
                pass

print()
print('=== 2) порядок полей MGEF с CTDA ===')
for want in (0x065805F0, 0x06075337):
    for r in recs:
        if r.formid == want:
            print(f'--- {want:08X} {edid_of(r)} ---')
            print(' поля:', ' '.join(st for st, v in subrecords(r)))
            for st, v in subrecords(r):
                if st == 'CTDA':
                    print(f'   CTDA: op={v[0]:#x} val={struct.unpack_from("<f", v, 4)[0]:g} '
                          f'func={struct.unpack_from("<I", v, 8)[0]} '
                          f'p1={struct.unpack_from("<I", v, 12)[0]:#x} '
                          f'p2={struct.unpack_from("<I", v, 16)[0]:#x} '
                          f'ro={struct.unpack_from("<H", v, 20)[0]} tail={v[22:].hex()}')
            break

print()
print('=== 3) CTDA func=71 у ISP_SPELL_SPEECH_DisguiseBreakDetection (06060E83) ===')
for r in recs:
    if r.formid == 0x06060E83:
        for st, v in subrecords(r):
            if st == 'CTDA':
                func = struct.unpack_from('<I', v, 8)[0]
                if func == 71:
                    val = struct.unpack_from('<f', v, 4)[0]
                    print(f'полный hex: {v.hex()}  (val={val:g})')
        break

print()
print('=== 4) SPIT SPEL-маскировок ===')
for r in recs:
    if r.label == b'SPEL' and edid_of(r).startswith('ISP_AB_SPEECH_Disguise'):
        spit = next((v for st, v in subrecords(r) if st == 'SPIT'), b'')
        efid = next((v for st, v in subrecords(r) if st == 'EFID'), b'')
        efit = next((v for st, v in subrecords(r) if st == 'EFIT'), b'')
        n_ct = sum(1 for st, v in subrecords(r) if st == 'CTDA')
        print(f'{r.formid:08X} {edid_of(r)[:38]}: SPIT={spit.hex()} EFID={efid.hex()} '
              f'EFIT={efit.hex()} CTDA×{n_ct}')
