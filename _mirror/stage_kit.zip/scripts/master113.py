#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 113 (v1.5.14): откат 9 правок 112 — директива игрока от 07.11.2026
(тир-доктрина: «ламеллярная броня» = низкий тир; «чешуйчатый» = только
Dragonscale/высший тир). Доказательства: EN PoE 1.4 «Scaled» ×38 / «Lamellar»
×0; офиц. корпус SoftClub: Scaled-тир = «ламеллярный» (93 имени), армор-имена
с «чешуйчат» = только «Драконий чешуйчатый» (×119), перк 61046 «ламеллярные
и пластинчатые», «чешуйчатые и пластинчатые» = 0; канон игрока All items.txt
строки 33–39 (Scaled = «Ламеллярный») и 49–55 (Dragonscale = «Драконий
чешуйчатый»).

Источник: user zip «Paths of Empyrean RU 1.5 (5).zip» = байт-в-байт наш
v1.5.13 (63/63 CRC, diff_zip_113.py). Приемник: work/qa113/v114.
Машина ESP байт-в-байт как в master112 (сжатые записи 0x40000/zlib, XXXX).
Контроль: результат == ESP v1.5.12 (work/ru15_4) БАЙТ-В-БАЙТ.
"""
import struct, zlib, os, json, zipfile, hashlib

SRC_ZIP = '/home/z/my-project/upload/Paths of Empyrean RU 1.5 (5).zip'
DST = '/home/z/my-project/work/qa113/v114/00 Core/PathsOfEmpyrean.esp'
FIX = '/home/z/my-project/work/qa113/fixlist_v114.jsonl'
V112_ESP = '/home/z/my-project/work/ru15_4/00 Core/PathsOfEmpyrean.esp'

REC_HDR = 24


class Node:
    __slots__ = ('kind', 'label', 'tail', 'formid', 'data', 'children')


def parse(buf):
    root = []

    def walk(off, end, out):
        while off < end:
            t = buf[off:off+4]
            size = struct.unpack_from('<I', buf, off+4)[0]
            if t == b'GRUP':
                node = Node()
                node.kind = 'grup'
                node.tail = bytes(buf[off+8:off+24])
                node.children = []
                walk(off + REC_HDR, off + size, node.children)
                out.append(node)
                off += size
            else:
                node = Node()
                node.kind = 'rec'
                node.label = t
                node.tail = bytes(buf[off+8:off+24])
                node.formid = struct.unpack_from('<I', buf, off+12)[0]
                node.data = bytes(buf[off+REC_HDR:off+REC_HDR+size])
                out.append(node)
                off += REC_HDR + size
    walk(0, len(buf), root)
    return root


def serialize_node(n, parts):
    if n.kind == 'grup':
        sub = []
        for c in n.children:
            serialize_node(c, sub)
        s = b''.join(sub)
        parts.append(b'GRUP' + struct.pack('<I', 24 + len(s)) + n.tail)
        parts.append(s)
    else:
        parts.append(n.label + struct.pack('<I', len(n.data)) + n.tail)
        parts.append(n.data)


def find_rec(nodes, formid):
    for n in nodes:
        if n.kind == 'grup':
            r = find_rec(n.children, formid)
            if r is not None:
                return r
        elif n.formid == formid:
            return n
    return None


def rec_flags(rec):
    return struct.unpack_from('<I', rec.tail, 0)[0]


def decode_body(rec):
    if rec_flags(rec) & 0x00040000:
        usz = struct.unpack_from('<I', rec.data, 0)[0]
        dec = zlib.decompress(rec.data[4:])
        assert len(dec) == usz
        return bytearray(dec), True
    return bytearray(rec.data), False


def encode_body(body, was_c):
    if was_c:
        return struct.pack('<I', len(body)) + zlib.compress(bytes(body))
    return bytes(body)


def apply_esp(src_bytes, dst, patches):
    buf = src_bytes
    root = parse(buf)
    out = []
    for n in root:
        serialize_node(n, out)
    if b''.join(out) != buf:
        raise SystemExit('САМОТЕСТ ПРОВАЛЕН: user zip ESP')
    print(f'  самотест OK: ESP из user zip ({len(buf)} Б)')
    applied = 0
    for formid, field, occ, old, new in patches:
        rec = find_rec(root, formid)
        if rec is None:
            raise SystemExit(f'запись {formid:08X} не найдена')
        body, was_c = decode_body(rec)
        off, seen, done = 0, 0, False
        while off < len(body):
            if off + 6 > len(body):
                break
            st = body[off:off+4].decode('ascii', 'replace')
            ssz = struct.unpack_from('<H', body, off+4)[0]
            if st == 'XXXX':
                real = struct.unpack_from('<I', body, off+6)[0]
                off += 6 + ssz + 6 + real
                continue
            cur_sz = ssz
            if st == field:
                seen += 1
                cur = bytes(body[off+6:off+6+ssz]).rstrip(b'\x00').decode('utf-8', 'replace')
                if seen == occ:
                    assert cur == old, f'{formid:08X} {field}#{occ}: old не совпал: {cur[:80]!r} != {old[:80]!r}'
                    newb = new.encode('utf-8') + b'\x00'
                    body[off+6:off+6+ssz] = newb
                    struct.pack_into('<H', body, off+4, len(newb))
                    done = True
                    applied += 1
                    cur_sz = len(newb)
            off += 6 + cur_sz
        if not done:
            raise SystemExit(f'патч {formid:08X} {field}#{occ} не применён')
        rec.data = encode_body(body, was_c)
    out = []
    for n in root:
        serialize_node(n, out)
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    open(dst, 'wb').write(b''.join(out))
    print(f'  -> {dst} ({os.path.getsize(dst)} Б), патчей: {applied}')
    return applied


def main():
    esp_patches = []
    for line in open(FIX, encoding='utf-8'):
        r = json.loads(line)
        assert r['kind'] == 'esp' and r['scope'] == 'main', r
        esp_patches.append((int(r['formid'], 16), r['field'], r['occ'], r['old'], r['new']))
    assert len(esp_patches) == 9, len(esp_patches)
    with zipfile.ZipFile(SRC_ZIP) as z:
        info = z.read('fomod/info.xml').decode('utf-8')
        assert '<Version>1.5.13</Version>' in info, 'база не v1.5.13!'
        esp_src = z.read('00 Core/PathsOfEmpyrean.esp')
    print(f'база: user zip (5) = v1.5.13, ESP {len(esp_src)} Б')
    tot = apply_esp(esp_src, DST, esp_patches)
    print(f'ИТОГО применено: {tot} (ожидается 9)')
    assert tot == 9

    # === контроль отката: байт-в-байт равен v1.5.12 ===
    a = open(DST, 'rb').read()
    b = open(V112_ESP, 'rb').read()
    print(f'ESP v1.5.14: {len(a)} Б | ESP v1.5.12: {len(b)} Б')
    assert len(a) == len(b), 'размеры расходятся с v1.5.12!'
    if a != b:
        # показать первый байт расхождения для диагностики
        for i, (x, y) in enumerate(zip(a, b)):
            if x != y:
                raise SystemExit(f'ОТКАТ НЕ БАЙТ-В-БАЙТ: первое расхождение @ {i:#x}')
    md = hashlib.md5(a).hexdigest()
    print(f'ОТКАТ ПОДТВЕРЖДЁН: ESP v1.5.14 == ESP v1.5.12 байт-в-байт (md5 {md})')


if __name__ == '__main__':
    main()
