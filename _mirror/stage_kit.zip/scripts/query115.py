#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап-запрос 115: все маскировки ISP Speech — MGEF, MESG, CTDA-условия.
Разбор main ESP v1.5.15: индекс formid->(type, EDID); для MGEF
ISP_MGEF_SPEECH_Disguise* — FULL/DNAM + CTDA (32 Б: op u8, value f32,
func u32, param1 u32, param2 u32) с резолвом param->EDID.
"""
import struct, zlib, sys, io, json

ESP = '/home/z/my-project/work/qa114/release115/00 Core/PathsOfEmpyrean.esp'
REC_HDR = 24


class Node:
    __slots__ = ('kind', 'label', 'tail', 'formid', 'data', 'children')


def parse(buf):
    root = []

    def walk(off, end, out):
        while off < end:
            t = buf[off:off+4]
            size = struct.unpack_from('<I', buf, off+4)[0]
            if t == b'GRUP':
                node = Node()
                node.kind = 'grup'
                node.children = []
                walk(off + REC_HDR, off + size, node.children)
                out.append(node)
                off += size
            else:
                node = Node()
                node.kind = 'rec'
                node.label = t
                node.tail = bytes(buf[off+8:off+24])
                node.formid = struct.unpack_from('<I', buf, off+12)[0]
                node.data = bytes(buf[off+REC_HDR:off+REC_HDR+size])
                out.append(node)
                off += REC_HDR + size
    walk(0, len(buf), root)
    return root


def walk_recs(nodes):
    for n in nodes:
        if n.kind == 'grup':
            yield from walk_recs(n.children)
        else:
            yield n


def subrecords(rec):
    body = rec.data
    if struct.unpack_from('<I', rec.tail, 0)[0] & 0x00040000:
        usz = struct.unpack_from('<I', body, 0)[0]
        body = zlib.decompress(body[4:])
        assert len(body) == usz
    out = []
    off = 0
    while off < len(body):
        st = body[off:off+4].decode('ascii', 'replace')
        ssz = struct.unpack_from('<H', body, off+4)[0]
        val = bytes(body[off+6:off+6+ssz])
        out.append((st, val))
        if st == 'XXXX':
            real = struct.unpack_from('<I', body, off+6)[0]
            off += 6 + ssz + 6 + real
            continue
        off += 6 + ssz
    return out


def main():
    buf = open(ESP, 'rb').read()
    root = parse(buf)
    index = {}
    bags = {}
    for n in walk_recs(root):
        if n.kind != 'rec':
            continue
        subs = subrecords(n)
        edid = ''
        for st, val in subs:
            if st == 'EDID':
                edid = val.rstrip(b'\x00').decode('utf-8', 'replace')
                break
        index[n.formid] = (n.label.decode('ascii', 'replace'), edid)
        bags[edid] = subs

    print('=== MGEF маскировок: FULL / DNAM / CTDA-условия ===')
    targets = [e for e in bags if e.startswith('ISP_MGEF_SPEECH_Disguise')]
    for edid in sorted(targets):
        subs = bags[edid]
        full = next((v.rstrip(b'\x00').decode('utf-8', 'replace')
                     for st, v in subs if st == 'FULL'), '')
        dnam = next((v.rstrip(b'\x00').decode('utf-8', 'replace')
                     for st, v in subs if st == 'DNAM'), '')
        formid = [k for k, (t, e) in index.items() if e == edid and t == 'MGEF'][0]
        print('-' * 90)
        print(f'MGEF {formid:08X} {edid}')
        print(f'  FULL: {full}')
        print(f'  DNAM: {dnam}')
        for st, val in subs:
            if st != 'CTDA':
                continue
            b = val
            # CTDA может быть кратен 32; блоки идут подряд
            for i in range(0, len(b), 32):
                c = b[i:i+32]
                if len(c) < 20:
                    continue
                op = c[0]
                value = struct.unpack_from('<f', c, 4)[0]
                func = struct.unpack_from('<I', c, 8)[0]
                p1, p2 = struct.unpack_from('<II', c, 12)[0]
                def res(p):
                    if p == 0:
                        return '0'
                    r = index.get(p)
                    if r:
                        return f'{p:08X}={r[0]}/{r[1]}'
                    return f'{p:08X}=(вне ESP — ваниль)'
                print(f'  CTDA op={op:#04x} val={value:g} func={func} '
                      f'p1={res(p1)} p2={res(p2)}')

    print()
    print('=== MESG маскировок ===')
    for edid in sorted(e for e in bags if e.startswith('ISP_MSG_SPEECH_Disguise')):
        subs = bags[edid]
        desc = next((v.rstrip(b'\x00').decode('utf-8', 'replace')
                     for st, v in subs if st == 'DESC'), '')
        formid = [k for k, (t, e) in index.items() if e == edid and t == 'MESG'][0]
        print(f'MESG {formid:08X} {edid}: {desc}')

    print()
    print('=== резолв ключевых KYWD/FACT/CLAS из CTDA ===')
    seen = set()
    for edid in targets:
        for st, val in bags[edid]:
            if st != 'CTDA':
                continue
            for i in range(0, len(val), 32):
                c = val[i:i+32]
                if len(c) < 20:
                    continue
                for p in struct.unpack_from('<II', c, 12)[0:2]:
                    if p and p in index and index[p][0] in ('KYWD', 'FACT', 'CLAS', 'OTFT', 'FLST'):
                        seen.add((index[p][0], index[p][1]))
    for t, e in sorted(seen):
        print(f'{t}: {e}')


if __name__ == '__main__':
    main()
