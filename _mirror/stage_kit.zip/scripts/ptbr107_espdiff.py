# -*- coding: utf-8 -*-
"""Этап 107: тройной дифф EN 1.4 <-> PT-BR <-> RU v1.5.9 (corpus57).
Кандидаты ассимиляции: PT перевел, RU оставил EN (или наоборот). work/qa107/."""
import json, collections, os

OUT = '/home/z/my-project/work/handoff/work/qa107'
CORPUS = '/home/z/my-project/work/handoff/handoff/06_код-истина_перевода/corpus57.json'

def load_jsonl(path):
    rows = []
    with open(path, encoding='utf-8') as f:
        for line in f:
            rows.append(json.loads(line))
    return rows

en14 = load_jsonl(f'{OUT}/dump_en14.jsonl')
pt = load_jsonl(f'{OUT}/dump_pt.jsonl')
ru = json.load(open(CORPUS, encoding='utf-8'))

def keyed(rows, valkey):
    d = {}
    for r in rows:
        k = (r['file'], r['rtype'], r['fid'], r['field'], r['occ'])
        d[k] = r[valkey]
    return d

E, P = keyed(en14, 'text'), keyed(pt, 'text')
R = {}
for r in ru:
    R[(r['file'], r['type'], r['fid'], r['field'], r['occ'])] = (r.get('ru'), r.get('en'))

rep = []
rep.append('=== Этап 107: тройной дифф EN14/PT/RU (поля EN14) ===')
rep.append(f'EN14 fields={len(E)}  PT fields={len(P)}  RU fields={len(R)}')

# 1) Дрейф базы: ключи RU, которых нет в EN14 (автор добавил в 1.5)
drift = [k for k in R if k not in E]
rep.append(f'1) Полей RU (v1.5.9), отсутствующих в EN14 (добавлены автором в 1.5): {len(drift)}')

# 2) PT-поля, которых нет в EN14 (внезапные добавления PT?)
pt_extra = [k for k in P if k not in E]
rep.append(f'2) Полей PT, отсутствующих в EN14 (PT-инновации): {len(pt_extra)}')
for k in pt_extra[:20]:
    rep.append(f'   {k} -> {P[k]!r}')

# 3) Статусы PT по полям EN14
pt_tr = pt_en = 0
missing_in_pt = []
for k, en in E.items():
    if k not in P:
        missing_in_pt.append(k)
    elif P[k] != en:
        pt_tr += 1
    else:
        pt_en += 1
rep.append(f'3) По {len(E)} полям EN14: PT перевел {pt_tr}, PT=EN {pt_en}, поля нет в PT {len(missing_in_pt)}')

# 4) Статусы RU по полям EN14 (сверка через corpus57 en-пару)
ru_tr = ru_en = ru_abs = en_drift = 0
ru_en_list = []
for k, en in E.items():
    if k not in R:
        ru_abs += 1
        continue
    ruv, ru_en_val = R[k]
    if ru_en_val is not None and ru_en_val != en:
        en_drift += 1  # EN изменился между 1.4 и 1.5
        continue
    if ruv is not None and ruv != en:
        ru_tr += 1
    else:
        ru_en += 1
        ru_en_list.append(k)
rep.append(f'4) По полям EN14 в RU-corpus: RU перевел {ru_tr}, RU=EN {ru_en}, нет в corpus {ru_abs}, EN-дрейф 1.4->1.5 {en_drift}')

# 5) Кандидаты ассимиляции: PT != EN, а RU == EN (по en-паре corpus)
cands = []
for k, en in E.items():
    if k not in P or k not in R:
        continue
    if P[k] == en:
        continue
    ruv, ru_en_val = R[k]
    if ru_en_val is not None and ru_en_val != en:
        continue  # EN-дрейф — не наш случай
    if ruv == en or ruv is None:
        cands.append((k, en, P[k], ruv))
rep.append(f'5) КАНДИДАТЫ ассимиляции (PT перевел, RU=EN): {len(cands)}')
by_rtype = collections.Counter((k[1], k[3]) for k, *_ in cands)
rep.append(f'   по (rtype, field): {dict(by_rtype)}')
for k, en, ptv, ruv in cands[:60]:
    rep.append(f'   {k[0]}/{k[1]}/{k[2]}/{k[3]}#{k[4]} EDID-в-E: см. файл')
with open(f'{OUT}/candidates_pt_ru.tsv', 'w', encoding='utf-8') as f:
    f.write('file\trtype\tfid\tfield\tocc\ten\tpt\tru\n')
    for k, en, ptv, ruv in cands:
        edid = next((r.get('edid', '') for r in en14
                     if (r['file'], r['rtype'], r['fid'], r['field'], r['occ']) == k), '')
        f.write(f'{k[0]}\t{k[1]}\t{k[2]}\t{k[3]}\t{k[4]}\t{en}\t{ptv}\t{ruv}\t{edid}\n')

# EDID для кандидатов — отдельная карта
edid_map = {}
for r in en14:
    edid_map[(r['file'], r['rtype'], r['fid'], r['field'], r['occ'])] = r['edid']
with open(f'{OUT}/candidates_pt_ru.tsv', 'w', encoding='utf-8') as f:
    f.write('file\trtype\tfid\tedid\tfield\tocc\ten\tpt\tru\n')
    for k, en, ptv, ruv in cands:
        f.write(f'{k[0]}\t{k[1]}\t{k[2]}\t{edid_map.get(k,"")}\t{k[3]}\t{k[4]}\t{en}\t{ptv}\t{ruv}\n')

# 6) Обратное: RU перевел, PT=EN (наши победы — ожидаемо много)
wins = 0
for k, en in E.items():
    if k not in P or k not in R:
        continue
    if P[k] != en:
        continue
    ruv, ru_en_val = R[k]
    if ru_en_val is not None and ru_en_val != en:
        continue
    if ruv is not None and ruv != en:
        wins += 1
rep.append(f'6) Наши победы (RU перевел, PT=EN): {wins}')

# 7) PT = EN по всей базе 1.4: главные семьи непереведенного PT
pt_en_fam = collections.Counter((k[1], k[3]) for k, en in E.items() if k in P and P[k] == en)
rep.append(f'7) PT=EN семьи (что бразильцы НЕ перевели): {dict(pt_en_fam.most_common(12))}')

with open(f'{OUT}/espdiff_107.txt', 'w', encoding='utf-8') as f:
    f.write('\n'.join(rep))
print('\n'.join(rep))
