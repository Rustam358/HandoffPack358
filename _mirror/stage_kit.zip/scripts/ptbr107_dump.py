# -*- coding: utf-8 -*-
"""Этап 107: дамп текстовых полей EN 1.4 и PT-BR ESP -> work/qa107/*.jsonl.
Схема как у corpus57 (file/rtype/fid/edid/field/occ/text), кодировка: utf-8 -> cp1252."""
import sys, os, json

sys.path.insert(0, '/home/z/my-project/work/handoff/scripts')
from parse_tes4 import Plugin

OUT = '/home/z/my-project/work/handoff/work/qa107'
os.makedirs(OUT, exist_ok=True)
EN14 = '/home/z/my-project/work/handoff/handoff/08_оригинал_1.4_EN/полный_разбор_1.4/PoE 1.4'
PT = '/home/z/my-project/work/ptbr/PathsOfEmpyrean_FOMODSetup'

TEXT_FIELDS = {'FULL', 'DESC', 'ITXT', 'NNAM'}
enc_stats = {'utf8': 0, 'cp1252': 0}

def decode(b):
    s = b.rstrip(b'\x00')
    try:
        t = s.decode('utf-8')
        enc_stats['utf8'] += 1
        return t
    except UnicodeDecodeError:
        enc_stats['cp1252'] += 1
        return s.decode('cp1252', 'replace')

def dump_esp(path, tag, out):
    p = Plugin(path)
    n = 0
    occ = {}
    for formid, r in p.records.items():
        rtype = r['type']
        edid = r.get('edid') or ''
        for st, sd in r['subs']:
            text = None
            if st in TEXT_FIELDS:
                if st == 'NNAM' and rtype == 'PERK':
                    continue
                text = decode(sd)
            elif st == 'DNAM' and rtype == 'MGEF':
                cand = decode(sd)
                ctrl = sum(1 for c in cand if ord(c) < 32 and c != '\n')
                letters = sum(1 for c in cand if c.isalpha())
                spaces = cand.count(' ')
                if cand and ctrl == 0 and letters >= 4 and (spaces >= 1 or len(cand) <= 64):
                    text = cand
            elif st == 'DATA' and rtype == 'GMST':
                if edid.startswith('s'):
                    text = decode(sd)
            if text is None:
                continue
            key = (rtype, formid, st)
            occ[key] = occ.get(key, 0) + 1
            out.write(json.dumps({'file': tag, 'rtype': rtype,
                                  'fid': f'{formid:08X}', 'edid': edid,
                                  'field': st, 'occ': occ[key], 'text': text},
                                 ensure_ascii=False) + '\n')
            n += 1
    return len(p.records), n

def jobs_en14():
    for fn in sorted(os.listdir(EN14)):
        if not fn.endswith('.esp'):
            continue
        if fn == 'PathsOfEmpyrean.esp': tag = 'main'
        elif fn == 'PoE-Addon-MissingShields.esp': tag = 'ms'
        elif fn == 'PoE-Addon-Spears.esp': tag = 'sp'
        else:
            tag = 'cc:' + fn.replace('PoE-CC', '').replace('-Patch.esp', '')
        yield os.path.join(EN14, fn), tag

def jobs_pt():
    for dp, _, fns in os.walk(PT):
        for fn in sorted(fns):
            if not fn.endswith('.esp'):
                continue
            p = os.path.join(dp, fn)
            if fn == 'PathsOfEmpyrean.esp': tag = 'main'
            elif fn == 'PoE-Addon-MissingShields.esp': tag = 'ms'
            elif fn == 'PoE-Addon-Spears.esp': tag = 'sp'
            else:
                tag = 'cc:' + fn.replace('PoE-CC', '').replace('-Patch.esp', '')
            yield p, tag

for name, jobs, dst in (('EN14', jobs_en14(), f'{OUT}/dump_en14.jsonl'),
                        ('PT', jobs_pt(), f'{OUT}/dump_pt.jsonl')):
    rec_total = field_total = 0
    with open(dst, 'w', encoding='utf-8') as out:
        for path, tag in jobs:
            rc, fc = dump_esp(path, tag, out)
            rec_total += rc; field_total += fc
            print(f'{name} {tag}: records={rc} fields={fc}')
    print(f'== {name}: records={rec_total} fields={field_total} enc={enc_stats}')
    enc_stats.update({'utf8': 0, 'cp1252': 0})
