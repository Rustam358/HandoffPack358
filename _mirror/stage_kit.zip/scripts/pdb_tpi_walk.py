#!/usr/bin/env python3
"""Full TPI record walker: index -> (leaf, name, members) so we can print any struct's fields."""
import struct, re, sys, json

PDB = "/home/z/my-project/spid_work/spid_extracted/SKSE/Plugins/po3_SpellPerkItemDistributor.pdb"
data = open(PDB, "rb").read()
MAGIC = b"Microsoft C/C++ MSF 7.00\r\n\x1aDS\x00\x00\x00"
bs, fm, nb, ds, unk, bma = struct.unpack_from("<IIIIII", data, len(MAGIC))
nd = (ds + bs - 1) // bs
db = struct.unpack_from(f"<{nd}I", data, bma * bs)
directory = b"".join(data[b * bs: b * bs + bs] for b in db)[:ds]
pos = 0
ns = struct.unpack_from("<I", directory, pos)[0]; pos += 4
sizes = [struct.unpack_from("<I", directory, pos + 4 * i)[0] for i in range(ns)]
pos += 4 * ns
streams = []
for i, sz in enumerate(sizes):
    if sz in (0, 0xFFFFFFFF):
        streams.append(b""); continue
    nbk = (sz + bs - 1) // bs
    blks = struct.unpack_from(f"<{nbk}I", directory, pos); pos += 4 * nbk
    streams.append(b"".join(data[b * bs: b * bs + bs] for b in blks)[:sz])
tpi = streams[2]

ver, hsize, imin, imax = struct.unpack_from("<IIII", tpi, 0)
print(f"TPI ver={ver} header={hsize:#x} indices {imin}..{imax}", file=sys.stderr)

LF_FIELDLIST = 0x1203
LF_ENUM = 0x1507
LF_STRUCTURE = 0x1505
LF_CLASS = 0x1504
LF_UNION = 0x1506
LF_MEMBER = 0x1501
LF_ENUMERATE = 0x1502
LF_STMEMBER = 0x150E
LF_METHOD = 0x150F
LF_ONEMETHOD = 0x1511
LF_NESTTYPE = 0x1510
LF_BCLASS = 0x1400
LF_VFUNCTAB = 0x1409
LF_INDEX = 0x1404

def read_zstr(buf, off):
    end = buf.index(b"\x00", off)
    return buf[off:end].decode("latin1"), end + 1

def pad4(x):
    return (x + 3) & ~3

records = {}   # idx -> dict(leaf, name, unique, members(list))
i = hsize
idx = imin
total = imax - imin
count = 0
while i < len(tpi) - 4 and idx < imax:
    reclen = struct.unpack_from("<H", tpi, i)[0]
    leaf = struct.unpack_from("<H", tpi, i + 2)[0]
    rec_start = i
    payload = tpi[i + 4: i + 2 + reclen]
    p = 0
    info = {"leaf": leaf, "name": None, "unique": None, "members": []}
    if leaf == LF_FIELDLIST:
        # walk members
        p = 0
        plen = len(payload)
        while p < plen - 2:
            # CodeView pads: 0xf0..0xff => skip low nibble bytes
            if payload[p] >= 0xF0:
                p += payload[p] & 0x0F
                continue
            mleaf = struct.unpack_from("<H", payload, p)[0]; p += 2
            try:
                if mleaf == LF_MEMBER:
                    attrs = struct.unpack_from("<H", payload, p)[0]; p += 2
                    tidx = struct.unpack_from("<I", payload, p)[0]; p += 4
                    # offset is a CodeView numeric
                    v16 = struct.unpack_from("<H", payload, p)[0]
                    if v16 >= 0x8000:
                        if v16 == 0x8001: p += 2; p += 2
                        elif v16 == 0x8002: p += 2; p += 2
                        elif v16 in (0x8003, 0x8004): p += 2; p += 4
                        else: p += 2
                    else:
                        p += 2
                    nm, p = read_zstr(payload, p)
                    info["members"].append(("member", nm, tidx))
                elif mleaf == LF_STMEMBER:
                    attrs = struct.unpack_from("<H", payload, p)[0]; p += 2
                    tidx = struct.unpack_from("<I", payload, p)[0]; p += 4
                    nm, p = read_zstr(payload, p)
                    info["members"].append(("static", nm, tidx))
                elif mleaf == LF_ENUMERATE:
                    attrs = struct.unpack_from("<H", payload, p)[0]; p += 2
                    # value: if u16 >= 0x8000 -> numeric leaf, else direct u16 value
                    v16 = struct.unpack_from("<H", payload, p)[0]
                    if v16 >= 0x8000:
                        # parse minimal numeric leaves
                        if v16 in (0x8000,):  # LF_CHAR? no, LF_NUMERIC base
                            p += 2; val = struct.unpack_from("<b", payload, p)[0]; p += 1
                        elif v16 == 0x8001:  # LF_SHORT
                            p += 2; val = struct.unpack_from("<h", payload, p)[0]; p += 2
                        elif v16 == 0x8002:  # LF_USHORT
                            p += 2; val = struct.unpack_from("<H", payload, p)[0]; p += 2
                        elif v16 == 0x8003:  # LF_LONG
                            p += 2; val = struct.unpack_from("<i", payload, p)[0]; p += 4
                        elif v16 == 0x8004:  # LF_ULONG
                            p += 2; val = struct.unpack_from("<I", payload, p)[0]; p += 4
                        else:
                            val = None; p += 2  # skip unknown numeric
                    else:
                        val = v16; p += 2
                    nm, p = read_zstr(payload, p)
                    info["members"].append(("enum", nm, val))
                elif mleaf == LF_METHOD:
                    cnt = struct.unpack_from("<H", payload, p)[0]; p += 2
                    nm, p = read_zstr(payload, p)
                    info["members"].append(("method", nm, cnt))
                elif mleaf == LF_ONEMETHOD:
                    attrs = struct.unpack_from("<H", payload, p)[0]; p += 2
                    tidx = struct.unpack_from("<I", payload, p)[0]; p += 4
                    nm, p = read_zstr(payload, p)
                    info["members"].append(("onemethod", nm, tidx))
                elif mleaf == LF_NESTTYPE:
                    attrs = struct.unpack_from("<H", payload, p)[0]; p += 2
                    tidx = struct.unpack_from("<I", payload, p)[0]; p += 4
                    nm, p = read_zstr(payload, p)
                    info["members"].append(("nesttype", nm, tidx))
                elif mleaf == LF_BCLASS:
                    attrs = struct.unpack_from("<H", payload, p)[0]; p += 2
                    tidx = struct.unpack_from("<I", payload, p)[0]; p += 4
                    # offset: numeric
                    v16 = struct.unpack_from("<H", payload, p)[0]
                    p += 2
                    if v16 >= 0x8000:
                        if v16 == 0x8003: p += 4
                        elif v16 in (0x8001, 0x8002): p += 2
                    info["members"].append(("base", f"base_{tidx}", tidx))
                elif mleaf == LF_VFUNCTAB:
                    p += 2  # attrs? pad
                    tidx = struct.unpack_from("<I", payload, p)[0]; p += 4
                    info["members"].append(("vftable", "vfptr", tidx))
                elif mleaf == LF_INDEX:
                    p += 2 + 4  # pad2 + type index
                else:
                    break  # unknown member leaf -> bail
            except (ValueError, struct.error):
                break
            # pad to even for next member? CodeView subrecords are unpadded except leaf alignment rules:
            # each subrecord starts at even offset? Actually subrecords in field lists are unpadded
            # but leaf values >= 0x8002 are padded to even. We'll accept slight misalignment; bail on garbage.
    elif leaf in (LF_STRUCTURE, LF_CLASS, LF_UNION, LF_ENUM):
        try:
            cnt = struct.unpack_from("<H", payload, 0)[0]
            p = 2
            prop = struct.unpack_from("<H", payload, p)[0]; p += 2
            fieldlist_idx = struct.unpack_from("<I", payload, p)[0]; p += 4
            if leaf in (LF_STRUCTURE, LF_CLASS, LF_UNION):
                derived, vshape = struct.unpack_from("<II", payload, p); p += 8
            else:
                utype = struct.unpack_from("<I", payload, p)[0]; p += 4
            if prop & 0x80:  # forward ref, no name? no: has name but no members
                pass
            nm, p = read_zstr(payload, p)
            info["name"] = nm
            if p < len(payload) and payload[p] != 0:
                try:
                    uq, p = read_zstr(payload, p)
                    info["unique"] = uq
                except ValueError:
                    pass
            elif p < len(payload):
                p += 1
                if p < len(payload):
                    try:
                        uq, p = read_zstr(payload, p)
                        info["unique"] = uq
                    except ValueError:
                        pass
            if fieldlist_idx and fieldlist_idx != 0:
                info["fieldlist"] = fieldlist_idx
        except (ValueError, struct.error):
            pass
    records[idx] = info
    count += 1
    i = pad4(rec_start + 2 + reclen)
    idx += 1

print(f"parsed {count} TPI records", file=sys.stderr)

# Build name lookup
def tname(tidx, depth=0):
    r = records.get(tidx)
    if not r or depth > 3:
        return f"<t{tidx}>"
    if r["name"]:
        return r["name"]
    return f"<t{tidx}:{r['leaf']:#x}>"

# Target: print any struct/enum whose name is in our interest list
targets = ["Data", "Strings", "Forms", "Levels", "Traits", "Result", "Filters", "Range",
           "DistributionSet", "Distributables", "LinkedForms", "RawLinkedForm", "DeathData",
           "INI::Data", "Settings", "Outfit", "PCLevelMult"]
for tidx, r in records.items():
    nm = r.get("name")
    if not nm:
        continue
    if nm.split("::")[-1] in targets or nm in targets:
        fl = r.get("fieldlist")
        members = []
        if fl and fl in records:
            members = records[fl]["members"]
        if members:
            print(f"\n=== [{tidx}] {nm} ({'enum' if r['leaf']==LF_ENUM else 'struct'}) ===")
            for kind, mn, val in members:
                if kind in ("member", "static", "nesttype"):
                    print(f"    {kind:8s} {mn:28s} : {tname(val)}")
                elif kind == "enum":
                    print(f"    enum     {mn} = {val}")
                elif kind == "onemethod":
                    print(f"    method   {mn}")
                elif kind == "method":
                    print(f"    method*  {mn} x{val}")
                elif kind == "base":
                    print(f"    base     {mn}")
