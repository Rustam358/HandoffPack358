#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 120, шаг: сборка пакета v1.5.20 (вердикт 112-а — «Разделять»).

База = наш выпуск v1.5.19 (download/Paths of Empyrean RU 1.5.zip, md5
d87317dc79bf1025bf6a38f2625520fd). Замены ровно 2 записей: main ESP
(112-а: 2 поля SPEL FULL) и info.xml 1.5.19→1.5.20. Выход:
download/Paths of Empyrean RU 1.5.zip + копия в корне репо (истина для
пака передачи, сборщик build_handoff_pack_v5.py).
"""
import zipfile, os, hashlib, io

SRC_ZIP = '/home/z/my-project/download/Paths of Empyrean RU 1.5.zip'
V119_ZIP_MD5 = 'd87317dc79bf1025bf6a38f2625520fd'
DST = '/home/z/my-project/download/Paths of Empyrean RU 1.5.zip'
ROOT_COPY = '/home/z/my-project/Paths of Empyrean RU 1.5.zip'
V120 = '/home/z/my-project/work/qa120/v120'

MAIN = '00 Core/PathsOfEmpyrean.esp'


def main():
    # [T53] SRC_ZIP == DST: сначала читаем источник ПОЛНОСТЬЮ в память,
    # только потом открываем цель на запись (иначе zipfile усекает файл
    # ещё до чтения — «Truncated file header»).
    src_bytes = open(SRC_ZIP, 'rb').read()
    assert hashlib.md5(src_bytes).hexdigest() == V119_ZIP_MD5
    repl = {MAIN: open(f'{V120}/{MAIN}', 'rb').read()}

    zsrc = zipfile.ZipFile(io.BytesIO(src_bytes))
    names = zsrc.namelist()
    orig_crc = {i.filename: i.CRC for i in zsrc.infolist()}
    payload = {n: zsrc.read(n) for n in names}
    print('источник: выпуск v1.5.19 (%d записей, прочитан в память)' % len(names))

    info_src = payload['fomod/info.xml'].decode('utf-8')
    assert '<Version>1.5.19</Version>' in info_src
    info_new = info_src.replace('<Version>1.5.19</Version>',
                                '<Version>1.5.20</Version>')
    assert '<Version>1.5.20</Version>' in info_new and '1.5.19' not in info_new
    repl['fomod/info.xml'] = info_new.encode('utf-8')
    print('info.xml: Version 1.5.19 -> 1.5.20')

    zout = zipfile.ZipFile(DST, 'w')
    for item in zsrc.infolist():
        arc = item.filename
        zout.writestr(item, repl[arc] if arc in repl else payload[arc])
    zout.close()
    print('zip собран')

    print()
    print('=== ВЕРИФИКАЦИЯ ПАКЕТА v1.5.20 ===')
    z2 = zipfile.ZipFile(DST)
    names2 = z2.namelist()
    assert z2.testzip() is None
    assert len(names2) == 63 and set(names2) == set(names)
    print('testzip: OK, записей: %d (набор совпадает)' % len(names2))

    diff = [n for n in names if orig_crc[n] != z2.getinfo(n).CRC]
    assert set(diff) == set(repl), 'CRC-дифф: %s' % diff
    print('CRC vs v1.5.19: изменены ровно 2 записи (main ESP, info.xml), '
          'остальные %d байт-в-байт' % (len(names) - 2))

    got = hashlib.md5(z2.read(MAIN)).hexdigest()
    want = hashlib.md5(open(f'{V120}/{MAIN}', 'rb').read()).hexdigest()
    assert got == want, MAIN
    print('md5 main ESP == work/qa120/v120')

    ver = z2.read('fomod/info.xml').decode('utf-8')
    assert '<Version>1.5.20</Version>' in ver
    print('версия пакета: 1.5.20')

    # копия истины в корень репо (для build_handoff_pack_v5.py, [S8])
    data = open(DST, 'rb').read()
    open(ROOT_COPY, 'wb').write(data)
    assert hashlib.md5(open(ROOT_COPY, 'rb').read()).hexdigest() == \
        hashlib.md5(data).hexdigest()
    print('копия истины в корне репо обновлена (v1.5.20)')

    print()
    print('ПАКЕТ:', DST, '(%d Б)' % os.path.getsize(DST))
    print('md5 пакета: %s' % hashlib.md5(open(DST, 'rb').read()).hexdigest())


if __name__ == '__main__':
    main()
