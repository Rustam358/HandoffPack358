#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 112 (v1.5.13): возврат «чешуйчатого» тира — директива игрока
«Верни "чешуйчатый" тир везде» (07.11.2026). Откат 5 фиксов 111 (ламелляр)
+ выравнивание 4 Masterwork Scaled, «ламеллярных» с v1.5.7. Итого 9 полей.

Источник: work/ru15_4 (распакованный user zip «Paths of Empyrean RU 1.5 (4).zip»
= байт-в-байт наш v1.5.12, 63/63 CRC). Приемник: work/qa112/v113.
Машина ESP байт-в-байт как в master111 (сжатые записи 0x40000/zlib, XXXX).
"""
import struct, zlib, os, json

SRC = '/home/z/my-project/work/ru15_4'
DST = '/home/z/my-project/work/qa112/v113'
FIX = '/home/z/my-project/work/qa112/fixlist_v113.jsonl'

REC_HDR = 24


class Node:
    __slots__ = ('kind', 'label', 'tail', 'formid', 'data', 'children')


def parse(buf):
    root = []

    def walk(off, end, out):
        while off < end:
            t = buf[off:off+4]
            size = struct.unpack_from('<I', buf, off+4)[0]
            if t == b'GRUP':
                node = Node()
                node.kind = 'grup'
                node.tail = bytes(buf[off+8:off+24])
                node.children = []
                walk(off + REC_HDR, off + size, node.children)
                out.append(node)
                off += size
            else:
                node = Node()
                node.kind = 'rec'
                node.label = t
                node.tail = bytes(buf[off+8:off+24])
                node.formid = struct.unpack_from('<I', buf, off+12)[0]
                node.data = bytes(buf[off+REC_HDR:off+REC_HDR+size])
                out.append(node)
                off += REC_HDR + size
    walk(0, len(buf), root)
    return root


def serialize_node(n, parts):
    if n.kind == 'grup':
        sub = []
        for c in n.children:
            serialize_node(c, sub)
        s = b''.join(sub)
        parts.append(b'GRUP' + struct.pack('<I', 24 + len(s)) + n.tail)
        parts.append(s)
    else:
        parts.append(n.label + struct.pack('<I', len(n.data)) + n.tail)
        parts.append(n.data)


def find_rec(nodes, formid):
    for n in nodes:
        if n.kind == 'grup':
            r = find_rec(n.children, formid)
            if r is not None:
                return r
        elif n.formid == formid:
            return n
    return None


def rec_flags(rec):
    return struct.unpack_from('<I', rec.tail, 0)[0]


def decode_body(rec):
    if rec_flags(rec) & 0x00040000:
        usz = struct.unpack_from('<I', rec.data, 0)[0]
        dec = zlib.decompress(rec.data[4:])
        assert len(dec) == usz
        return bytearray(dec), True
    return bytearray(rec.data), False


def encode_body(body, was_c):
    if was_c:
        return struct.pack('<I', len(body)) + zlib.compress(bytes(body))
    return bytes(body)


def apply_esp(src, dst, patches):
    """patches: [(formid_int, field, occ, old, new)]"""
    buf = open(src, 'rb').read()
    root = parse(buf)
    out = []
    for n in root:
        serialize_node(n, out)
    if b''.join(out) != buf:
        raise SystemExit(f'САМОТЕСТ ПРОВАЛЕН: {src}')
    print(f'  самотест OK: {os.path.basename(src)} ({len(buf)} B)')
    applied = 0
    for formid, field, occ, old, new in patches:
        rec = find_rec(root, formid)
        if rec is None:
            raise SystemExit(f'{src}: запись {formid:08X} не найдена')
        body, was_c = decode_body(rec)
        off, seen, done = 0, 0, False
        while off < len(body):
            if off + 6 > len(body):
                break
            st = body[off:off+4].decode('ascii', 'replace')
            ssz = struct.unpack_from('<H', body, off+4)[0]
            if st == 'XXXX':
                real = struct.unpack_from('<I', body, off+6)[0]
                off += 6 + ssz + 6 + real
                continue
            cur_sz = ssz
            if st == field:
                seen += 1
                cur = bytes(body[off+6:off+6+ssz]).rstrip(b'\x00').decode('utf-8', 'replace')
                if seen == occ:
                    assert cur == old, f'{formid:08X} {field}#{occ}: old не совпал: {cur[:80]!r} != {old[:80]!r}'
                    newb = new.encode('utf-8') + b'\x00'
                    body[off+6:off+6+ssz] = newb
                    struct.pack_into('<H', body, off+4, len(newb))
                    done = True
                    applied += 1
                    cur_sz = len(newb)
            off += 6 + cur_sz
        if not done:
            raise SystemExit(f'{src}: патч {formid:08X} {field}#{occ} не применён')
        rec.data = encode_body(body, was_c)
    out = []
    for n in root:
        serialize_node(n, out)
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    open(dst, 'wb').write(b''.join(out))
    print(f'  -> {dst} ({os.path.getsize(dst)} B), патчей: {applied}')
    return applied


def main():
    esp_patches = []
    for line in open(FIX, encoding='utf-8'):
        r = json.loads(line)
        assert r['kind'] == 'esp' and r['scope'] == 'main', r
        esp_patches.append((int(r['formid'], 16), r['field'], r['occ'], r['old'], r['new']))
    assert len(esp_patches) == 9, len(esp_patches)
    tot = apply_esp(f'{SRC}/00 Core/PathsOfEmpyrean.esp',
                    f'{DST}/00 Core/PathsOfEmpyrean.esp', esp_patches)
    print(f'ИТОГО применено: {tot} (ожидается 9)')
    assert tot == 9


if __name__ == '__main__':
    main()
