#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 118: разведка #5 — свитки/стрелы, магические лестницы SPEL/MGEF, кузнечные перки."""
import json
from collections import defaultdict, Counter

A = json.load(open('/home/z/my-project/work/qa118/aligned.json', encoding='utf-8'))

print('=== 1. Mixture-свитки (14) ===')
for r in A:
    if r['rtype'] == 'SCRL' and r['field'] == 'FULL' and r['en_text'] and 'Mixture' in r['en_text']:
        print(f"  [{r['file']} {r['formid']}] {r['edid'][:36]:36} EN: {r['en_text'][:48]:48} RU: {r['ru_text'][:48]}")

print('\n=== 2. Стрелы PoE: Lucky/Barbed/Broadhead/Ancient/Dwemer/Ballista ===')
for r in A:
    if r['rtype'] == 'AMMO' and r['field'] == 'FULL' and r['en_text']:
        w = r['en_text'].split()
        if w and w[0] in ('Lucky', 'Barbed', 'Broadhead', 'Ancient', 'Dwemer', 'Ballista'):
            print(f"  [{r['file']} {r['formid']}] {r['edid'][:36]:36} EN: {r['en_text'][:40]:40} RU: {r['ru_text'][:44]}")

print('\n=== 3. SPEL/MGEF/ENCH FULL: тиражные слова EN ===')
TIER_WORDS = ['Novice', 'Apprentice', 'Adept', 'Expert', 'Master', 'Potent', 'High', 'Greater',
              'Lesser', 'Minor', 'Major', 'Grand', 'Peerless', 'Eminent', 'Extreme', 'Exquisite',
              'Strong', 'Weak', 'Slight', 'Plentiful', 'Vigorous', 'Ultimate', 'Concentrated',
              'Virulent', 'Simple', 'Superior', 'Fine', 'Flawless', 'Epic', 'Legendary', 'Ascendant']
cnt = defaultdict(Counter)
rows_tw = defaultdict(list)
for r in A:
    if r['rtype'] in ('SPEL', 'MGEF', 'ENCH', 'SCRL') and r['field'] == 'FULL' and r['en_text']:
        for tw in TIER_WORDS:
            if re_tw := (' ' + tw + ' ') in (' ' + r['en_text'] + ' '):
                cnt[(r['rtype'], tw)][r['ru_text'][:40]] += 1
                rows_tw[(r['rtype'], tw)].append(r)
for (rt, tw), c in sorted(cnt.items()):
    print(f'  {rt} «{tw}»: ' + ' | '.join(f'«{k}»×{v}' for k, v in c.most_common(6)))

print('\n=== 4. Кузнечные перки: PERK FULL по EDID-фильтру smith ===')
for r in A:
    if r['rtype'] == 'PERK' and r['field'] == 'FULL':
        ed = r['edid'].lower()
        if 'smith' in ed or 'craft' in ed or 'masterwork' in ed or 'materialmastery' in ed:
            print(f"  [{r['file']} {r['formid']}] {r['edid'][:44]:44} EN: {str(r['en_text'])[:40]:40} RU: {r['ru_text'][:44]}")
