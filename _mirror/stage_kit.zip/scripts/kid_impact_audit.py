#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 98 (итог v3): аудит влияния перевода на KID name-правила.

Грамматика фильтра KID (реконструкция по ini+datamodel):
  Keyword = <целевой KW EDID> | <тип формы> | <фильтры> [| <спец: слот/вес/анимация>]
  фильтры: альтернативы через ','  (OR)
  альтернатива: термы через '+'     (AND)
  терм: 'EDID' (имеет ключевик X) | '-EDID'/'-*tok' (NOT) | '*tok' (wildcard:
        подстрока в ИМЕНИ или EDID)

Симуляция EN-прогона: имена из v14_en.json (EN-дамп 1.4), KWDA — из текущего
переведённого ядра. Потеря = все термы группы истинны по EN-имени, целевой
ключ не запечён в KWDA. Имя-зависимость = wildcard-терм матчится именем, а не
EDID (EDID перевод не меняет).
"""
import json
import struct
import sys
from collections import Counter

sys.path.insert(0, "/home/z/my-project/scripts")
from parse_tes4 import Plugin

KID_INI = ("/home/z/my-project/handoff/08_оригинал_1.4_EN/"
           "полный_разбор_1.4/PoE 1.4/PathsOfEmpyrean_KID.ini")
CORE = "/home/z/my-project/work/v156/00 Core/PathsOfEmpyrean.esp"
SPEARS = "/home/z/my-project/work/v156/20 Spears/PoE-Addon-Spears.esp"
SHIELDS = "/home/z/my-project/work/v156/10 Missing Shields/PoE-Addon-MissingShields.esp"
EN_DUMP = "/home/z/my-project/handoff/05_стринги_ESP/v14_en.json"

core = Plugin(CORE)
spears = Plugin(SPEARS)
shields = Plugin(SHIELDS)

# ---- 1. разбор правил: [(kw, ftype, [альтернатива-[терм-...]...])] ----
# терм = (kind, value): kind in {'kw', 'notkw', 'name'}; name = wildcard
def parse_terms(filt):
    alts = []
    for alt in filt.split(","):
        terms = []
        for part in alt.split("+"):
            part = part.strip()
            if not part:
                continue
            if part.startswith("-"):
                body = part[1:].strip()
                if body.startswith("*"):
                    terms.append(("notname", body.lstrip("*").strip().lower()))
                else:
                    terms.append(("notkw", body))
            elif part.startswith("*"):
                terms.append(("name", part.lstrip("*").strip().lower()))
            else:
                terms.append(("kw", part))
        if terms:
            alts.append(terms)
    return alts

rules = []
for line in open(KID_INI, encoding="utf-8", errors="ignore"):
    line = line.strip()
    if not line.startswith("Keyword"):
        continue
    parts = line.split("|")
    if len(parts) < 3:
        continue
    kw = parts[0].split("=", 1)[1].strip()
    ftype = parts[1].strip()
    alts = parse_terms(parts[2])
    has_name = any(t[0] == "name" for alt in alts for t in alt)
    if has_name:
        rules.append((kw, ftype, alts))
print(f"правил с wildcard-термами: {len(rules)}")

# ---- 2. карты ключевиков ----
kw_fid = {}
for p in (core, spears, shields):
    for fid, r in p.records.items():
        if r["type"] == "KYWD" and r["edid"]:
            kw_fid.setdefault(r["edid"], fid)
# известные ванильные ключевики (Skyrim.esm#06D931 и т.п.)
VANILLA = {
    "WeapTypeGreatsword": 0x0006D931, "WeapTypeBattleaxe": 0x0006D932,
    "WeapTypeWarhammer": 0x0006D933, "WeapTypeSword": 0x0001E711,
    "WeapTypeBow": 0x0001E712, "WeapTypeDagger": 0x0001E713,
    "WeapTypeCrossbow": 0x01CD10DC, "ArmorShield": 0x000965B2,
    "ArmorJewelry": 0x0008F95B, "VendorItemWeapon": 0x0008F958,
    "ArmorCuirass": 0x0006BBB8, "ArmorGauntlets": 0x0006BBC0,
    "ArmorHelmet": 0x0006BBC1, "ArmorBoots": 0x0006BBBF,
}
def kw_formid(edid):
    if edid in kw_fid:
        return kw_fid[edid]
    if edid in VANILLA:
        return VANILLA[edid]
    return None

def kwda_set(p, fid):
    r = p.records.get(fid)
    if not r:
        return set()
    out = set()
    for st, sd in r["subs"]:
        if st == "KWDA":
            for i in range(len(sd) // 4):
                out.add(struct.unpack_from("<I", sd, i * 4)[0])
    return out

def kw_in_baked(kw_edid, baked):
    """ключевик в KWDA записи (с учётом namespace-дублей 0x01/0x06)"""
    f = kw_formid(kw_edid)
    if f is None:
        return None  # не резолвится — не знаем
    for cand in (f, 0x01000000 | (f & 0xFFFFFF), 0x06000000 | (f & 0xFFFFFF)):
        if cand in baked:
            return True
    return False

# ---- 3. симуляция ----
d = json.load(open(EN_DUMP, encoding="utf-8"))
losses = {}
unresolved = set()
n_matched = 0
for r in d["records"]:
    t = r.get("t")
    if t not in ("WEAP", "ARMO"):
        continue
    fid_s = r.get("fid", "")
    if len(fid_s) != 8:
        continue
    fid = int(fid_s, 16)
    s = r.get("s", {})
    if "FULL" not in s:
        continue
    full = s["FULL"][0] if isinstance(s["FULL"], list) else s["FULL"]
    if not full:
        continue
    fl = full.lower()
    edid = r.get("e") or ""
    el = edid.lower()
    cur = core.records.get(fid)
    if not cur:
        continue
    baked = kwda_set(core, fid)
    idx = fid >> 24
    kind = ("self" if idx >= 6 else
            f"ovr:{core.masters[idx] if idx < len(core.masters) else idx}")
    for kw, ftype, alts in rules:
        if ftype == "Weapon" and t != "WEAP":
            continue
        if ftype == "Armor" and t != "ARMO":
            continue
        tgt = kw_fid.get(kw)
        if tgt is not None and (tgt in baked or
                                (0x01000000 | (tgt & 0xFFFFFF)) in baked):
            continue  # уже запечён — переводу всё равно
        for alt in alts:
            name_dep = False
            ok = True
            for kind_t, val in alt:
                if kind_t == "name":
                    if val in el:
                        continue           # матч по EDID — перевод-стойко
                    if val not in fl:
                        ok = False
                        break
                    name_dep = True
                elif kind_t == "notname":
                    if val in fl or val in el:
                        ok = False
                        break
                elif kind_t == "kw":
                    hit = kw_in_baked(val, baked)
                    if hit is None:
                        unresolved.add(val)
                    elif not hit:
                        ok = False
                        break
                elif kind_t == "notkw":
                    hit = kw_in_baked(val, baked)
                    if hit:
                        ok = False
                        break
            if ok and name_dep:
                n_matched += 1
                losses.setdefault((fid, edid, full, kind), []).append(
                    (kw, next(v for k, v in alt if k == "name")))
                break

print(f"имя-зависимых потерь (записей): {len(losses)}")
print(f"неразрешённых ваниль-ключевиков (приняты как True): {sorted(unresolved)[:8]}\n")

for (fid, edid, full, kind), lst in sorted(losses.items()):
    print(f"  [{kind}] {fid:08X} [{edid}] «{full}»")
    for kw, tok in lst:
        print(f"        - {kw}  (*{tok})")

c = Counter(k for lst in losses.values() for k, _ in lst)
print("\n=== сводка: целевой ключ → записей теряет ===")
for k, n in c.most_common():
    print(f"  {n:3d}  {k}")

kinds = Counter(k for (_, _, _, k) in losses)
print("\n=== по происхождению ===")
for k, n in kinds.most_common():
    print(f"  {n:3d}  {k}")
