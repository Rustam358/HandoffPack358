#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 116 (v1.5.17): вердикт 115-а — регистр мужских форм гендерных пар
маскировочных сообщений поднят до регистра женских (заглавные).

4 строковых патча MESG/DESC в main ESP (fixlist_v117.jsonl):
  06060E78 «под бандита.» → «под Бандита.»
  06060E9A «под имперца.» → «под Имперца.»
  06060EA6 «под культиста.» → «под Культиста.»
  06024573 «под вампира.» → «под Вампира.»
06060E93 «под Брата Бури.» уже с заглавной — не тронут. CC-патчи, MGEF FULL,
DNAM, женские MESG_F, VMAD/CTDA/SPEL клоны 115 — не трогаются.

Механика — master115/master114 (parse → assert(old) → patch → serialize).
База: upload «Paths of Empyrean RU 1.5 (9).zip» = байт-в-байт v1.5.16
(md5 687c057356f4ebd5b519dee0712c0ddd, сверено diff_zip_116).
Приёмник: work/qa116/v117 (свежая распаковка базы).
"""
import struct, zlib, os, json, zipfile, hashlib, shutil

SRC_ZIP = '/home/z/my-project/upload/Paths of Empyrean RU 1.5 (9).zip'
SRC_MD5 = '687c057356f4ebd5b519dee0712c0ddd'
DST = '/home/z/my-project/work/qa116/v117'
FIX = '/home/z/my-project/work/qa116/fixlist_v117.jsonl'
MAIN = '00 Core/PathsOfEmpyrean.esp'

REC_HDR = 24


class Node:
    __slots__ = ('kind', 'label', 'tail', 'formid', 'data', 'children')


def parse(buf):
    root = []

    def walk(off, end, out):
        while off < end:
            t = buf[off:off+4]
            size = struct.unpack_from('<I', buf, off+4)[0]
            if t == b'GRUP':
                node = Node()
                node.kind = 'grup'
                node.label = None
                node.tail = bytes(buf[off+8:off+24])
                node.children = []
                walk(off + REC_HDR, off + size, node.children)
                out.append(node)
                off += size
            else:
                node = Node()
                node.kind = 'rec'
                node.label = t
                node.tail = bytes(buf[off+8:off+24])
                node.formid = struct.unpack_from('<I', buf, off+12)[0]
                node.data = bytes(buf[off+REC_HDR:off+REC_HDR+size])
                out.append(node)
                off += REC_HDR + size
    walk(0, len(buf), root)
    return root


def serialize_node(n, parts):
    if n.kind == 'grup':
        sub = []
        for c in n.children:
            serialize_node(c, sub)
        s = b''.join(sub)
        parts.append(b'GRUP' + struct.pack('<I', 24 + len(s)) + n.tail)
        parts.append(s)
    else:
        parts.append(n.label + struct.pack('<I', len(n.data)) + n.tail)
        parts.append(n.data)


def find_rec(nodes, formid):
    for n in nodes:
        if n.kind == 'grup':
            r = find_rec(n.children, formid)
            if r is not None:
                return r
        elif n.formid == formid:
            return n
    return None


def rec_flags(rec):
    return struct.unpack_from('<I', rec.tail, 0)[0]


def decode_body(rec):
    if rec_flags(rec) & 0x00040000:
        usz = struct.unpack_from('<I', rec.data, 0)[0]
        dec = zlib.decompress(rec.data[4:])
        assert len(dec) == usz
        return bytearray(dec), True
    return bytearray(rec.data), False


def encode_body(body, was_c):
    if was_c:
        return struct.pack('<I', len(body)) + zlib.compress(bytes(body))
    return bytes(body)


def patch_strings(path, patches):
    buf = open(path, 'rb').read()
    root = parse(buf)
    out = []
    for n in root:
        serialize_node(n, out)
    assert b''.join(out) == buf, f'самотест сериализации: {path}'
    applied = 0
    for formid, field, occ, old, new in patches:
        rec = find_rec(root, formid)
        assert rec is not None, f'{formid:08X} не найдена'
        body, was_c = decode_body(rec)
        off, seen, done = 0, 0, False
        while off < len(body):
            if off + 6 > len(body):
                break
            st = body[off:off+4].decode('ascii', 'replace')
            ssz = struct.unpack_from('<H', body, off+4)[0]
            if st == 'XXXX':
                real = struct.unpack_from('<I', body, off+6)[0]
                off += 6 + ssz + 6 + real
                continue
            cur_sz = ssz
            if st == field:
                seen += 1
                cur = bytes(body[off+6:off+6+ssz]).rstrip(b'\x00').decode(
                    'utf-8', 'replace')
                if seen == occ:
                    assert cur == old, (
                        f'{formid:08X} {field}#{occ}: {cur[:80]!r} != {old[:80]!r}')
                    newb = new.encode('utf-8') + b'\x00'
                    body[off+6:off+6+ssz] = newb
                    struct.pack_into('<H', body, off+4, len(newb))
                    done = True
                    applied += 1
                    cur_sz = len(newb)
            off += 6 + cur_sz
        assert done, f'{formid:08X} {field}#{occ} не применён'
        rec.data = encode_body(body, was_c)
    out = []
    for n in root:
        serialize_node(n, out)
    data = b''.join(out)
    open(path, 'wb').write(data)
    print(f'  строки {path}: патчей {applied}, файл {len(buf)} -> {len(data)} Б')
    return applied


def main():
    assert hashlib.md5(open(SRC_ZIP, 'rb').read()).hexdigest() == SRC_MD5, \
        'база не v1.5.16!'
    if os.path.isdir(DST):
        shutil.rmtree(DST)
    with zipfile.ZipFile(SRC_ZIP) as z:
        assert z.testzip() is None
        info = z.read('fomod/info.xml').decode('utf-8')
        assert '<Version>1.5.16</Version>' in info, 'база не v1.5.16!'
        z.extractall(DST)
    print('база: user zip (9) = v1.5.16 (63 файла), свежая распаковка в v117')

    patches = []
    for line in open(FIX, encoding='utf-8'):
        r = json.loads(line)
        assert r['scope'] == 'main', 'этап 116 трогает только main ESP'
        patches.append((int(r['formid'], 16), r['field'], r['occ'],
                        r['old'], r['new']))
    assert len(patches) == 4, f'ожидается 4 патча, в фикс-листе {len(patches)}'

    n2 = patch_strings(os.path.join(DST, MAIN), patches)
    assert n2 == 4

    full = os.path.join(DST, MAIN)
    md5 = hashlib.md5(open(full, 'rb').read()).hexdigest()
    print(f'md5 {MAIN}: {md5} ({os.path.getsize(full)} Б)')


if __name__ == '__main__':
    main()
