#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 99: пересборка пакета v1.5.7 — мини-фикс KID (PoE_RU_KID.ini).

Директива игрока (вердикт 98-а, вариант «а»): 37 имя-зависимых потерь
ключевиков KID восстанавливаются собственной KID-ини с EDID-фильтрами,
0 правок ESP.

Изменения против v1.5.6 (58 записей -> 59):
  + 00 Core/PoE_RU_KID.ini            (НОВАЯ запись, генератор
                                       scripts/kid_fix_build99.py)
  ~ fomod/ModuleConfig.xml            moduleName v1.5.6 -> v1.5.7
  ~ fomod/info.xml                    <Version> 1.5.6 -> 1.5.7
Все остальные записи копируются байт-в-байт (ZipInfo: даты/атрибуты/сжатие).
FOMOD правки не нужны: requiredInstallFiles = папка «00 Core», новый файл
ставится вместе с ней (0 file-источников — правило Vortex, [D9]).
SRC и DST совпадают -> сборка во временный файл + os.replace.
"""
import zipfile
import os
import sys

SRC = '/home/z/my-project/download/Paths of Empyrean RU 1.5.zip'
DST = SRC
TMP = '/home/z/my-project/work/qa99/package_v157.tmp.zip'
NEW_ARC = '00 Core/PoE_RU_KID.ini'
NEW_FILE = '/home/z/my-project/work/v156/00 Core/PoE_RU_KID.ini'


def patch_module_config(xml):
    assert xml.count('v1.5.6') == 1, f'moduleName v1.5.6: {xml.count("v1.5.6")}'
    xml2 = xml.replace('v1.5.6', 'v1.5.7')
    assert 'v1.5.7' in xml2 and 'v1.5.6' not in xml2
    print('  ModuleConfig.xml: moduleName -> v1.5.7')
    return xml2


def patch_info(xml):
    assert '<Version>1.5.6</Version>' in xml
    xml2 = xml.replace('<Version>1.5.6</Version>', '<Version>1.5.7</Version>')
    print('  info.xml: Version -> 1.5.7')
    return xml2


def main():
    zin = zipfile.ZipFile(SRC)
    names = zin.namelist()
    print('исходный архив v1.5.6:', len(names), 'записей')
    assert NEW_ARC not in names, 'PoE_RU_KID.ini уже в архиве?'

    orig_crc = {i.filename: i.CRC for i in zin.infolist()}

    mc2 = patch_module_config(zin.read('fomod/ModuleConfig.xml').decode('utf-8'))
    info2 = patch_info(zin.read('fomod/info.xml').decode('utf-8'))

    assert os.path.exists(NEW_FILE), NEW_FILE
    new_bytes = open(NEW_FILE, 'rb').read()
    assert new_bytes.decode('ascii')  # ASCII-безопасность
    assert new_bytes.count(b'\r\n') == new_bytes.count(b'\n')
    n_rules = sum(1 for l in new_bytes.decode('ascii').split('\r\n')
                  if l.strip().startswith('Keyword = '))
    assert n_rules == 14, f'правил в ини: {n_rules}'
    print(f'  {NEW_ARC}: +{len(new_bytes)} B, {n_rules} правил')

    os.makedirs(os.path.dirname(TMP), exist_ok=True)
    zout = zipfile.ZipFile(TMP, 'w')
    changed = []
    for item in zin.infolist():
        arc = item.filename
        if arc == 'fomod/ModuleConfig.xml':
            zout.writestr(item, mc2.encode('utf-8'))
            changed.append(arc)
        elif arc == 'fomod/info.xml':
            zout.writestr(item, info2.encode('utf-8'))
            changed.append(arc)
        else:
            zout.writestr(item, zin.read(arc))

    # новая запись: атрибуты/дата в стиле ESP-записи пакета
    esp_info = zin.getinfo('00 Core/PathsOfEmpyrean.esp')
    zi = zipfile.ZipInfo(NEW_ARC, date_time=esp_info.date_time)
    zi.compress_type = zipfile.ZIP_DEFLATED
    zi.external_attr = esp_info.external_attr
    zi.flag_bits = esp_info.flag_bits
    zout.writestr(zi, new_bytes)
    zout.close()
    changed.append(NEW_ARC)
    print('изменено/добавлено записей:', len(changed))
    for c in changed:
        print('  *', c)

    # ---------------- ВЕРИФИКАЦИЯ ----------------
    print()
    print('=== ВЕРИФИКАЦИЯ ПАКЕТА v1.5.7 ===')
    z2 = zipfile.ZipFile(TMP)
    names2 = z2.namelist()
    assert z2.testzip() is None, 'testzip провален!'
    print('testzip: OK,', len(names2), 'записей')

    assert set(names2) == set(names) | {NEW_ARC}, 'состав записей неверен'
    assert len(names2) == len(names) + 1 == 59, f'записей: {len(names2)}'

    # CRC: изменены ровно 3 записи (2 FOMOD + 1 новая), остальные идентичны
    diff = [n for n in names if orig_crc[n] != z2.getinfo(n).CRC]
    assert set(diff) == {'fomod/ModuleConfig.xml', 'fomod/info.xml'}, \
        f'CRC-дифф не совпал: {diff}'
    print(f'CRC: изменены ровно 2 FOMOD-записи, остальные {len(names) - 2} '
          f'байт-в-байт, +1 новая ({NEW_ARC})')

    # новая запись дословно == рабочей копии
    assert z2.read(NEW_ARC) == new_bytes
    print('PoE_RU_KID.ini в архиве дословно == рабочей копии')

    # FOMOD: все source существуют, 0 file-источников, readme-ссылок нет
    import re
    xml = z2.read('fomod/ModuleConfig.xml').decode('utf-8')
    assert 'Readme' not in xml
    srcs = set(re.findall(r'source="([^"]+)"', xml))
    missing = [s for s in srcs
               if not any(n == s or n.startswith(s + '/') for n in names2)]
    assert not missing, f'висячие source в FOMOD: {missing}'
    assert len(re.findall(r'<file\s', xml)) == 0, 'появились file-источники!'
    print(f'FOMOD: {len(srcs)} source-ссылок (папки), все существуют; '
          f'file-источников 0; ссылок на readme нет')
    assert 'v1.5.7' in xml and 'v1.5.6' not in xml
    ver = z2.read('fomod/info.xml').decode('utf-8')
    assert '<Version>1.5.7</Version>' in ver
    print('версии: moduleName v1.5.7, info.xml 1.5.7')

    # KID-ини внутри архива: суффикс, грамматика первых полей
    arc_ini = z2.read(NEW_ARC).decode('ascii')
    for line in arc_ini.split('\r\n'):
        s = line.strip()
        if s.startswith('Keyword = '):
            parts = s.split('|')
            assert 3 <= len(parts) <= 4 and parts[1].strip() in (
                'Weapon', 'Armor', 'Ammo'), s
    print('грамматика 14 правил в архиве: OK')

    zin.close()
    z2.close()
    os.replace(TMP, DST)
    print()
    print('ПАКЕТ:', DST, f'({os.path.getsize(DST)} B)')
    print('ГОТОВ К ПЕРЕЗАЛИВКЕ НА NEXUS (замена файла, страница 197444)')


if __name__ == '__main__':
    main()
