#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Сборка handoff-пакета v5.x (v5.20 — Этап 122 / исполнительский без
выпуска: пересборка по запросу игрока «Подготовь новый handoff pack. НЕ
включай туда вопрос про locational damage, это была моя ошибка»: zip
корня пака поднят до v1.5.20 (63 файла), REPORTS 99–120 + 122 (report_121
исключён — тема Этапа 121 отозвана игроком; вопрос 121-а закрыт без
правки), +work/qa119/qa120, +скрипты 119/120; guard-инвариант: появление
report_121.md в базе знаний или check121_ald.py в списках = отказ сборки.
История: v5.19 заявлен в report_119 §7, но НЕ собирался (пробел закрыт
report_120 §7); v5.18 — Этап 118 («Великая» проверка тиров); v5.10 —
Этап 108 (FOMOD установщика; опыт поглощен в handoff/18_FOMOD_установщик/);
v5.9 — Этап 106 (аудит «ванильный стандарт»); v5.8 — Этап 102 (ось
«сильнее vs эффективнее»); v5.7 — Этап 101 (слой 06_ из дампа истины);
v5.6 — Этап 99 (v1.5.7, мини-фикс PoE_RU_KID.ini).

Состав (самодостаточный — новый чат стартует с чистой песочницы, [S5]):
- корень: документы передачи 00–06 + CHANGELOG.md (handoff/15_передача/),
  выпущенный пакет v1.5.20 (= истина, 63 файла), report_99…120 + 122.md,
  материалы Этапов 94–120 (work/qa94…qa120);
- scripts/ — активный конвейер: ядро + патчеры/сборки этапов + слои +
  аналитика + реверс SPID/KID + этапы 99–120 (разовые qa-пробы и
  patch-скрипты правки доков в пак не идут);
- handoff/ — база знаний целиком (без 07_/11_/13_, без дублей 05_/09_;
  опыты: 16_SPID_реверс, 17_KID_реверс, 18_FOMOD_установщик); из базы
  исключён report_121.md (отозванная тема, Этап 122).

Version-guard: версии в 00_ПРОЧТИ ↔ state.md ↔ CHANGELOG ↔ info.xml
выпущенного пакета обязаны совпадать — иначе сборка ОТКАЖЕТ (защита
быстрого старта от протухания, [S8]). При подъёме версии править все
четыре места. Второй guard: вложенный handoff/handoff (протухший
снапшот базы знаний) = сборка ОТКАЖЕТ; при обходе handoff/ вложенный
handoff/ дополнительно вырезается (prune).

Выход: download/PoE_Translation_Handoff_Pack_v<PACK_VERSION>.zip
"""
import os, re, zipfile

ROOT = '/home/z/my-project'
PACK_VERSION = '5.20'
OUT = f'/home/z/my-project/download/PoE_Translation_Handoff_Pack_v{PACK_VERSION}.zip'
HANDOFF = f'{ROOT}/handoff'
DOCS = f'{HANDOFF}/15_передача'
RU_ZIP = f'{ROOT}/Paths of Empyrean RU 1.5.zip'
# Директива игрока (Этап 122): тема Этапа 121 (локационные сообщения)
# отозвана — report_121 в пак не входит; номер занят, REPORTS идёт с
# пропуском 121 и отдельной строкой 122 (пробел объяснён report_122/INDEX).
REPORTS = [(f'report_{n}.md', f'{ROOT}/report_{n}.md')
           for n in range(99, 121)] + [('report_122.md', f'{ROOT}/report_122.md')]

DOC_NAMES = ['00_ПРОЧТИ_ПЕРВЫМ.md', '01_состояние_и_история.md',
             '02_конвейер_и_сборка.md', '03_техбаза_ESP_PEX.md',
             '04_каноны_и_санкции.md', '05_карта_файлов.md',
             '06_симптомы_и_декодер.md', 'CHANGELOG.md']

ACTIVE_SCRIPTS = ['parse_tes4.py', 'dump150.py', 'espdiff88.py',
                  'qa94_scan.py', 'master91.py', 'master94.py',
                  'build_package94.py', 'verify94.py',
                  'build_handoff_pack_v5.py', 'verify_pack_v5.py',
                  'inventory95.py', 'inventory95b.py', 'inventory95c.py',
                  'perkdump96.py', 'perkdump96b.py', 'perkdump96c.py',
                  'perkdump96d.py', 'perkdump96e.py',
                  'extract_spid.py', 'spid_strings.py', 'pdb_symbols.py',
                  'pdb_msf.py', 'pdb_filter_enum.py', 'pdb_tpi_walk.py',
                  'pdb_datamodel.py',
                  'extract_kid.py', 'kid_strings.py', 'kid_symbols.py',
                  'kid_datamodel.py', 'kid_poe_analysis.py',
                  'kid_kwda_check.py', 'kid_clone_kwda.py',
                  'kid_spear_audit.py', 'kid_perk_conds.py',
                  'kid_name_dep_use.py', 'kid_impact_audit.py',
                  'kid_fix_build99.py', 'verify99.py',
                  'build_package99.py',
                  'dump157.py', 'case_scan100.py', 'case_scan100b.py',
                  'case_scan100c.py', 'drift101.py', 'gen101.py',
                  'poe_verdict102.py', 'verify102.py',
                  'dump103.py', 'master103.py', 'build_package103.py',
                  'verify103.py', 'gen103.py',
                  'master104.py', 'build_package104.py', 'verify104.py',
                  'gen104.py', 'audit105.py', 'audit106.py',
                  'ptbr107_dump.py', 'ptbr107_inventory.py',
                  'ptbr107_layers.py', 'ptbr107_layers2.py',
                  'ptbr107_espdiff.py',
                  'fomod_struct.py', 'build_package108.py',
                  'canon111_scan.py', 'canon111_layers.py', 'master111.py',
                  'build_package111.py', 'verify111.py', 'gen111.py',
                  'diff_zip_112.py', 'master112.py', 'build_package112.py',
                  'verify112.py', 'gen112.py',
                  'diff_zip_113.py', 'master113.py', 'build_package113.py',
                  'verify113.py', 'gen113.py',
                  'diff_zip_114.py', 'master114.py', 'build_package114.py',
                  'verify114.py', 'gen114.py',
                  'query115.py', 'scan115.py', 'probe115b.py', 'probe115c.py',
                  'probe115d.py', 'probe115e.py', 'probe115f.py',
                  'probe115g.py', 'probe115h.py',
                  'master115.py', 'build_package115.py',
                  'verify115.py', 'gen115.py',
                  'diff_zip_116.py', 'master116.py', 'build_package116.py',
                  'verify116.py', 'gen116.py',
                  'master117.py', 'build_package117.py',
                  'verify117.py', 'gen117.py',
                  'dump118_en.py', 'tier118_explore.py', 'tier118_explore2.py',
                  'tier118_explore3.py', 'tier118_explore4.py',
                  'tier118_explore5.py', 'audit118.py', 'audit118b.py',
                  'fixproj118.py',
                  'fixproj119.py', 'master119.py', 'build_package119.py',
                  'verify119.py', 'gen119.py',
                  'check120_armorclass.py', 'fixproj120.py', 'master120.py',
                  'build_package120.py', 'verify120.py', 'gen120.py']

WORK_FILES = ['work/qa94/fixlist.jsonl', 'work/qa94/dump_v155.jsonl',
              'work/qa95/inventory_records.txt',
              'work/qa95/inventory_subsystems.txt',
              'work/qa95/inventory_taxonomy.txt', 'work/qa95/avif_stars.txt',
              'work/qa96/perkdump.jsonl',
              'work/qa100/dump_v157.jsonl',
              'work/qa100/case_report.txt', 'work/qa100/case_report2.txt',
              'work/qa100/case_report3.txt',
              'work/qa101/drift_report.txt',
              'work/qa102/fixlist_v158.jsonl', 'work/qa102/README.md',
              'work/qa103/dump_v158.jsonl',
              'work/qa104/fixlist_v159.jsonl',
              'work/qa104/dump_v159_full.jsonl',
              'work/qa105/audit105_report.txt', 'work/qa105/findings.jsonl',
              'work/qa106/audit106_report.txt',
              'work/qa106/formula_violations.tsv', 'work/qa106/aliens.tsv',
              'work/qa106/lore.tsv', 'work/qa106/summon_family.tsv',
              'work/qa106/lint.tsv', 'work/qa106/fixlist_106.jsonl',
              'work/qa107/inventory_107.txt', 'work/qa107/espdiff_107.txt',
              'work/qa107/kid_name_dep_107.txt', 'work/qa107/layers_107.txt',
              'work/qa107/candidates_pt_ru.tsv', 'work/qa107/dump_en14.jsonl',
              'work/qa107/dump_pt.jsonl',
              'work/qa108/fomod_ru.txt', 'work/qa108/fomod_ptbr.txt',
              'work/qa108/fomod_new.txt', 'work/qa108/build_log.txt',
              'work/qa111/fixlist_v112.jsonl',
              'work/qa111/canon_scan_report.txt',
              'work/qa111/findings_111.jsonl',
              'work/qa111/layers_111.txt',
              'work/qa111/dump_v112_full.jsonl',
              'work/qa112/fixlist_v113.jsonl',
              'work/qa112/dump_v113_full.jsonl',
              'work/qa113/fixlist_v114.jsonl',
              'work/qa113/dump_v114_full.jsonl',
              'work/qa114/fixlist_v115.jsonl',
              'work/qa114/dump_v115_full.jsonl',
              'work/qa115/fixlist_v116.jsonl',
              'work/qa115/dump_v116_full.jsonl',
              'work/qa116/fixlist_v117.jsonl',
              'work/qa116/dump_v117_full.jsonl',
              'work/qa117/fixlist_v118.jsonl',
              'work/qa117/dump_v118_full.jsonl',
              'work/qa118/dump_en14.jsonl',
              'work/qa118/aligned.json',
              'work/qa118/audit_report.txt',
              'work/qa118/audit_b.txt',
              'work/qa118/fixlist_project_118.jsonl',
              'work/qa119/fixlist_v119.jsonl',
              'work/qa119/dump_v119_full.jsonl',
              'work/qa120/fixlist_v120.jsonl',
              'work/qa120/dump_v120_full.jsonl']


def read(p):
    with open(p, encoding='utf-8') as f:
        return f.read()


def version_guard():
    """Согласованность версий четырёх источников — иначе exit."""
    v_doc = re.search(r'ВЕРСИЯ ПЕРЕДАЧИ:\s*v(\d+\.\d+\.\d+)',
                      read(f'{DOCS}/00_ПРОЧТИ_ПЕРВЫМ.md'))
    v_state = re.search(r'СБОРКА\s+\*\*v(\d+\.\d+\.\d+)\*\*',
                        read(f'{HANDOFF}/03_агентская_память/state.md'))
    v_log = re.search(r'^##\s*v(\d+\.\d+\.\d+)',
                      read(f'{DOCS}/CHANGELOG.md'), re.M)
    with zipfile.ZipFile(RU_ZIP) as z:
        if z.testzip() is not None:
            raise SystemExit('GUARD: выпущенный пакет не проходит testzip')
        info = z.read('fomod/info.xml').decode('utf-8')
    v_zip = re.search(r'<Version>(\d+\.\d+\.\d+)</Version>', info)
    src = {'00_ПРОЧТИ_ПЕРВЫМ.md': v_doc, 'state.md': v_state,
           'CHANGELOG.md': v_log, 'info.xml пакета': v_zip}
    for name, m in src.items():
        if not m:
            raise SystemExit(f'GUARD: не найдена версия в {name}')
        print(f'  версия {name}: v{m.group(1)}')
    vals = {m.group(1) for m in src.values()}
    if len(vals) != 1:
        raise SystemExit(f'GUARD: РАССИНХРОН версий {vals} — править все '
                         'четыре места и пересобрать')
    return vals.pop()


def check_required():
    req = ([f'{DOCS}/{n}' for n in DOC_NAMES] + [RU_ZIP]
           + [arc for _, arc in REPORTS]
           + [f'{ROOT}/{p}' for p in WORK_FILES]
           + [f'{ROOT}/scripts/{s}' for s in ACTIVE_SCRIPTS])
    for p in req:
        if not os.path.isfile(p):
            raise SystemExit(f'НЕТ ФАЙЛА: {p}')
    for extra in ('handoff/02_хелпер_SoftClub/work/softclub/db.jsonl',
                  'handoff/04_эталоны_игрока/perks_v149.jsonl',
                  'handoff/04_эталоны_игрока/perks_v150.jsonl',
                  'handoff/06_код-истина_перевода/corpus57.json',
                  'handoff/06_код-истина_перевода/README.md',
                  'handoff/06_код-истина_перевода/_архив_мастер-эры/README.md',
                  'handoff/12_отчёты_этапов/INDEX.md',
                  'handoff/12_отчёты_этапов/report_94.md',
                  'handoff/12_отчёты_этапов/report_97.md',
                  'handoff/12_отчёты_этапов/report_98.md',
                  'handoff/12_отчёты_этапов/report_99.md',
                  'handoff/12_отчёты_этапов/report_100.md',
                  'handoff/12_отчёты_этапов/report_101.md',
                  'handoff/12_отчёты_этапов/report_102.md',
                  'handoff/12_отчёты_этапов/report_103.md',
                  'handoff/12_отчёты_этапов/report_104.md',
                  'handoff/12_отчёты_этапов/report_105.md',
                  'handoff/12_отчёты_этапов/report_106.md',
                  'handoff/12_отчёты_этапов/report_107.md',
                  'handoff/12_отчёты_этапов/report_108.md',
                  'handoff/12_отчёты_этапов/report_109.md',
                  'handoff/12_отчёты_этапов/report_110.md',
                  'handoff/12_отчёты_этапов/report_111.md',
                  'handoff/12_отчёты_этапов/report_112.md',
                  'handoff/12_отчёты_этапов/report_113.md',
                  'handoff/12_отчёты_этапов/report_114.md',
                  'handoff/12_отчёты_этапов/report_115.md',
                  'handoff/12_отчёты_этапов/report_116.md',
                  'handoff/12_отчёты_этапов/report_117.md',
                  'handoff/04_эталоны_игрока/perks_v152.jsonl',
                  'handoff/04_эталоны_игрока/perks_v153.jsonl',
                  'handoff/04_эталоны_игрока/perks_v154.jsonl',
                  'handoff/04_эталоны_игрока/perks_v155.jsonl',
                  'handoff/06_код-истина_перевода/PathsOfEmpyrean_RUSSIAN.txt',
                  'handoff/06_код-истина_перевода/ArcheryLocationalDamage_ru.ini',
                  'handoff/16_SPID_реверс/README.md',
                  'handoff/16_SPID_реверс/SPID_7.3.3_реверс-отчёт.md',
                  'handoff/16_SPID_реверс/datamodel.txt',
                  'handoff/17_KID_реверс/README.md',
                  'handoff/17_KID_реверс/KID_4.1.0_реверс-отчёт.md',
                  'handoff/17_KID_реверс/datamodel.txt',
                  'handoff/18_FOMOD_установщик/README.md',
                  'handoff/18_FOMOD_установщик/FOMOD_установщик_опыт.md'):
        if not os.path.isfile(f'{ROOT}/{extra}'):
            raise SystemExit(f'НЕТ ФАЙЛА: {extra}')


def main():
    print('Version-guard:')
    ver = version_guard()
    check_required()
    if os.path.exists(f'{HANDOFF}/handoff'):
        raise SystemExit('GUARD: вложенный handoff/handoff (протухший снапшот '
                         'базы знаний) — удалить перед сборкой')
    # Директива игрока (Этап 122): тема Этапа 121 (локационные сообщения)
    # отозвана («это была моя ошибка») — носители темы в пак НЕ включаются.
    if os.path.exists(f'{HANDOFF}/12_отчёты_этапов/report_121.md'):
        raise SystemExit('GUARD: handoff/12_отчёты_этапов/report_121.md — '
                         'тема отозвана игроком (Этап 122); файл не должен '
                         'возвращаться в базу знаний')
    if 'check121_ald.py' in ACTIVE_SCRIPTS or \
            any(a == 'report_121.md' for a, _ in REPORTS):
        raise SystemExit('GUARD: check121_ald.py/report_121.md в списках — '
                         'тема отозвана игроком (Этап 122), исключить')
    if os.path.exists(OUT):
        os.remove(OUT)
    count = 0
    with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        # 1) корень: документы передачи + CHANGELOG
        for n in DOC_NAMES:
            z.write(f'{DOCS}/{n}', n)
            count += 1
        # 2) корень: истина (без пересжатия) и отчёты этапов
        z.write(RU_ZIP, 'Paths of Empyrean RU 1.5.zip',
                compress_type=zipfile.ZIP_STORED)
        count += 1
        for arc_name, src in REPORTS:
            z.write(src, arc_name)
            count += 1
        # 3) материалы последнего этапа
        for rel in WORK_FILES:
            z.write(f'{ROOT}/{rel}', rel)
            count += 1
        # 4) активный конвейер
        for s in ACTIVE_SCRIPTS:
            z.write(f'{ROOT}/scripts/{s}', f'scripts/{s}')
            count += 1
        # 5) база знаний целиком
        for root, dirs, files in os.walk(HANDOFF):
            dirs[:] = sorted(d for d in dirs if d != 'handoff')  # prune вложенных
            for f in sorted(files):
                full = os.path.join(root, f)
                arc = os.path.relpath(full, HANDOFF)
                z.write(full, f'handoff/{arc}')
                count += 1
    print(f'OK: {OUT}')
    print(f'версия: v{ver} | файлов: {count} | '
          f'размер: {os.path.getsize(OUT):,} Б')


if __name__ == '__main__':
    main()
