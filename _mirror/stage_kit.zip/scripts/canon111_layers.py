#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 111: скан НЕ-ESP слоёв пака (ini/xml/psc/txt) по канон-терминам
и name-фильтрам KID/SPID/SkyPatcher, зависящим от правимых строк.
База = user zip (v1.5.11 + правка игрока $Forsworn)."""
import zipfile, re, os, sys

ZIP = '/home/z/my-project/upload/Paths of Empyrean RU 1.5 (3).zip'
OUT = '/home/z/my-project/work/qa111/base'
os.makedirs(OUT, exist_ok=True)

TEXT_EXT = ('.ini', '.xml', '.txt', '.json', '.psc', '.csv')

def decode(b):
    for enc in ('utf-8-sig', 'utf-8', 'utf-16le', 'utf-16be', 'cp1251'):
        try:
            s = b.decode(enc)
            # эвристика: если много символов замены или нулей — не та кодировка
            if s.count('\x00') == 0 and s.count('\ufffd') <= len(s) * 0.01:
                return enc, s
        except (UnicodeDecodeError, UnicodeError):
            continue
    return None, None

PATTERNS = [
    # директива игрока: фракции
    (r'Изгнанник', 'изгнанник (ANTI-канон Forsworn)'),
    (r'изгнанник', 'изгнанник (ANTI-канон Forsworn)'),
    (r'Изго[йеяеи]', 'Изго* (Forsworn)'),
    (r'изго[йеяеи]', 'изго* (Forsworn)'),
    (r'Шторм', 'Шторм* (Stormcloak-семья; бел.список: Storm Rift)'),
    (r'Брат[аов]', 'Брат* (Stormcloak/Братство)'),
    (r'Воровская', 'Воровская (ANTI ТивГильдии)'),
    (r'Гильди', 'Гильди*'),
    (r'Стража Рассвета|Стражи Рассвета', 'Стража Рассвета (Dawnguard)'),
    (r'Пенитус', 'Пенитус Окулатус'),
    (r'Клинк', 'Клинки (Blades)'),
    (r'Талмор', 'Талмор'),
    (r'Соратник', 'Соратники'),
    (r'Скаал|скаал', 'Скаал'),
    # материалы/предметы (для слоёв: только подозреваемые правки)
    (r'пластинчат', 'пластинчат (Steel Plate=ок; Dragonplate=ANTI)'),
    (r'панцирн', 'панцирн (Dragonplate канон)'),
    (r'чешуйчат', 'чешуйчат (Scaled=? родовое=ок)'),
    (r'ламелляр', 'ламелляр (Scaled канон)'),
    (r'из шкур', 'сапоги из шкур (ANTI: сыромятные)'),
    (r'Маска культиста', 'Маска культиста (ANTI: члена культа)'),
    (r'шлем имперского офицера', 'шлем имперского офицера (ANTI)'),
    (r'офицера Братьев', 'сапоги офицера Братьев (ANTI)'),
    (r'нордская стрела героя', 'нордская стрела героя (ANTI)'),
    (r'древний нордский доспех|Древний нордский доспех', 'древний нордский доспех (ANTI: броня)'),
    (r'разбойник', 'разбойник (ANTI: бандит)'),
    (r'Под изгоя|под изгоя', 'под изгоя (регистр)'),
    (r'под брата Бури', 'под брата Бури (регистр)'),
    # name-фильтры распределителей
    (r'(?im)^\s*Keyword\s*=.*\bName\b/', 'KID name-фильтр'),
    (r'(?im)^\s*(Spell|Perk|Item|Outfit|Skin|Faction|Race)\s*=.*\bName\b/', 'SPID name-фильтр'),
    (r'(?im)^\s*;?\s*\[?Names?\]?', 'Names-секция'),
]

def main():
    z = zipfile.ZipFile(ZIP)
    names = z.namelist()
    report = open('/home/z/my-project/work/qa111/layers_111.txt', 'w', encoding='utf-8')
    W = lambda *a: print(*a, file=report)
    W('База: %s (%d записей)' % (ZIP, len(names)))
    W('=' * 100)
    # распаковка
    for n in names:
        p = os.path.join(OUT, n)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, 'wb') as f:
            f.write(z.read(n))
    print('распаковано в', OUT)
    hits_total = 0
    for n in sorted(names):
        ext = os.path.splitext(n)[1].lower()
        if ext not in TEXT_EXT:
            continue
        raw = z.read(n)
        enc, s = decode(raw)
        if s is None:
            W('[БИНАРНЫЙ/неопр.] %s' % n)
            continue
        lines = s.splitlines()
        for rx, what in PATTERNS:
            crx = re.compile(rx)
            for i, l in enumerate(lines):
                if crx.search(l):
                    W('[%s] %s :: строка %d :: %s' % (what, n, i + 1, l.strip()[:200]))
                    hits_total += 1
    W('=' * 100)
    W('всего попаданий: %d' % hits_total)
    report.close()
    print('OK, попаданий:', hits_total)

if __name__ == '__main__':
    main()
