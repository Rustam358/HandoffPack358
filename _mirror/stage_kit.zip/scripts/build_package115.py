#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 115, шаг: сборка пакета v1.5.16.
База = user zip «Paths of Empyrean RU 1.5 (8).zip» = байт-в-байт наш v1.5.15
(md5 27f15c15cd95c22a287ec1f0f67aab67). Замены ровно 3 записи:
main ESP (гендерная система маскировок + 115-строки),
CC Orcish Scaled patch ESP (вердикт 113-а), info.xml 1.5.15→1.5.16.
"""
import zipfile, os, hashlib, shutil

SRC_ZIP = '/home/z/my-project/upload/Paths of Empyrean RU 1.5 (8).zip'
DST = '/home/z/my-project/download/Paths of Empyrean RU 1.5.zip'
V116 = '/home/z/my-project/work/qa115/v116'
MAIN = '00 Core/PathsOfEmpyrean.esp'
CC = ('30 CC Patches/Alternative Armors - Orcish Scaled/'
      'PoE-CCAltArmorOrcishScaled-Patch.esp')
RU15 = '/home/z/my-project/work/ru15'


def main():
    esp = open(f'{V116}/{MAIN}', 'rb').read()
    cc = open(f'{V116}/{CC}', 'rb').read()
    md5_esp = hashlib.md5(esp).hexdigest()
    md5_cc = hashlib.md5(cc).hexdigest()

    zsrc = zipfile.ZipFile(SRC_ZIP)
    names = zsrc.namelist()
    orig_crc = {i.filename: i.CRC for i in zsrc.infolist()}
    print('источник: user zip v1.5.15 (%d записей)' % len(names))

    info_src = zsrc.read('fomod/info.xml').decode('utf-8')
    assert '<Version>1.5.15</Version>' in info_src
    info_new = info_src.replace('<Version>1.5.15</Version>', '<Version>1.5.16</Version>')
    assert '<Version>1.5.16</Version>' in info_new and '1.5.15' not in info_new
    print('info.xml: Version 1.5.15 -> 1.5.16')

    repl = {MAIN: esp, CC: cc, 'fomod/info.xml': info_new.encode('utf-8')}
    zout = zipfile.ZipFile(DST, 'w')
    for item in zsrc.infolist():
        arc = item.filename
        zout.writestr(item, repl[arc] if arc in repl else zsrc.read(arc))
    zout.close()
    print('zip собран')

    print()
    print('=== ВЕРИФИКАЦИЯ ПАКЕТА v1.5.16 ===')
    z2 = zipfile.ZipFile(DST)
    names2 = z2.namelist()
    assert z2.testzip() is None
    assert len(names2) == 63 and set(names2) == set(names)
    print('testzip: OK, записей: %d (набор совпадает)' % len(names2))

    diff = [n for n in names if orig_crc[n] != z2.getinfo(n).CRC]
    assert set(diff) == set(repl), 'CRC-дифф: %s' % diff
    print('CRC vs v1.5.15: изменены ровно 3 записи (main ESP, CC-патч, info.xml), '
          'остальные %d байт-в-байт' % (len(names) - 3))

    assert hashlib.md5(z2.read(MAIN)).hexdigest() == md5_esp
    assert hashlib.md5(z2.read(CC)).hexdigest() == md5_cc
    print('ESP md5 == work/qa115/v116: main %s, CC %s' % (md5_esp, md5_cc))

    ver = z2.read('fomod/info.xml').decode('utf-8')
    assert '<Version>1.5.16</Version>' in ver
    print('версия пакета: 1.5.16')

    shutil.copyfile(f'{V116}/{MAIN}', os.path.join(RU15, '00 Core', 'PathsOfEmpyrean.esp'))
    shutil.copyfile(f'{V116}/{CC}', os.path.join(RU15, '30 CC Patches',
                    'Alternative Armors - Orcish Scaled', 'PoE-CCAltArmorOrcishScaled-Patch.esp'))
    open(os.path.join(RU15, 'fomod', 'info.xml'), 'w', encoding='utf-8', newline='').write(info_new)
    print('зеркало work/ru15: main ESP, CC-патч, info.xml обновлены')

    print()
    print('ПАКЕТ:', DST, '(%d Б)' % os.path.getsize(DST))
    print('md5 пакета: %s' % hashlib.md5(open(DST, 'rb').read()).hexdigest())


if __name__ == '__main__':
    main()
