#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 114: пофайловая CRC-сверка user zip (6) с нашим v1.5.14.
Референс v1.5.14 — распакованное дерево release (work/qa113/release114),
т.к. download-zip уже пересобран в v1.5.15. Контроль целости референса:
md5 user zip (6) == md5, записанный за v1.5.14 при выпуске.
"""
import zipfile, hashlib, os

REF = "/home/z/my-project/work/qa113/release114"
USER = "/home/z/my-project/upload/Paths of Empyrean RU 1.5 (6).zip"
V114_MD5 = "7ba701e9537b73e5a3d7de548880b843"

user_md5 = hashlib.md5(open(USER, 'rb').read()).hexdigest()
print(f"md5 user zip (6): {user_md5}")
print(f"md5 v1.5.14 (запись выпуска): {V114_MD5}")
assert user_md5 == V114_MD5, "md5 не совпал — zip (6) не байт-в-байт v1.5.14!"

b = {}
with zipfile.ZipFile(USER) as z:
    for i in z.infolist():
        if i.is_dir():
            continue
        data = z.read(i.filename)
        b[i.filename] = (i.CRC, hashlib.md5(data).hexdigest(), len(data))
print(f"USER zip(6): {len(b)} записей")

bad, missing_ref = [], []
for name, (crc, md5, sz) in b.items():
    ref = os.path.join(REF, *name.split('/'))
    if not os.path.isfile(ref):
        missing_ref.append(name)
        continue
    rb = open(ref, 'rb').read()
    if hashlib.md5(rb).hexdigest() != md5:
        bad.append(name)

print(f"-- байт-в-байт с деревом v1.5.14: {len(b)-len(bad)-len(missing_ref)}/{len(b)}")
print(f"-- РАСХОЖДЕНИЯ: {bad}")
print(f"-- нет в референсе: {missing_ref}")
print("ВЕРДИКТ:", "база чистая (63/63, md5-архива совпадает)" if not bad and not missing_ref
      else "ЕСТЬ РАСХОЖДЕНИЯ!")
