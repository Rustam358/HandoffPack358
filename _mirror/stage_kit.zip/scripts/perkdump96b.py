#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 96: полный дамп перков 18 деревьев навыков PoE v1.5.6 (RU ESP).

Деливерабл: download/PoE_Перки_156_полный_дамп.md + work/qa96/perkdump.jsonl.

Форматы (UESP Mod File Format PERK/MGEF/SPEL/PROJ + техбаза [T13]/[T26]/[T30]):
- PERK DATA[5] = [IsTrait, Level, NumRanks, IsPlayable, IsHidden]
- секции PRKE[3] = [тип: 0=Quest 1=Ability 2=EntryPoint, ранг, приоритет]:
  Quest: DATA[8]=[QUST formid, stage u8]; Ability: DATA[4]=SPEL formid;
  EntryPoint: DATA[3]=[EffectType, Function, CondCount] + PRKC-группы CTDA +
  EPFT(тип данных) + EPFD + EPF2/EPF3
- CTDA[32]: b0 = (оператор<<5)|OR; value f32@4; функция u32@8; p1@0xC; p2@0x10
- SPIT[36]: cost@0, flags@4, тип@8, зарядка f32@0xC, каст@0x10, доставка@0x14,
  длительность@0x18, дальность f32@0x1C, перк полузатрат@0x20
- EFIT[12]: сила f32, радиус u32, длительность u32
- MGEF DATA[152] по UESP; DNAM = zstring c offset 0
- VMAD v5/objfmt 2: строки u16-длина; obj 8Б; у перков хвост Papyrus-фрагментов
- AVIF-звёзды: [PNAM перк][FNAM][XNAM][YNAM][HNAM x][VNAM y][SNAM][CNAM связи][INAM id]
  (CNAM/INAM относятся к ПРЕДЫДУЩЕЙ звезде; верифицировано: Новобранец→Костолом→
  Блэкджек→Контузия; корень → оба входных перка)

Аналитический скрипт: НИЧЕГО не правит.
"""
import sys, struct, json, os
from collections import defaultdict, Counter

sys.path.insert(0, '/home/z/my-project/upload/poe_pack/scripts')
from parse_tes4 import Plugin

ESP = '/home/z/my-project/work/v156/00 Core/PathsOfEmpyrean.esp'
OUT_MD = '/home/z/my-project/download/PoE_Перки_156_полный_дамп.md'
OUT_JSONL = '/home/z/my-project/work/qa96/perkdump.jsonl'

p = Plugin(ESP)
NM = len(p.masters)
SELF = NM
SPEL_BY_EDID = {p.records[f]['edid']: f for f in p.by_type['SPEL'] if p.records[f]['edid']}

def u32(sd, o=0): return struct.unpack_from('<I', sd, o)[0]
def i32(sd, o=0): return struct.unpack_from('<i', sd, o)[0]
def f32(sd, o=0): return struct.unpack_from('<f', sd, o)[0]
def u16(sd, o=0): return struct.unpack_from('<H', sd, o)[0]
def zstr(sd, o=0):
    e = sd.find(b'\x00', o)
    if e < 0:
        e = len(sd)
    return sd[o:e].decode('utf-8', 'replace')

# ------------------------------------------------------------------- енумы
SCHOOLS = {6: 'Одноручное оружие', 7: 'Двуручное оружие', 8: 'Стрельба', 9: 'Блокирование',
           10: 'Кузнечное дело', 11: 'Тяжелая броня', 12: 'Легкая броня', 13: 'Карманные кражи',
           14: 'Взлом', 15: 'Скрытность', 16: 'Алхимия', 17: 'Красноречие', 18: 'Изменение',
           19: 'Колдовство', 20: 'Разрушение', 21: 'Иллюзия', 22: 'Восстановление',
           23: 'Зачарование'}
# карта AV выведена эмпирически из MGEF PoE (EDID/FULL -> PrimaryAV), Этап 96
AV_MAP = dict(SCHOOLS)
AV_MAP.update({24: 'Здоровье', 25: 'Магия', 26: 'Запас сил', 28: 'Очки Голоса',
               30: 'Скорость передвижения', 39: 'Броня (DamageResist)',
               41: 'Сопротивление огню', 42: 'Сопротивление молниям',
               43: 'Сопротивление холоду', 44: 'Сопротивление магии',
               53: 'Паралич', 54: 'Невидимость', 83: 'Поглощение заклинаний',
               85: 'Скорость оружия', 86: 'Сила Криков', 89: 'Сила Криков (вариант 2)',
               92: 'Заглушение (Muffle)', 118: 'счётчик урона броне (внутр.)',
               137: 'Стрельба (модификатор)', 144: 'Скрытность (модификатор)',
               156: 'Восстановление магии', 157: 'Восстановление запаса сил'})

SPELL_TYPE = {0: 'Заклинание', 1: 'Болезнь', 2: 'Сила', 3: 'Малая сила', 4: 'Способность',
              5: 'Яд', 10: 'Зависимость', 11: 'Голос'}
CAST_TYPE = {0: 'Постоянный эффект', 1: 'Огненный-и-забыл', 2: 'Концентрация'}
DELIVERY = {0: 'На себя', 1: 'Касание', 2: 'Направленное', 3: 'На актёра-цель', 4: 'На точку'}

ARCHETYPE = {0: 'Value Mod (модификатор значения)', 1: 'Script (скрипт)', 2: 'Dispel',
             3: 'Cure Disease', 4: 'Absorb (поглощение)', 5: 'Dual Value Mod',
             6: 'Calm (успокоение)', 7: 'Demoralize (устрашение)', 8: 'Frenzy (ярость)',
             9: 'Disarm (обезоруживание)', 10: 'Command Summoned', 11: 'Invisibility (невидимость)',
             12: 'Light (свет)', 15: 'Lock', 16: 'Open', 17: 'Bound Weapon (окованное оружие)',
             18: 'Summon Creature (призыв существа)', 19: 'Detect Life', 20: 'Telekinesis',
             21: 'Paralysis (паралич)', 22: 'Reanimate (подъём мёртвых)', 23: 'Soul Trap (поимка души)',
             24: 'Turn Undead (изгнание нежити)', 25: 'Guide', 26: 'Werewolf Feed',
             27: 'Cure Paralysis', 28: 'Cure Addiction', 29: 'Cure Poison', 30: 'Concussion',
             31: 'Value and Parts', 32: 'Accumulate Magnitude (барьер)', 33: 'Stagger (отшвыривание)',
             34: 'Peak Value Mod', 35: 'Cloak (плащ-аура)', 36: 'Werewolf', 37: 'Slow Time',
             38: 'Rally (ободрение)', 39: 'Enchant Weapon', 40: 'Spawn Hazard (зона на земле)',
             41: 'Etherealize', 42: 'Banish (изгнание)', 43: 'Spawn Scripted Ref',
             44: 'Disguise', 45: 'Grab Actor', 46: 'Vampire Lord'}

ENTRY_POINTS = {
    0x00: 'Calculate Weapon Damage', 0x01: 'Calculate My Critical Hit Chance',
    0x02: 'Calculate My Critical Hit Damage', 0x03: 'Calculate Mine Explode Chance',
    0x04: 'Adjust Limb Damage', 0x05: 'Adjust Book Skill Points', 0x06: 'Mod Recovered Health',
    0x07: 'Get Should Attack', 0x08: 'Mod Buy Prices', 0x09: 'Add Level List On Death',
    0x0A: 'Get Max Carry Weight', 0x0B: 'Mod Addiction Chance', 0x0D: 'Mod Positive Chem Duration',
    0x0E: 'Activate', 0x0F: 'Ignore Running During Detection', 0x10: 'Ignore Broken Lock',
    0x11: 'Mod Enemy Critical Hit Chance', 0x12: 'Mod Sneak Attack Multiplier',
    0x13: 'Mod Max Placeable Mines', 0x14: 'Mod Bow Zoom', 0x15: 'Mod Recover Arrow Chance',
    0x16: 'Mod Skill Use', 0x17: 'Mod Telekinesis Distance', 0x18: 'Mod Telekinesis Damage Multiplier',
    0x19: 'Mod Telekinesis Damage', 0x1A: 'Mod Bashing Damage', 0x1B: 'Mod Power Attack Stamina',
    0x1C: 'Mod Power Attack Damage', 0x1D: 'Mod Spell Magnitude', 0x1E: 'Mod Spell Duration',
    0x1F: 'Mod Secondary Value Weight', 0x20: 'Mod Armor Weight', 0x21: 'Mod Incoming Stagger',
    0x22: 'Mod Target Stagger', 0x23: 'Mod Attack Damage', 0x24: 'Mod Incoming Damage',
    0x25: 'Mod Target Damage Resistance', 0x26: 'Mod Spell Cost', 0x27: 'Mod Percent Blocked',
    0x28: 'Mod Shield Deflect Arrow Chance', 0x29: 'Mod Incoming Spell Magnitude',
    0x2A: 'Mod Incoming Spell Duration', 0x2B: 'Mod Player Intimidation',
    0x2C: 'Mod Player Reputation', 0x2D: 'Mod Favor Points', 0x2E: 'Mod Bribe Amount',
    0x2F: 'Mod Detection Light', 0x30: 'Mod Detection Movement', 0x31: 'Mod Soul Gem Recharge',
    0x32: 'Set Sweep Attack', 0x33: 'Apply Combat Hit Spell', 0x34: 'Apply Bashing Spell',
    0x35: 'Apply Reanimate Spell', 0x36: 'Set Boolean Graph Variable',
    0x37: 'Mod Spell Casting Sound Event', 0x38: 'Mod Pickpocket Chance',
    0x39: 'Mod Detection Sneak Skill', 0x3A: 'Mod Falling Damage', 0x3B: 'Mod Lockpick Sweet Spot',
    0x3C: 'Mod Sell Prices', 0x3D: 'Can Pickpocket Equipped Item', 0x3E: 'Mod Lockpick Level Allowed',
    0x3F: 'Set Lockpick Start Position', 0x40: 'Set Progression Picking',
    0x41: 'Make Lockpicks Unbreakable', 0x42: 'Mod Alchemy Effectiveness',
    0x43: 'Apply Weapon Swing Spell', 0x44: 'Mod Commanded Actor Limit',
    0x45: 'Apply Sneaking Spell', 0x46: 'Mod Player Magic Slowdown',
    0x47: 'Mod Ward Magic Absorption Percent', 0x48: 'Mod Ingredient Effects Learned',
    0x49: 'Purify Alchemy Ingredients', 0x4A: 'Filter Activation', 0x4B: 'Can Dual Cast Spell',
    0x4C: 'Mod Tempering Health', 0x4D: 'Mod Enchantment Power',
    0x4E: 'Mod Soul Percent Captured to Weapon', 0x4F: 'Mod Soul Gem Enchanting',
    0x50: 'Mod Number of Enchantments Allowed', 0x51: 'Set Activate Label', 0x52: 'Mod Shout OK',
    0x53: 'Mod Poison Dose Count', 0x54: 'Should Apply Placed Item', 0x55: 'Mod Armor Rating',
    0x56: 'Mod Lockpick Crime Chance', 0x57: 'Mod Ingredients Harvested',
    0x58: 'Mod Spell Range to Location', 0x59: 'Mod Potions Created',
    0x5A: 'Mod Lockpick Key Reward Chance (Wax Key)'}

EP_FUNCTIONS = {
    0x01: 'Set Value (новое = VALUE)', 0x02: 'Add Value (+ AMOUNT)',
    0x03: 'Multiply Value (× FACTOR)', 0x04: 'Add Range to Value (+ random MIN..MAX)',
    0x05: 'Add Actor Value Mult (+ AV × FACTOR)', 0x08: 'Add Level List',
    0x09: 'Add Activate Choice', 0x0A: 'Select Spell (применять заклинание)',
    0x0B: 'Select Text', 0x0C: 'Set AV Mult (= AV × FACTOR)',
    0x0D: 'Multiply AV Mult (× AV × FACTOR)',
    0x0E: 'Multiply 1 + AV Mult (× (1 + AV × FACTOR))', 0x0F: 'Set Text'}

FN_NAMES = {560: 'HasKeyword', 448: 'HasPerk', 277: 'GetBaseActorValue', 74: 'GetGlobalValue'}
OPER = {0: '==', 1: '!=', 2: '>', 3: '>=', 4: '<', 5: '<='}

MGEF_FLAGS = [(0x00000001, 'Hostile'), (0x00000002, 'Recover'), (0x00000004, 'Detrimental'),
              (0x00000008, 'Snap to Navmesh'), (0x00000010, 'No Hit Event'),
              (0x00000100, 'Dispel Effects'), (0x00000200, 'No Duration'),
              (0x00000400, 'No Magnitude'), (0x00000800, 'No Area'), (0x00001000, 'FX Persist'),
              (0x00004000, 'Gory Visual'), (0x00008000, 'Hide in UI'), (0x00020000, 'No Recast'),
              (0x00200000, 'Power Affects Magnitude'), (0x00400000, 'Power Affects Duration'),
              (0x04000000, 'Painless'), (0x08000000, 'No Hit Effect'),
              (0x10000000, 'No Death Dispel')]

VANILLA_MGEF = {
    0x0007809B: 'Stagger Attack (StaggerAttackFFContact) — ванильный эффект отшвыривания',
    0x00105F17: 'ванильный эффект «Быстрого выстрела» (скорость натяжения лука)',
    0x00091F77: 'ванильный эффект масштабирования (способности «Сила существ» и т.п.)',
    0x00053124: 'ванильный эффект сопротивлений (автоматоны/сопротивление магии)',
    0x000A1A3F: 'Fortify Health (AbFortifyHealth) — ванильное увеличение здоровья',
    0x000424E2: 'ванильный эффект урона безоружных/существ (когти, луркер)',
    0x0010CAAB: 'ванильный эффект «Сокрушительного набега» (стаггер)',
    0x00017331: 'shieldChargeDamageStamina — урон запасу сил «Сокрушительного набега»',
    0x0006C0F3: 'Fortify Bow Stagger (AbFortifyBowStagger) — стаггер от выстрела',
    0x0009379B: 'ванильный Muffle-эффект (приглушение шума)',
    0x000EA075: 'ванильный эффект толчка/отбрасывания (Крик, «Чародейский разряд»; по контексту)',
    0x0008CAC9: 'ванильный эффект способностей драконьих жрецов/призванных существ (по контексту)',
    0x000AA01C: 'ванильный эффект способностей нежити (сопротивления; по контексту)',
    0x000E40D3: 'ванильный эффект способностей нежити/призраков (по контексту)',
    0x000AA024: 'ванильный эффект способностей нежити/двемеров (по контексту)',
    0x0501A8D3: 'эффект Lost Grimoire (вне ESP)',
    0x000D4889: 'ванильный огненный эффект («Шквал огненных стрел»; по контексту)',
    0x000A44C0: 'ванильный огненный эффект («Шквал огненных стрел»; по контексту)',
    0x0001EA6A: 'ванильный эффект невидимости («Невидимость», «Приманка»; по контексту)'}

GROUP_NAMES = {0: 'Perk Owner', 1: 'Target', 2: 'Attacker', 3: 'Attacker Weapon',
               4: 'Spell', 5: 'Weapon', 6: 'Item', 7: 'Enchantment', 8: 'Locked Reference'}

# субъекты условий по индексу PRKC для каждой точки входа (UESP, PERK)
EP_COND_GROUPS = {
    0x00: ['Perk Owner', 'Weapon', 'Target'], 0x01: ['Perk Owner', 'Weapon', 'Target'],
    0x02: ['Perk Owner', 'Weapon', 'Target'], 0x03: ['Perk Owner', 'Item'],
    0x04: ['Perk Owner', 'Attacker', 'Attacker Weapon'], 0x05: ['Perk Owner'],
    0x06: ['Perk Owner'], 0x07: ['Perk Owner', 'Attacker'], 0x08: ['Perk Owner', 'Target'],
    0x09: ['Perk Owner', 'Target'], 0x0A: ['Perk Owner'], 0x0B: ['Perk Owner'],
    0x0D: ['Perk Owner'], 0x0E: ['Perk Owner', 'Target'], 0x0F: ['Perk Owner'],
    0x10: ['Perk Owner'], 0x11: ['Perk Owner', 'Weapon', 'Target'],
    0x12: ['Perk Owner', 'Weapon', 'Target'], 0x13: ['Perk Owner'],
    0x14: ['Perk Owner', 'Weapon'], 0x15: ['Perk Owner'], 0x16: ['Perk Owner'],
    0x17: ['Perk Owner'], 0x18: ['Perk Owner'], 0x19: ['Perk Owner', 'Target'],
    0x1A: ['Perk Owner', 'Target'], 0x1B: ['Perk Owner', 'Weapon'],
    0x1C: ['Perk Owner', 'Weapon', 'Target'], 0x1D: ['Perk Owner', 'Spell', 'Target'],
    0x1E: ['Perk Owner', 'Spell', 'Target'], 0x1F: ['Perk Owner', 'Spell', 'Target'],
    0x20: ['Perk Owner', 'Item'], 0x21: ['Perk Owner', 'Attacker'],
    0x22: ['Perk Owner', 'Target'], 0x23: ['Perk Owner', 'Weapon', 'Target'],
    0x24: ['Perk Owner', 'Attacker', 'Attacker Weapon'], 0x25: ['Perk Owner', 'Weapon', 'Target'],
    0x26: ['Perk Owner', 'Spell'], 0x27: ['Perk Owner'], 0x28: ['Perk Owner'],
    0x29: ['Perk Owner', 'Spell'], 0x2A: ['Perk Owner', 'Spell'], 0x2B: ['Perk Owner', 'Target'],
    0x2C: ['Perk Owner'], 0x2D: ['Perk Owner', 'Target'], 0x2E: ['Perk Owner', 'Target'],
    0x2F: ['Perk Owner', 'Target'], 0x30: ['Perk Owner', 'Target'], 0x31: ['Perk Owner', 'Item'],
    0x32: ['Perk Owner', 'Weapon'], 0x33: ['Perk Owner', 'Weapon', 'Target'],
    0x34: ['Perk Owner', 'Target'], 0x35: ['Perk Owner', 'Spell', 'Target'], 0x36: ['Perk Owner'],
    0x37: ['Perk Owner', 'Spell'], 0x38: ['Perk Owner', 'Target', 'Item'],
    0x39: ['Perk Owner', 'Target'], 0x3A: ['Perk Owner'], 0x3B: ['Perk Owner', 'Locked Reference'],
    0x3C: ['Perk Owner', 'Target'], 0x3D: ['Perk Owner', 'Target', 'Item'], 0x3E: ['Perk Owner'],
    0x3F: ['Perk Owner'], 0x40: ['Perk Owner'], 0x41: ['Perk Owner'], 0x42: ['Perk Owner'],
    0x43: ['Perk Owner', 'Attacker', 'Attacker Weapon'], 0x44: ['Perk Owner', 'Spell'],
    0x45: ['Perk Owner'], 0x46: ['Perk Owner', 'Spell'], 0x47: ['Perk Owner', 'Spell'],
    0x48: ['Perk Owner', 'Spell'], 0x49: ['Perk Owner'], 0x4A: ['Perk Owner', 'Target'],
    0x4B: ['Perk Owner', 'Spell'], 0x4C: ['Perk Owner', 'Item'],
    0x4D: ['Perk Owner', 'Enchantment', 'Item'], 0x4E: ['Perk Owner', 'Target', 'Item'],
    0x4F: ['Perk Owner', 'Enchantment', 'Item'], 0x50: ['Perk Owner'],
    0x51: ['Perk Owner', 'Target'], 0x52: ['Perk Owner'], 0x53: ['Perk Owner', 'Weapon', 'Spell'],
    0x54: ['Perk Owner', 'Target', 'Item'], 0x55: ['Perk Owner', 'Item'],
    0x56: ['Perk Owner', 'Locked Reference'], 0x57: ['Perk Owner', 'Item'],
    0x58: ['Perk Owner', 'Spell'], 0x59: ['Perk Owner', 'Spell'],
    0x5A: ['Perk Owner', 'Locked Reference']}

# ------------------------------------------------------------------- ярлыки
def ep_group_name(ep, g):
    """Имя группы условий PRKC: индекс в списке субъектов КОНКРЕТНОЙ точки входа."""
    if g is None:
        return None
    lst = EP_COND_GROUPS.get(ep)
    if lst and g < len(lst):
        return lst[g]
    return GROUP_NAMES.get(g, f'группа {g}')

def spel_refs_vmad(vm):
    refs = []
    if not vm:
        return refs
    for s in vm['scripts']:
        for pn, (t, v) in s['props']:
            if t == 'obj' and isinstance(v, str) and v.startswith('SPEL:'):
                f = SPEL_BY_EDID.get(v[5:])
                if f:
                    refs.append(f)
    return refs

def fid_label(v):
    if v == 0:
        return 'NULL'
    if v in p.records:
        r = p.records[v]
        return f"{r['type']}:{r['edid'] or hex(v)}"
    idx = v >> 24
    if idx < NM:
        return f"{p.masters[idx]}#0x{v & 0xFFFFFF:06X}"
    return f"0x{v:08X}"

def fid_name(v):
    return p.records[v].get('full') if v in p.records else None

def av(idx):
    if idx in (0xFFFFFFFF, -1, None):
        return '—'
    n = AV_MAP.get(idx)
    return f"{n} ({idx})" if n else f"AV {idx}"

# ------------------------------------------------------------------- CTDA
def parse_ctda(sd):
    return {'op': sd[0] >> 5, 'or': bool(sd[0] & 1), 'val': f32(sd, 4),
            'fn': u32(sd, 8), 'p1': u32(sd, 12), 'p2': u32(sd, 16)}

def val_str(v):
    return str(int(v)) if v == int(v) else f"{v:.4g}"

def ctda_str(c):
    fn = c['fn']
    name = FN_NAMES.get(fn, f"ф.{fn}")
    p1s = ''
    if c['p1']:
        if c['p1'] in p.records:
            r = p.records[c['p1']]
            nm = f" «{r['full']}»" if r.get('full') else ''
            p1s = f"{r['type']}:{r['edid']}{nm}"
        elif fn in (277, 14) and c['p1'] < 256:
            p1s = av(c['p1'])
        else:
            p1s = fid_label(c['p1'])
    p2s = ''
    if c['p2']:
        p2s = f", {fid_label(c['p2'])}" if c['p2'] in p.records else f", 0x{c['p2']:X}"
    return f"{name}({p1s}{p2s}) {OPER.get(c['op'], '?')} {val_str(c['val'])}"

def join_conds(ctdas):
    """И-цепочка с ИЛИ-пометками: ИЛИ-бит условия значит ИЛИ со СЛЕДУЮЩИМ."""
    if not ctdas:
        return ''
    parts = [ctda_str(c) for c in ctdas]
    out = parts[0]
    for i in range(1, len(parts)):
        out += (' ИЛИ ' if ctdas[i - 1]['or'] else ' И ') + parts[i]
    return out

# ------------------------------------------------------------------- VMAD
def parse_vmad(sd):
    out = {'scripts': [], 'fragments': None}
    try:
        off = 4
        scount = u16(sd, off); off += 2

        def lstr(o):
            n = u16(sd, o); o += 2
            return sd[o:o + n].decode('utf-8', 'replace'), o + n

        for _ in range(scount):
            name, off = lstr(off)
            status = sd[off]; off += 1
            pcount = u16(sd, off); off += 2
            props = []
            for _ in range(pcount):
                pn, off = lstr(off)
                pt = sd[off]; off += 2
                if pt == 1:
                    val = ('obj', fid_label(u32(sd, off + 4))); off += 8
                elif pt == 2:
                    sl = u16(sd, off); off += 2
                    val = ('str', sd[off:off + sl].decode('utf-8', 'replace')); off += sl
                elif pt == 3:
                    val = ('int', i32(sd, off)); off += 4
                elif pt == 4:
                    val = ('float', round(f32(sd, off), 4)); off += 4
                elif pt == 5:
                    val = ('bool', sd[off]); off += 1
                elif pt == 11:
                    cnt = u32(sd, off); off += 4
                    val = ('objarr', [fid_label(u32(sd, off + 4 + i * 8)) for i in range(cnt)])
                    off += 8 * cnt
                elif pt == 12:
                    cnt = u32(sd, off); off += 4
                    arr = []
                    for _ in range(cnt):
                        s, off = lstr(off)
                        arr.append(s)
                    val = ('strarr', arr)
                elif pt in (13, 14, 15):
                    cnt = u32(sd, off); off += 4
                    fmtm = {13: 'i', 14: 'f', 15: 'B'}[pt]
                    val = ({13: 'intarr', 14: 'floatarr', 15: 'boolarr'}[pt],
                           list(struct.unpack_from(f'<{cnt}{fmtm}', sd, off)))
                    off += struct.calcsize(f'<{cnt}{fmtm}')
                else:
                    raise ValueError('тип свойства ' + str(pt))
                props.append((pn, val))
            out['scripts'].append({'name': name, 'status': status, 'props': props})
        if off < len(sd):
            frag = {}
            off += 1  # маркер 0x02
            sname, off = lstr(off)
            frag['script'] = sname
            off += 1; off += 2; off += 4  # статус, propCount, u32
            frags = []
            while off < len(sd):
                off += 4  # u32-лидер
                sn, off = lstr(off)
                fnm, off = lstr(off)
                ep = None
                if off < len(sd):
                    ep = sd[off]
                    off += 1
                frags.append({'script': sn, 'fragment': fnm, 'ep': ep})
            frag['fragments'] = frags
            out['fragments'] = frag
    except Exception:
        return out
    return out

def vmad_props_flat(vm):
    lines = []
    for s in vm['scripts']:
        lines.append(f"{s['name']}.pex")
        for pn, (t, v) in s['props']:
            lines.append(f"    {pn} = {v}")
    return lines

# ------------------------------------------------------------------- MGEF
def parse_mgef(r):
    d = {'edid': r['edid'], 'full': r.get('full'), 'formid': r['formid']}
    for st, sd in r['subs']:
        if st == 'DATA' and len(sd) == 152:
            d['flags'] = u32(sd, 0)
            d['cost'] = f32(sd, 4)
            d['related'] = u32(sd, 8)
            d['school'] = i32(sd, 0x0C)
            d['resist'] = i32(sd, 0x10)
            d['light'] = u32(sd, 0x18)
            d['hit_shader'] = u32(sd, 0x20)
            d['ench_shader'] = u32(sd, 0x24)
            d['skill_level'] = u32(sd, 0x28)
            d['area'] = u32(sd, 0x2C)
            d['secondw'] = f32(sd, 0x3C)
            d['arch'] = u32(sd, 0x40)
            d['pav'] = i32(sd, 0x44)
            d['proj'] = u32(sd, 0x48)
            d['expl'] = u32(sd, 0x4C)
            d['cast'] = u32(sd, 0x50)
            d['delivery'] = u32(sd, 0x54)
            d['sav'] = i32(sd, 0x58)
            d['equip_ab'] = u32(sd, 0x80)
            d['perk'] = u32(sd, 0x88)
        elif st == 'DNAM':
            d['desc'] = zstr(sd, 0)
        elif st == 'VMAD':
            d['vmad'] = parse_vmad(sd)
        elif st == 'CTDA':
            d.setdefault('ctda', []).append(parse_ctda(sd))
    return d

def mg_str(d):
    sch = SCHOOLS.get(d['school'], '—') if d['school'] in SCHOOLS else (av(d['school']) if d['school'] not in (-1, 0xFFFFFFFF) else '—')
    fl = [n for b, n in MGEF_FLAGS if d['flags'] & b]
    s = f"школа: {sch}; архетип: {ARCHETYPE.get(d['arch'], d['arch'])}"
    if d['pav'] not in (-1, 0xFFFFFFFF):
        s += f"; PrimaryAV: {av(d['pav'])}"
    if d['sav'] not in (-1, 0xFFFFFFFF):
        s += f"; SecondAV: {av(d['sav'])} (вес {d['secondw']:g})"
    if d['resist'] not in (-1, 0xFFFFFFFF):
        s += f"; сопротивление: {av(d['resist'])}"
    if d['cost']:
        s += f"; базовая стоимость: {d['cost']:g}"
    if d['skill_level']:
        s += f"; требуемый навык: {d['skill_level']}"
    if fl:
        s += f"; флаги: {', '.join(fl)}"
    s += f"; каст: {CAST_TYPE.get(d['cast'], d['cast'])}, доставка: {DELIVERY.get(d['delivery'], d['delivery'])}"
    if d['related']:
        rel_t = {12: 'свет', 17: 'оружие', 18: 'существо', 35: 'заклинание-плащ', 25: 'hazard',
                 40: 'hazard', 39: 'зачарование', 34: 'ключ. слово', 36: 'раса', 46: 'раса'}.get(d['arch'], 'связанная запись')
        nm = f" «{fid_name(d['related'])}»" if fid_name(d['related']) else ''
        s += f"; {rel_t}: {fid_label(d['related'])}{nm}"
    if d['light']:
        s += f"; свет: {fid_label(d['light'])}"
    if d['hit_shader']:
        s += f"; шейдер попадания: {fid_label(d['hit_shader'])}"
    if d['ench_shader']:
        s += f"; шейдер зачарования: {fid_label(d['ench_shader'])}"
    if d['equip_ab']:
        s += f"; способность экипировки: {fid_label(d['equip_ab'])}"
    if d['perk']:
        s += f"; перк: {fid_label(d['perk'])}"
    return s

# ------------------------------------------------------------------- PROJ/HAZD
PROJ_FLAGS = [(0x0001, 'Hitscan'), (0x0002, 'Explosion'), (0x0004, 'Alt.Trigger'),
              (0x0008, 'Muzzle Flash'), (0x0020, 'Can be Disabled'), (0x0040, 'Can be Picked Up'),
              (0x0080, 'Supersonic'), (0x0100, 'Pins Limbs'),
              (0x0200, 'Pass Through Small Transparent'), (0x0400, 'Disable Combat Aim Correction')]
PROJ_TYPE = {0x01: 'Missile', 0x02: 'Lobber', 0x04: 'Beam', 0x08: 'Flame', 0x10: 'Cone',
             0x20: 'Barrier', 0x40: 'Arrow'}

def parse_proj(r):
    d = {'edid': r['edid'], 'full': r.get('full')}
    for st, sd in r['subs']:
        if st == 'DATA' and len(sd) == 92:
            d['flags'] = u16(sd, 0)
            d['ptype'] = u16(sd, 2)
            d['gravity'] = f32(sd, 4)
            d['speed'] = f32(sd, 8)
            d['range'] = f32(sd, 12)
            d['light'] = u32(sd, 16)
            d['expl'] = u32(sd, 36)
            d['sound'] = u32(sd, 40)
            d['expltimer'] = f32(sd, 32)
            d['conesp'] = f32(sd, 68)
            d['colrad'] = f32(sd, 72)
            d['lifetime'] = f32(sd, 76)
        elif st == 'MODL':
            d['model'] = zstr(sd)
    return d

def proj_str(d):
    fl = [n for b, n in PROJ_FLAGS if d['flags'] & b]
    pt = PROJ_TYPE.get(d['ptype'], hex(d['ptype']))
    s = f"тип {pt}"
    if fl:
        s += f" ({', '.join(fl)})"
    s += f"; скорость {d['speed']:g}; гравитация {d['gravity']:g}; дальность {d['range']:g}"
    if d['lifetime']:
        s += f"; время жизни {d['lifetime']:g} с"
    if d['expltimer']:
        s += f"; таймер взрыва {d['expltimer']:g} с"
    if d.get('model'):
        s += f"; модель: {d['model']}"
    return s

# ------------------------------------------------------------------- SPEL
def parse_spel(r):
    d = {'edid': r['edid'], 'full': r.get('full'), 'formid': r['formid'], 'effects': []}
    cur = None
    for st, sd in r['subs']:
        if st == 'SPIT':
            d['cost'] = u32(sd, 0)
            d['flags'] = u32(sd, 4)
            d['type'] = u32(sd, 8)
            d['charge'] = f32(sd, 0xC)
            d['cast'] = u32(sd, 0x10)
            d['delivery'] = u32(sd, 0x14)
            d['castdur'] = f32(sd, 0x18)
            d['range'] = f32(sd, 0x1C)
            d['halfcost'] = u32(sd, 0x20)
        elif st == 'EFID':
            cur = {'mgef': u32(sd), 'ctda': []}
            d['effects'].append(cur)
        elif st == 'EFIT':
            if cur is not None:
                cur['mag'] = f32(sd, 0)
                cur['area'] = u32(sd, 4)
                cur['dur'] = u32(sd, 8)
        elif st == 'CTDA' and cur is not None:
            cur['ctda'].append(parse_ctda(sd))
        elif st == 'VMAD':
            d['vmad'] = parse_vmad(sd)
    return d

# ------------------------------------------------------------------- деревья
TREE_ORDER = ['AVOneHanded', 'AVTwoHanded', 'AVMarksman', 'AVBlock', 'AVSmithing',
              'AVHeavyArmor', 'AVLightArmor', 'AVPickpocket', 'AVLockpicking', 'AVSneak',
              'AVAlchemy', 'AVSpeechcraft', 'AVEnchanting', 'AVAlteration', 'AVConjuration',
              'AVDestruction', 'AVMysticism', 'AVRestoration']

def parse_avif(r):
    """Звезда = [PNAM][FNAM][XNAM][YNAM][HNAM][VNAM][SNAM] + [CNAM...][INAM] (свои)."""
    stars = []
    root_links = []
    cur = None
    for st, sd in r['subs']:
        v = u32(sd) if len(sd) == 4 else None
        if st == 'PNAM':
            if cur is not None:
                stars.append(cur)
            cur = {'id': None, 'perk': v, 'x': None, 'y': None, 'links': [], 'grid': None,
                   'root': (v == 0)}
        elif st == 'HNAM' and cur is not None and len(sd) == 4:
            cur['x'] = f32(sd)
        elif st == 'VNAM' and cur is not None and len(sd) == 4:
            cur['y'] = f32(sd)
        elif st == 'XNAM' and cur is not None and len(sd) == 4:
            cur['grid'] = v
        elif st == 'CNAM' and len(sd) == 4:
            if cur is not None:
                cur['links'].append(v)
            else:
                root_links.append(v)
        elif st == 'INAM' and len(sd) == 4 and cur is not None:
            cur['id'] = v
    if cur is not None:
        stars.append(cur)
    return stars, root_links

# ------------------------------------------------------------------- PERK
def parse_perk(r):
    d = {'edid': r['edid'], 'full': r.get('full'), 'formid': r['formid'],
         'new': (r['formid'] >> 24) >= SELF, 'sections': [], 'perk_conds': []}
    cur_sec = None
    cur_group = None
    for st, sd in r['subs']:
        if st == 'DESC':
            d['desc'] = zstr(sd)
        elif st == 'DATA' and len(sd) == 5:
            d['trait'], d['level'], d['ranks'], d['playable'], d['hidden'] = sd[0], sd[1], sd[2], sd[3], sd[4]
        elif st == 'NNAM':
            d['next'] = u32(sd)
        elif st == 'PRKE':
            t = sd[0]
            cur_sec = {'type': ['quest', 'ability', 'ep'][t], 'rank': sd[1], 'prio': sd[2],
                       'conds': []}
            d['sections'].append(cur_sec)
            cur_group = None
        elif st == 'DATA' and cur_sec is not None and len(sd) == 8 and cur_sec['type'] == 'quest':
            cur_sec['quest'] = u32(sd)
            cur_sec['stage'] = sd[4]
        elif st == 'DATA' and cur_sec is not None and len(sd) == 4 and cur_sec['type'] == 'ability':
            cur_sec['spell'] = u32(sd)
        elif st == 'DATA' and cur_sec is not None and len(sd) == 3:
            cur_sec['ep'] = sd[0]
            cur_sec['fn'] = sd[1]
        elif st == 'PRKC':
            if cur_sec is None:
                cur_group = None
                d['perk_conds'].append({'group': sd[0], 'ctdas': []})
            else:
                cur_group = {'group': sd[0], 'ctdas': []}
                cur_sec['conds'].append(cur_group)
        elif st == 'CTDA':
            c = parse_ctda(sd)
            if cur_sec is None:
                if d['perk_conds']:
                    d['perk_conds'][-1]['ctdas'].append(c)
                else:
                    d['perk_conds'].append({'group': None, 'ctdas': [c]})
            elif cur_group is not None:
                cur_group['ctdas'].append(c)
            else:
                cur_sec['conds'].append({'group': None, 'ctdas': [c]})
        elif st == 'EPFT' and cur_sec is not None:
            cur_sec['epft'] = sd[0]
        elif st == 'EPFD' and cur_sec is not None:
            if len(sd) == 8:
                cur_sec['epfd_av'] = f32(sd)
                cur_sec['epfd_factor'] = f32(sd, 4)
            elif len(sd) == 4:
                cur_sec['epfd_f'] = f32(sd)
                cur_sec['epfd_u'] = u32(sd)
            else:
                cur_sec['epfd_s'] = zstr(sd)
        elif st == 'EPF2' and cur_sec is not None:
            cur_sec['epf2'] = zstr(sd) if sd and all(32 <= b < 127 for b in sd[:-1]) else sd.hex()
        elif st == 'EPF3' and cur_sec is not None:
            cur_sec['epf3'] = u32(sd)
        elif st == 'VMAD':
            d['vmad'] = parse_vmad(sd)
    return d

def render_conditions(groups, indent='  '):
    out = []
    for g in groups:
        if not g['ctdas']:
            continue
        gname = GROUP_NAMES.get(g['group'], f"группа {g['group']}") if g['group'] is not None else None
        body = join_conds(g['ctdas'])
        out.append(f"{indent}- " + (f"[{gname}] " if gname else '') + body)
    return out

def epf3_str(v):
    lo, hi = v & 0xFFFF, v >> 16
    parts = []
    if lo & 0x01:
        parts.append('Run Immediately')
    if lo & 0x02:
        parts.append('Replace Default')
    if hi == 0x03:
        parts.append('Spell')
    if hi == 0x04:
        parts.append('Script Fragment')
    return '/'.join(parts) if parts else hex(v)

def epfd_value(sec):
    t = sec.get('epft')
    if 'epfd_av' in sec:
        return f"AV = {av(int(sec['epfd_av']))}, множитель = {sec['epfd_factor']:g}"
    if 'epfd_f' in sec:
        u = sec.get('epfd_u')
        if t in (3, 5) and u in p.records:
            return None  # формид: отрисуем отдельно
        return f"значение = {sec['epfd_f']:g}"
    if 'epfd_s' in sec:
        return f"текст = {sec['epfd_s']!r}"
    return None

# ------------------------------------------------------------------- рендер заклинаний
van_mgef_used = Counter()

def spell_md(sid, seen=None, depth=0):
    if seen is None:
        seen = set()
    if sid in seen or depth > 3:
        return ['      …(см. выше)']
    seen = seen | {sid}
    if sid not in p.records:
        return [f"      Заклинание вне ESP: {fid_label(sid)}"]
    sp = parse_spel(p.records[sid])
    ind = '  ' * (2 + depth)
    L = []
    nm = f" «{sp['full']}»" if sp.get('full') else ''
    L.append(f"{ind}▸ {fid_label(sid)}{nm}")
    bits = [f"тип: {SPELL_TYPE.get(sp['type'], sp['type'])}",
            f"стоимость: {sp['cost']}",
            f"каст: {CAST_TYPE.get(sp['cast'], sp['cast'])}",
            f"доставка: {DELIVERY.get(sp['delivery'], sp['delivery'])}"]
    if sp.get('charge'):
        bits.append(f"зарядка: {sp['charge']:g} с")
    if sp.get('castdur'):
        bits.append(f"длительность каста: {sp['castdur']:g} с")
    if sp.get('halfcost'):
        bits.append(f"перк полузатрат: {fid_label(sp['halfcost'])}")
    L.append(f"{ind}  " + '; '.join(bits))
    for i, e in enumerate(sp['effects'], 1):
        mid = e['mgef']
        if mid in p.records:
            m = parse_mgef(p.records[mid])
            mnm = f" «{m['full']}»" if m.get('full') else ''
            L.append(f"{ind}  Эффект {i}: {fid_label(mid)}{mnm} — "
                     f"сила {val_str(e['mag'])}, длительность {e['dur']}, радиус {e['area']}")
            L.append(f"{ind}    {mg_str(m)}")
            if m.get('desc'):
                L.append(f"{ind}    описание: «{m['desc']}»")
            if m.get('vmad') and m['vmad']['scripts']:
                L.append(f"{ind}    скрипты эффекта:")
                for ln in vmad_props_flat(m['vmad']):
                    L.append(f"{ind}      {ln}")
                for ref in spel_refs_vmad(m['vmad']):
                    if ref not in seen:
                        L.append(f"{ind}    скрипт применяет:")
                        L.extend(spell_md(ref, seen, depth + 1))
            if m.get('proj') and m['proj'] in p.records:
                pr = parse_proj(p.records[m['proj']])
                L.append(f"{ind}    снаряд {fid_label(m['proj'])}: {proj_str(pr)}")
            if m.get('expl') and m['expl'] in p.records:
                L.append(f"{ind}    взрыв: {fid_label(m['expl'])}")
            rel_t = p.records[m['related']]['type'] if m.get('related') and m['related'] in p.records else None
            if rel_t == 'HAZD':
                hz = p.records[m['related']]
                model = next((zstr(sd) for st, sd in hz['subs'] if st == 'MODL'), '')
                L.append(f"{ind}    зона на земле {fid_label(m['related'])}" + (f" (модель {model})" if model else ''))
            if rel_t == 'SPEL' and m['arch'] == 35:
                L.append(f"{ind}    заклинание-плащ:")
                L.extend(spell_md(m['related'], seen, depth + 1))
        else:
            van_mgef_used[mid] += 1
            L.append(f"{ind}  Эффект {i}: {fid_label(mid)} — {VANILLA_MGEF.get(mid, 'ваниль/LG MGEF вне ESP')} — "
                     f"сила {val_str(e['mag'])}, длительность {e['dur']}, радиус {e['area']}")
        if e['ctda']:
            L.append(f"{ind}    условия эффекта: {join_conds(e['ctda'])}")
    if sp.get('vmad') and sp['vmad']['scripts']:
        L.append(f"{ind}  скрипты заклинания:")
        for ln in vmad_props_flat(sp['vmad']):
            L.append(f"{ind}    {ln}")
        for ref in spel_refs_vmad(sp['vmad']):
            if ref not in seen:
                L.append(f"{ind}  скрипт применяет:")
                L.extend(spell_md(ref, seen, depth + 1))
    return L

# ------------------------------------------------------------------- рендер перка
def perk_md(d, star):
    L = []
    tag = 'новая запись PoE' if d['new'] else f"правка ({p.masters[d['formid'] >> 24]})"
    L.append(f"### {d['full'] or d['edid']}")
    meta = [f"**{d['edid']}**", f"formid `0x{d['formid']:08X}`", tag]
    if star is not None:
        pos = ''
        if star['x'] is not None:
            pos = f", позиция ({star['x']:.3g}, {star['y']:.3g})"
        meta.append(f"звезда {star['id']}{pos}")
    if d.get('ranks') and d['ranks'] > 1:
        meta.append(f"рангов: {d['ranks']}")
    if d.get('next'):
        meta.append(f"следующий по NNAM: {fid_label(d['next'])}")
    if d.get('hidden'):
        meta.append('скрытый')
    L.append(' · '.join(meta))
    if d.get('desc'):
        for ln in d['desc'].replace('\r', '').split('\n'):
            if ln.strip():
                L.append(f"> {ln.strip()}")
    if d['perk_conds']:
        L.append("**Требования (условия перка):**")
        L.extend(render_conditions(d['perk_conds']))
    eps = [s for s in d['sections'] if s['type'] == 'ep']
    others = [s for s in d['sections'] if s['type'] != 'ep']
    if d['sections']:
        L.append(f"**Секции эффектов: {len(d['sections'])}**")
    for s in others:
        if s['type'] == 'quest':
            L.append(f"- **Quest-секция**: квест {fid_label(s['quest'])}, стадия {s['stage']} (приоритет {s['prio']})")
        elif s['type'] == 'ability':
            nm = f" «{fid_name(s['spell'])}»" if fid_name(s['spell']) else ''
            L.append(f"- **Ability-секция** (приоритет {s['prio']}): способность {fid_label(s['spell'])}{nm}")
            L.extend(spell_md(s['spell']))
    groups = defaultdict(list)
    for s in eps:
        groups[(s.get('ep'), s.get('fn'))].append(s)
    for (ep, fn), secs in groups.items():
        epn = ENTRY_POINTS.get(ep, f"EP {ep:#04x}")
        fnn = EP_FUNCTIONS.get(fn, f"функция {fn:#04x}")
        L.append(f"- **{epn}** — {fnn} ({len(secs)} секц.)")
        for s in sorted(secs, key=lambda x: -x['prio']):
            val = epfd_value(s)
            line = f"  - приоритет {s['prio']}"
            if val:
                line += f": {val}"
            if s.get('epf2'):
                line += f"; кнопка: «{s['epf2']}»"
            if s.get('epf3') is not None:
                line += f"; EPF3: {epf3_str(s['epf3'])}"
            L.append(line)
            u = s.get('epfd_u')
            if s.get('epft') in (3, 5) and u in p.records:
                L.append(f"    запись: {fid_label(u)}")
                if p.records[u]['type'] == 'SPEL':
                    L.extend(spell_md(u))
            for cg in s['conds']:
                if not cg['ctdas']:
                    continue
                gname = ep_group_name(s.get('ep'), cg['group']) or '—'
                L.append(f"    [{gname}] {join_conds(cg['ctdas'])}")
    if d.get('vmad') and d['vmad']['scripts']:
        L.append("**Скрипты перка:**")
        for ln in vmad_props_flat(d['vmad']):
            L.append(f"  {ln}")
    if d.get('vmad') and d['vmad'].get('fragments'):
        fr = d['vmad']['fragments']
        L.append(f"**Papyrus-фрагменты:** скрипт {fr['script']} — "
                 + ', '.join(x['fragment'] for x in fr['fragments']))
    L.append('')
    return L

# ------------------------------------------------------------------- главный проход
os.makedirs('/home/z/my-project/work/qa96', exist_ok=True)
trees = {}
for f in p.by_type['AVIF']:
    r = p.records[f]
    stars, root_links = parse_avif(r)
    trees[r['edid']] = {'full': r.get('full'), 'stars': [s for s in stars if s['perk'] and not s['root']],
                        'root_links': root_links + ([l for s in stars if s['root'] for l in s['links']] or [])}

tree_perks = set()
for t in trees.values():
    for s in t['stars']:
        tree_perks.add(s['perk'])

out = open(OUT_MD, 'w', encoding='utf-8')
jl = open(OUT_JSONL, 'w', encoding='utf-8')
W = out.write

W("# PoE v1.5.6 — полный дамп перков 18 деревьев навыков\n\n")
W("> Источник: `PathsOfEmpyrean.esp` v1.5.6 (RU, выпущенный; 563 записи PERK). ")
W("Сгенерировано `scripts/perkdump96b.py` (Этап 96, аналитический — правок ESP нет).\n>\n")
W("> Цепочка дампа: PERK (секции эффектов, условия) → SPEL (тип/стоимость/каст/эффекты ")
W("с силой и длительностью) → MGEF (школа, архетип, значения, скрипты, снаряд) → ")
W("PROJ (скорость/гравитация/модель) и HAZD (зона на земле). Каждому перку дано ")
W("игровое описание (DESC) из ESP + механика.\n\n")

total_stars = sum(len(t['stars']) for t in trees.values())
W(f"**Итого**: **{len(tree_perks)} перков в 18 деревьях** (в созвездиях {total_stars} звёзд с перками ")
W(f"+ 18 корневых узлов), остальные {len(p.by_type['PERK']) - len(tree_perks)} записей PERK — служебные, ")
W("вне деревьев (приложение А). Ванильные MGEF, используемые эффектами перков, — приложение Б.\n\n")

W("## Содержание\n\n")
for i, ed in enumerate(TREE_ORDER, 1):
    t = trees[ed]
    W(f"{i}. {t['full']} ({ed}) — {len(t['stars'])} перков\n")
W("\n---\n\n## Легенда\n\n")
W("- **Секции перка** (PRKE): Quest — установить стадию квеста; Ability — постоянная ")
W("способность (SPEL); EntryPoint — точка входа (канонические имена CK/UESP) с условиями ")
W("по группам [Perk Owner] / [Target] / [Weapon] / [Spell] / [Item] и т.д.\n")
W("- **EPFD**: `AV = навык, множитель` — для функций вида × (1 + AV × FACTOR) и т.п.; ")
W("для Select Spell — применяемое заклинание (полный дамп ниже).\n")
W("- **Условия (CTDA)**: `функция(параметр) оператор значение`, цепочки через И/ИЛИ. ")
W("Именованные функции: HasKeyword, HasPerk, GetBaseActorValue (значение навыка), ")
W("GetGlobalValue (MCM-переключатели). Остальные — по индексу `ф.NNN` (индексы стабильны, ")
W("имена можно смотреть в xEdit; параметры разрешены по записям ESP).\n")
W("- **SPEL**: тип (Заклинание/Сила/Малая сила/Способность/Яд/Голос), стоимость маны, ")
W("каст, доставка, зарядка, перк полузатрат. Эффекты: сила/длительность/радиус.\n")
W("- **MGEF**: школа, архетип, PrimaryAV/SecondAV — затрагиваемые значения (карта значений ")
W("выведена из данных PoE), базовая стоимость, флаги, связанные записи (призыв/свет/шейдеры), ")
W("снаряд PROJ, сопротивление. DNAM-описание эффекта — русский текст из ESP.\n")
W("- **PROJ**: тип, скорость, гравитация, дальность, время жизни, модель .nif. ")
W("**HAZD** — зона на земле (огонь и т.п.).\n")
W("- Записи вне ESP: `Мастер#0xNNNNNN` (ваниль/DLC/LostGrimoire); ванильские ключевые слова ")
W("оружия `Skyrim.esm#0x1E71x` — семейство типов/материалов (см. в xEdit).\n\n---\n\n")

all_fn = Counter()
jsonl_records = []

for ti, ed in enumerate(TREE_ORDER, 1):
    t = trees[ed]
    stars = sorted(t['stars'], key=lambda s: (s['id'] is None, s['id']))
    W(f"\n## {ti}. {t['full']} — {len(stars)} перков\n\n")
    W(f"AVIF `{ed}`. Карта созвездия (id → перк, координаты, связи-потомки):\n\n")
    W("| зв. | перк | X | Y | потомки (зв.) |\n|---|---|---|---|---|\n")
    for s in stars:
        r = p.records.get(s['perk'])
        nm = (r.get('full') or r['edid']) if r else fid_label(s['perk'])
        links = ', '.join(str(l) for l in s['links']) or '—'
        xs = f"{s['x']:.3g}" if s['x'] is not None else '—'
        ys = f"{s['y']:.3g}" if s['y'] is not None else '—'
        W(f"| {s['id']} | {nm} | {xs} | {ys} | {links} |\n")
    W('\n')
    for s in stars:
        if not s['perk'] or s['perk'] not in p.records:
            continue
        d = parse_perk(p.records[s['perk']])
        for g in d['perk_conds']:
            for c in g['ctdas']:
                all_fn[c['fn']] += 1
        for sec in d['sections']:
            for g in sec['conds']:
                for c in g['ctdas']:
                    all_fn[c['fn']] += 1
        jsonl_records.append({'tree': t['full'], 'star': s['id'], 'perk': d['edid'],
                              'formid': f"{d['formid']:08X}", 'full': d['full']})
        W('\n'.join(perk_md(d, s)))
        W('\n')

# приложение А
W("\n---\n\n## Приложение А. Перки вне деревьев (служебные/скриптовые)\n\n")
W(f"{len(p.by_type['PERK']) - len(tree_perks)} записей PERK не привязаны к звёздам: квестовые ")
W("менеджеры систем, MCM-обработчики, внутренние ступени. Список (EDID — имя):\n\n")
for f in sorted(p.by_type['PERK'], key=lambda x: p.records[x]['edid'] or ''):
    if f in tree_perks:
        continue
    r = p.records[f]
    W(f"- `{r['edid']}` — «{r.get('full') or '—'}» (`0x{f:08X}`)\n")

# приложение Б
W("\n## Приложение Б. Ванильные MGEF вне ESP, используемые эффектами перков\n\n")
if van_mgef_used:
    for v, n in van_mgef_used.most_common():
        W(f"- `0x{v:08X}` ×{n} — {VANILLA_MGEF.get(v, 'ванильный эффект (см. xEdit)')}\n")
else:
    W("(в деревьях не использованы)\n")

# приложение В
W("\n## Приложение В. Функции условий (CTDA) по индексам\n\n")
for fn, n in all_fn.most_common():
    nm = FN_NAMES.get(fn, '')
    W(f"- ф.{fn}{(' = ' + nm) if nm else ''} — {n} условий\n")

out.close()
for rec in jsonl_records:
    jl.write(json.dumps(rec, ensure_ascii=False) + '\n')
jl.close()

print('OK ->', OUT_MD)
print('деревья:', len(trees), '| перков:', len(tree_perks), '| строк md:',
      sum(1 for _ in open(OUT_MD, encoding='utf-8')))
print('ванильных MGEF в цепочках:', len(van_mgef_used))
