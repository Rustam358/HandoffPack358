#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 98: извлечение имён функций/классов KID из PDB (SE-вариант).

Адаптация scripts/pdb_symbols.py (Этап 97) под Keyword Item Distributor 4.1.0.
Выход: kid_work/pdb_kid_funcs.txt, kid_work/pdb_all_names.txt
"""
import collections
import re

PDB = ("/home/z/my-project/kid_work/kid_extracted/"
       "Keyword Item Distributor FOMOD Installer/SE/SKSE/Plugins/"
       "po3_KeywordItemDistributor.pdb")
data = open(PDB, "rb").read()
print(f"PDB size: {len(data)/1e6:.1f} MB")

# collect ascii strings >= 6 chars
strs = set()
for m in re.finditer(rb"[\x20-\x7e]{6,400}", data):
    s = m.group().decode("ascii", "ignore")
    strs.add(s)
print(f"Unique strings: {len(strs)}")

# KID-specific namespaces
kid_pat = re.compile(
    r"(Keyword|Distribute|Forms?|Filter|ItemData|INI|FormData|Settings|"
    r"ExclusiveGroups|KeywordDependencies|Hooks|MergeMapper|Distributable)")

funcs = [s for s in strs if "__cdecl" in s or "::" in s]
kid_funcs = [s for s in funcs if kid_pat.search(s)
             and "std::" not in s.split("(")[0][:60]]
mangled = [s for s in strs if s.startswith("?")
           and re.search(r"(Keyword|Distribut|ItemData|ExclusiveGroup)", s)]

print(f"Function-like strings: {len(funcs)}, KID-specific: {len(kid_funcs)}, "
      f"mangled KID: {len(mangled)}")

with open("/home/z/my-project/kid_work/pdb_kid_funcs.txt", "w") as f:
    for s in sorted(set(kid_funcs)):
        f.write(s + "\n")
with open("/home/z/my-project/kid_work/pdb_all_names.txt", "w") as f:
    for s in sorted(strs):
        f.write(s + "\n")

# Classify by namespace
buckets = collections.defaultdict(set)
for s in set(kid_funcs):
    m = re.match(r"([A-Za-z_][A-Za-z0-9_]*(?:::[A-Za-z_][A-Za-z0-9_]*)*)", s)
    if m:
        ns = m.group(1)
        parts = ns.split("::")
        buckets["::".join(parts[:2])].add(s)

print("\n=== TOP NAMESPACE BUCKETS ===")
for k in sorted(buckets, key=lambda k: -len(buckets[k]))[:45]:
    print(f"{len(buckets[k]):4d}  {k}")
