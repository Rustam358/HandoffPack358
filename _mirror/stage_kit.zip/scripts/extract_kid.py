#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 98: распаковка 7z Keyword Item Distributor 4.1.0 (Nexus 55728).

Вход:  upload/Keyword Item Distributor (SE AE) 55728 4.1.0 ...7z
Выход: kid_work/kid_extracted/

ВНИМАНИЕ: архив сжат BCJ2-фильтром (LZMA2:27 LZMA:20 BCJ2) — py7zr его НЕ
читает (UnsupportedCompressionMethodError). Нужен настоящий 7-Zip:
официальный статический бинарь 7zz (7-zip.org / github ip7z/7zip),
например 7z2409-linux-x64.tar.xz → tar -xJf → ./7zz x.
Скрипт сам ищет 7zz в PATH и /tmp, при отсутствии печатает инструкцию.
"""
import os
import shutil
import subprocess
import sys

SRC = ("/home/z/my-project/upload/"
       "Keyword Item Distributor (SE AE) 55728 4.1.0 "
       "2026-08-25T01-04Z 587RqTfrf.7z")
DST = "/home/z/my-project/kid_work/kid_extracted"

exe = shutil.which("7zz") or ("/tmp/7zz" if os.access("/tmp/7zz", os.X_OK)
                              else None)
if exe is None:
    sys.exit("7zz не найден. Скачать: "
             "https://github.com/ip7z/7zip/releases/download/24.09/"
             "7z2409-linux-x64.tar.xz, распаковать 7zz в /tmp/.")

os.makedirs(DST, exist_ok=True)
r = subprocess.run([exe, "x", "-y", f"-o{DST}", SRC],
                   capture_output=True, text=True)
print(r.stdout[-2000:])
if r.returncode != 0:
    sys.exit(f"7zz failed: {r.stderr[-1000:]}")
print("--- extracted to", DST)
