#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 104: батарея верификации пакета v1.5.9.
1) дамп ESP из ВЫПУСКНОГО zip в download/ -> work/qa104/dump_v159.jsonl;
2) точный дифф с dump_v158 (ровно 2 записи ESP);
3) 0 «скрыт(не скрытн)» вне белого списка (EN "hidden"/вскрытие/раскрытие);
4) ini: 16/16/64 «урон скрытной атакой», 0 старых; скан всего zip utf8/utf16/cp1251;
5) [T26]: цифры изменённых полей не изменились; DESC <= 290;
6) построчный дифф ini: только слово «скрытной/скрытой», счёт строк 16/16/64.
"""
import sys, os, json, re, zipfile, difflib, collections

sys.path.insert(0, '/home/z/my-project/upload/poe_pack/scripts')
from dump150 import dump_esp

ROOT = '/home/z/my-project/upload/poe_pack'
DL = '/home/z/my-project/download/Paths of Empyrean RU 1.5.zip'
Q104 = f'{ROOT}/work/qa104'
NEW_ESP = f'{Q104}/v159/00 Core/PathsOfEmpyrean.esp'

rx_bad = re.compile(r'скрыт(?!н)', re.I)
WHITELIST = [
    (r'скрытого дракона', 'EN "Hidden Dragon Style" — стилевое имя, не скрытность'),
    (r'\(скрытый\)', 'EN "Advanced Bolts (Hidden)" — букв. hidden'),
]


def rec_key(r):
    return (r['file'], r['rtype'], r['formid'], r['edid'], r['field'], r['occ'])


def main():
    print('=== 1. Дамп ESP из выпущенного пакета ===')
    out = open(f'{Q104}/dump_v159.jsonl', 'w', encoding='utf-8')
    p = dump_esp(NEW_ESP, 'main', out)
    out.close()
    print('  main: records =', len(p.records))

    new = {}
    for line in open(f'{Q104}/dump_v159.jsonl', encoding='utf-8'):
        r = json.loads(line)
        new[rec_key(r)] = r['text']
    old = {}
    for line in open(f'{ROOT}/work/qa103/dump_v158.jsonl', encoding='utf-8'):
        r = json.loads(line)
        if r['file'] == 'main':  # остальные ESP не патчились (CRC-дифф байт-в-байт, см. build104)
            old[rec_key(r)] = r['text']

    print('=== 2. Дифф с dump_v158 ===')
    assert set(new) == set(old), 'состав записей дампа изменился!'
    diff = [k for k in old if old[k] != new[k]]
    assert len(diff) == 2, f'ожидались ровно 2 изменённые записи, получено {len(diff)}: {diff}'
    for k in sorted(diff, key=str):
        print('  *', k[2], k[3], k[4])
        print('     СТАРОЕ:', old[k])
        print('     НОВОЕ :', new[k])

    print('=== 3. «скрыт(не скрытн)» в дампе вне белого списка ===')
    bad = 0
    for k, t in new.items():
        stripped = t
        for pat, _why in WHITELIST:
            stripped = re.sub(pat, ' ', stripped, flags=re.I)
        # вс-крыт / ра-крыт — подстрочные артефакты, не термин
        stripped = re.sub(r'вскрыт|раскрыт', ' ', stripped, flags=re.I)
        if rx_bad.search(stripped):
            print('  ОСТАЛОСЬ:', k, '->', t[:120])
            bad += 1
    assert bad == 0, f'незакрытых вхождений: {bad}'
    print('  OK: 0 вхождений вне белого списка (скрытого дракона / (скрытый) / вскр-раскрыт)')

    print('=== 4. Скан выпущенного zip ===')
    z = zipfile.ZipFile(DL)
    rx_new = 'урон скрытной атакой'
    rx_old = 'урон скрытой атакой'
    inis = {
        '00 Core/PathsOfEmpyrean_DESC.ini': 16,
        '30 CC Patches/Advanced Crossbows/PoE-CCAdvancedCrossbows-Patch_DESC.ini': 16,
        '30 CC Patches/Expanded Crossbow Pack/PoE-CCExpandedCrossbowPack-Patch_DESC.ini': 64,
    }
    for name, expect in inis.items():
        raw = z.read(name).decode('utf-8')
        nn, no = raw.count(rx_new), raw.count(rx_old)
        assert nn == expect and no == 0, f'{name}: новых={nn} старых={no}'
        print(f'  {os.path.basename(name)}: скрытной={nn}, старой=0')
    # весь архив, все кодировки
    rx = re.compile('скрыт', re.I)
    for name in z.namelist():
        raw = z.read(name)
        for enc, dec in (('utf-8', None), ('utf-16-le', None), ('cp1251', None)):
            try:
                txt = raw.decode(enc, errors='ignore') if dec is None else raw.decode(enc)
            except Exception:
                continue
            if rx_bad.search(re.sub(r'вскрыт|раскрыт|скрытого дракона|\(скрытый\)', ' ', txt, flags=re.I)):
                raise SystemExit(f'ОСТАЛОСЬ в {name} ({enc})')
    print('  весь архив: 0 «скрыт(не скрытн)» вне белого списка (utf8/utf16/cp1251)')

    print('=== 5. [T26] цифры + длина DESC ===')
    # цифры изменённых ESP-полей
    for k in diff:
        d_o = re.findall(r'<(\d+)>|\b(\d+)\b', old[k])
        d_n = re.findall(r'<(\d+)>|\b(\d+)\b', new[k])
        assert [a or b for a, b in d_o] == [a or b for a, b in d_n], f'цифры поехали: {k}'
        print(f'  {k[2]} {k[3]}: цифры без изменений {[a or b for a, b in d_n]}')
        if k[4] == 'DESC':
            assert len(new[k]) <= 290, f'DESC > 290: {len(new[k])}'
            print(f'  длина DESC: {len(new[k])} <= 290')

    print('=== 6. Построчный дифф ini ===')
    zs = zipfile.ZipFile(ROOT + '/Paths of Empyrean RU 1.5.zip')
    for name, expect in inis.items():
        a = zs.read(name).decode('utf-8').splitlines()
        b = z.read(name).decode('utf-8').splitlines()
        assert len(a) == len(b)
        changes = [i for i, (x, y) in enumerate(zip(a, b)) if x != y]
        assert len(changes) == expect, f'{name}: строк с изменениями {len(changes)} != {expect}'
        for i in changes:
            assert a[i].replace('скрытой атакой', 'скрытной атакой') == b[i], f'{name}:{i+1} не чистая замена'
        print(f'  {os.path.basename(name)}: {len(changes)} строк, каждая — только скрытой->скрытной')

    print()
    print('БАТАРЕЯ ЗЕЛЁНАЯ: пакет v1.5.9 согласован (ESP +3 ini +2 fomod, 98 замен, 0 старых вхождений)')


if __name__ == '__main__':
    main()
