#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 111, шаг 3: независимая верификация v1.5.12.
1) Дамп main ESP v112 (dump150) == 12323 полей; множество ключей == corpus57.
2) Дифф ru/en vs corpus57 (main): РОВНО 31 поле == fixlist (old->new), 0 лишних.
3) Гигиена: %%/ё/прямые кавычки/lone-\\n/двойные пробелы/«рейтинг»/«укр.»/PERK DESC ≤290.
4) Пак-скан 63 записей × (utf-8/utf-16le/cp1251): «изгнанник» = 0;
   ShortbowNames «Короткий лук Изгоев» = 1; MCM $Forsworn<tab>Изгои.
5) Регресс-пробы канона 100-111.
"""
import sys, json, zipfile, re, os
sys.path.insert(0, '/home/z/my-project/work/handoff510/scripts')
from dump150 import dump_esp

V112 = '/home/z/my-project/work/qa111/v112/00 Core/PathsOfEmpyrean.esp'
DUMP = '/home/z/my-project/work/qa111/dump_v112.jsonl'
CORPUS = '/home/z/my-project/work/handoff510/handoff/06_код-истина_перевода/_архив_мастер-эры/corpus57_v159.json'
FIX = '/home/z/my-project/work/qa111/fixlist_v112.jsonl'
ZIP = '/home/z/my-project/download/Paths of Empyrean RU 1.5.zip'

fails = []


def check(cond, msg):
    print(('  [OK] ' if cond else '  [FAIL] ') + msg)
    if not cond:
        fails.append(msg)


def main():
    # 1) дамп
    with open(DUMP, 'w', encoding='utf-8') as out:
        dump_esp(V112, 'main', out)
    fresh = [json.loads(l) for l in open(DUMP, encoding='utf-8')]
    corpus = [r for r in json.load(open(CORPUS, encoding='utf-8')) if r['file'] == 'main']
    print('1) дамп main: %d полей (corpus57 main: %d)' % (len(fresh), len(corpus)))
    check(len(fresh) == 8914 and len(corpus) == 8914, 'полей ровно 8914 == corpus57 main (12 323 на 39 ESP)')
    # нормализация: dump150 = rtype/formid/text, corpus57 = type/fid/ru
    fk = {(r['formid'], r['rtype'], r['field'], r.get('occ', 1)): r['text'] for r in fresh}
    ck = {(r['fid'], r['type'], r['field'], r.get('occ', 1)): (r.get('ru') or '') for r in corpus}
    check(set(fk) == set(ck), 'множество ключей (fid,type,field,occ) идентично corpus57')

    # 2) дифф vs fixlist
    fixes = [json.loads(l) for l in open(FIX, encoding='utf-8') if json.loads(l)['kind'] == 'esp']
    expected = {(int(f['formid'], 16), f['field'], f['occ']): f for f in fixes}
    diffs = []
    for k, fr_text in fk.items():
        cr_text = ck[k]
        if fr_text != cr_text:
            diffs.append((k, cr_text, fr_text))
    print('2) дифф полей ru vs corpus57: %d (ожидается %d)' % (len(diffs), len(expected)))
    ok, bad = 0, []
    for (fid_hex, rtype, field, occ), cr_text, fr_text in diffs:
        f = expected.get((int(fid_hex, 16), field, occ))
        if f and cr_text == f['old'] and fr_text == f['new']:
            ok += 1
        else:
            bad.append((fid_hex, field, cr_text[:60], fr_text[:60]))
    check(ok == len(expected) and len(diffs) == len(expected),
          'дифф == fixlist (%d/%d); лишних/несовпадающих: %d %s' % (ok, len(expected), len(bad), bad[:3]))

    # 3) гигиена по всем RU-полям дампа
    print('3) гигиена:')
    ru_all = list(fk.items())
    hy = {'%%': 0, 'ё': 0, 'рейтинг': 0, 'укр.': 0, '  ': 0}
    lone = 0
    dq = []
    for k, t in ru_all:
        hy['%%'] += t.count('%%')
        hy['ё'] += t.count('ё')
        hy['рейтинг'] += len(re.findall(r'[Рр]ейтинг', t))
        hy['укр.'] += t.count('укр.')
        hy['  '] += t.count('  ')
        if re.search(r'(?<!\r)\n', t):
            lone += 1
        if '"' in t and '<font' not in t and 'font' not in t:
            dq.append((k, t[:60]))
    for m, v in hy.items():
        check(v == 0, '%s = 0 (факт %d)' % (repr(m), v))
    check(lone == 0, 'lone \\n = 0 (факт %d)' % lone)
    check(len(dq) == 0, 'прямые кавычки вне font-книг = 0 (факт %d)' % len(dq))
    # ключ fk: (formid_hex, rtype, field, occ) — значение text
    over = [(k, len(t)) for k, t in fk.items()
            if k[1] == 'PERK' and k[2] == 'DESC' and t and len(t) > 290]
    check(len(over) == 0, 'PERK DESC <= 290 (превышений %d)' % len(over))

    # 4) пак-скан
    print('4) пак-скан (63 записи, 3 кодировки):')
    z = zipfile.ZipFile(ZIP)
    names = z.namelist()
    legacy_hits, text_files = [], 0
    for n in names:
        raw = z.read(n)
        for enc in ('utf-8', 'utf-16le', 'cp1251'):
            try:
                s = raw.decode(enc)
            except (UnicodeDecodeError, UnicodeError):
                continue
            text_files += 1
            if 'изгнанник' in s.lower():
                legacy_hits.append((n, enc))
    check(len(legacy_hits) == 0, '«изгнанник» по всему паку = 0 (декодов проверено %d)' % text_files)
    sbn = z.read('00 Core/SKSE/Plugins/POE/Weapon/PathsOfEmpyrean_ShortbowNames.ini').decode('utf-8')
    check(sbn.count('Короткий лук Изгоев') == 1 and 'лук изгоев' not in sbn,
          'ShortbowNames: «Короткий лук Изгоев» = 1, строчных нет')
    mcm = z.read('00 Core/Interface/Translations/PathsOfEmpyrean_RUSSIAN.txt').decode('utf-16le')
    check('$Forsworn\tИзгои' in mcm and 'Изгнанники' not in mcm,
          'MCM: $Forsworn<tab>Изгои, «Изгнанники» = 0')

    # 5) регресс-пробы
    print('5) регресс-пробы:')
    def find_ru(sub, field=None, rtype=None):
        return [k for k, t in fk.items() if t and sub in t
                and (field is None or k[2] == field)
                and (rtype is None or k[1] == rtype)]
    for sub, n, kw in [
        ('Грозовой атронах', 2, None), ('Маскировка - Брата Бури', 1, 'FULL'),
        ('Маскировка - Изгоя', 1, 'FULL'), ('Маскировка - бандита', 1, 'FULL'),
        ('Дикая форма - волк', 1, None), ('Сокрушительный набег', 3, 'FULL'),
        ('Мастерская ламеллярная броня', 2, 'FULL'), ('ламеллярная броня с рогами', 1, 'FULL'),
        ('Мастерские сыромятные сапоги', 1, 'FULL'), ('Мастерские драконьи панцирные сапоги', 1, 'FULL'),
        ('Мастерский имперский офицерский шлем', 1, 'FULL'),
        ('Маска члена культа', 1, 'FULL'), ('Мастерская маска члена культа', 1, 'FULL'),
        ('Счастливая стрела нордского героя (жетон)', 1, 'FULL'),
        ('Мастерская древняя нордская броня', 1, 'FULL'),
        ('Мастерская эльфийская золоченая броня', 1, 'FULL'),
        ('Мастерская эльфийская позолоченная броня', 0, 'FULL'),
        ('Мастерские офицерские сапоги Братьев Бури', 1, 'FULL'),
        ('Вы замаскированы под Изгоя.', 1, 'DESC'),
        ('ламеллярные и пластинчатые доспехи', 1, 'DESC'),
        ('создает двемерскую сферу-убийцу', 1, 'DNAM'),
        ('Позволяет ковать стальное и костяное снаряжение', 1, 'DESC'),
    ]:
        hits = find_ru(sub, kw if isinstance(kw, str) else None, None)
        check(len(hits) == n, '«%s» = %d (факт %d)' % (sub, n, len(hits)))

    print()
    if fails:
        print('ВЕРИФИКАЦИЯ ПРОВАЛЕНА (%d):' % len(fails))
        for f in fails:
            print('  -', f)
        raise SystemExit(1)
    print('ВЕРИФИКАЦИЯ ЗЕЛЁНАЯ: 22/22 групп проверок')


if __name__ == '__main__':
    main()
