#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Дамп ESP из загруженного пакета v1.5.0 (для сверки с v1.4.9 и поиска проблемных строк)."""
import sys, os, json

sys.path.insert(0, '/home/z/my-project/scripts')

TEXT_FIELDS = {'FULL', 'DESC', 'ITXT', 'NNAM'}

def decode(b):
    try:
        return b.rstrip(b'\x00').decode('utf-8')
    except UnicodeDecodeError:
        return b.rstrip(b'\x00').decode('utf-8', 'replace')

def dump_esp(path, tag, out):
    from parse_tes4 import Plugin
    p = Plugin(path)
    for formid, r in p.records.items():
        rtype = r['type']
        edid = r.get('edid') or ''
        occ = {}
        for st, sd in r['subs']:
            text = None
            if st in TEXT_FIELDS:
                if st == 'NNAM' and rtype == 'PERK':
                    continue
                text = decode(sd)
            elif st == 'DNAM' and rtype == 'MGEF':
                try:
                    cand = sd.rstrip(b'\x00').decode('utf-8')
                except UnicodeDecodeError:
                    cand = None
                if cand:
                    ctrl = sum(1 for c in cand if ord(c) < 32 and c != '\n')
                    letters = sum(1 for c in cand if c.isalpha())
                    spaces = cand.count(' ')
                    if ctrl == 0 and letters >= 4 and (spaces >= 1 or len(cand) <= 64):
                        text = cand
            elif st == 'DATA' and rtype == 'GMST':
                if edid.startswith('s'):
                    text = decode(sd)
            if text is None:
                continue
            key = (rtype, formid, st)
            occ[key] = occ.get(key, 0) + 1
            rec = {'file': tag, 'rtype': rtype, 'formid': f'{formid:08X}',
                   'edid': edid, 'field': st, 'occ': occ[key], 'text': text}
            out.write(json.dumps(rec, ensure_ascii=False) + '\n')
    return p

def main():
    base = '/home/z/my-project/work/v150'
    jobs = [
        (f'{base}/00 Core/PathsOfEmpyrean.esp', 'main'),
        (f'{base}/10 Missing Shields/PoE-Addon-MissingShields.esp', 'ms'),
        (f'{base}/20 Spears/PoE-Addon-Spears.esp', 'sp'),
    ]
    with open('/home/z/my-project/work/qa89/dump_ru150.jsonl', 'w', encoding='utf-8') as out:
        n = 0
        for path, tag in jobs:
            p = dump_esp(path, tag, out)
            n += len(p.records)
            print(f'{tag}: records={len(p.records)}')
        print(f'total: {n}')

if __name__ == '__main__':
    main()
