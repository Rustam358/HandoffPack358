#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 98: условия перков PoE на оружейные ключевики.

Ищем PERK-записи с CTDA HasKeyword на PoE_K_WeapTypeBladed1H (0641D79A)
и печатаем ПОЛНЫЙ список условий HasKeyword — есть ли ванильные
WeapTypeSword/WeapTypeGreatsword рядом (альтернатива для клонов без OCF-ключей).
"""
import struct
import sys

sys.path.insert(0, "/home/z/my-project/scripts")
from parse_tes4 import Plugin

CORE = "/home/z/my-project/work/v156/00 Core/PathsOfEmpyrean.esp"
core = Plugin(CORE)

# PoE_K_WeapTypeBladed1H и соседние
TARGETS = {
    0x0641D79A: "PoE_K_WeapTypeBladed1H",
    0x0641D79B: "PoE_K_WeapTypeBladed2H",
    0x0641D79E: "PoE_K_WeapTypePiercing1H",
    0x0641D79F: "PoE_K_WeapTypePiercing2H",
}
KNOWN = {
    0x0001E711: "WeapTypeSword(Skyrim)",
    0x0006D931: "WeapTypeGreatsword",
    0x0006D932: "WeapTypeBattleaxe",
    0x0008F958: "VendorItemWeapon",
}

def ctda_keywords(r):
    """все CTDA c функцией HasKeyword (CTDA data = keyword formID)."""
    out = []
    for st, sd in r["subs"]:
        if st != "CTDA" or len(sd) < 24:
            continue
        # CTDA: oper(1) unused(3) IFUNC(2) arg-count(2) params(8) comp(4) ...
        oper = sd[0]
        ifunc = struct.unpack_from("<H", sd, 4)[0]
        if ifunc in (0x469, 0x46A):  # HasKeyword / HasKeywordWithKeyword... подстраховка
            kwfid = struct.unpack_from("<I", sd, 8)[0]
            out.append((oper, ifunc, kwfid))
    return out

hits = 0
for fid, r in core.records.items():
    if r["type"] != "PERK":
        continue
    cts = ctda_keywords(r)
    tgts = [c for c in cts if c[2] in TARGETS]
    if not tgts:
        continue
    hits += 1
    if hits > 6:
        continue
    print(f"\n### PERK {fid:#010x} [{r['edid']}] «{r.get('full')}»")
    for oper, ifunc, kw in cts:
        name = TARGETS.get(kw) or KNOWN.get(kw)
        if not name:
            # резолв self-KYWD из core
            kwr = core.records.get(kw)
            if kwr and kwr["type"] == "KYWD":
                name = f"KYWD:{kwr['edid']}"
            else:
                idx, off = kw >> 24, kw & 0xFFFFFF
                name = f"raw{kw:#010x}"
        print(f"    CTDA oper={oper:#04x} ifunc={ifunc:#06x} -> {name}")

print(f"\nперков с условиями на PoE_K_WeapType*(Bladed/Piercing): {hits}")
