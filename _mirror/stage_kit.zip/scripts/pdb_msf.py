#!/usr/bin/env python3
"""Minimal MSF (PDB) container parser: extract streams, then hunt enum members.

MSF Superblock:
  magic 24 bytes, block_size u32, free_block_map u32, num_blocks u32,
  directory_size u32, unknown u32, block_map_addr u32
Stream dir = array of u32 stream sizes, then u32 block numbers per stream."""
import struct, sys, re

PDB = "/home/z/my-project/spid_work/spid_extracted/SKSE/Plugins/po3_SpellPerkItemDistributor.pdb"
data = open(PDB, "rb").read()

MAGIC = b"Microsoft C/C++ MSF 7.00\r\n\x1aDS\x00\x00\x00"
assert data.startswith(MAGIC), "not MSF 7.00"
SB = len(MAGIC)  # 32 bytes
block_size, free_map, num_blocks, dir_size, _unk, block_map_addr = struct.unpack_from("<IIIIII", data, SB)
print(f"block_size={block_size}, num_blocks={num_blocks}, dir_size={dir_size}, block_map_addr={block_map_addr}", flush=True)
assert block_size in (512, 1024, 2048, 4096, 8192, 16384), "bad block size - wrong superblock offset"

def block(off):  # block index -> file offset
    return off * block_size

# block map: array of u32 block indices containing the directory
nblocks_dir = (dir_size + block_size - 1) // block_size
map_off = block(block_map_addr)
dir_blocks = struct.unpack_from(f"<{nblocks_dir}I", data, map_off)
directory = b"".join(data[block(b): block(b) + block_size] for b in dir_blocks)[:dir_size]

# parse directory: stream count, then sizes, then block lists
pos = 0
num_streams = struct.unpack_from("<I", directory, pos)[0]; pos += 4
sizes = []
for i in range(num_streams):
    sz = struct.unpack_from("<I", directory, pos)[0]; pos += 4
    sizes.append(sz)
streams = []
for i, sz in enumerate(sizes):
    nblks = (sz + block_size - 1) // block_size if sz != 0xFFFFFFFF else 0
    blks = struct.unpack_from(f"<{nblks}I", directory, pos) if nblks else ()
    pos += 4 * nblks
    content = b"".join(data[block(b): block(b) + block_size] for b in blks)[:sz] if sz != 0xFFFFFFFF else b""
    streams.append(content)
print(f"streams: {num_streams}")

# stream 1 or named: find the named-streams table. It's usually stream 1 ("/names" of names? no).
# Named stream directory lives in the DBI stream (3): header + names hash. Simpler: scan each stream
# for readable strings and identify by signature.
for i, s in enumerate(streams):
    head = s[:32]
    tag = ""
    if s.startswith(b"\x0eff\x0eff"): tag = "names/hash stream (global names)"
    print(f"stream {i}: {len(s)} bytes, head={head[:20]!r}")

# TPI stream signature 0x53445352 ('RSDS'?) no: TPI starts with version u32 (e.g. 0x00000001?) Actually
# TPI/IPI start with 'VPDx'? no. They start with: version u32, header_size u32, ... signature is version like 19980827..20090201 then index ranges.
for i, s in enumerate(streams):
    if len(s) > 100:
        ver, hsz, minx, maxx = struct.unpack_from("<IIII", s, 0)
        if 19950320 <= ver <= 20240000 and hsz in (0x38, 0x54, 0x5c):
            print(f"stream {i}: looks like TPI/IPI ver={ver} idx {minx}..{maxx}")
