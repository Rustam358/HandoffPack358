# -*- coding: utf-8 -*-
"""Дамп всех текстовых полей ESP пакета v1.5.7 (истина) -> work/qa100/dump_v157.jsonl."""
import sys, json
sys.path.insert(0, '/home/z/my-project/scripts')
from dump150 import dump_esp

BASE = '/home/z/my-project/work/v157'
JOBS = [
    (f'{BASE}/00 Core/PathsOfEmpyrean.esp', 'main'),
    (f'{BASE}/10 Missing Shields/PoE-Addon-MissingShields.esp', 'ms'),
    (f'{BASE}/20 Spears/PoE-Addon-Spears.esp', 'sp'),
]
import glob, os
for path in sorted(glob.glob(f'{BASE}/30 CC Patches/*/*.esp')):
    tag = 'cc:' + os.path.basename(path).replace('PoE-CC', '').replace('-Patch.esp', '')
    JOBS.append((path, tag))

with open('/home/z/my-project/work/qa100/dump_v157.jsonl', 'w', encoding='utf-8') as out:
    total = 0
    for path, tag in JOBS:
        p = dump_esp(path, tag, out)
        print(f'{tag}: records={len(p.records)}')
        total += len(p.records)
    print('total records:', total)
