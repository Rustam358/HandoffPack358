#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 95, часть 2: подсистемы PoE по EDID-префиксам, TREE/FLOR, перки vs ваниль."""
import sys, re, struct
from collections import defaultdict

sys.path.insert(0, '/home/z/my-project/upload/poe_pack/scripts')
from parse_tes4 import Plugin

BASE = '/home/z/my-project/work/v156'
p = Plugin(f'{BASE}/00 Core/PathsOfEmpyrean.esp')

# 1. SMEN/SMBN/SMQN в бинарнике?
buf = p.buf
for sig in (b'SMEN', b'SMBN', b'SMQN', b'SKIL'):
    cnt = buf.count(sig)
    print(f'сигнатура {sig.decode()} в бинарнике: {cnt}')

# 2. TREE / FLOR — что за записи
print('\n### TREE EDID-образцы (первые 12):')
for f in p.by_type.get('TREE', [])[:12]:
    r = p.records[f]
    print(f"  0x{f:08X} {r['edid']} | {r['full']}")
print('### FLOR EDID-образцы (первые 12):')
for f in p.by_type.get('FLOR', [])[:12]:
    r = p.records[f]
    print(f"  0x{f:08X} {r['edid']} | {r['full']}")

# 3. Подсистемы по префиксам: типы записей + образцы FULL
fams = defaultdict(lambda: defaultdict(list))
for fid, r in p.records.items():
    if (fid >> 24) >= len(p.masters) and r['edid']:
        pref = r['edid'].split('_')[0]
        fams[pref][r['type']].append(r)
print('\n### Подсистемы (префикс EDID → типы → образцы имён):')
for pref in ('IWP', 'PoE', 'ISP', 'IMP', 'IAP', 'GRIM', 'SF'):
    if pref not in fams:
        continue
    d = fams[pref]
    print(f'\n--- {pref}: {sum(len(v) for v in d.values())} записей; типы: ' + ', '.join(f'{k}={len(v)}' for k, v in sorted(d.items(), key=lambda x: -len(x[1]))[:8]))
    shown = 0
    for t in ('PERK', 'SPEL', 'MGEF', 'WEAP', 'ARMO', 'MISC', 'ACTI', 'CONT', 'NPC_', 'MESG', 'ENCH', 'FLST'):
        for r in d.get(t, [])[:3]:
            if r['full'] and shown < 14:
                print(f'   [{t}] {r["full"]}')
                shown += 1

# 4. Ванильные PERK-правки: старое имя (известное по ванили) → новое
ovr = [(f, p.records[f]) for f in p.by_type['PERK'] if (f >> 24) < len(p.masters)]
print(f'\n### Ванильных PERK переопределено: {len(ovr)}')
by_master = defaultdict(list)
for f, r in ovr:
    by_master[p.masters[f >> 24]].append((f, r))
for m, lst in by_master.items():
    print(f'-- {m}: {len(lst)}')
    for f, r in lst[:14]:
        print(f"   0x{f:06X} {r['edid']} → «{r['full']}»")

# 5. DATA-байты перков: сколько скрытых/неплейабельных среди новых
hidden = play = 0
perk_data = []
for f in p.by_type['PERK']:
    r = p.records[f]
    dt = next((sd for st, sd in r['subs'] if st == 'DATA'), None)
    if dt and len(dt) >= 5:
        is_new = (f >> 24) >= len(p.masters)
        perk_data.append((r['edid'], dt[3], dt[4], is_new))
hid_new = sum(1 for e, pl, h, n in perk_data if n and h)
hid_old = sum(1 for e, pl, h, n in perk_data if not n and h)
print(f'\n### PERK hidden-флаг: новых скрыто {hid_new}, ванильных-правок скрыто {hid_old}')

# 6. Новые COBJ: что крафтится (по FULL/анализу CNAM?)
cobj_new = [p.records[f] for f in p.by_type['COBJ'] if (f >> 24) >= len(p.masters)]
print(f'\n### COBJ новых: {len(cobj_new)}')
# образцы EDID
for r in cobj_new[:15]:
    print(f"   {r['edid']}")
