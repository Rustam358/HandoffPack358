#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 98: KWDA-проверка — запечены ли классификационные ключевики
в записях самого PoE (core + Spears), или их выдаёт только KID по именам?

Если ключевики (OCF_WeapType*, PoE_K_WeapType*, WeapType*) есть в KWDA
записи ESP — перевод FULL ничего не ломает (правило KID просто дублирует).
Если нет — классификация аддонного оружия держится на EN-именах.
"""
import struct
import sys

sys.path.insert(0, "/home/z/my-project/scripts")
from parse_tes4 import Plugin

CORE = "/home/z/my-project/work/v156/00 Core/PathsOfEmpyrean.esp"
SPEARS = "/home/z/my-project/work/v156/20 Spears/PoE-Addon-Spears.esp"


def keywords_of(p, fid):
    r = p.records.get(fid)
    if not r:
        return None
    kws = []
    for st, sd in r["subs"]:
        if st == "KSIZ":
            continue
        if st == "KWDA":
            n = len(sd) // 4
            for i in range(n):
                kfid = struct.unpack_from("<I", sd, i * 4)[0]
                kws.append(p.label(kfid))
    return kws


def show(p, name, fid):
    kws = keywords_of(p, fid)
    r = p.records.get(fid)
    full = r["full"] if r else "?"
    edid = r["edid"] if r else "?"
    print(f"\n### {name}: {fid:#010x} [{edid}] «{full}»")
    if kws is None:
        print("  запись не найдена")
        return
    print(f"  ключевиков: {len(kws)}")
    for k in kws:
        print(f"    - {k}")


core = Plugin(CORE)
print(f"core: {len(core.records)} записей, мастеров {len(core.masters)}")

# Masterwork-образцы (имя-зависимые по анализу EN-дампа)
show(core, "Masterwork Steel Greatsword", 0x0608A1F7)
show(core, "Masterwork Blades Sword", 0x060AA615)
show(core, "Masterwork Shrouded Armor", 0x06090D23)
# обычное оружие PoE (клон ванильного)
show(core, "Masterwork Orcish Greatsword", 0x0608A418)

# --- Spears аддон ---
spears = Plugin(SPEARS)
print(f"\nspears: {len(spears.records)} записей, мастеров {len(spears.masters)}:")
for m in spears.masters:
    print("   ", m)

weap = [fid for fid in spears.by_type.get("WEAP", [])][:400]
print(f"\nWEAP в аддоне: {len(weap)}")
# ищем спиры: FULL/EDID c 'spear'/'pike'/'lance'
import re
spear_re = re.compile(r"spear|pike|lance|halberd|glaive", re.I)
found = 0
stats = {"с_ключами": 0, "без_ключей": 0, "имя_или_edid_spear": 0}
for fid in weap:
    r = spears.records[fid]
    edid = r["edid"] or ""
    full = r["full"] or ""
    if not (spear_re.search(edid) or spear_re.search(full)):
        continue
    stats["имя_или_edid_spear"] += 1
    kws = keywords_of(spears, fid) or []
    wkws = [k for k in kws if "WeapType" in k or "Weap" in k]
    if found < 8:
        print(f"\n  [{edid}] «{full}»  ключевиков {len(kws)}")
        for k in kws[:12]:
            print(f"    - {k}")
    if wkws:
        stats["с_ключами"] += 1
    else:
        stats["без_ключей"] += 1
    found += 1

print(f"\n=== Spears: 'spear-подобных' записей {stats['имя_или_edid_spear']}, "
      f"с WeapType-ключами в ESP {stats['с_ключами']}, "
      f"без {stats['без_ключей']} ===")
