#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 98: полные KWDA выборки клонов PoE + резолюция всех ключей.

Выдаёт: полный список ключевиков записи (raw formID -> мастер + EDID, если
ключевик определён в PoE core/Update-namespace), для оценки зависимости
классификации PoE-self записей от EN-имён.
"""
import struct
import sys

sys.path.insert(0, "/home/z/my-project/scripts")
from parse_tes4 import Plugin

CORE = "/home/z/my-project/work/v156/00 Core/PathsOfEmpyrean.esp"
SPEARS = "/home/z/my-project/work/v156/20 Spears/PoE-Addon-Spears.esp"

core = Plugin(CORE)

# карта: raw formID -> EDID для всех KYWD, определённых в PoE core
# (включая namespace-injected в Update.esm: 0x01xxxxxx)
kw_by_fid = {}
for fid, r in core.records.items():
    if r["type"] == "KYWD":
        kw_by_fid[fid] = r["edid"] or ""

def resolve_kw(p, kfid):
    idx = kfid >> 24
    off = kfid & 0xFFFFFF
    if idx == 0:
        # Skyrim.esm: известные нам
        known = {0x06D931: "WeapTypeGreatsword", 0x06D932: "WeapTypeBattleaxe",
                 0x08F958: "VendorItemWeapon", 0x01E711: "WeaponMaterialBlades?",
                 0x01E718: "WeaponMaterialIron", 0x01E719: "WeaponMaterialSteel?",
                 0x01E71A: "WeaponMaterialDwarven", 0x01E71C: "WeaponMaterialOrcish",
                 0x0C5C01: "WeapMaterialDraugr?"}
        return known.get(off, f"Skyrim#{off:06X}")
    if idx == 1:
        edid = kw_by_fid.get(kfid)
        return f"PoE-inject:{edid}" if edid else f"Update#{off:06X}"
    if idx == 6:
        edid = kw_by_fid.get(0x06000000 | off)
        return f"PoE-self:{edid}" if edid else f"PoE#{off:06X}"
    master = p.masters[idx] if idx < len(p.masters) else "??"
    return f"{master}#{off:06X}"

def dump(p, fid, title):
    r = p.records.get(fid)
    if not r:
        print(f"{title}: запись не найдена"); return
    print(f"\n### {title}: {fid:#010x} [{r['edid']}] «{r.get('full')}»")
    for st, sd in r["subs"]:
        if st == "KWDA":
            for i in range(len(sd) // 4):
                k = struct.unpack_from("<I", sd, i * 4)[0]
                print(f"    {k:#010x} -> {resolve_kw(p, k)}")

# клоны 1H/2H оружия PoE
dump(core, 0x060AA615, "Masterwork Blades Sword (катана)")
dump(core, 0x0608A1F7, "Masterwork Steel Greatsword")
dump(core, 0x0608A418, "Masterwork Orcish Greatsword")
dump(core, 0x0608A1C0, "Masterwork Steel Imperial Gauntlets")

# ищем 1H-меч клон без _M (обычный клон PoE)
swords = [fid for fid in core.by_type.get("WEAP", [])
          if (core.records[fid]["edid"] or "").endswith(("Sword", "SwordPoE"))][:4]
for fid in swords[:3]:
    dump(core, fid, f"WEAP-клон {core.records[fid]['edid']}")

# все KYWD PoE core в Update-namespace (сводка)
upd = {f: e for f, e in kw_by_fid.items() if (f >> 24) == 1}
print(f"\n=== KYWD PoE core в Update-namespace: {len(upd)} ===")
for f, e in sorted(upd.items()):
    print(f"    {f:#010x}  {e}")
