#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Проверка класса брони (BOD2) семей Scaled/Dragonplate/Dragonscale
и условий (CTDA) у mastery-SPEL — для вердикта 112-а.
BOD2: биты 24-25: 0=Light, 1=Heavy, 2=Clothing, 3=None."""
import sys, struct
sys.path.insert(0, '/home/z/my-project/scripts')
from parse_tes4 import Plugin

p = Plugin('/home/z/my-project/work/qa119/release119/00 Core/PathsOfEmpyrean.esp')
CLS = {0: 'LIGHT', 1: 'HEAVY', 2: 'CLOTH', 3: 'NONE'}
print(f"main ESP: {len(p.by_type['ARMO'])} ARMO, {len(p.by_type['SPEL'])} SPEL, "
      f"{len(p.by_type.get('KYWD', []))} KYWD")

def cls(r):
    for st, sd in r['subs']:
        if st == 'BOD2' and len(sd) >= 4:
            return CLS.get((struct.unpack_from('<I', sd)[0] >> 24) & 3, '?')
    return '?'

def kws(r):
    out = []
    for st, sd in r['subs']:
        if st == 'KWDA':
            for i in range(0, len(sd), 4):
                out.append(p.label(struct.unpack_from('<I', sd, i)[0]))
    return out

print("\n=== ARMO: Scaled / Dragonplate / Dragonscale семьи ===")
for fid in sorted(p.by_type['ARMO']):
    r = p.records[fid]
    e = r['edid'] or ''
    if any(s in e for s in ('Scaled', 'Dragonplate', 'Dragonscale')):
        print(f"{fid:08X} {cls(r):5} {e} | {r['full']!r} | kw={kws(r)}")

print("\n=== SPEL Mastery (dragon/scaled): CTDA (func@8, keyword@12) ===")
for fid in sorted(p.by_type['SPEL']):
    r = p.records[fid]
    e = r['edid'] or ''
    if 'MaterialMastery' in e and any(s in e for s in ('dragon', 'scaled')):
        print(f"{fid:08X} {e} | FULL={r['full']!r}")
        for st, sd in r['subs']:
            if st == 'CTDA' and len(sd) >= 16:
                func = struct.unpack_from('<I', sd, 8)[0]
                kw = struct.unpack_from('<I', sd, 12)[0]
                print(f"    func={func} kw={p.label(kw)}")

print("\n=== KYWD PoE-материалы (0639EDxx, 061EF0xx-061EF1xx) ===")
for fid in sorted(p.by_type.get('KYWD', [])):
    if 0x0639ED00 <= fid <= 0x0639EDFF or 0x061EF000 <= fid <= 0x061EFFFF or 0x061EF100 <= fid <= 0x061EF1FF:
        r = p.records[fid]
        print(f"{fid:08X} {r['edid']} | FULL={r['full']!r}")

print("\n=== BOD2 сырые байты: контроль классов (main ESP) ===")
for fid in sorted(p.by_type['ARMO']):
    r = p.records[fid]
    e = r['edid'] or ''
    if e in ('ArmorSteelPlateCuirass_M', 'ArmorLeatherCuirass_M', 'ArmorHideCuirass_M',
             'ArmorDragonplateCuirass_M', 'ArmorDragonscaleCuirass_M', 'ArmorScaledCuirass_M',
             'ArmorDwarvenPlateCuirass_M', 'ArmorBladesCuirass_M'):
        bod = next((sd.hex() for st, sd in r['subs'] if st == 'BOD2'), '-')
        print(f"{fid:08X} {cls(r):5} BOD2={bod} {e}")

print("\n=== КОНТРОЛЬ: CC Iron Plate (тяжёлая ваниль CC) ===")
cc = Plugin('/home/z/my-project/work/qa119/release119/30 CC Patches/Alternative Armors - Iron/PoE-CCAltArmorIron-Patch.esp')
for fid in sorted(cc.by_type['ARMO']):
    r = cc.records[fid]
    e = r['edid'] or ''
    if 'Cuirass' in e:
        bod = next((sd.hex() for st, sd in r['subs'] if st == 'BOD2'), '-')
        print(f"{fid:08X} {cls(r):5} BOD2={bod} {e} | {r['full']!r}")
        break
