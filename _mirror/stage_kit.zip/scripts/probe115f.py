#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап-разведка 115f.
1) Полные записи SPEL 06060E76 / MESG 06060E78 / MGEF 06060E75 (поля+размеры).
2) file-список dump_v115_full.jsonl (откуда cc:AltArmorOrcishScaled).
3) _cc_esp.bin: хедер и мастера.
4) Все CTDA с func=71 (GetIsSex) в main ESP — формат параметра.
"""
import struct, zlib, os, json, collections

REL = '/home/z/my-project/work/qa114/release115'
REC_HDR = 24


class Node:
    __slots__ = ('kind', 'label', 'tail', 'formid', 'data', 'children')


def parse(buf):
    root = []

    def walk(off, end, out):
        while off < end:
            t = buf[off:off+4]
            size = struct.unpack_from('<I', buf, off+4)[0]
            if t == b'GRUP':
                node = Node(); node.kind = 'grup'; node.children = []
                walk(off + REC_HDR, off + size, node.children)
                out.append(node); off += size
            else:
                node = Node(); node.kind = 'rec'
                node.label = t
                node.tail = bytes(buf[off+8:off+24])
                node.formid = struct.unpack_from('<I', buf, off+12)[0]
                node.data = bytes(buf[off+REC_HDR:off+REC_HDR+size])
                out.append(node); off += REC_HDR + size
    walk(0, len(buf), root)
    return root


def walk_recs(nodes):
    for n in nodes:
        if n.kind == 'grup':
            yield from walk_recs(n.children)
        else:
            yield n


def subrecords(rec):
    body = rec.data
    if struct.unpack_from('<I', rec.tail, 0)[0] & 0x00040000:
        usz = struct.unpack_from('<I', body, 0)[0]
        body = zlib.decompress(body[4:])
        assert len(body) == usz
    out = []
    off = 0
    while off < len(body):
        st = body[off:off+4].decode('ascii', 'replace')
        ssz = struct.unpack_from('<H', body, off+4)[0]
        val = bytes(body[off+6:off+6+ssz])
        out.append((st, val))
        if st == 'XXXX':
            real = struct.unpack_from('<I', body, off+6)[0]
            off += 6 + ssz + 6 + real
            continue
        off += 6 + ssz
    return out


def edid_of(rec):
    for st, v in subrecords(rec):
        if st == 'EDID':
            return v.rstrip(b'\x00').decode('utf-8', 'replace')
    return ''


def dump_rec(rec, title):
    print(f'--- {title} ---')
    for st, v in subrecords(rec):
        if st in ('EDID', 'FULL', 'DESC', 'DNAM'):
            print(f'  {st} [{len(v)}]: {v.rstrip(chr(0).encode()).decode("utf-8", "replace")!r}')
        else:
            hx = v.hex()
            print(f'  {st} [{len(v)}]: {hx[:150]}{"..." if len(hx) > 150 else ""}')


def main():
    buf = open(os.path.join(REL, '00 Core/PathsOfEmpyrean.esp'), 'rb').read()
    root = parse(buf)
    recs = list(walk_recs(root))
    index = {}
    for rec in recs:
        index[rec.formid] = (rec.label.decode('ascii', 'replace'), edid_of(rec))

    print('=== 1) полные записи ===')
    for want, name in ((0x06060E76, 'SPEL bandit ability'),
                       (0x06060E78, 'MESG bandit'),
                       (0x06060E75, 'MGEF bandit')):
        for rec in recs:
            if rec.formid == want:
                dump_rec(rec, f'{name} {want:08X}')
                break

    print()
    print('=== 2) file-список dump_v115_full.jsonl ===')
    files = collections.Counter()
    for line in open('work/qa114/dump_v115_full.jsonl', encoding='utf-8'):
        files[json.loads(line)['file']] += 1
    for k, v in files.most_common():
        print(f'{v:6d}  {k}')

    print()
    print('=== 3) _cc_esp.bin ===')
    cbuf = open('work/qa114/_cc_esp.bin', 'rb').read()
    print('sig:', cbuf[:4], 'size:', len(cbuf))
    hsize = struct.unpack_from('<I', cbuf, 4)[0]
    body = cbuf[REC_HDR:REC_HDR+hsize]
    off = 0
    while off < len(body):
        st = body[off:off+4]
        ssz = struct.unpack_from('<H', body, off+4)[0]
        val = body[off+6:off+6+ssz]
        if st == b'EDID':
            print('EDID:', val.rstrip(b'\x00').decode('utf-8', 'replace'))
        elif st == b'MAST':
            print('MAST:', val.rstrip(b'\x00').decode('utf-8', 'replace'))
        elif st == b'DATA':
            print('DATA reached, header end')
            break
        off += 6 + ssz
    croot = parse(cbuf)
    cc_recs = list(walk_recs(croot))
    print('записей:', len(cc_recs))
    for rec in cc_recs[:5]:
        print(' ', rec.label.decode(), f'{rec.formid:08X}', edid_of(rec))
    for rec in cc_recs:
        if rec.formid in (0x05000800, 0x05000801, 0x05000802):
            dump_rec(rec, f'cc {rec.formid:08X}')

    print()
    print('=== 4) CTDA func=71 (GetIsSex) в main ESP ===')
    n = 0
    for rec in recs:
        for st, v in subrecords(rec):
            if st != 'CTDA':
                continue
            for i in range(0, len(v) - 15, 32):
                c = v[i:i+32]
                func = struct.unpack_from('<I', c, 8)[0]
                if func != 71:
                    continue
                n += 1
                if n <= 12:
                    op = c[0]
                    val = struct.unpack_from('<f', c, 4)[0]
                    p1, p2 = struct.unpack_from('<II', c, 12)
                    ro = struct.unpack_from('<H', c, 20)[0]
                    rest = c[22:].hex()
                    print(f'{rec.label.decode()} {rec.formid:08X} {edid_of(rec)[:40]}: '
                          f'op={op:#x} val={val:g} p1={p1} p2={p2} runOn={ro} '
                          f'tail={rest}')
    print('всего func=71:', n)


if __name__ == '__main__':
    main()
