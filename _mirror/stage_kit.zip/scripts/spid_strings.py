#!/usr/bin/env python3
"""Extract and classify strings from SPID DLL (.rdata/.data): log messages, INI keys, filters."""
import struct, re, sys, json

DLL = "/home/z/my-project/spid_work/spid_extracted/SKSE/Plugins/po3_SpellPerkItemDistributor.dll"
with open(DLL, "rb") as f:
    data = f.read()

# section ranges to know where a string lives
pe_off = struct.unpack_from("<I", data, 0x3C)[0]
opt_size = struct.unpack_from("<H", data, pe_off + 20)[0]
num_sections = struct.unpack_from("<H", data, pe_off + 6)[0]
sec_off = pe_off + 24 + opt_size
sections = {}
for i in range(num_sections):
    o = sec_off + i * 40
    name = data[o:o+8].rstrip(b"\x00").decode()
    vsize, vaddr, rsize, raddr = struct.unpack_from("<IIII", data, o + 8)
    sections[name] = (raddr, rsize)

def section_of(off):
    for name, (raddr, rsize) in sections.items():
        if raddr <= off < raddr + rsize:
            return name
    return "?"

# ASCII strings >= 5 chars
ascii_re = re.compile(rb"[\x20-\x7e]{5,}")
strs = []
for m in ascii_re.finditer(data):
    s = m.group().decode()
    strs.append((m.start(), s))

# UTF-16LE strings
utf16_re = re.compile(rb"(?:[\x20-\x7e]\x00){5,}")
u16 = []
for m in utf16_re.finditer(data):
    try:
        s = m.group().decode("utf-16-le")
    except Exception:
        continue
    u16.append((m.start(), s))

print(f"ASCII strings: {len(strs)}, UTF-16 strings: {len(u16)}")

# Classify ASCII by themes
themes = {
    "INI_KEYWORDS": re.compile(r"^(Spell|Perk|Item|Shout|Package|Outfit|Keyword|DeathItem|FormListMap|LeveledItemMap)?\s*[-_]?\s*(Forms?)?$|^(Forms?|Spell|Perk|Item|Shout|Package|Outfit|Keyword|DeathItem)$", re.I),
    "LOG_MSGS": re.compile(r"(\bDistribut|Filter|filter|match|Package|NPC|log|FormID|EditorID|path|loaded|count|Total|error|Error|failed|skipped|invalid|INI)", re.I),
}
seen_ini, seen_log, seen_other = [], [], []
for off, s in strs:
    sec = section_of(off)
    if themes["LOG_MSGS"].search(s) and len(s) > 8:
        seen_log.append((off, sec, s))
    else:
        seen_other.append((off, sec, s))

with open("/home/z/my-project/spid_work/spid_strings_all.txt", "w") as f:
    for off, s in strs:
        f.write(f"{off:#010x} [{section_of(off):8s}] {s}\n")

print("\n=== LOG/DOC STRINGS (sample, first 220) ===")
for off, sec, s in seen_log[:220]:
    print(f"{off:#x} [{sec}] {s[:200]}")
