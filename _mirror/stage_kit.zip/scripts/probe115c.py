#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап-разведка 115c: полный hex VMAD + brute-force подбор грамматики VMAD.
Носители MGEF-маскировок в main ESP тоже."""
import struct, zlib

ESP = '/home/z/my-project/work/qa114/release115/00 Core/PathsOfEmpyrean.esp'
REC_HDR = 24
MGEF_PREFIX = 'ISP_MGEF_SPEECH_Disguise'


class Node:
    __slots__ = ('kind', 'label', 'tail', 'formid', 'data', 'children')


def parse(buf):
    root = []

    def walk(off, end, out):
        while off < end:
            t = buf[off:off+4]
            size = struct.unpack_from('<I', buf, off+4)[0]
            if t == b'GRUP':
                node = Node(); node.kind = 'grup'; node.children = []
                walk(off + REC_HDR, off + size, node.children)
                out.append(node); off += size
            else:
                node = Node(); node.kind = 'rec'
                node.label = t
                node.tail = bytes(buf[off+8:off+24])
                node.formid = struct.unpack_from('<I', buf, off+12)[0]
                node.data = bytes(buf[off+REC_HDR:off+REC_HDR+size])
                out.append(node); off += REC_HDR + size
    walk(0, len(buf), root)
    return root


def walk_recs(nodes):
    for n in nodes:
        if n.kind == 'grup':
            yield from walk_recs(n.children)
        else:
            yield n


def subrecords(rec):
    body = rec.data
    if struct.unpack_from('<I', rec.tail, 0)[0] & 0x00040000:
        usz = struct.unpack_from('<I', body, 0)[0]
        body = zlib.decompress(body[4:])
        assert len(body) == usz
    out = []
    off = 0
    while off < len(body):
        st = body[off:off+4].decode('ascii', 'replace')
        ssz = struct.unpack_from('<H', body, off+4)[0]
        val = bytes(body[off+6:off+6+ssz])
        out.append((st, val))
        if st == 'XXXX':
            real = struct.unpack_from('<I', body, off+6)[0]
            off += 6 + ssz + 6 + real
            continue
        off += 6 + ssz
    return out


def edid_of(rec):
    for st, v in subrecords(rec):
        if st == 'EDID':
            return v.rstrip(b'\x00').decode('utf-8', 'replace')
    return ''


def wstr(b, off):
    n = struct.unpack_from('<H', b, off)[0]
    return b[off+2:off+2+n].decode('utf-8', 'replace'), off + 2 + n


def try_parse_vmad(v, obj_with_unk, arr_count_u32, obj_in_array_with_unk):
    """Гипотеза грамматики. Возвращает (ok, список строк, formid-хиты [(path, formid)])."""
    off = 0
    try:
        ver, objfmt, nscripts = struct.unpack_from('<HHH', v, off); off += 6
        lines = [f'ver={ver} objFmt={objfmt} scripts={nscripts}']
        hits = []
        for si in range(nscripts):
            name, off = wstr(v, off)
            nprops = struct.unpack_from('<H', v, off)[0]; off += 2
            lines.append(f'script[{si}] {name!r} props={nprops}')
            for pi in range(nprops):
                pname, off = wstr(v, off)
                ptype = v[off]; pflags = v[off+1]; off += 2
                tag = f'  {pname!r} type={ptype} flags={pflags}'
                if ptype == 5:          # bool u8
                    b = v[off]; off += 1
                    lines.append(tag + f' bool={b}')
                elif ptype == 2:        # int u32
                    x = struct.unpack_from('<I', v, off)[0]; off += 4
                    lines.append(tag + f' int={x}')
                elif ptype == 3:        # float u32
                    f = struct.unpack_from('<f', v, off)[0]; off += 4
                    lines.append(tag + f' float={f:g}')
                elif ptype == 1:        # object
                    if obj_with_unk:
                        unk = v[off]; off += 1
                        fid = struct.unpack_from('<I', v, off)[0]; off += 4
                        lines.append(tag + f' obj unk={unk} form={fid:08X}')
                    else:
                        fid = struct.unpack_from('<I', v, off)[0]; off += 4
                        lines.append(tag + f' obj form={fid:08X}')
                    hits.append((f'{name}.{pname}', fid))
                elif ptype == 11:       # object array
                    if arr_count_u32:
                        cnt = struct.unpack_from('<I', v, off)[0]; off += 4
                    else:
                        cnt = struct.unpack_from('<H', v, off)[0]; off += 2
                    parts = []
                    for k in range(cnt):
                        if obj_in_array_with_unk:
                            unk = v[off]; off += 1
                            fid = struct.unpack_from('<I', v, off)[0]; off += 4
                            parts.append(f'[unk={unk} form={fid:08X}]')
                        else:
                            fid = struct.unpack_from('<I', v, off)[0]; off += 4
                            parts.append(f'[form={fid:08X}]')
                    lines.append(tag + f' arr[{cnt}]=' + ','.join(parts))
                    hits.append((f'{name}.{pname}', parts))
                else:
                    return False, lines, hits
        if off != len(v):
            return False, lines, hits
        return True, lines, hits
    except (IndexError, struct.error):
        return False, lines if 'lines' in dir() else [], []


def main():
    buf = open(ESP, 'rb').read()
    root = parse(buf)
    recs = list(walk_recs(root))

    vmads = {}
    for rec in recs:
        if rec.label != b'MGEF':
            continue
        edid = edid_of(rec)
        if not edid.startswith(MGEF_PREFIX):
            continue
        for st, v in subrecords(rec):
            if st == 'VMAD':
                vmads[edid] = (rec.formid, v)

    print('=== полный hex VMAD bandit ===')
    fid, v = vmads['ISP_MGEF_SPEECH_Disguise_bandit']
    print(f'{fid:08X} len={len(v)}')
    for i in range(0, len(v), 32):
        chunk = v[i:i+32]
        print(f'  {i:03d}: {chunk.hex()}')
        txt = ''.join(chr(c) if 32 <= c < 127 else '.' for c in chunk)
        print(f'      |{txt}|')

    print()
    print('=== подбор грамматики VMAD ===')
    combos = [(a, b, c) for a in (True, False) for b in (True, False)
              for c in (True, False)]
    for obj_unk, cnt32, arr_unk in combos:
        oks = 0
        for edid, (_, vv) in vmads.items():
            ok, _, _ = try_parse_vmad(vv, obj_unk, cnt32, arr_unk)
            if ok:
                oks += 1
        print(f'гипотеза obj_unk={obj_unk} arr_count_u32={cnt32} '
              f'arr_obj_unk={arr_unk}: ok {oks}/{len(vmads)}')

    # печатаем разборы единственной согласующейся гипотезы
    print()
    for obj_unk, cnt32, arr_unk in combos:
        oks = sum(1 for edid, (_, vv) in vmads.items()
                  if try_parse_vmad(vv, obj_unk, cnt32, arr_unk)[0])
        if oks == len(vmads):
            print(f'=== согласовано: obj_unk={obj_unk} arr_count_u32={cnt32} '
                  f'arr_obj_unk={arr_unk} ===')
            for edid in sorted(vmads):
                fid, vv = vmads[edid]
                ok, lines, hits = try_parse_vmad(vv, obj_unk, cnt32, arr_unk)
                print(f'--- {fid:08X} {edid} ---')
                print('\n'.join(lines))
            break

    # носители
    print()
    print('=== носители MGEF-маскировок (main ESP) ===')
    index = {}
    for rec in recs:
        index[rec.formid] = (rec.label.decode('ascii', 'replace'), edid_of(rec))
    pats = {rec.formid for rec in recs if rec.label == b'MGEF'
            and edid_of(rec).startswith(MGEF_PREFIX)}
    carriers = {}
    for rec in recs:
        if rec.formid in pats:
            continue
        subs = subrecords(rec)
        for st, v in subs:
            for fid in pats:
                pat = struct.pack('<I', fid)
                if pat in v:
                    key = rec.formid
                    carriers.setdefault(key, [rec.label.decode('ascii', 'replace'),
                                              edid_of(rec), {}])
                    carriers[key][2].setdefault(st, set()).add(f'{fid:08X}')
    for fid, (rl, edid, fields) in sorted(carriers.items()):
        fl = '; '.join(f'{st}: {", ".join(sorted(v))}' for st, v in fields.items())
        print(f'{rl} {fid:08X} {edid} | {fl}')


if __name__ == '__main__':
    main()
