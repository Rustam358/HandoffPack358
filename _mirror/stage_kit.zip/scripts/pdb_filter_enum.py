#!/usr/bin/env python3
"""Find 'Filter' enum and its members in TPI/IPI streams of the PDB."""
import struct, re, sys
sys.path.insert(0, "/home/z/my-project/scripts")

# re-run the MSF parse quickly (import side effects avoided: just re-parse)
PDB = "/home/z/my-project/spid_work/spid_extracted/SKSE/Plugins/po3_SpellPerkItemDistributor.pdb"
data = open(PDB, "rb").read()
MAGIC = b"Microsoft C/C++ MSF 7.00\r\n\x1aDS\x00\x00\x00"
block_size, free_map, num_blocks, dir_size, _unk, block_map_addr = struct.unpack_from("<IIIIII", data, len(MAGIC))
nblocks_dir = (dir_size + block_size - 1) // block_size
map_off = block_map_addr * block_size
dir_blocks = struct.unpack_from(f"<{nblocks_dir}I", data, map_off)
directory = b"".join(data[b * block_size: b * block_size + block_size] for b in dir_blocks)[:dir_size]

pos = 0
num_streams = struct.unpack_from("<I", directory, pos)[0]; pos += 4
sizes = [struct.unpack_from("<I", directory, pos + 4 * i)[0] for i in range(num_streams)]
pos += 4 * num_streams
streams = []
for i, sz in enumerate(sizes):
    if sz == 0xFFFFFFFF or sz == 0:
        streams.append(b""); continue
    nb = (sz + block_size - 1) // block_size
    blks = struct.unpack_from(f"<{nb}I", directory, pos); pos += 4 * nb
    streams.append(b"".join(data[b * block_size: b * block_size + block_size] for b in blks)[:sz])

tpi, ipi = streams[2], streams[4]
print(f"TPI {len(tpi)} bytes, IPI {len(ipi)} bytes")

# Scan TPI for LF_ENUM records with name "Filter" followed by members.
# Field list records: LF_FIELDLIST = 0x1203, members LF_ENUMERATE = 0x1502.
# We do a pragmatic scan: find b'Filter\x00' occurrences and dump 400 bytes around.
def scan(stream, label):
    out = 0
    for m in re.finditer(rb'\x00Filter\x00', stream):
        i = m.start()
        ctx = stream[max(0, i - 60): i + 400]
        # extract all ascii runs in context
        runs = re.findall(rb'[\x20-\x7e]{3,40}', ctx)
        print(f"\n[{label}] Filter enum @ {i:#x}:")
        for r in runs:
            print("   ", r.decode())
        out += 1
        if out > 6: break
    return out

scan(tpi, "TPI")
scan(ipi, "IPI")
