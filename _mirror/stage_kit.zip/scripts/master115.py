#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 115 (v1.5.16): (А) вердикт 113-а — CC «Orcish Scaled» → «ламеллярный»;
(Б) гендерная система маскировочных сообщений ISP Speech.

Механизм (установлен разведкой 115a-h):
  PERK → SPEL (ISP_AB_SPEECH_Disguise_X, пары EFID/EFIT + CTDA)
       → MGEF (ISP_MGEF_SPEECH_Disguise_X, VMAD: Utility_AddToFaction +
         Utility_ShowMessageMagicEff{msgStart=MESG, msgEnd=06060E79}).
Гендер: CTDA GetIsSex (func=70, op=EQ, val=1.0, p1=0 male / 1 female) —
формат по UESP Function Indices и 359 образцам CTDA мода.

Правки:
  1) fixlist_v116.jsonl — 11 строк (6 FULL cc:AltArmorOrcishScaled + 5 MESG main).
  2) Структурно в main ESP:
     - 5 ориг. MGEF: +CTDA male;
     - 5 новых MESG_F (текст игрока, женские формы);
     - 5 новых MGEF_F (клоны: EDID _F, VMAD msgStart→MESG_F, +CTDA female);
     - 5 SPEL: +вторая пара EFID/EFIT → MGEF_F.
База: upload «Paths of Empyrean RU 1.5 (8).zip» = v1.5.15 байт-в-байт
(md5 27f15c15cd95c22a287ec1f0f67aab67). Приёмник: work/qa115/v116.
"""
import struct, zlib, os, json, zipfile, hashlib

SRC_ZIP = '/home/z/my-project/upload/Paths of Empyrean RU 1.5 (8).zip'
DST = '/home/z/my-project/work/qa115/v116'
FIX = '/home/z/my-project/work/qa115/fixlist_v116.jsonl'
MAIN = '00 Core/PathsOfEmpyrean.esp'
CC = ('30 CC Patches/Alternative Armors - Orcish Scaled/'
      'PoE-CCAltArmorOrcishScaled-Patch.esp')
SCOPES = {'main': MAIN, 'cc:AltArmorOrcishScaled': CC}

REC_HDR = 24

# --- гендерные константы -------------------------------------------------
END_MESG = 0x06060E79  # «Ваша маскировка сорвалась...»

CTDA_MALE = bytes.fromhex(
    '00000000'   # op=0x00 (EQ) + unused
    '0000803f'   # value = 1.0
    '46000000'   # func=70 GetIsSex
    '00000000'   # param1 = 0 (male)
    '00000000'   # param2 = 0
    '0000'       # runOn = 0 (subject)
    '000000000000'
    'ffffffff')  # ref = -1 (формат MGEF-условий PoE)
CTDA_FEMALE = CTDA_MALE[:12] + b'\x01\x00\x00\x00' + CTDA_MALE[16:]
assert len(CTDA_MALE) == 32 and len(CTDA_FEMALE) == 32
assert struct.unpack_from('<I', CTDA_MALE, 8)[0] == 70

DISG = [
    # key: (orig_mgef, orig_mesg, orig_spel, mesg_f, mgef_f, mgef_edid_f,
    #       msg_edid_f, fem_text)
    ('bandit', 0x06060E75, 0x06060E78, 0x06060E76, 0x065D69D7, 0x065D69DC,
     'ISP_MGEF_SPEECH_Disguise_bandit_F',
     'ISP_MSG_SPEECH_Disguise_bandit_F',
     'Вы замаскированы под Бандитку.'),
    ('Stormcloak', 0x06060E95, 0x06060E93, 0x06060E96, 0x065D69D8, 0x065D69DD,
     'ISP_MGEF_SPEECH_Disguise_Stormcloak_F',
     'ISP_MSG_SPEECH_Disguise_Stormcloak_F',
     'Вы замаскированы под Сестру Бури.'),
    ('Imperial', 0x06060E9B, 0x06060E9A, 0x06060E9C, 0x065D69D9, 0x065D69DE,
     'ISP_MGEF_SPEECH_Disguise_Imperial_F',
     'ISP_MSG_SPEECH_Disguise_Imperial_F',
     'Вы замаскированы под Имперку.'),
    ('Cultist', 0x06060EA7, 0x06060EA6, 0x06060EA8, 0x065D69DA, 0x065D69DF,
     'ISP_MGEF_SPEECH_Disguise_Cultist_F',
     'ISP_MSG_SPEECH_Disguise_Cultist_F',
     'Вы замаскированы под Культистку.'),
    ('vampire', 0x06024576, 0x06024573, 0x0602457B, 0x065D69DB, 0x065D69E0,
     'ISP_MGEF_SPEECH_Disguise_vampire_F',
     'ISP_MSG_SPEECH_Disguise_vampire_F',
     'Вы замаскированы под Вампирессу.'),
]


class Node:
    __slots__ = ('kind', 'label', 'tail', 'formid', 'data', 'children')


def parse(buf):
    root = []

    def walk(off, end, out):
        while off < end:
            t = buf[off:off+4]
            size = struct.unpack_from('<I', buf, off+4)[0]
            if t == b'GRUP':
                node = Node()
                node.kind = 'grup'
                node.label = None
                node.tail = bytes(buf[off+8:off+24])
                node.children = []
                walk(off + REC_HDR, off + size, node.children)
                out.append(node)
                off += size
            else:
                node = Node()
                node.kind = 'rec'
                node.label = t
                node.tail = bytes(buf[off+8:off+24])
                node.formid = struct.unpack_from('<I', buf, off+12)[0]
                node.data = bytes(buf[off+REC_HDR:off+REC_HDR+size])
                out.append(node)
                off += REC_HDR + size
    walk(0, len(buf), root)
    return root


def serialize_node(n, parts):
    if n.kind == 'grup':
        sub = []
        for c in n.children:
            serialize_node(c, sub)
        s = b''.join(sub)
        parts.append(b'GRUP' + struct.pack('<I', 24 + len(s)) + n.tail)
        parts.append(s)
    else:
        parts.append(n.label + struct.pack('<I', len(n.data)) + n.tail)
        parts.append(n.data)


def find_rec(nodes, formid):
    for n in nodes:
        if n.kind == 'grup':
            r = find_rec(n.children, formid)
            if r is not None:
                return r
        elif n.formid == formid:
            return n
    return None


def rec_flags(rec):
    return struct.unpack_from('<I', rec.tail, 0)[0]


def decode_body(rec):
    if rec_flags(rec) & 0x00040000:
        usz = struct.unpack_from('<I', rec.data, 0)[0]
        dec = zlib.decompress(rec.data[4:])
        assert len(dec) == usz
        return bytearray(dec), True
    return bytearray(rec.data), False


def encode_body(body, was_c):
    if was_c:
        return struct.pack('<I', len(body)) + zlib.compress(bytes(body))
    return bytes(body)


def split_fields(body):
    """[(st_bytes, val_bytes)] без XXXX-логики (для новых тел)."""
    out, off = [], 0
    while off < len(body):
        st = bytes(body[off:off+4])
        ssz = struct.unpack_from('<H', body, off+4)[0]
        out.append((st, bytes(body[off+6:off+6+ssz])))
        off += 6 + ssz
    return out


def find_field(body, sig, occ=1):
    off, seen = 0, 0
    while off < len(body):
        st = bytes(body[off:off+4])
        ssz = struct.unpack_from('<H', body, off+4)[0]
        if st == sig:
            seen += 1
            if seen == occ:
                return off, ssz
        off += 6 + ssz
    raise AssertionError(f'{sig}#{occ} не найдено')


def find_top_grup(root, sig):
    for n in root:
        if n.kind == 'grup' and n.tail[0:4] == sig:
            return n
    raise AssertionError(f'top-GRUP {sig} не найден')


def make_node(orig, formid, body, uncompressed=True):
    tail = bytearray(orig.tail)
    struct.pack_into('<I', tail, 4, formid)
    if uncompressed:
        struct.pack_into('<I', tail, 0, struct.unpack_from('<I', tail, 0)[0]
                         & ~0x00040000)
    n = Node()
    n.kind = 'rec'
    n.label = orig.label
    n.tail = bytes(tail)
    n.formid = formid
    n.data = bytes(body)
    return n


def field_bytes(sig, val):
    return sig + struct.pack('<H', len(val)) + val


def patch_strings(path, patches):
    """Строковые ESP-патчи (master114-механика)."""
    buf = open(path, 'rb').read()
    root = parse(buf)
    out = []
    for n in root:
        serialize_node(n, out)
    assert b''.join(out) == buf, f'самотест сериализации: {path}'
    applied = 0
    for formid, field, occ, old, new in patches:
        rec = find_rec(root, formid)
        assert rec is not None, f'{formid:08X} не найдена'
        body, was_c = decode_body(rec)
        off, seen, done = 0, 0, False
        while off < len(body):
            if off + 6 > len(body):
                break
            st = body[off:off+4].decode('ascii', 'replace')
            ssz = struct.unpack_from('<H', body, off+4)[0]
            if st == 'XXXX':
                real = struct.unpack_from('<I', body, off+6)[0]
                off += 6 + ssz + 6 + real
                continue
            cur_sz = ssz
            if st == field:
                seen += 1
                cur = bytes(body[off+6:off+6+ssz]).rstrip(b'\x00').decode(
                    'utf-8', 'replace')
                if seen == occ:
                    assert cur == old, (
                        f'{formid:08X} {field}#{occ}: {cur[:80]!r} != {old[:80]!r}')
                    newb = new.encode('utf-8') + b'\x00'
                    body[off+6:off+6+ssz] = newb
                    struct.pack_into('<H', body, off+4, len(newb))
                    done = True
                    applied += 1
                    cur_sz = len(newb)
            off += 6 + cur_sz
        assert done, f'{formid:08X} {field}#{occ} не применён'
        rec.data = encode_body(body, was_c)
    out = []
    for n in root:
        serialize_node(n, out)
    data = b''.join(out)
    open(path, 'wb').write(data)
    print(f'  строки {path}: патчей {applied}, файл {len(buf)} -> {len(data)} Б')
    return applied


def structural_main(path):
    buf = open(path, 'rb').read()
    root = parse(buf)
    out = []
    for n in root:
        serialize_node(n, out)
    assert b''.join(out) == buf, 'самотест сериализации main'
    mesg_grup = find_top_grup(root, b'MESG')
    mgef_grup = find_top_grup(root, b'MGEF')

    for key, om, om_, os_, mf, gf, gef_edid, msg_edid, fem in DISG:
        # --- снимок тел оригиналов (до правок) ---
        mgef = find_rec(root, om)
        mesg = find_rec(root, om_)
        spel = find_rec(root, os_)
        mgef_body0, mgef_c = decode_body(mgef)
        mesg_body, mesg_c = decode_body(mesg)
        spel_body, spel_c = decode_body(spel)
        clean_mgef_body = bytearray(mgef_body0)  # копия без CTDA

        # --- 1) оригинальный MGEF: +CTDA male ---
        mgef_body = bytearray(mgef_body0)
        mgef_body += field_bytes(b'CTDA', CTDA_MALE)
        mgef.data = encode_body(mgef_body, mgef_c)

        # --- 2) MESG_F: копия структуры, EDID/DESC новые ---
        fields = split_fields(mesg_body)
        st_ed, sz_ed = find_field(mesg_body, b'EDID')
        st_de, sz_de = find_field(mesg_body, b'DESC')
        new_body = bytearray()
        new_body += field_bytes(b'EDID', msg_edid.encode('utf-8') + b'\x00')
        new_body += field_bytes(b'DESC', fem.encode('utf-8') + b'\x00')
        for sig in (b'INAM', b'DNAM', b'TNAM'):
            _, szv = find_field(mesg_body, sig)
            off, _ = find_field(mesg_body, sig)
            val = bytes(mesg_body[off+6:off+6+szv])
            new_body += field_bytes(sig, val)
        mesg_f = make_node(mesg, mf, new_body)
        mesg_grup.children.append(mesg_f)

        # --- 3) MGEF_F: клон; EDID _F; VMAD msgStart->MESG_F; +CTDA female ---
        vm_off, vm_sz = find_field(clean_mgef_body, b'VMAD')
        vm = bytearray(clean_mgef_body[vm_off+6:vm_off+6+vm_sz])
        pat = struct.pack('<I', om_)
        assert vm.count(pat) == 1, f'{key}: msgStart в VMAD x{vm.count(pat)}'
        vm[vm.find(pat):vm.find(pat)+4] = struct.pack('<I', mf)
        new_mgef = bytearray()
        for st, val in split_fields(clean_mgef_body):
            if st == b'EDID':
                new_mgef += field_bytes(b'EDID', gef_edid.encode('utf-8') + b'\x00')
            elif st == b'VMAD':
                new_mgef += field_bytes(b'VMAD', bytes(vm))
            else:
                new_mgef += field_bytes(st, val)
        new_mgef += field_bytes(b'CTDA', CTDA_FEMALE)
        mgef_f = make_node(mgef, gf, new_mgef)
        mgef_grup.children.append(mgef_f)

        # --- 4) SPEL: +вторая пара EFID/EFIT ---
        ef_off, ef_sz = find_field(spel_body, b'EFID')
        it_off, it_sz = find_field(spel_body, b'EFIT')
        efit_data = bytes(spel_body[it_off+6:it_off+6+it_sz])
        add = field_bytes(b'EFID', struct.pack('<I', gf)) \
            + field_bytes(b'EFIT', efit_data)
        ins = it_off + 6 + it_sz
        spel_body = spel_body[:ins] + add + spel_body[ins:]
        spel.data = encode_body(spel_body, spel_c)
        print(f'  {key}: MGEF {om:08X}+CTDA(m); MESG_F {mf:08X}; '
              f'MGEF_F {gf:08X}; SPEL {os_:08X}+EFID')

    # --- пост-проверки ---
    ids = []
    def collect(nodes):
        for n in nodes:
            if n.kind == 'grup':
                collect(n.children)
            else:
                ids.append(n.formid)
    collect(root)
    assert len(ids) == len(set(ids)), 'formid не уникальны'
    out = []
    for n in root:
        serialize_node(n, out)
    data = b''.join(out)
    open(path, 'wb').write(data)
    print(f'  структура {path}: {len(buf)} -> {len(data)} Б')
    return data


def main():
    patches = {'main': [], 'cc:AltArmorOrcishScaled': []}
    for line in open(FIX, encoding='utf-8'):
        r = json.loads(line)
        patches[r['scope']].append(
            (int(r['formid'], 16), r['field'], r['occ'], r['old'], r['new']))
    assert len(patches['main']) == 5 and len(patches['cc:AltArmorOrcishScaled']) == 6

    with zipfile.ZipFile(SRC_ZIP) as z:
        info = z.read('fomod/info.xml').decode('utf-8')
        assert '<Version>1.5.15</Version>' in info, 'база не v1.5.15!'
    print('база: user zip (8) = v1.5.15 (63 файла)')

    n1 = patch_strings(os.path.join(DST, CC), patches['cc:AltArmorOrcishScaled'])
    n2 = patch_strings(os.path.join(DST, MAIN), patches['main'])
    assert n1 == 6 and n2 == 5

    structural_main(os.path.join(DST, MAIN))

    for p in (MAIN, CC):
        full = os.path.join(DST, p)
        md5 = hashlib.md5(open(full, 'rb').read()).hexdigest()
        print(f'md5 {p}: {md5} ({os.path.getsize(full)} Б)')


if __name__ == '__main__':
    main()
