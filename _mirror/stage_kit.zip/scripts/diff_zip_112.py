#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 112: пофайловая CRC-сверка user zip (4) с нашим релизом v1.5.12."""
import sys, zipfile, hashlib

OURS = "/home/z/my-project/download/Paths of Empyrean RU 1.5.zip"
USER = "/home/z/my-project/upload/Paths of Empyrean RU 1.5 (4).zip"

def load(path):
    d = {}
    with zipfile.ZipFile(path) as z:
        for i in z.infolist():
            if i.is_dir():
                continue
            data = z.read(i.filename)
            d[i.filename] = (i.CRC, hashlib.md5(data).hexdigest(), len(data), data)
    return d

a = load(OURS)
b = load(USER)
print(f"OUR  v1.5.12: {len(a)} записей")
print(f"USER zip(4) : {len(b)} записей")

only_ours = sorted(set(a) - set(b))
only_user = sorted(set(b) - set(a))
print(f"\n-- только в нашем (нет у игрока): {len(only_ours)}")
for f in only_ours: print("   ", f)
print(f"\n-- только у игрока (нет у нас): {len(only_user)}")
for f in only_user: print("   ", f)

common = sorted(set(a) & set(b))
changed = []
same = 0
for f in common:
    if a[f][0] != b[f][0]:
        changed.append(f)
    else:
        same += 1
print(f"\n-- идентичны по CRC: {same}/{len(common)}")
print(f"-- ИЗМЕНЕНЫ ({len(changed)}):")
for f in changed:
    print(f"    {f}: ours md5={a[f][1]} ({a[f][2]} Б) | user md5={b[f][1]} ({b[f][2]} Б)")
print(f"\nUSER zip md5 (целый архив): {hashlib.md5(open(USER,'rb').read()).hexdigest()}")
