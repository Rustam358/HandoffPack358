#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 102 (аналитический): добыча строк для вердиктов «сильнее vs эффективнее».
Истина = зеркала слоя 06_ (пересобраны из дампа v1.5.7, Этап 101) + эталон v149.
Только чтение; правок не делает."""
import json

BASE = '/home/z/my-project'
CORP = f'{BASE}/handoff/06_код-истина_перевода/corpus57.json'
DESC = f'{BASE}/handoff/06_код-истина_перевода/desc_ru.py'
DESCI = f'{BASE}/handoff/06_код-истина_перевода/PathsOfEmpyrean_DESC.ini'
PERKS = f'{BASE}/handoff/04_эталоны_игрока/perks_v149.jsonl'

EDIDS = ('MageWard', 'MageArmor', 'FearTheDawn', 'Dragonblood')
REG100 = ('000BE124', '00018E6A', '0600081E', '060290CE')

d = json.load(open(CORP, encoding='utf-8'))

print('== corpus57: целевые EDID (MageWard/MageArmor/FearTheDawn/Dragonblood) ==')
for r in d:
    if r.get('edid') and any(e.lower() in r['edid'].lower() for e in EDIDS):
        print(json.dumps(r, ensure_ascii=False))

print()
print('== corpus57: все поля с "эффективн" в RU, по типам ==')
by_type = {}
for r in d:
    if r.get('ru') and 'эффективн' in r['ru'].lower():
        by_type.setdefault(r.get('type'), []).append(r)
for t, rows in sorted(by_type.items()):
    print(f'-- тип {t}: {len(rows)}')
for t, rows in sorted(by_type.items()):
    if t in ('PERK', 'MGEF', 'SCRL', 'SPEL', 'ENCH'):
        for r in rows:
            print(f"[{t}|{r['file']}|{r['fid']}] {r['edid']}: {r['ru'][:230]}")

print()
print('== corpus57: PERK с "сильнее" в RU — счетчик ==')
n = sum(1 for r in d if r.get('ru') and 'сильнее' in r['ru'].lower()
        and r.get('type') == 'PERK')
print('PERK-полей со "сильнее":', n)
perk_eff = sum(1 for r in d if r.get('ru') and 'эффективн' in r['ru'].lower()
               and r.get('type') == 'PERK')
print('PERK-полей с "эффективн":', perk_eff)

print()
print('== corpus57: записи 100-а (регистр, report_100 §4) ==')
for r in d:
    if r.get('fid') in REG100 and r.get('type') == 'PERK':
        print(json.dumps(r, ensure_ascii=False))

print()
print('== desc_ru.py: целевые EDID ==')
for line in open(DESC, encoding='utf-8'):
    if any(e in line for e in EDIDS):
        print(line.rstrip()[:460])

print()
print('== DESC.ini (MGEF DNAM): строки с "эффективн" ==')
c = 0
for line in open(DESCI, encoding='utf-8-sig'):
    if 'эффективн' in line.lower():
        c += 1
        print(line.strip()[:240])
print('всего строк:', c)

print()
print('== эталон v149: целевые EDID ==')
for line in open(PERKS, encoding='utf-8'):
    if any(e in line for e in EDIDS):
        print(line.rstrip()[:460])
