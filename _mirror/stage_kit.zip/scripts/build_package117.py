#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 117, шаг: сборка пакета v1.5.18.
База = снапшот нашего релиза v1.5.17 (work/qa117/base_v117.zip, md5
344e699a76f44d3c6bd69c0870dbcab4; аплоада игрока в этом заходе нет).
Замены ровно 2 записи: main ESP (регистр MGEF FULL «Маскировка - …»,
вердикт 116-а), info.xml 1.5.17→1.5.18.
"""
import zipfile, os, hashlib, shutil

SRC_ZIP = '/home/z/my-project/work/qa117/base_v117.zip'
V117_ZIP_MD5 = '344e699a76f44d3c6bd69c0870dbcab4'
DST = '/home/z/my-project/download/Paths of Empyrean RU 1.5.zip'
V118 = '/home/z/my-project/work/qa117/v118'
MAIN = '00 Core/PathsOfEmpyrean.esp'
RU15 = '/home/z/my-project/work/ru15'


def main():
    assert hashlib.md5(open(SRC_ZIP, 'rb').read()).hexdigest() == V117_ZIP_MD5
    esp = open(f'{V118}/{MAIN}', 'rb').read()
    md5_esp = hashlib.md5(esp).hexdigest()

    zsrc = zipfile.ZipFile(SRC_ZIP)
    names = zsrc.namelist()
    orig_crc = {i.filename: i.CRC for i in zsrc.infolist()}
    print('источник: снапшот v1.5.17 (%d записей)' % len(names))

    info_src = zsrc.read('fomod/info.xml').decode('utf-8')
    assert '<Version>1.5.17</Version>' in info_src
    info_new = info_src.replace('<Version>1.5.17</Version>', '<Version>1.5.18</Version>')
    assert '<Version>1.5.18</Version>' in info_new and '1.5.17' not in info_new
    print('info.xml: Version 1.5.17 -> 1.5.18')

    repl = {MAIN: esp, 'fomod/info.xml': info_new.encode('utf-8')}
    zout = zipfile.ZipFile(DST, 'w')
    for item in zsrc.infolist():
        arc = item.filename
        zout.writestr(item, repl[arc] if arc in repl else zsrc.read(arc))
    zout.close()
    print('zip собран')

    print()
    print('=== ВЕРИФИКАЦИЯ ПАКЕТА v1.5.18 ===')
    z2 = zipfile.ZipFile(DST)
    names2 = z2.namelist()
    assert z2.testzip() is None
    assert len(names2) == 63 and set(names2) == set(names)
    print('testzip: OK, записей: %d (набор совпадает)' % len(names2))

    diff = [n for n in names if orig_crc[n] != z2.getinfo(n).CRC]
    assert set(diff) == set(repl), 'CRC-дифф: %s' % diff
    print('CRC vs v1.5.17: изменены ровно 2 записи (main ESP, info.xml), '
          'остальные %d байт-в-байт' % (len(names) - 2))

    assert hashlib.md5(z2.read(MAIN)).hexdigest() == md5_esp
    print('ESP md5 == work/qa117/v118: %s' % md5_esp)

    ver = z2.read('fomod/info.xml').decode('utf-8')
    assert '<Version>1.5.18</Version>' in ver
    print('версия пакета: 1.5.18')

    shutil.copyfile(f'{V118}/{MAIN}', os.path.join(RU15, '00 Core', 'PathsOfEmpyrean.esp'))
    open(os.path.join(RU15, 'fomod', 'info.xml'), 'w', encoding='utf-8', newline='').write(info_new)
    print('зеркало work/ru15: main ESP, info.xml обновлены')

    print()
    print('ПАКЕТ:', DST, '(%d Б)' % os.path.getsize(DST))
    print('md5 пакета: %s' % hashlib.md5(open(DST, 'rb').read()).hexdigest())


if __name__ == '__main__':
    main()
