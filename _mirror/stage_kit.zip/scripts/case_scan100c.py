# -*- coding: utf-8 -*-
"""Добор: 77 FULL-диффов, 11 DESC-диффов, полный аудит прописных, фикс парсера desc_ru."""
import json
import re
from pathlib import Path
from collections import defaultdict, Counter

ROOT = Path("/home/z/my-project")
DUMP = ROOT / "work/qa100/dump_v157.jsonl"
V149 = ROOT / "handoff/04_эталоны_игрока/perks_v149.jsonl"
QA96 = ROOT / "work/qa96/perkdump.jsonl"
DESC_RU = ROOT / "handoff/06_код-истина_перевода/desc_ru.py"
OUT = ROOT / "work/qa100/case_report3.txt"

out = []
def emit(s=""):
    out.append(s)

recs = [json.loads(l) for l in open(DUMP, encoding="utf-8") if l.strip()]
v149 = [json.loads(l) for l in open(V149, encoding="utf-8") if l.strip()]
v149_by = {r["formid"]: r for r in v149}
q96 = {p["formid"]: p for p in (json.loads(l) for l in open(QA96, encoding="utf-8") if l.strip())}

by_rec = defaultdict(list)
for r in (x for x in recs if x["rtype"] == "PERK"):
    by_rec[(r["file"], r["formid"])].append(r)

def join_perk(fs):
    full = next((x["text"] for x in fs if x["field"] == "FULL" and x["occ"] == 1), "")
    descs = [x["text"] for x in fs if x["field"] == "DESC"]
    desc = max(descs, key=len) if descs else ""
    return full, desc

# --- 1. парсер desc_ru: диагностика --------------------------------------
dru_txt = DESC_RU.read_text(encoding="utf-8")
emit("1. ПАРСЕР desc_ru.py")
emit(f"   размер файла: {len(dru_txt)} байт; строк: {dru_txt.count(chr(10))}")
emit(f"   вхождений «DESC_RU»: {dru_txt.count('DESC_RU')}")
# найти все dict-определения верхнего уровня
for mo in re.finditer(r"^([A-Z_]+)\s*=\s*\{", dru_txt, re.M):
    emit(f"   dict: {mo.group(1)} @ offset {mo.start()}")
# парсим весь файл как python (безопасно: это словари литералов)
import ast
tree = ast.parse(dru_txt)
dru = {}
for node in ast.walk(tree):
    if isinstance(node, ast.Assign) and getattr(node.targets[0], "id", "") in ("DESC_RU", "DESC"):
        dru = ast.literal_eval(node.value)
emit(f"   распарсено ast.literal_eval: {len(dru)} записей")
emit(f"   первые ключи: {list(dru)[:6]}")

# --- 2. 11 DESC-диффов эталон vs ESP --------------------------------------
emit()
emit("2. DESC: ЭТАЛОН v1.4.9 vs ESP v1.5.7 (все отличия)")
n = 0
for formid, r in v149_by.items():
    fs = by_rec.get(("main", formid))
    if not fs:
        continue
    _, desc = join_perk(fs)
    if desc and desc != r.get("desc"):
        n += 1
        emit(f"   {formid} {r['edid']}:")
        emit(f"     v149: {r['desc']}")
        emit(f"     v157: {desc}")
emit(f"   итого отличий: {n}")

# --- 3. 77 FULL-диффов ----------------------------------------------------
emit()
emit("3. FULL: ЭТАЛОН v1.4.9 vs ESP v1.5.7 (все отличия)")
cnt_tree = cnt_other = 0
groups = Counter()
for formid, r in v149_by.items():
    fs = by_rec.get(("main", formid))
    if not fs:
        continue
    full, _ = join_perk(fs)
    if full and full != r.get("full"):
        in_tree = "дерево" if formid in q96 else "вне деревьев"
        groups[in_tree] += 1
        emit(f"   [{in_tree}] {formid} {r['edid']}: {r.get('full')!r} -> {full!r}")
emit(f"   распределение: {dict(groups)}")

# --- 4. все ПРОПИСНЫЕ вхождения лексем (поиск обратных дефектов) ----------
emit()
emit("4. ВСЕ ПРОПИСНЫЕ вхождения навыков/школ в DESC (контекст — не начало ли предложения)")
TOKENS = ["колдовств", "иллюзи", "изменени", "разрушени", "восстановлени",
          "зачарован", "алхими", "красноречи", "кузнечн", "скрытност",
          "блокирован", "стрельб", "легкой брони", "тяжелой брони"]
def sent_start(blob, pos):
    head = blob[:pos].rstrip()
    return (not head) or head[-1] in ".!?:\n"
for (f, formid), fs in sorted(by_rec.items()):
    if f != "main":
        continue
    full, desc = join_perk(fs)
    blob = (full + " «» " + desc) if desc else full
    for t in TOKENS:
        for mo in re.finditer(t, blob, re.I):
            w = mo.group(0)
            if not w[0].isupper():
                continue
            a = max(0, mo.start() - 45)
            frag = blob[a:mo.end() + 45].replace("\r", "").replace("\n", "⏎")
            tag = "начало" if sent_start(blob, mo.start()) else "СЕРЕДИНА"
            emit(f"   [{tag}] {formid} ({full[:20]}) | …{frag}…")

OUT.write_text("\n".join(out), encoding="utf-8")
print(f"отчёт: {OUT} ({len(out)} строк)")
