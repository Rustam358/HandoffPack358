#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 105 (аналитический аудит покрытия перевода v1.5.9).

Вопрос игрока: «есть ли что-то, что мы не перевели, но что может быть
видно игроку в игре?». НИЧЕГО не правит — только инвентаризация.

Слои аудита:
 1) 39 ESP — полный дамп текстовых полей (dump_v159_full.jsonl, 12 323 полей):
    без кириллицы + латиница => кандидат; деление на санкции/политику/находки;
    смешанные RU+EN-поля (латиница вне белого списка) => отдельный список.
 2) DESC.ini ×3 (MGEF-описания, SkyPatcher-инъекция) — значения EN.
 3) ShortbowNames.ini — имена EN.
 4) MCM RUSSIAN.txt (UTF-16LE) — значения EN.
 5) FOMOD ModuleConfig.xml — видимые строки установщика.
 6) PEX ×12 пакета — строковые таблицы: поиск игровых EN-строк.
 7) EN-пары из corpus57.json — для каждой находки её EN-источник.

Выход: work/qa105/audit105_report.txt + work/qa105/findings.jsonl.
"""
import json, re, os, sys, zipfile, io, zlib, struct

ROOT = '/home/z/my-project/upload/poe_pack'
REL = f'{ROOT}/work/qa104/release159'
QA = f'{ROOT}/work/qa105'
DUMP = f'{ROOT}/work/qa104/dump_v159_full.jsonl'
CORPUS = f'{ROOT}/handoff/06_код-истина_перевода/corpus57.json'
os.makedirs(QA, exist_ok=True)

rep = open(f'{QA}/audit105_report.txt', 'w', encoding='utf-8')
fin = open(f'{QA}/findings.jsonl', 'w', encoding='utf-8')


def w(s=''):
    rep.write(s + '\n')


TOKEN_RE = re.compile(r'<[^<>]*>|%[a-zA-Z0-9.\-]*|\[[^\[\]]*\]|\{[^{}]*\}')
LATIN = re.compile(r"[A-Za-z][A-Za-z'’.\-]*")
CYR = re.compile(r'[А-Яа-яЁё]')
BRAND = re.compile(r'Paths of Empyrean|Path of Sorcery|PoE\b|ENB|WeaponSpeedMult|pc\b|ParDragonborn|DLC1|DLC2|Hearthfirees?|Update\.esm', re.I)

# ---------------------------------------------------------------- санкции
SANCTION_EN_FIELDS = {('MGEF', 'FULL'), ('SPEL', 'FULL'), ('QUST', 'FULL'),
                      ('ENCH', 'FULL'), ('RACE', 'FULL')}
NO_TRANSLATE_RTYPES = {'CLAS', 'FACT', 'HDPT', 'WOOP'}
SERVICE_EDID = re.compile(r'TEST|ISP Test|AscendantConjurerTest|^GRIM|Cooldown|QA[-_ ]|_QA', re.I)

# corpus57: en-пары по ключу
en_of = {}
for r in json.load(open(CORPUS, encoding='utf-8')):
    en_of[(r['file'], r['type'], r['fid'], r['field'], r.get('occ', 1))] = r.get('en')


def en_pair(r):
    k = (r['file'], r['rtype'], r['formid'], r['field'], r['occ'])
    return en_of.get(k)


ESP_FINDINGS = []


def emit(rec, layer, why, note='', en=None):
    out = {'layer': layer, 'why': why,
           'file': rec.get('file', ''), 'rtype': rec.get('rtype', ''),
           'formid': rec.get('formid', ''), 'edid': rec.get('edid', ''),
           'field': rec.get('field', ''), 'occ': rec.get('occ', ''),
           'text': rec.get('text', '')}
    if note:
        out['note'] = note
    if en is not None:
        out['en'] = en
    fin.write(json.dumps(out, ensure_ascii=False) + '\n')
    fin.flush()
    if layer == 'ESP':
        ESP_FINDINGS.append(out)
    return out


w('=' * 76)
w('АУДИТ ПОКРЫТИЯ ПЕРЕВОДА — выпущенный v1.5.9 (истина, md5 == zip игрока)')
w('=' * 76)

# ================================================================= 1. ESP
recs = [json.loads(l) for l in open(DUMP, encoding='utf-8')]
w(f'\n[1] ESP-слой: {len(recs)} текстовых полей (39 ESP)')

cls = {'sanction_names': 0, 'no_translate_type': 0, 'service': 0,
       'nnam_sleeping': 0, 'brand_only': 0, 'mixed_ok': 0,
       'no_cyr_no_latin': 0, 'findings': 0, 'mixed_findings': 0}
seen = set()


def split_cat(r, t):
    """Вернуть (категорию, лат-слова вне бренд-токенов)."""
    if (r['rtype'], r['field']) in SANCTION_EN_FIELDS:
        return 'sanction_names'
    if r['rtype'] in NO_TRANSLATE_RTYPES:
        return 'no_translate_type'
    if SERVICE_EDID.search(r['edid'] or ''):
        return 'service'
    if r['file'] == 'main' and r['rtype'] == 'QUST' and r['field'] == 'NNAM':
        return 'nnam_sleeping'
    if r['rtype'] == 'MISC' and r['field'] == 'FULL' and (r['text'] or '').strip() in ('Заучить: ',):
        return 'service'
    return None


n_no_cyr = 0
for r in recs:
    t = r['text'] or ''
    has_cyr = bool(CYR.search(t))
    words = LATIN.findall(TOKEN_RE.sub(' ', t))
    latin_clean = [x for x in words if not BRAND.fullmatch(x)]
    if not has_cyr:
        n_no_cyr += 1
        if not words:
            cls['no_cyr_no_latin'] += 1
            continue
        cat = split_cat(r, t)
        key = (r['file'], r['rtype'], r['formid'], r['field'], r['occ'])
        if key in seen:
            continue
        if cat:
            cls[cat] += 1
            continue
        if not latin_clean:
            cls['brand_only'] += 1
            continue
        cls['findings'] += 1
        seen.add(key)
        emit(r, 'ESP', 'EN-остаток (нет кириллицы, вне санкций)', en=en_pair(r))
    else:
        # смешанные: кириллица + латиница вне бренда/токенов
        if latin_clean:
            cat = split_cat(r, t)
            if cat:
                cls['mixed_ok'] += 1
                continue
            cls['mixed_findings'] += 1
            emit(r, 'ESP', 'смешанное RU+EN (латиница вне белого списка)', en=en_pair(r))

w(f'  полей вообще без кириллицы: {n_no_cyr}')
for k, v in cls.items():
    w(f'  {k}: {v}')

# сводка находок ESP по (file, rtype, field) — из памяти, файл не перечитываем
w('\n  -- находки ESP (вне санкций) по типам:')
cnt = {}
for r in ESP_FINDINGS:
    cnt[(r['file'], r['rtype'], r['field'], r['why'][:12])] = cnt.get((r['file'], r['rtype'], r['field'], r['why'][:12]), 0) + 1
for k in sorted(cnt, key=lambda x: (-cnt[x], str(x))):
    w(f'    {k}: {cnt[k]}')

# ============================================================ 2. DESC.ini
w('\n[2] DESC.ini (MGEF-описания, SkyPatcher-инъекция)')
DESC_INIS = [
    '00 Core/PathsOfEmpyrean_DESC.ini',
    '30 CC Patches/Advanced Crossbows/PoE-CCAdvancedCrossbows-Patch_DESC.ini',
    '30 CC Patches/Expanded Crossbow Pack/PoE-CCExpandedCrossbowPack-Patch_DESC.ini',
]
# EN-исходник 1.4 (для сверки значений)
en_desc = {}
for path in ['handoff/08_оригинал_1.4_EN/Data/SKSE/Plugins/POE/PathsOfEmpyrean_DESC.ini',
             'handoff/08_оригинал_1.4_EN/00 Core/PathsOfEmpyrean_DESC.ini']:
    if os.path.exists(f'{ROOT}/{path}'):
        for ln in open(f'{ROOT}/{path}', encoding='utf-8-sig', errors='replace'):
            if '|' in ln:
                k = ln.split('|', 1)[0].strip()
                v = ln.split('|', 1)[1].split('|')[0].strip()
                en_desc[k] = v
        w(f'  EN-исходник DESC.ini найден: {path} ({len(en_desc)} ключей)')
        break
else:
    # искать глубже
    hits = []
    for dp, dn, fn in os.walk(f'{ROOT}/handoff/08_оригинал_1.4_EN'):
        for f in fn:
            if 'DESC' in f and f.endswith('.ini'):
                hits.append(os.path.join(dp, f))
    w('  EN DESC.ini кандидаты: ' + '; '.join(os.path.relpath(h, ROOT) for h in hits[:5]))
    if hits:
        for ln in open(hits[0], encoding='utf-8-sig', errors='replace'):
            if '|' in ln:
                k = ln.split('|', 1)[0].strip()
                v = ln.split('|', 1)[1].split('|')[0].strip()
                en_desc[k] = v
        w(f'  взят первый: {len(en_desc)} ключей')

for arc in DESC_INIS:
    raw = open(f'{REL}/{arc}', encoding='utf-8-sig').read()
    lines = [l for l in raw.splitlines() if l.strip()]
    n_ru = n_en = n_empty = 0
    for l in lines:
        parts = l.split('|')
        if len(parts) < 2:
            n_empty += 1
            continue
        val = parts[1]
        if not val.strip():
            n_empty += 1
            emit({'file': arc, 'rtype': 'DESC.ini', 'formid': parts[0], 'field': 'value',
                  'occ': 1, 'text': l}, 'DESC.ini', 'пустое значение')
        elif not CYR.search(val) and LATIN.search(val):
            n_en += 1
            k = parts[0].strip()
            en = en_desc.get(k)
            emit({'file': arc, 'rtype': 'DESC.ini', 'formid': k, 'field': 'value',
                  'occ': 1, 'text': val}, 'DESC.ini', 'значение без кириллицы',
                  en=en)
        else:
            n_ru += 1
    w(f'  {os.path.basename(arc)}: строк={len(lines)}, RU={n_ru}, EN-значений={n_en}, прочее={n_empty}')

# ===================================================== 3. ShortbowNames.ini
w('\n[3] ShortbowNames.ini (KID/SkyPatcher fullName-инъекции)')
sb = open(f'{REL}/00 Core/SKSE/Plugins/POE/Weapon/PathsOfEmpyrean_ShortbowNames.ini',
          encoding='utf-8-sig').read()
n_sb = n_sb_en = 0
for l in sb.splitlines():
    m = re.search(r'fullName=~([^~]*)~', l)
    if not m:
        continue
    n_sb += 1
    name = m.group(1)
    if not CYR.search(name) and LATIN.search(name):
        n_sb_en += 1
        emit({'file': 'ShortbowNames.ini', 'rtype': 'KID', 'formid': l.split(':')[0],
              'field': 'fullName', 'occ': 1, 'text': name}, 'ShortbowNames',
             'имя без кириллицы')
w(f'  имён: {n_sb}, без кириллицы: {n_sb_en}')

# ========================================================== 4. MCM-слой
w('\n[4] MCM PathsOfEmpyrean_RUSSIAN.txt (UTF-16LE)')
mcm = open(f'{REL}/00 Core/Interface/Translations/PathsOfEmpyrean_RUSSIAN.txt',
           encoding='utf-16').read()
n_mcm = n_mcm_en = 0
for l in mcm.splitlines():
    if '\t' not in l:
        continue
    k, v = l.split('\t', 1)
    n_mcm += 1
    if not CYR.search(v) and LATIN.search(v):
        n_mcm_en += 1
        emit({'file': 'RUSSIAN.txt', 'rtype': 'MCM', 'formid': k, 'field': 'value',
              'occ': 1, 'text': v}, 'MCM', 'значение без кириллицы')
w(f'  ключей: {n_mcm}, значений без кириллицы: {n_mcm_en} (санкц.: $PoEModName + 4 наследия v1.34)')

# ============================================================== 5. FOMOD
w('\n[5] FOMOD ModuleConfig.xml (видимые строки установщика)')
mc = open(f'{REL}/fomod/ModuleConfig.xml', encoding='utf-8').read()
disp = re.findall(r'(?:name|text|title)="([^"]+)"', mc)
n_fo = n_fo_en = 0
for s in disp:
    if len(s) < 2:
        continue
    n_fo += 1
    if not CYR.search(s) and LATIN.search(TOKEN_RE.sub(' ', s)):
        n_fo_en += 1
w(f'  видимых строк: {n_fo}, без кириллицы: {n_fo_en} (канон: имена опций = оригинал установщика PoE)')

# ================================================================ 6. PEX
w('\n[6] PEX-слой пакета (12 скриптов): строковые таблицы')

def pex_strings(data):
    """Строковые константы PEX: таблица строк + литералы. Возвращает список str."""
    out = []
    body = data
    # PEX v3 (SSE): magic FA57C0DE, ver u16, gameID u16, compression u8,
    # затем строковая таблица: u16 count + zstr*  (порядок BE у v3)
    if data[:4] == bytes.fromhex('de c0 57 fa'):
        comp = data[8]
        ver = struct.unpack('>H', data[4:6])[0]
        body = data
        if comp == 1:
            # сжат участок после заголовка (см. Papyrus asm): пробуем zlib с разных оффсетов
            for off in (9, 11, 12, 13):
                try:
                    body = data[:off] + zlib.decompress(data[off:])
                    break
                except Exception:
                    body = data
        cnt_off = 9 if comp == 0 else -1
        # строковая таблица: счётчик u16 (BE) на оффсете 9 (после 4+2+2+1)
        if cnt_off > 0:
            try:
                cnt = struct.unpack('>H', body[9:11])[0]
                off = 11
                for _ in range(cnt):
                    e = body.index(b'\x00', off)
                    s = body[off:e].decode('utf-8', 'replace')
                    if len(s) >= 2:
                        out.append(s)
                    off = e + 1
                # остальное: литеральные zstr в байт-коде (ascii-свалка ниже всё покроет)
            except Exception:
                pass
    # резерв: все printable-цепочки >= 4 (поймёт и сжатые после decompress)
    for m in re.finditer(rb'[\x20-\x7e][\x20-\x7e\xc2-\xf4]*[\x20-\x7e\xc0-\xff]|[\xc0-\xff][\x80-\xbf\xc0-\xff]{1,}[\x20-\x7e\xc0-\xff]|[\x20-\x7e\xc0-\xff][\x20-\x7e\x80-\xbf\xc0-\xff]{3,}', body):
        try:
            s = m.group().decode('utf-8')
        except UnicodeDecodeError:
            continue
        if s not in out:
            out.append(s)
    return out

SCRIPTS = sorted(os.listdir(f'{REL}/00 Core/scripts'))
WANT_NOTIFY = re.compile(r'Notification|MessageBox|Message\b|Show\(|Debug\.', re.I)
for f in SCRIPTS:
    raw = open(f'{REL}/00 Core/scripts/{f}', 'rb').read()
    strs = [s for s in pex_strings(raw) if len(s) >= 4]

    def is_prose(s):
        words = re.findall(r'[A-Za-zА-Яа-яЁё]{2,}', s)
        return len(words) >= 3 and ' ' in s
    prose = [s for s in strs if is_prose(s) and not WANT_NOTIFY.search(s)]
    cyr = [s for s in strs if CYR.search(s)]
    w(f'  {f}: строк={len(strs)}, кириллица={len(cyr)}, проза-кандидаты={len(prose)}')
    for s in prose[:12]:
        w(f'      ~ {s[:90]}')
    for s in prose:
        if CYR.search(s):
            continue
        emit({'file': f, 'rtype': 'PEX', 'formid': '', 'field': 'strtab',
              'occ': 1, 'text': s}, 'PEX', 'EN-строка в скрипте (кандидат)')

w()
w('=== КОНЕЦ АУДИТА (детали находок: findings.jsonl) ===')
rep.close()
fin.close()
print('OK -> work/qa105/audit105_report.txt')
