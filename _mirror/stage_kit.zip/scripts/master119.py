#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 119 (v1.5.19): вердикт игрока по отчёту 118 — «согласен со всеми
пунктами + 118-е. Делай»: применены 118-а (24 арбалета ECP — вернуть материал),
118-б (орочая/орочие → орочья/орочьи ×5), 118-в (Turn/Repel MGEF+ENCH → офиц.
«Отпугивание/Отталкивание» ×7), 118-г (Lucky-стрелы из офиц. баз ×6) и
118-е (порядок слов «нордского героя»/«Соловья»: 16 полей ESP + 6 строк
ShortbowNames.ini). 118-д НЕ утверждён (нет целевых имён; эталон v150).

База: аплоад игрока «Paths of Empyrean RU 1.5 (10).zip» = байт-в-байт наш
релиз v1.5.18 (md5 f55ce29f5fb6682d72a129486ab16de8 = записи выпуска, [T43];
правок игрока нет). Вход upload/ не редактируется — только читается.
Приёмник: work/qa119/v119 (свежая распаковка).
Фикслист: work/qa119/fixlist_v119.jsonl (58 esp + 2 ini; old сверены
байт-в-байт генератором scripts/fixproj119.py).
"""
import struct, zlib, os, json, zipfile, hashlib, shutil

BASE_ZIP = '/home/z/my-project/upload/Paths of Empyrean RU 1.5 (10).zip'
V118_ZIP_MD5 = 'f55ce29f5fb6682d72a129486ab16de8'
DST = '/home/z/my-project/work/qa119/v119'
FIX = '/home/z/my-project/work/qa119/fixlist_v119.jsonl'

FILEMAP = {
    'main': '00 Core/PathsOfEmpyrean.esp',
    'cc:ExpandedCrossbowPack':
        '30 CC Patches/Expanded Crossbow Pack/'
        'PoE-CCExpandedCrossbowPack-Patch.esp',
    'cc:Fishing': '30 CC Patches/Fishing/PoE-CCFishing-Patch.esp',
}

EXPECT = {'main': 31, 'cc:ExpandedCrossbowPack': 24, 'cc:Fishing': 3}

REC_HDR = 24


class Node:
    __slots__ = ('kind', 'label', 'tail', 'formid', 'data', 'children')


def parse(buf):
    root = []

    def walk(off, end, out):
        while off < end:
            t = buf[off:off+4]
            size = struct.unpack_from('<I', buf, off+4)[0]
            if t == b'GRUP':
                node = Node()
                node.kind = 'grup'
                node.label = None
                node.tail = bytes(buf[off+8:off+24])
                node.children = []
                walk(off + REC_HDR, off + size, node.children)
                out.append(node)
                off += size
            else:
                node = Node()
                node.kind = 'rec'
                node.label = t
                node.tail = bytes(buf[off+8:off+24])
                node.formid = struct.unpack_from('<I', buf, off+12)[0]
                node.data = bytes(buf[off+REC_HDR:off+REC_HDR+size])
                out.append(node)
                off += REC_HDR + size
    walk(0, len(buf), root)
    return root


def serialize_node(n, parts):
    if n.kind == 'grup':
        sub = []
        for c in n.children:
            serialize_node(c, sub)
        s = b''.join(sub)
        parts.append(b'GRUP' + struct.pack('<I', 24 + len(s)) + n.tail)
        parts.append(s)
    else:
        parts.append(n.label + struct.pack('<I', len(n.data)) + n.tail)
        parts.append(n.data)


def find_rec(nodes, formid):
    for n in nodes:
        if n.kind == 'grup':
            r = find_rec(n.children, formid)
            if r is not None:
                return r
        elif n.formid == formid:
            return n
    return None


def rec_flags(rec):
    return struct.unpack_from('<I', rec.tail, 0)[0]


def decode_body(rec):
    if rec_flags(rec) & 0x00040000:
        usz = struct.unpack_from('<I', rec.data, 0)[0]
        dec = zlib.decompress(rec.data[4:])
        assert len(dec) == usz
        return bytearray(dec), True
    return bytearray(rec.data), False


def encode_body(body, was_c):
    if was_c:
        return struct.pack('<I', len(body)) + zlib.compress(bytes(body))
    return bytes(body)


def patch_strings(path, patches):
    buf = open(path, 'rb').read()
    root = parse(buf)
    out = []
    for n in root:
        serialize_node(n, out)
    assert b''.join(out) == buf, f'самотест сериализации: {path}'
    applied = 0
    for formid, field, occ, old, new in patches:
        rec = find_rec(root, formid)
        assert rec is not None, f'{formid:08X} не найдена'
        body, was_c = decode_body(rec)
        off, seen, done = 0, 0, False
        while off < len(body):
            if off + 6 > len(body):
                break
            st = body[off:off+4].decode('ascii', 'replace')
            ssz = struct.unpack_from('<H', body, off+4)[0]
            if st == 'XXXX':
                real = struct.unpack_from('<I', body, off+6)[0]
                off += 6 + ssz + 6 + real
                continue
            cur_sz = ssz
            if st == field:
                seen += 1
                cur = bytes(body[off+6:off+6+ssz]).rstrip(b'\x00').decode(
                    'utf-8', 'replace')
                if seen == occ:
                    assert cur == old, (
                        f'{formid:08X} {field}#{occ}: {cur[:80]!r} != {old[:80]!r}')
                    newb = new.encode('utf-8') + b'\x00'
                    body[off+6:off+6+ssz] = newb
                    struct.pack_into('<H', body, off+4, len(newb))
                    done = True
                    applied += 1
                    cur_sz = len(newb)
            off += 6 + cur_sz
        assert done, f'{formid:08X} {field}#{occ} не применён'
        rec.data = encode_body(body, was_c)
    out = []
    for n in root:
        serialize_node(n, out)
    data = b''.join(out)
    open(path, 'wb').write(data)
    print(f'  строки {os.path.basename(path)}: патчей {applied}, '
          f'файл {len(buf)} -> {len(data)} Б')
    return applied


def apply_ini(path, old, new, expect):
    raw = open(path, 'rb').read()
    n = raw.count(old.encode('utf-8'))
    assert n == expect, f'{path}: ожидалось {expect} вхождений, найдено {n}'
    out = raw.replace(old.encode('utf-8'), new.encode('utf-8'))
    assert out.count(new.encode('utf-8')) == expect
    assert old.encode('utf-8') not in out
    open(path, 'wb').write(out)
    print(f'  INI {os.path.basename(path)}: замен {n} (ожидалось {expect})')
    return n


def main():
    assert hashlib.md5(open(BASE_ZIP, 'rb').read()).hexdigest() == V118_ZIP_MD5, \
        'аплоад игрока не равен записи выпуска v1.5.18!'
    if os.path.isdir(DST):
        shutil.rmtree(DST)
    with zipfile.ZipFile(BASE_ZIP) as z:
        assert z.testzip() is None
        info = z.read('fomod/info.xml').decode('utf-8')
        assert '<Version>1.5.18</Version>' in info, 'база не v1.5.18!'
        z.extractall(DST)
    print('база: аплоад игрока = наш релиз v1.5.18 (md5 сверен), '
          'свежая распаковка в work/qa119/v119')

    esp, ini = [], []
    for line in open(FIX, encoding='utf-8'):
        r = json.loads(line)
        if r['kind'] == 'esp':
            esp.append(r)
        else:
            ini.append(r)
    assert len(esp) == 58 and len(ini) == 2, (len(esp), len(ini))

    total = 0
    for scope in ['main', 'cc:ExpandedCrossbowPack', 'cc:Fishing']:
        patches = [(int(r['formid'], 16), r['field'], r['occ'], r['old'], r['new'])
                   for r in esp if r['file'] == scope]
        assert len(patches) == EXPECT[scope], (scope, len(patches))
        print(f'[{scope}] {FILEMAP[scope]}')
        total += patch_strings(os.path.join(DST, FILEMAP[scope]), patches)

    for r in ini:
        path = os.path.join(DST, r['scope'])
        assert os.path.exists(path), path
        total += apply_ini(path, r['old'], r['new'], r['expect'])
    assert total == 58 + 6, total

    print()
    for scope in ['main', 'cc:ExpandedCrossbowPack', 'cc:Fishing']:
        full = os.path.join(DST, FILEMAP[scope])
        print(f'md5 {os.path.basename(full)}: '
              f'{hashlib.md5(open(full, "rb").read()).hexdigest()} '
              f'({os.path.getsize(full)} Б)')
    ini_path = os.path.join(
        DST, '00 Core/SKSE/Plugins/POE/Weapon/PathsOfEmpyrean_ShortbowNames.ini')
    print(f'md5 ShortbowNames.ini: '
          f'{hashlib.md5(open(ini_path, "rb").read()).hexdigest()} '
          f'({os.path.getsize(ini_path)} Б)')
    print(f'ИТОГО применено: {total} (58 патчей ESP + 6 строк INI)')


if __name__ == '__main__':
    main()
