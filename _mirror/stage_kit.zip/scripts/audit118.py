#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 118 «Великая» проверка тиров — ГЛАВНЫЙ АУДИТ (ESP-сторона).

Домены: оружие, броня, зачарования, кузнечное дело, магия, прочее.
Входы:
  work/qa117/dump_v118_full.jsonl  — истина RU v1.5.18 (39 ESP)
  work/qa118/dump_en14.jsonl       — EN 1.4 (те же 39 ESP)
  handoff/04_эталоны_игрока/Skyrim_ITEM_IDs_official.txt — офиц. имена (канон игрока)
Выход: work/qa118/audit_report.txt + tsv-детали.
Аналитический скрипт: НИЧЕГО не правит.
"""
import json
import re
from collections import defaultdict, Counter

RU = [json.loads(l) for l in open('/home/z/my-project/work/qa117/dump_v118_full.jsonl', encoding='utf-8')]
EN = [json.loads(l) for l in open('/home/z/my-project/work/qa118/dump_en14.jsonl', encoding='utf-8')]
en_map = {(r['file'], r['formid'], r['rtype'], r['field'], r.get('occ', 1)): r['text'] for r in EN}
A = []
for r in RU:
    e = en_map.get((r['file'], r['formid'], r['rtype'], r['field'], r.get('occ', 1)))
    A.append({**r, 'en': e if e is not None else None})

# ---- офиц. канон по ID ----
canon = {}
for line in open('/home/z/my-project/handoff/04_эталоны_игрока/Skyrim_ITEM_IDs_official.txt', encoding='utf-8'):
    m = re.match(r'^(.*?)\s+-\s+([0-9A-Fa-fXx]{6,8})$', line.strip())
    if m:
        fid = m.group(2).upper().lstrip('X').zfill(6)
        canon[fid] = m.group(1).strip()
print('канон-имён:', len(canon))

OUT = open('/home/z/my-project/work/qa118/audit_report.txt', 'w', encoding='utf-8')


def w(s=''):
    OUT.write(s + '\n')


def canon_match(formid):
    fid8 = formid.upper()
    if fid8.startswith(('000', '001', '003')):
        return canon.get(fid8[3:])
    return None  # DLC/CC c XX-префиксами — отдельно


w('=' * 76)
w('ЭТАП 118. ВЕЛИКАЯ ПРОВЕРКА ТИРОВ — главный аудит (ESP, v1.5.18 vs EN 1.4 vs офиц. канон)')
w('=' * 76)

# ============================ A/B: ванильные ID vs офиц. канон ============================
w()
w('=' * 76)
w('1. ВАНИЛЬНЫЕ ЗАПИСИ (000/001/003) vs ОФИЦИАЛЬНЫЙ КАНОН ИГРОКА')
w('   (перки/заклинания/эффекты не проверяем — там санкции/эталоны; только предметы)')
w('=' * 76)
ITEM_RTYPES = {'WEAP', 'ARMO', 'AMMO', 'MISC', 'INGR', 'ALCH', 'SCRL', 'SLGM', 'BOOK'}
mismatches = []
van_checked = 0
for r in A:
    if r['rtype'] not in ITEM_RTYPES or r['field'] != 'FULL':
        continue
    off = canon_match(r['formid'])
    if off is None:
        continue
    van_checked += 1
    if r['text'] != off:
        mismatches.append((r, off))
w(f'проверено ванильных предметов: {van_checked}, расхождений с офиц. именем: {len(mismatches)}')
for r, off in mismatches:
    w(f"  [{r['file']} {r['formid']} {r['rtype']}] {r['edid'][:36]:36}")
    w(f"     RU:  {r['text'][:70]}")
    w(f"     ОФФ: {off[:70]}")
    w(f"     EN:  {(r['en'] or '(нет в EN 1.4)')[:70]}")

# ============================ C: Turn-лестница ============================
w()
w('=' * 76)
w('2. TURN-ЛЕСТНИЦА зачарований/оружия (Blessed→…→Holy; канон v1.5.6)')
w('=' * 76)
TURN = [('Blessed', 'Благословленный'), ('Sanctified', 'Освященный'), ('Reverent', 'Почитаемый'),
        ('Hallowed', 'Святой'), ('Virtuous', 'Добродетельный'), ('Holy', 'Священный')]
turn_rows = []
for r in A:
    if r['field'] != 'FULL' or not r['en']:
        continue
    for en_t, ru_t in TURN:
        if r['en'].startswith(en_t + ' '):
            turn_rows.append((r, en_t, ru_t))
            break
bad_turn = [(r, en_t, ru_t) for r, en_t, ru_t in turn_rows
            if not r['text'].lower().startswith(ru_t.lower())]
w(f'полей с Turn-тиром: {len(turn_rows)}, нарушений канона: {len(bad_turn)}')
for r, en_t, ru_t in bad_turn:
    w(f"  [{r['file']} {r['formid']} {r['rtype']}] {en_t}→? RU: {r['text'][:60]}")
for en_t, ru_t in TURN:
    n = sum(1 for _, e, _ in turn_rows if e == en_t)
    w(f'  {en_t}→«{ru_t}»: {n}')

# ============================ D1: кузнечная лестница IWP ============================
w()
w('=' * 76)
w('3. КУЗНЕЧНАЯ ЛЕСТНИЦА ПЕРКОВ IWP (Basic→Apprentice→Journeyman→Master→Legendary)')
w('=' * 76)
SMITH_LADDER = ['Basic Smithing', 'Apprentice Smithing', 'Journeyman Smithing',
                'Expert Smithing', 'Master Smithing', 'Legendary Smithing']
for r in A:
    if r['en'] in SMITH_LADDER and r['field'] == 'FULL':
        w(f"  [{r['file']} {r['formid']} {r['rtype']}] EN: {r['en']:24} RU: {r['text']}")
# SPEL/PERK зеркала
w('  -- зеркала PERK↔SPEL (одинаковые имена):')
name_to_types = defaultdict(set)
for r in A:
    if r['en'] in SMITH_LADDER and r['field'] == 'FULL':
        name_to_types[r['text']].add((r['file'], r['rtype'], r['formid']))
for name, locs in sorted(name_to_types.items()):
    w(f"     «{name}»: " + ', '.join(f'{t}:{f}' for f, t, _ in sorted(locs)))

# ============================ A5: элементные лестницы зачарований ============================
w()
w('=' * 76)
w('4. ЛЕСТНИЦЫ ВЕЛИЧИН ЗАЧАРОВАНИЙ (EN-суффиксы "of X" в WEAP FULL)')
w('=' * 76)
SUF_TIER = {
    'Dismay': ['Dismay', 'Cowardice', 'Fear'],
    'Embers': ['Embers', 'Burning', 'Scorching', 'Fire', 'Inferno'],
    'Cold': ['Cold', 'Frost', 'Ice', 'Storms', 'Blizzard'],
    'Sapping': ['Sapping', 'Draining', 'Diminishing', 'Depletion', 'Void'],
    'Sparks': ['Sparks', 'Arcing', 'Shocks', 'Storms', 'Thunder'],
    'Souls': ['Souls', 'Soul Snares', 'Binding'],
    'Fatigue': ['Fatigue', 'Weariness', 'Torpor', 'Lethargy', 'Exhaustion'],
}
en_suf_ru = defaultdict(Counter)
for r in A:
    if r['rtype'] == 'WEAP' and r['field'] == 'FULL' and r['en'] and ' of ' in r['en']:
        suf = r['en'].split(' of ', 1)[1]
        ru = r['text']
        # вычленяем RU-хвост: после материала/типа — родительный хвост
        en_suf_ru[suf][ru] += 1
for suf in sorted(en_suf_ru):
    c = en_suf_ru[suf]
    if len(c) > 1:
        w(f'  «of {suf}» -> {len(c)} вариантов RU:')
        for k, v in c.most_common(8):
            w(f'     «{k}»×{v}')

# ============================ C2: Minor/Major/... на ENCH/MGEF ============================
w()
w('=' * 76)
w('5. ПРЕФИКСЫ ВЕЛИЧИН ENCH/MGEF (Minor/Lesser/Common/Greater/Grand/Potent/...)')
w('=' * 76)
PREFIXES = ['Minor', 'Lesser', 'Common', 'Greater', 'Grand', 'Major', 'Peerless',
            'Eminent', 'Extreme', 'Exquisite', 'Potent', 'Weak', 'Slight', 'Plentiful',
            'Vigorous', 'Ultimate', 'Concentrated', 'Virulent', 'Simple', 'Proven',
            'Refined', 'Elite', 'Ascendant']
pref_ru = defaultdict(Counter)
pref_rows = defaultdict(list)
for r in A:
    if r['rtype'] in ('ENCH', 'MGEF', 'SPEL', 'SCRL', 'ALCH') and r['field'] in ('FULL', 'DNAM') and r['en']:
        for p in PREFIXES:
            if r['en'].startswith(p + ' '):
                pref_ru[(r['rtype'], p)][r['text'][:44]] += 1
                pref_rows[(r['rtype'], p)].append(r)
                break
for (rt, p), c in sorted(pref_ru.items()):
    top = c.most_common(6)
    flag = ' <-- РАЗНОБОЙ' if len(c) > 1 else ''
    w(f'  {rt} {p}: ' + ' | '.join(f'«{k}»×{v}' for k, v in top) + flag)

OUT.close()
print('OK -> work/qa118/audit_report.txt')
