#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 94: пересборка пакета v1.5.6 с фиксом FOMOD (ошибка Vortex).

Причина ошибки Vortex: в fomod/ModuleConfig.xml файл Readme_PoE_Russian.txt указан в
<requiredInstallFiles>, но игрок удалил его из архива перед заливкой на Nexus ->
инсталлер не находит обязательный источник -> «Installer reported errors».

Фикс: убрать висячую <file>-ссылку на readme (сам readme игрок удалил сознательно).
Версия пакета: 1.5.5 -> 1.5.6 (moduleName + info.xml).
Замены записей: 3 ESP + ShortbowNames.ini (из work/v156) + fomod/*.xml.
Все остальные записи копируются байт-в-байт (ZipInfo: даты/атрибуты/метод сжатия)."""
import zipfile, re, os, sys

SRC = '/home/z/my-project/upload/Paths of Empyrean RU 1.5.zip'
DST = '/home/z/my-project/download/Paths of Empyrean RU 1.5.zip'
V156 = '/home/z/my-project/work/v156'

REPLACE_FILES = {
    '00 Core/PathsOfEmpyrean.esp': f'{V156}/00 Core/PathsOfEmpyrean.esp',
    '20 Spears/PoE-Addon-Spears.esp': f'{V156}/20 Spears/PoE-Addon-Spears.esp',
    '30 CC Patches/Necromantic Grimoire/PoE-CCNecroGrimoire-Patch.esp':
        f'{V156}/30 CC Patches/Necromantic Grimoire/PoE-CCNecroGrimoire-Patch.esp',
    '00 Core/SKSE/Plugins/POE/Weapon/PathsOfEmpyrean_ShortbowNames.ini':
        f'{V156}/00 Core/SKSE/Plugins/POE/Weapon/PathsOfEmpyrean_ShortbowNames.ini',
}


def patch_module_config(xml):
    n0 = xml.count('Readme_PoE_Russian.txt')
    xml2 = re.sub(r'[ \t]*<file\s+source="Readme_PoE_Russian\.txt"[^>]*/>[ \t]*\r?\n', '', xml)
    assert 'Readme_PoE_Russian.txt' not in xml2, 'readme-ссылка не удалена'
    assert xml2.count('v1.5.5') == 1, f'moduleName v1.5.5: {xml2.count("v1.5.5")}'
    xml2 = xml2.replace('v1.5.5', 'v1.5.6')
    print(f'  ModuleConfig.xml: readme-ссылок было {n0}, стало 0; moduleName -> v1.5.6')
    return xml2


def patch_info(xml):
    assert '<Version>1.5.5</Version>' in xml
    xml2 = xml.replace('<Version>1.5.5</Version>', '<Version>1.5.6</Version>')
    print('  info.xml: Version -> 1.5.6')
    return xml2


def main():
    zin = zipfile.ZipFile(SRC)
    names = zin.namelist()
    print('исходный архив:', len(names), 'записей')

    # Снимок CRC оригинала ДО записи (writestr мутирует ZipInfo из infolist)
    orig_crc = {i.filename: i.CRC for i in zin.infolist()}

    mc = zin.read('fomod/ModuleConfig.xml').decode('utf-8')
    info = zin.read('fomod/info.xml').decode('utf-8')
    mc2 = patch_module_config(mc)
    info2 = patch_info(info)

    replacements = dict(REPLACE_FILES)
    for arc, path in replacements.items():
        assert os.path.exists(path), path
        assert arc in names, arc

    os.makedirs(os.path.dirname(DST), exist_ok=True)
    zout = zipfile.ZipFile(DST, 'w')
    changed = []
    for item in zin.infolist():
        arc = item.filename
        if arc == 'fomod/ModuleConfig.xml':
            zout.writestr(item, mc2.encode('utf-8'))
            changed.append(arc)
        elif arc == 'fomod/info.xml':
            zout.writestr(item, info2.encode('utf-8'))
            changed.append(arc)
        elif arc in replacements:
            zout.writestr(item, open(replacements[arc], 'rb').read())
            changed.append(arc)
        else:
            zout.writestr(item, zin.read(arc))
    zout.close()
    print('заменено записей:', len(changed))
    for c in changed:
        print('  *', c)

    # ---------------- ВЕРИФИКАЦИЯ ----------------
    print()
    print('=== ВЕРИФИКАЦИЯ ПАКЕТА ===')
    z2 = zipfile.ZipFile(DST)
    names2 = z2.namelist()
    assert z2.testzip() is None, 'testzip провален!'
    print('testzip: OK,', len(names2), 'записей')

    assert 'Readme_PoE_Russian.txt' not in names2
    assert set(names2) == set(names) - {'Readme_PoE_Russian.txt'} | set() if False else True
    assert set(names2) == set(names), 'состав записей изменился (не должно!)'
    # NB: в оригинале readme уже нет (игрок удалил) — состав не меняется.

    # CRC: изменены ровно 6 записей, остальные идентичны
    diff = []
    for n in names:
        c1 = orig_crc[n]
        c2 = z2.getinfo(n).CRC
        if c1 != c2:
            diff.append(n)
    expected = set(REPLACE_FILES) | {'fomod/ModuleConfig.xml', 'fomod/info.xml'}
    assert set(diff) == expected, f'CRC-дифф не совпал: {set(diff) ^ expected}'
    print(f'CRC: изменены ровно {len(diff)} ожидаемых записей, остальные {len(names) - len(diff)} байт-в-байт')

    # FOMOD: все source существуют, ссылки на readme нет
    xml = z2.read('fomod/ModuleConfig.xml').decode('utf-8')
    assert 'Readme_PoE_Russian.txt' not in xml
    srcs = set(re.findall(r'source="([^"]+)"', xml))
    missing = [s for s in srcs
               if not any(n == s or n.startswith(s + '/') for n in names2)]
    assert not missing, f'висячие source в FOMOD: {missing}'
    print(f'FOMOD: {len(srcs)} source-ссылок, все существуют; ссылок на readme нет')
    assert 'v1.5.6' in xml and 'v1.5.5' not in xml
    ver = z2.read('fomod/info.xml').decode('utf-8')
    assert '<Version>1.5.6</Version>' in ver
    print('версии: moduleName v1.5.6, info.xml 1.5.6')

    print()
    print('ПАКЕТ:', DST, f'({os.path.getsize(DST)} B)')
    print('ГОТОВ К ПЕРЕЗАЛИВКЕ НА NEXUS')


if __name__ == '__main__':
    main()
