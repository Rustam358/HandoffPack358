import py7zr, os, sys

src = "/home/z/my-project/upload/Spell Perk Item Distributor 36869 7.3.3 2026-08-26T21-53Z rvwm2B1Z2.7z"
dst = "/home/z/my-project/spid_work/spid_extracted"
os.makedirs(dst, exist_ok=True)

with py7zr.SevenZipFile(src, mode="r") as z:
    names = z.getnames()
    print(f"Entries in archive: {len(names)}")
    for n in names:
        print(" ", n)
    z.extractall(dst)
print("--- extracted to", dst)
