#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 113, шаг: независимая верификация v1.5.14 (откат 9 правок 112).
1) Дамп release-ESP (main) == 8914 полей; множество ключей == v1.5.13.
2) Дифф ru vs v1.5.13 == РОВНО 9 полей == fixlist_v114 (старое=v1.5.13,
   новое=v1.5.12), 0 лишних.
3) «ламелляр» в main = РОВНО 9 полей fixlist (точные значения);
   «чешуйчатые и пластинчатые» / «стальные пластинчатые и чешуйчатые» = 0;
   остальные «чешуйчат» main = ровно 31 канон-поле (Dragonscale MW ×5,
   кокон ×23, Чешуйчатка ×3).
4) Гигиена: %%/ё/рейтинг/укр./двойные пробелы/lone-\\n/кавычки/PERK DESC <=290.
5) Пак-скан: «чешуйчатые и пластинчатые» = 0 по всему паку (3 кодировки);
   «ламелляр» по паку = ровно 9 (все main); ShortbowNames/MCM/ALD/info.xml.
6) ESP релиза байт-в-байт == ESP v1.5.12 (md5 91d9767851a3f36eb50ed10c17fbfcc6).
7) Регресс-пробы 111/104/102 + CC-серии + соседи кузнечного дерева +
   112-а «- Драконий» ×2 (не тронуто).
"""
import sys, json, zipfile, re, os, glob, io, hashlib
sys.path.insert(0, '/home/z/my-project/work/handoff510/scripts')
from dump150 import dump_esp

ZIP = '/home/z/my-project/download/Paths of Empyrean RU 1.5.zip'
DUMP_NEW = '/home/z/my-project/work/qa113/dump_v114_release.jsonl'
DUMP_OLD = '/home/z/my-project/work/qa112/dump_v113_release.jsonl'
FIX = '/home/z/my-project/work/qa113/fixlist_v114.jsonl'
V112_MD5 = '91d9767851a3f36eb50ed10c17fbfcc6'

fails = []


def check(cond, msg):
    print(('  [OK] ' if cond else '  [FAIL] ') + msg)
    if not cond:
        fails.append(msg)


def dump_main(esp_path, out_path):
    with io.open(out_path, 'w', encoding='utf-8') as f:
        dump_esp(esp_path, 'main', f)
    return [json.loads(l) for l in io.open(out_path, encoding='utf-8')]


def main():
    # --- 0) распаковка выпускного zip ---
    z = zipfile.ZipFile(ZIP)
    esp_bytes = z.read('00 Core/PathsOfEmpyrean.esp')
    open('/home/z/my-project/work/qa113/_release_esp.bin', 'wb').write(esp_bytes)

    # --- 6) байт-регресс с v1.5.12 ---
    got = hashlib.md5(esp_bytes).hexdigest()
    check(got == V112_MD5,
          'ESP релиза == ESP v1.5.12 байт-в-байт (md5 %s)' % got)

    # --- 1) дампы ---
    fresh = dump_main('/home/z/my-project/work/qa113/_release_esp.bin', DUMP_NEW)
    old = [json.loads(l) for l in io.open(DUMP_OLD, encoding='utf-8')]
    print('1) дампы: new %d полей, old (v1.5.13) %d полей' % (len(fresh), len(old)))
    check(len(fresh) == 8914 and len(old) == 8914, 'полей ровно 8914 в обоих дампах')

    fk = {(r['formid'], r['rtype'], r['field'], r.get('occ', 1)): r['text'] for r in fresh}
    ok_ = {(r['formid'], r['rtype'], r['field'], r.get('occ', 1)): r['text'] for r in old}
    check(set(fk) == set(ok_), 'множество ключей идентично v1.5.13')

    # --- 2) дифф == fixlist ---
    fixes = [json.loads(l) for l in io.open(FIX, encoding='utf-8')]
    expected = {(int(f['formid'], 16), f['field'], f['occ']): f for f in fixes}
    diffs = [(k, ok_[k], fk[k]) for k in ok_ if ok_[k] != fk[k]]
    print('2) дифф полей vs v1.5.13: %d (ожидается %d)' % (len(diffs), len(expected)))
    okn, bad = 0, []
    for (formid, rtype, field, occ), old_t, new_t in diffs:
        f = expected.get((int(formid, 16), field, occ))
        if f and old_t == f['old'] and new_t == f['new']:
            okn += 1
        else:
            bad.append((formid, field, old_t[:60], new_t[:60]))
    check(okn == len(expected) and len(diffs) == len(expected) and not bad,
          'дифф == fixlist (%d/%d); лишних: %d %s' % (okn, len(expected), len(bad), bad[:3]))

    # --- 3) ламелляр/чешуйчат картина ---
    lam = {k: t for k, t in fk.items() if 'ламелляр' in (t or '').lower()}
    rtype_of = {}
    for r in fresh:
        rtype_of.setdefault((int(r['formid'], 16), r['field'], r.get('occ', 1)), r['rtype'])
    exp_lam = {}
    for x in fixes:
        exp_lam[(int(x['formid'], 16), x['field'], x['occ'])] = x['new']
    lam3 = {(int(k[0], 16), k[2], k[3]): t for k, t in lam.items()}
    check(set(lam3) == set(exp_lam) and lam3 == exp_lam,
          'main ESP: «ламелляр» = ровно 9 полей fixlist с точными значениями (факт %d)' % len(lam))
    for k in sorted(exp_lam):
        fk_key = ('%08X' % k[0], rtype_of[k], k[1], k[2])
        check(fk[fk_key] == exp_lam[k], '  %08X %s#%d = «%s»' % (k[0], k[1], k[2], exp_lam[k]))
    cnt1 = sum(1 for t in fk.values() if t and 'чешуйчатые и пластинчатые' in t)
    cnt2 = sum(1 for t in fk.values() if t and 'стальные пластинчатые и чешуйчатые' in t)
    check(cnt1 == 0 and cnt2 == 0,
          'main ESP: «чешуйчатые и пластинчатые» = 0 и «стальные пластинчатые и чешуйчатые» = 0 (факт %d/%d)' % (cnt1, cnt2))

    # классификация остальных «чешуйчат»
    che = [(k, t) for k, t in fk.items() if t and 'чешуйчат' in t.lower()]
    def allowed(k, t):
        if 'дракон' in t.lower() and 'чешуйчат' in t.lower() and t.startswith('Мастерск'):
            return True   # Masterwork Dragonscale ×5
        if 'Чешуйчатый кокон' in t:
            return True   # Грим-серия (санкция 111)
        if 'Чешуйчатка' in t:
            return True   # имя зелья/существа
        return False
    alien = [(k, t) for k, t in che if not allowed(k, t)]
    mw_dragon = [t for k, t in che if t.startswith('Мастерск') and 'дракон' in t.lower()]
    print('3b) «чешуйчат» в main: %d полей (MW Dragonscale %d, кокон %d, Чешуйчатка %d)'
          % (len(che), len(mw_dragon), sum(1 for _, t in che if 'Чешуйчатый кокон' in t),
             sum(1 for _, t in che if 'Чешуйчатка' in t)))
    check(len(che) == 31 and len(mw_dragon) == 5 and not alien,
          '«чешуйчат» main = ровно 31 канон-поле (MW Dragonscale ×5 + кокон ×23 + Чешуйчатка ×3); чужих: %d %s'
          % (len(alien), alien[:3]))

    # --- 4) гигиена ---
    print('4) гигиена:')
    hy = {'%%': 0, 'ё': 0, 'рейтинг': 0, 'укр.': 0, '  ': 0}
    lone = 0
    dq = []
    for k, t in fk.items():
        hy['%%'] += (t or '').count('%%')
        hy['ё'] += (t or '').count('ё')
        hy['рейтинг'] += len(re.findall(r'[Рр]ейтинг', t or ''))
        hy['укр.'] += (t or '').count('укр.')
        hy['  '] += (t or '').count('  ')
        if re.search(r'(?<!\r)\n', t or ''):
            lone += 1
        if '"' in t and '<font' not in t and 'font' not in t:
            dq.append((k, t[:60]))
    for m, v in hy.items():
        check(v == 0, '%s = 0 (факт %d)' % (repr(m), v))
    check(lone == 0, 'lone \\n = 0 (факт %d)' % lone)
    check(len(dq) == 0, 'прямые кавычки вне font-книг = 0 (факт %d)' % len(dq))
    over = [(k, len(t)) for k, t in fk.items()
            if k[1] == 'PERK' and k[2] == 'DESC' and t and len(t) > 290]
    check(len(over) == 0, 'PERK DESC <= 290 (превышений %d)' % len(over))

    # --- 5) пак-скан ---
    print('5) пак-скан (63 записи, 3 кодировки):')
    names = z.namelist()
    assert z.testzip() is None
    assert len(names) == 63
    lam_pack, che_bad = [], 0
    decs = 0
    for n in names:
        raw = z.read(n)
        for enc in ('utf-8', 'utf-16le', 'cp1251'):
            try:
                s = raw.decode(enc)
            except (UnicodeDecodeError, UnicodeError):
                continue
            decs += 1
            low = s.lower()
            if 'ламелляр' in low and n != '00 Core/PathsOfEmpyrean.esp':
                lam_pack.append((n, enc))
            if 'чешуйчатые и пластинчатые' in low or 'стальные пластинчатые и чешуйчатые' in low:
                che_bad += 1
    check(len(lam_pack) == 0, '«ламелляр» вне main ESP = 0 (факт %d %s)' % (len(lam_pack), lam_pack[:2]))
    check(che_bad == 0, '«чешуйчатые и пластинчатые»/«стальные…чешуйчатые» по всему паку = 0 (декодов %d)' % decs)
    sbn = z.read('00 Core/SKSE/Plugins/POE/Weapon/PathsOfEmpyrean_ShortbowNames.ini').decode('utf-8')
    check(sbn.count('Короткий лук Изгоев') == 1 and 'лук изгоев' not in sbn,
          'ShortbowNames: «Короткий лук Изгоев» = 1')
    mcm = z.read('00 Core/Interface/Translations/PathsOfEmpyrean_RUSSIAN.txt').decode('utf-16le')
    check('$Forsworn\tИзгои' in mcm and 'Изгнанники' not in mcm,
          'MCM: $Forsworn<tab>Изгои, «Изгнанники» = 0')
    ald = z.read('00 Core/SKSE/Plugins/ArcheryLocationalDamage.ini').decode('utf-8')
    check(ald.count('Message = В яблочко!') == 2 and ald.count('Message = Травма руки!') == 2
          and ald.count('Message = Травма ноги!') == 2,
          'ALD ini: «В яблочко!»×2, «Травма руки!»×2, «Травма ноги!»×2')
    ver = z.read('fomod/info.xml').decode('utf-8')
    check('<Version>1.5.14</Version>' in ver and '1.5.13' not in ver,
          'info.xml = 1.5.14')

    # --- 7) регресс-пробы ---
    print('7) регресс-пробы:')
    cc_names = [n for n in names if n.endswith('.esp') and n != '00 Core/PathsOfEmpyrean.esp']
    cc_texts = []
    for n in cc_names:
        raw = z.read(n)
        p = '/home/z/my-project/work/qa113/_cc_esp.bin'
        open(p, 'wb').write(raw)
        cc_texts += [r['text'] for r in dump_main(p, '/home/z/my-project/work/qa113/_cc_dump.jsonl')]
    def find_all(sub):
        return [k for k, t in fk.items() if t and sub in t] + \
               [i for i, t in enumerate(cc_texts) if sub in t]
    def find_ru(sub, field=None):
        return [k for k, t in fk.items() if t and sub in t
                and (field is None or k[2] == field)]
    for sub, n, kw in [
        # Откат к ламелляр-серии (v1.5.12-состояние)
        ('Мастерский ламеллярный шлем', 1, 'FULL'),
        ('Мастерские ламеллярные наручи', 1, 'FULL'),
        ('Мастерская ламеллярная броня', 2, 'FULL'),
        ('Мастерские ламеллярные сапоги', 1, 'FULL'),
        ('Мастерская ламеллярная броня с рогами', 1, 'FULL'),
        ('Железный человек - Ламеллярный', 1, 'FULL'),
        ('Вторая кожа - Ламеллярный', 1, 'FULL'),
        ('ламеллярные и пластинчатые доспехи', 1, 'DESC'),
        ('стальные пластинчатые и ламеллярные доспехи', 1, 'DESC'),
        # Dragonscale-канон игрока не тронут (высокий тир = «чешуйчатый»)
        ('Мастерский драконий чешуйчатый щит', 1, 'FULL'),
        ('Мастерский драконий чешуйчатый шлем', 1, 'FULL'),
        ('Мастерские драконьи чешуйчатые перчатки', 1, 'FULL'),
        ('Мастерская драконья чешуйчатая броня', 1, 'FULL'),
        ('Мастерские драконьи чешуйчатые сапоги', 1, 'FULL'),
        # Грим-серия и прочее «чешуйчат» — не тронуто
        ('Чешуйчатый кокон', 23, None),
        ('Чешуйчатка', 3, None),
        # CC-патчи (поиск по main + CC)
        ('Орочья чешуйчатая броня', 1, 'CC'),
        ('Клепаная драконья чешуйчатая броня', 1, 'CC'),
        ('Драконьи чешуйчатые перчатки драчуна', 2, 'CC'),
        # 112-а: SPEL «- Драконий» ×2 (EN Dragon, объединено как EN) — не тронуто
        ('- Драконий', 2, 'FULL'),
        # Регресс 111
        ('Грозовой атронах', 2, None), ('Маскировка - Брата Бури', 1, 'FULL'),
        ('Маскировка - Изгоя', 1, 'FULL'), ('Маскировка - бандита', 1, 'FULL'),
        ('Дикая форма - волк', 1, None), ('Сокрушительный набег', 3, 'FULL'),
        ('Мастерские сыромятные сапоги', 1, 'FULL'),
        ('Мастерские драконьи панцирные сапоги', 1, 'FULL'),
        ('Мастерский имперский офицерский шлем', 1, 'FULL'),
        ('Маска члена культа', 1, 'FULL'), ('Мастерская маска члена культа', 1, 'FULL'),
        ('Счастливая стрела нордского героя (жетон)', 1, 'FULL'),
        ('Мастерская древняя нордская броня', 1, 'FULL'),
        ('Мастерская эльфийская золоченая броня', 1, 'FULL'),
        ('Мастерская эльфийская позолоченная броня', 0, 'FULL'),
        ('Мастерские офицерские сапоги Братьев Бури', 1, 'FULL'),
        ('Вы замаскированы под Изгоя.', 1, 'DESC'),
        ('создает двемерскую сферу-убийцу', 1, 'DNAM'),
        ('Позволяет ковать стальное и костяное снаряжение', 1, 'DESC'),
        # Соседи кузнечного дерева (все уровни на месте)
        ('Основы кузнечного дела', 1, 'FULL'),
        ('Ученик в кузнечном деле', 2, 'FULL'),
        ('Подмастерье в кузнечном деле', 2, 'FULL'),
        ('Улучшенные доспехи', 1, 'FULL'),
        ('Кузнец-мастер', 2, 'FULL'),
        ('Легендарная ковка', 2, 'FULL'),
    ]:
        hits = find_all(sub) if kw == 'CC' else find_ru(sub, kw)
        check(len(hits) == n, '«%s» = %d (факт %d)' % (sub, n, len(hits)))

    print()
    if fails:
        print('ВЕРИФИКАЦИЯ ПРОВАЛЕНА (%d):' % len(fails))
        for f in fails:
            print('  -', f)
        raise SystemExit(1)
    print('ВЕРИФИКАЦИЯ ЗЕЛЁНАЯ: все группы проверок пройдены')


if __name__ == '__main__':
    main()
