#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 101: инвентаризация дрейфа справочного слоя (06_код-истина_перевода)
относительно истины — дампа выпущенного пакета v1.5.7 (work/qa100/dump_v157.jsonl).

Сверяются:
1. desc_ru.py   (DESC_RU, ключ=EDID)  vs PERK DESC дампа;
2. full_names_ru.py (данные-слои в порядке объявления) vs FULL дампа;
3. corpus56.json vs дамп (по fid+type+field): ru-диффы + en-покрытие;
4. PathsOfEmpyrean_DESC.ini / ShortbowNames_ru.ini vs байты из выпущенного zip.

Выход: work/qa101/drift_report.txt + stdout-сводка. НИЧЕГО не правит.
"""
import io, json, os, re, sys, zipfile, importlib.util
from collections import Counter, defaultdict

ROOT = '/home/z/my-project'
DIR06 = f'{ROOT}/handoff/06_код-истина_перевода'
DUMP = f'{ROOT}/work/qa100/dump_v157.jsonl'
OUT = f'{ROOT}/work/qa101/drift_report.txt'
RU_ZIP = f'{ROOT}/Paths of Empyrean RU 1.5.zip'

os.makedirs(f'{ROOT}/work/qa101', exist_ok=True)
rep = []


def w(s=''):
    rep.append(s)
    print(s)


def import_dict(path, var):
    spec = importlib.util.spec_from_file_location('m101_' + os.path.basename(path)[:-3], path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return getattr(mod, var)


# ---------- дамп истины ----------
fields = []          # все поля дампа
by_file = Counter()
for line in io.open(DUMP, encoding='utf-8'):
    r = json.loads(line)
    fields.append(r)
    by_file[r['file']] += 1
w('=== Дамп истины v1.5.7 (work/qa100/dump_v157.jsonl) ===')
w(f'полей всего: {len(fields)}; по файлам: {dict(by_file)}')
perk_desc = [r for r in fields if r['rtype'] == 'PERK' and r['field'] == 'DESC']
fulls = [r for r in fields if r['field'] == 'FULL']
w(f'PERK DESC: {len(perk_desc)}; FULL: {len(fulls)}')
w('')

# ---------- 1) desc_ru.py ----------
w('=== 1) desc_ru.py (мастер-эра) vs PERK DESC v1.5.7 ===')
desc_old = import_dict(f'{DIR06}/desc_ru.py', 'DESC_RU')
esp_by_edid = defaultdict(list)
for r in perk_desc:
    esp_by_edid[r['edid']].append(r['text'])
match = mismatch = missing = 0
mism_samples = []
for k, v in desc_old.items():
    cand = esp_by_edid.get(k)
    if not cand:
        missing += 1
        continue
    if len(cand) == 1 and cand[0] == v:
        match += 1
    else:
        mismatch += 1
        if len(mism_samples) < 40:
            mism_samples.append((k, v, cand))
w(f'ключей в справочнике: {len(desc_old)}; совпало: {match}; РАСШИЛОСЬ: {mismatch}; '
  f'нет в ESP (PERK DESC): {missing}')
esp_desc_edids = set(esp_by_edid)
only_esp = sorted(e for e in esp_desc_edids if e not in desc_old)
w(f'PERK DESC в ESP, отсутствующих в справочнике: {len(only_esp)} '
  f'({", ".join(only_esp[:10])}{"…" if len(only_esp) > 10 else ""})')
if mism_samples:
    w('Примеры расхождений (EDID; справочник → ESP):')
    for k, v, cand in mism_samples[:12]:
        w(f'  - {k}\n      справ: {v[:110]}\n      ESP  : {cand[0][:110]}')
w('')

# ---------- 2) full_names_ru.py (данные-слои) ----------
w('=== 2) full_names_ru.py: словарь EN→RU vs фактический перевод ESP v1.5.7 ===')
c56 = json.load(io.open(f'{DIR06}/corpus56.json', encoding='utf-8'))
src = io.open(f'{DIR06}/full_names_ru.py', encoding='utf-8').read()
order = [n for n in re.findall(r'^([A-Z][A-Z0-9_]+)\s*=\s*\{', src, re.M)]
RULES = {'MAT_LB', 'TURN', 'LB_SUFFIX', 'LB_UNIQ_MAT', '_MW_PLURAL', 'GENDER'}
data_names = [n for n in order if n not in RULES]
w(f'слои-данные (в порядке объявления): {data_names}')
# внутри файла есть self-import «from full_names_ru import …» —
# регистрируем модуль под ожидаемым именем
spec = importlib.util.spec_from_file_location('full_names_ru', f'{DIR06}/full_names_ru.py')
mod = importlib.util.module_from_spec(spec)
sys.modules['full_names_ru'] = mod
spec.loader.exec_module(mod)
merged = {}
dup_keys = 0
for n in data_names:
    d = getattr(mod, n, {})
    for k, v in d.items():
        if k in merged and merged[k] != v:
            dup_keys += 1
        merged[k] = v
w(f'суммарный effective-словарь: {len(merged)} пар; перекрытий с разными значениями: {dup_keys}')
# корректная сверка: EN-оригинал записи (corpus56.en) -> full_names[en] vs ESP ru
en_by_key = {}
for e in c56:
    en = e.get('en')
    if en:
        en_by_key.setdefault((e['fid'], e['type'], e['field']), en)
nm = nmm = 0
nmm_samples = []
nmm_by_type = Counter()
for r in fields:
    if r['field'] != 'FULL':
        continue
    en = en_by_key.get((r['formid'], r['rtype'], 'FULL'))
    if not en or en not in merged:
        continue
    if merged[en] == r['text']:
        nm += 1
    else:
        nmm += 1
        nmm_by_type[r['rtype']] += 1
        if len(nmm_samples) < 15:
            nmm_samples.append((en, merged[en], r['text'], r['edid'], r['rtype']))
w(f'записей ESP, где словарь применим (есть EN в corpus56): совпало {nm}, '
  f'РАСШИЛОСЬ {nmm}')
w(f'расхождения по типам записей: {dict(nmm_by_type.most_common())}')
w('  (CLAS/FACT/RACE/HDPT/WOOP — санкция типов «не переводить»; '
  'MGEF/SPEL — откат Этапа 78 для служебных эффектов)')
for en, v, ru, edid, rt in nmm_samples[:10]:
    w(f'  - {edid} [{rt}] [{en}]: словарь={v!r} vs ESP={ru!r}')
w('')

# ---------- 3) corpus56.json vs дамп ----------
w('=== 3) corpus56.json (корпус Этапа 56, сборка v1.13/14) vs дамп v1.5.7 ===')
dump_key = {}
for r in fields:
    dump_key.setdefault((r['formid'], r['rtype'], r['field']), []).append(r['text'])
same = diff = nokey = 0
diff_samples = []
for e in c56:
    k = (e['fid'], e['type'], e['field'])
    cand = dump_key.get(k)
    if not cand:
        nokey += 1
    elif e['ru'] in cand:
        same += 1
    else:
        diff += 1
        if len(diff_samples) < 15:
            diff_samples.append((k, e['ru'], cand[0]))
w(f'записей corpus56: {len(c56)}; ru совпало: {same}; РАСШИЛОСЬ: {diff}; '
  f'ключа нет в дампе: {nokey}')
for k, a, b in diff_samples[:10]:
    w(f'  - {k}\n      corpus: {a[:100]}\n      ESP   : {b[:100]}')
main_fields = sum(1 for r in fields if r['file'] == 'main')
w(f'полей дампа в main ESP: {main_fields} (corpus56 покрывал {len(c56)})')
en_have = sum(1 for e in c56 if e.get('en') not in (None, ''))
w(f'en-значений в corpus56 (для пары в corpus57): {en_have}')
w('')

# ---------- 4) INI-копии vs zip ----------
w('=== 4) INI-копии 06_ vs выпущенный zip v1.5.7 ===')
with zipfile.ZipFile(RU_ZIP) as z:
    for local, arc in [(f'{DIR06}/PathsOfEmpyrean_DESC.ini', '00 Core/PathsOfEmpyrean_DESC.ini'),
                       (f'{DIR06}/ShortbowNames_ru.ini', '00 Core/SKSE/Plugins/POE/Weapon/PathsOfEmpyrean_ShortbowNames.ini')]:
        a = open(local, 'rb').read()
        b = z.read(arc)
        w(f'  {"СОВПАДАЕТ" if a == b else "РАЗЛИЧАЕТСЯ"}: '
          f'{os.path.basename(local)} ↔ {arc} '
          f'({len(a)} vs {len(b)} Б)')
w('')
w('=== Итог ===')
w('Справочник мастер-эры desc_ru.py: см. §1; corpus56: см. §3; имена: см. §2.')
w('Истина — дамп выпущенного пакета (урок [T37]).')

io.open(OUT, 'w', encoding='utf-8').write('\n'.join(rep) + '\n')
print(f'\nOK: {OUT}')
