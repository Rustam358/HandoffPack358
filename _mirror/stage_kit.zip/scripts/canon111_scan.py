#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 111: канон-аудит ванильных терминов PoE RU против:
  1) канон-файла игрока All items.txt (ванильные имена, RU+EN+ID);
  2) офиц. корпуса SoftClub (work/softclub/db.jsonl, 92 762 записи);
  3) вердикта игрока: фракции «Изгои», а НЕ «изгнанники».
Скан corpus57.json (код-истина, 12 323 полей, 39 ESP).
Выход: work/qa111/canon_scan_report.txt + work/qa111/findings_111.jsonl
"""
import json, re, os, sys, collections

BASE = '/home/z/my-project'
CORPUS = BASE + '/work/handoff510/handoff/06_код-истина_перевода/corpus57.json'
ITEMS = BASE + '/upload/All items.txt'
OUTD = BASE + '/work/qa111'
os.makedirs(OUTD, exist_ok=True)

# ---------------------------------------------------------------- канон-файл
def parse_items():
    """Возвращает список пар (EN, RU, raw) для строк вида RU (EN) - ID."""
    pairs, ru_only = [], []
    rx = re.compile(r'^\s*(.+?)\s*\((?:ориг\.\s*)?([^()]+)\)\s*-\s*(.*)$')
    rx_id = re.compile(r'[0-9A-Fa-fА-ЕА-Я]{6,8}|XX[0-9A-Za-zА-Яа-фА-Ш]{6}')
    for raw in open(ITEMS, encoding='utf-8').read().splitlines():
        s = raw.strip()
        if not s or s.startswith('---'):
            continue
        m = rx.match(s)
        if m:
            ru, en, rest = m.group(1).strip(), m.group(2).strip(), m.group(3)
            # EN должен выглядеть как английское имя (латиница), а ID идти после
            if re.search(r'[A-Za-z]{3,}', en) and not re.match(r'^[0-9A-FXx\s]+$', en):
                pairs.append((en, ru, s))
            elif rx_id.search(rest):
                ru_only.append((ru, s))
            continue
        if rx_id.search(s) and re.search(r'[А-Яа-яЁё]', s):
            ru_only.append((s.split(' - ')[0].strip(), s))
    return pairs, ru_only

# --------------------------------------------------- канон-правила терминов
# EN-regex -> (название, req-RU-regex, anti-RU-regex, dump_all)
# req/anti в одном поле: чередование через |; проверка по re.search с учётом РЕГИСТРА.
RULES = [
    # --- фракции/существа (директива игрока + офиц. корпус) ---
    (r'Forsworn', 'Forsworn (Изгои)',
     r'Изгой|Изго[яею]|Изгои', r'изгнанник|Изгнанник', True),
    (r'Stormcloak', 'Stormcloak (Братья Бури)',
     r'Брат Бури|Брата Бури|Братьев Бури|Братьям|Братьями|Братьях|Братья Бури', r'Штормов?клоак', True),
    (r'Thieves Guild', 'Thieves Guild (Гильдия воров)',
     r'Гильдия воров|Гильдии воров|Гильдии воров', r'Воровская|воровская гильдия', True),
    (r'Dark Brotherhood|DarkBrotherhood', 'Dark Brotherhood (Темное Братство)',
     r'Братство|Братства|Братству|Братством|Братстве', r'', True),
    (r'Dawnguard', 'Dawnguard (Стража Рассвета)',
     r'Стража Рассвета|Стражи Рассвета|Страже Рассвета|Стражей Рассвета|Стражу Рассвета', r'', True),
    (r'Penitus', 'Penitus Oculatus (Пенитус Окулатус)',
     r'Пенитус Окулатус|Пенитус Окулатуса', r'', True),
    (r'\bBlades\b', 'Blades (Клинки)',
     r'Клинк', r'', True),
    (r'Thalmo?r', 'Thalmor (Талмор)', r'Талмор|талмор', r'', True),
    (r'Bandits?\b', 'Bandit (бандит)', r'бандит|Бандит', r'разбойник|Разбойник', True),
    (r'Cultists?\b', 'Cultist (культист / член культа)',
     r'культист|Культист|член культа|члена культа|члены культа', r'', True),
    (r'Draugr', 'Draugr (Драугр)', r'Драугр|драугр', r'', True),
    (r'Falmer', 'Falmer (Фалмер)', r'Фалмер|фалмер', r'', True),
    (r'Vampires?\b', 'Vampire (вампир)', r'[Вв]ампир', r'', False),
    (r'Necromancers?\b', 'Necromancer (некромант)', r'[Нн]екромант', r'', False),
    (r'Imperials?\b|Imperial', 'Imperial (имперский/империец)', r'[Ии]мперск|[Ии]мперец|[Ии]мперц', r'', True),
    (r'Companions?\b', 'Companions (Соратники)', r'Соратник|соратник|спутник', r'', True),
    (r'\bSkaal\b', 'Skaal (скаал)', r'скаал|Скаал', r'', True),
    (r'Nord Hero', 'Nord Hero (нордский герой)', r'нордск.{0,3} геро|Нордск.{0,3} геро', r'', True),
    (r'Morag Tong', 'Morag Tong (Мораг Тонг)', r'Мораг Тонг', r'', True),
    (r'Blackguard', r"Blackguard (Черный Страж)", r'Черн.{0,2} Страж', r'', True),
    (r'Nightingale', 'Nightingale (Соловьиный)', r'Соловь', r'', True),
    (r"Guild Master", 'Guild Master (глава Гильдии)', r'главы Гильдии|глава Гильдии|Главы Гильдии', r'', True),
    (r'Shrouded', 'Shrouded (… теней)', r'теней', r'', True),
    (r'\bWolf\b', 'Wolf (Волчий)', r'[Вв]олч', r'', False),
    # --- материалы ---
    (r'\bHide\b', 'Hide (сыромятный / шкура)', r'[Сс]ыромятн|[Шш]кур|[Кк]ож', r'', True),
    (r'Leather', 'Leather (кожаный)', r'[Кк]ожан', r'', False),
    (r'\bFur\b', 'Fur (меховой)', r'[Мм]ехов', r'', False),
    (r'\bIron\b', 'Iron (железный)', r'[Жж]елезн', r'', False),
    (r'Steel Plate', 'Steel Plate (стальной пластинчатый)', r'пластинчат', r'', True),
    (r'Banded Iron', 'Banded Iron (прочный железный)', r'[Пп]рочн', r'', True),
    (r'Studded', 'Studded (клёпаный)', r'[Кк]лепан', r'', True),
    (r'Elven', 'Elven (эльфийский)', r'[Ээ]льфийск', r'', False),
    (r'Gilded', 'Gilded (позолоченный/золоченый)', r'позолоч|золочен', r'', True),
    (r'Dwarven', 'Dwarven (двемерский)', r'[Дд]вемер', r'гном|Гном', False),
    (r'Orcish', 'Orcish (орочий)', r'[Оо]роч', r'[Оо]ркск', False),
    (r'\bEbony\b', 'Ebony (эбонитовый)', r'[Ээ]бонит', r'', False),
    (r'\bGlass\b', 'Glass (стеклянный)', r'[Сс]теклян', r'', False),
    (r'\bScaled\b', 'Scaled (ламеллярный)', r'[Лл]амелляр', r'', True),
    (r'Dragonscale', 'Dragonscale (драконий чешуйчатый)', r'чешуйчат', r'', True),
    (r'Dragonplate', 'Dragonplate (драконий панцирный)', r'панцирн', r'', True),
    (r'Dragonbone', 'Dragonbone (драконий костяной)', r'драконий костян|Драконий костян|драконь[иеяю]\s+костян|Драконь[иеяю]\s+костян', r'', True),
    (r'Daedric', 'Daedric (даэдрический)', r'[Дд]аэдр', r'', False),
    (r'Stalhrim', 'Stalhrim (сталгримовый)', r'[Сс]талгрим', r'[Сс]талл|[Сс]тальгрим', False),
    (r'Chitin', 'Chitin (хитиновый)', r'[Хх]итин', r'', False),
    (r'Bonemold', 'Bonemold (костяная)', r'[Кк]остян', r'', True),
    (r'Nordic', 'Nordic (нордский)', r'[Нн]ордск', r'', False),
    (r'Carved', 'Carved (резной)', r'[Рр]езн', r'', True),
    (r'Ancient Nord', 'Ancient Nord (древний нордский)', r'[Дд]ревн[аиоев]{0,3}\s+нордск|Древн[аиоев]{0,3}\s+нордск', r'', True),
    # --- уровни зачарований (канон-файл: малой/базовое/настоящее/истинное/великое/несравненное) ---
    (r'of Minor', 'of Minor (малой)', r'[Мм]алой|[Мм]алый|[Мм]алые|[Мм]алая', r'', True),
    (r'of Major', 'of Major (настоящий)', r'настоящ[иеяю]?|Настоящ', r'', True),
    (r'of Extreme', 'of Extreme (истинный)', r'истинн[ыоая]?|Истинн', r'', True),
    (r'of Eminent', 'of Eminent (великий)', r'велико|Велико|велик[аяо]', r'', True),
    (r'of Peerless', 'of Peerless (несравненный)', r'несравненн|Несравненн', r'', True),
    # --- типы предметов ---
    (r'Helmet', 'Helmet (шлем)', r'[Шш]лем', r'', False),
    (r'Boots', 'Boots (сапоги)', r'[Сс]апог', r'', False),
    (r'Gauntlets', 'Gauntlets (перчатки)', r'[Пп]ерчатк', r'', False),
    (r'Shield', 'Shield (щит)', r'[Щщ]ит', r'', False),
    (r'Bracers', 'Bracers (наручи)', r'[Нн]аруч', r'', False),
    (r'Hood', 'Hood (капюшон)', r'[Кк]апюшон', r'', False),
    (r'Cuirass', 'Cuirass (кираса)', r'[Кк]ирас', r'', True),
    (r'Headdress', 'Headdress (головной убор)', r'Головной убор|головной убор', r'', True),
    (r'Longbow', 'Longbow (длинный лук)', r'[Дд]линн.{1,4} лук', r'', True),
    (r'Shortbow', 'Shortbow (короткий лук)', r'[Кк]оротк.{1,4} лук', r'', True),
    (r'Crossbow', 'Crossbow (арбалет)', r'[Аа]рбалет', r'', False),
    (r'\bBolt', 'Bolt (болт)', r'[Бб]олт', r'', False),
    (r'Arrow', 'Arrow (стрела)', r'[Сс]трел', r'', False),
    (r'Amulet', 'Amulet (амулет)', r'[Аа]мулет', r'', False),
    (r'Circlet', 'Circlet (обруч)', r'[Оо]бруч|[Кк]орона', r'', True),
    (r'Robes', 'Robes (одеяние/мантия)', r'[Оо]деяни|[Мм]анти|[Рр]об', r'', True),
]

def main():
    corpus = json.load(open(CORPUS, encoding='utf-8'))
    pairs, ru_only = parse_items()
    fields = [r for r in corpus if r.get('en')]
    rep = open(OUTD + '/canon_scan_report.txt', 'w', encoding='utf-8')
    fj = open(OUTD + '/findings_111.jsonl', 'w', encoding='utf-8')

    def W(*a):
        print(*a, file=rep)

    W('=' * 100)
    W('КАНОН-АУДИТ ЭТАПА 111: corpus57.json (%d полей, %d с EN) vs All items.txt (%d EN-пар, %d RU-only)'
      % (len(corpus), len(fields), len(pairs), len(ru_only)))
    W('=' * 100)
    for en, ru, raw in pairs[:0]:
        pass

    total_findings = 0
    for en_rx, name, req, anti, dump_all in RULES:
        rx = re.compile(en_rx)
        req_rx = re.compile(req) if req else None
        anti_rx = re.compile(anti) if anti else None
        rows = [r for r in fields if rx.search(r['en'])]
        if not rows:
            W('\n### %s: вхождений EN = 0' % name)
            continue
        ok, viol, unseen = [], [], []
        for r in rows:
            ru = r.get('ru') or ''
            if anti_rx and anti_rx.search(ru):
                viol.append(r)
            elif req_rx and req_rx.search(ru):
                ok.append(r)
            else:
                unseen.append(r)
        W('\n### %s: EN-полей %d | ok %d | ANTI %d | не-по-правилу %d'
          % (name, len(rows), len(ok), len(viol), len(unseen)))
        # канон-строки из файла игрока
        canon_lines = [(en2, ru2, raw) for en2, ru2, raw in pairs
                       if re.search(en_rx, en2)]
        for en2, ru2, raw in canon_lines[:6]:
            W('   [канон] %s' % raw)
        show = viol + unseen if not dump_all else viol + unseen + ok
        for r in show:
            tag = 'ANTI' if (anti_rx and anti_rx.search(r.get('ru') or '')) else ('VIOL' if r in viol or r in unseen else 'ok')
            W('   [%s] %s|%s|%s|%s' % (tag, r['file'], r['fid'], r['type'] + '/' + r['field'], r['edid']))
            W('       EN: %s' % (r['en'] or '')[:220])
            W('       RU: %s' % (r.get('ru') or '')[:220])
            if tag in ('ANTI', 'VIOL'):
                fj.write(json.dumps({'term': name, 'tag': tag, 'fid': r['fid'],
                                     'type': r['type'], 'field': r['field'],
                                     'edid': r['edid'], 'file': r['file'],
                                     'en': r['en'], 'ru': r.get('ru')},
                                    ensure_ascii=False) + '\n')
                total_findings += 1

    # --- независимые guard-сканы ---
    W('\n' + '=' * 100)
    W('GUARD-сканы')
    W('=' * 100)
    # 1) анти-канон лексика
    for pat, what in [(r'[Ии]згнанник', 'изгнанник (Forsworn)'),
                      (r'[Шш]тормклоак', 'штормклоак'),
                      (r'[Вв]оровская', 'воровская (гильдия)'),
                      (r'[Гг]ном', 'гном (Dwarven)'),
                      (r'[Оо]ркск', 'оркск (Orcish)'),
                      (r'[Сс]тальгрим|[Сс]талл', 'стальгрим/сталл'),
                      (r'[Кк]увалда', 'кувалда (warhammer; перк-имя — санкция)'),
                      (r'ё', 'буква ё (канон 58: 0)')]:
        hits = [r for r in corpus if r.get('ru') and re.search(pat, r['ru'])]
        W('%-40s : %d' % (what, len(hits)))
        for r in hits[:10]:
            W('    %s|%s|%s|%s' % (r['file'], r['fid'], r['type'] + '/' + r['field'], r['edid']))
            W('      EN: %s' % (r['en'] or '')[:180])
            W('      RU: %s' % r['ru'][:180])
    # 2) латиница в RU (непереведённые ванильные имена)
    lat = [r for r in corpus if r.get('ru') and re.search(r'[A-Za-z]{4,}', r['ru'])]
    W('RU-поля с латиницей >=4: %d (аудит 105: все ложные — GRIM/<10>/NPC/QA/бренд)' % len(lat))
    rep.close()
    fj.close()
    print('OK: отчет %s, findings %d' % (OUTD + '/canon_scan_report.txt', total_findings))

if __name__ == '__main__':
    main()
