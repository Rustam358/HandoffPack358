#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 98: резолюция ключевиков копий PoE — запечены ли WeapType-ключи.

1. Дамп всех KYWD-записей PoE core и Spears-аддона (FormID + EDID).
2. Сырые KWDA-значения записей копий Spears: mod-index → мастер → EDID цели.
3. Вердикт: держится ли классификация копий (OCF_WeapTypeSpear2H и др.)
   на KWDA, или только на name-правиле KID.
"""
import struct
import sys

sys.path.insert(0, "/home/z/my-project/scripts")
from parse_tes4 import Plugin

CORE = "/home/z/my-project/work/v156/00 Core/PathsOfEmpyrean.esp"
SPEARS = "/home/z/my-project/work/v156/20 Spears/PoE-Addon-Spears.esp"

core = Plugin(CORE)
spears = Plugin(SPEARS)

print(f"core: {len(core.records)} записей; мастера: {core.masters}")
print(f"spears: {len(spears.records)} записей; мастера: {spears.masters}\n")

# --- 1. KYWD-записи обоих плагинов ---
core_kw = {fid: (r["edid"] or "") for fid, r in core.records.items()
           if r["type"] == "KYWD"}
spear_kw = {fid: (r["edid"] or "") for fid, r in spears.records.items()
            if r["type"] == "KYWD"}
print(f"KYWD в core:   {len(core_kw)}")
print(f"KYWD в spears: {len(spear_kw)}")

interesting = [e for e in core_kw.values() if "WeapType" in e or e.startswith(("OCF_", "PoE_K_", "SF_K_", "MAG_", "WAF_", "Sh"))]
print(f"\nKYWD core c WeapType/OCF_/PoE_K_/SF_K_/MAG_/WAF_: {len(interesting)}")
for e in sorted(interesting)[:40]:
    print(f"  {e}")
if len(interesting) > 40:
    print(f"  … и ещё {len(interesting)-40}")

# --- 2. сырые KWDA первых spear-записей ---
def raw_kwda(p, fid):
    r = p.records.get(fid)
    if not r:
        return None, None
    edid, kws = r["edid"], []
    for st, sd in r["subs"]:
        if st == "KWDA":
            for i in range(len(sd) // 4):
                kws.append(struct.unpack_from("<I", sd, i * 4)[0])
    return edid, kws

def resolve(p, kfid, extra):
    """kfid — сырой formID из KWDA плагина p; extra — {formid: edid} мастера PoE."""
    idx = kfid >> 24
    off = kfid & 0xFFFFFF
    if idx == 0xFF or off == 0:
        return "<светящийся/нулевой>"
    if idx == len(p.masters):
        # self
        return f"SELF#{off:06X}"
    if idx > len(p.masters):
        return f"??idx{idx}#{off:06X}"
    master = p.masters[idx]
    if master.startswith("PathsOfEmpyrean"):
        edid = extra.get(off)
        return f"PoE#{off:06X}={edid}"
    return f"{master}#{off:06X}"

# self-KYWD spears — тоже резолвить для self-ссылок
kw_all = dict(core_kw)
kw_all.update(spear_kw)

test_fids = [fid for fid in spears.by_type.get("WEAP", [])][:6]
print("\n=== сырые KWDA копий (spears WEAP) ===")
for fid in test_fids:
    edid, kws = raw_kwda(spears, fid)
    print(f"\n[{edid}] {fid:#010x}")
    for k in kws:
        print(f"   raw {k:#010x} -> {resolve(spears, k, core_kw)}")

# --- 3. сколько WEAP-записей spears имеют PoE-ключ WeapType/OCF baked ---
print("\n=== аудит всех WEAP spears на запечённые WeapType-ключи ===")
baked, unbaked = 0, 0
baked_names = {}
for fid in spears.by_type.get("WEAP", []):
    _, kws = raw_kwda(spears, fid)
    has = False
    for k in kws or []:
        idx = k >> 24
        off = k & 0xFFFFFF
        edid_of_kw = None
        if idx == 5:  # PathsOfEmpyrean master
            edid_of_kw = core_kw.get(off)
        elif idx == 6:  # self (spears)
            edid_of_kw = spear_kw.get(off)
        elif idx in (0, 1) and off in (0x777772, 0x003287):
            edid_of_kw = f"<{spears.masters[idx]}#{off:06X} (загадочный)>"
        if edid_of_kw and ("WeapType" in edid_of_kw or edid_of_kw.startswith(("OCF_", "PoE_K_"))):
            has = True
            baked_names[edid_of_kw] = baked_names.get(edid_of_kw, 0) + 1
    if has:
        baked += 1
    else:
        unbaked += 1
print(f"WEAP с запечёнными WeapType/OCF_/PoE_K_: {baked}")
print(f"WEAP без них:                            {unbaked}")
print("топ запечённых:")
for n, c in sorted(baked_names.items(), key=lambda x: -x[1])[:15]:
    print(f"   {c:4d}  {n}")
