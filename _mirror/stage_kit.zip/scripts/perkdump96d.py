#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 96, разведка D: VMAD v3 — скрипты + свойства + секция Papyrus-фрагментов перков."""
import sys, struct
from collections import Counter

sys.path.insert(0, '/home/z/my-project/upload/poe_pack/scripts')
from parse_tes4 import Plugin

p = Plugin('/home/z/my-project/work/v156/00 Core/PathsOfEmpyrean.esp')

def u32(sd, o=0): return struct.unpack_from('<I', sd, o)[0]
def i32(sd, o=0): return struct.unpack_from('<i', sd, o)[0]
def f32(sd, o=0): return struct.unpack_from('<f', sd, o)[0]
def u16(sd, o=0): return struct.unpack_from('<H', sd, o)[0]

class VmadParseError(Exception):
    pass

def parse_vmad(sd):
    """Возвращает {scripts: [{name, status, props}], fragments: {...}|None}."""
    out = {'scripts': [], 'fragments': None}
    off = 0
    ver, objfmt = struct.unpack_from('<HH', sd, off); off += 4
    scount = u16(sd, off); off += 2

    def lstr(o):
        n = u16(sd, o); o += 2
        s = sd[o:o + n].decode('utf-8', 'replace')
        return s, o + n

    for _ in range(scount):
        name, off = lstr(off)
        status = sd[off]; off += 1
        pcount = u16(sd, off); off += 2
        props = []
        for _ in range(pcount):
            pn, off = lstr(off)
            ptype = sd[off]; off += 1
            pstat = sd[off]; off += 1
            if ptype == 1:
                val = ('obj', u32(sd, off), p.label(u32(sd, off + 4))); off += 8
            elif ptype == 2:
                slen = u16(sd, off); off += 2
                val = ('str', sd[off:off + slen].decode('utf-8', 'replace')); off += slen
            elif ptype == 3:
                val = ('int', i32(sd, off)); off += 4
            elif ptype == 4:
                val = ('float', round(f32(sd, off), 6)); off += 4
            elif ptype == 5:
                val = ('bool', sd[off]); off += 1
            elif ptype == 11:
                cnt = u32(sd, off); off += 4
                arr = [u32(sd, off + 4 + i * 8) for i in range(cnt)]
                val = ('objarr', arr); off += 8 * cnt
            elif ptype == 12:
                cnt = u32(sd, off); off += 4
                arr = []
                for _ in range(cnt):
                    s, off = lstr(off)
                    arr.append(s)
                val = ('strarr', arr)
            elif ptype == 13:
                cnt = u32(sd, off); off += 4
                val = ('intarr', list(struct.unpack_from(f'<{cnt}i', sd, off))); off += 4 * cnt
            elif ptype == 14:
                cnt = u32(sd, off); off += 4
                val = ('floatarr', list(struct.unpack_from(f'<{cnt}f', sd, off))); off += 4 * cnt
            elif ptype == 15:
                cnt = u32(sd, off); off += 4
                val = ('boolarr', list(sd[off:off + cnt])); off += cnt
            else:
                raise VmadParseError(f'ptype {ptype}')
            props.append((pn, ptype, val))
        out['scripts'].append({'name': name, 'status': status, 'props': props})

    # секция фрагментов (у перков с Papyrus-фрагментами)
    if off < len(sd):
        frag = {}
        frag['marker'] = sd[off]; off += 1
        sname, off = lstr(off)
        frag['script'] = sname
        frag['status'] = sd[off]; off += 1
        frag['props'] = u16(sd, off); off += 2
        frag['unk'] = u32(sd, off); off += 4
        frags = []
        while off < len(sd):
            sn, off = lstr(off)
            fn, off = lstr(off)
            ep = sd[off]; off += 1
            one = u32(sd, off); off += 4
            frags.append({'script': sn, 'fragment': fn, 'ep': ep, 'unk': one})
        frag['fragments'] = frags
        out['fragments'] = frag
    if off != len(sd):
        raise VmadParseError(f'off={off} != {len(sd)}')
    return out

ok = fail = 0
fails = Counter()
for t in p.by_type:
    for f in p.by_type[t]:
        for st, sd in p.records[f]['subs']:
            if st == 'VMAD':
                try:
                    parse_vmad(sd)
                    ok += 1
                except Exception as e:
                    fail += 1
                    fails[f'{t}:{str(e)[:50]}'] += 1
print(f'VMAD v3: ok={ok} fail={fail} (по ВСЕМ типам записей)')
for k, v in fails.most_common(12):
    print('  FAIL:', k, 'x', v)

# пример фрагментной секции
for f in p.by_type['PERK']:
    r = p.records[f]
    if r['edid'] == 'IWP_PERK_SMITH_DwarvenMechanic1':
        sd = next(sd for st, sd in r['subs'] if st == 'VMAD')
        d = parse_vmad(sd)
        print('\nDwarvenMechanic1 fragments:')
        print(' ', d['fragments']['script'], 'status', d['fragments']['status'],
              'props', d['fragments']['props'], 'unk', d['fragments']['unk'])
        for fr in d['fragments']['fragments']:
            print('  ', fr['fragment'], 'ep =', fr['ep'], 'unk =', fr['unk'])
        break
