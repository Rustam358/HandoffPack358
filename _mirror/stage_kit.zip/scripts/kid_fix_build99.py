#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 99: генератор PoE_RU_KID.ini — мини-фикс 37 имя-зависимых потерь KID.

Директива игрока (вердикт 98-а, вариант «а»): восстанавливать потерянные при
переводе ключевики НЕ правкой ESP, а собственной KID-ини с EDID-фильтрами.

Метод: повторяет симуляцию kid_impact_audit.py (EN-имена из дампа 1.4 ×
wildcard-правила PathsOfEmpyrean_KID.ini 1.4 × KWDA ядра v1.5.6) с ДВУМЯ
исправлениями аудита v1:
  1) СТРОГИЙ фильтр типов: правило типа Weapon обрабатывает только WEAP,
     Armor — только ARMO, Ammo — только AMMO (аудит v1 пропускал Ammo-правила
     к броне/оружию -> 2 ложных записи: WAF_WeapMaterialFaction у латных
     перчаток и дубль у катаны);
  2) расширенная карта ванильных ключевиков (ClothingBody=0x000A8657
     подтверждён распределительно: 183 корпусных предмета одежды, шляпы без
     него; ClothingHead=0x0010CD11; 0x0006BBE8=Clothing на всех частях).

Каждой потере соответствует строка:
  Keyword = <kw>|<тип>|<EDID записи>[,<EDID>...]|<4-е поле оригинала>
EDID-фильтр «пришпиливает» форму (перевод его не меняет); 4-е поле (слот/
вес/анимация) переносится 1:1 — рантайм-поведение = паритет с EN-прогоном
оригинальной ини. Группировка по (kw, тип, 4-е поле).

Дополнительно печатает: NOT-терм флип-скан (обратный риск овер-матчинга),
счёт 1.5-новых записей без EN-источника (граница аудита).
"""
import json
import struct
import sys
from collections import OrderedDict

sys.path.insert(0, "/home/z/my-project/scripts")
from parse_tes4 import Plugin

KID_INI = ("/home/z/my-project/handoff/08_оригинал_1.4_EN/"
           "полный_разбор_1.4/PoE 1.4/PathsOfEmpyrean_KID.ini")
CORE = "/home/z/my-project/work/v156/00 Core/PathsOfEmpyrean.esp"
SPEARS = "/home/z/my-project/work/v156/20 Spears/PoE-Addon-Spears.esp"
SHIELDS = "/home/z/my-project/work/v156/10 Missing Shields/PoE-Addon-MissingShields.esp"
EN_DUMP = "/home/z/my-project/handoff/05_стринги_ESP/v14_en.json"
OUT_INI = "/home/z/my-project/work/v156/00 Core/PoE_RU_KID.ini"

# тип записи -> тип в грамматике KID (строгая свера)
TYPE_MAP = {"WEAP": "Weapon", "ARMO": "Armor", "AMMO": "Ammo"}

# ванильные ключевики (FormID Skyrim.esm); ClothingBody подтверждён
# распределительно (см. докстринг), остальные — канон из дампов этапа 98
VANILLA = {
    "WeapTypeGreatsword": 0x0006D931, "WeapTypeBattleaxe": 0x0006D932,
    "WeapTypeWarhammer": 0x0006D933, "WeapTypeSword": 0x0001E711,
    "WeapTypeBow": 0x0001E712, "WeapTypeDagger": 0x0001E713,
    "WeapTypeCrossbow": 0x01CD10DC, "ArmorShield": 0x000965B2,
    "ArmorJewelry": 0x0008F95B, "VendorItemWeapon": 0x0008F958,
    "ArmorCuirass": 0x0006BBB8, "ArmorGauntlets": 0x0006BBC0,
    "ArmorHelmet": 0x0006BBC1, "ArmorBoots": 0x0006BBBF,
    "ClothingBody": 0x000A8657, "ClothingHead": 0x0010CD11,
    "Clothing": 0x0006BBE8,
}

core = Plugin(CORE)
spears = Plugin(SPEARS)
shields = Plugin(SHIELDS)


# ---------- 1. разбор правил ----------
def parse_terms(filt):
    alts = []
    for alt in filt.split(","):
        terms = []
        for part in alt.split("+"):
            part = part.strip()
            if not part:
                continue
            if part.startswith("-"):
                body = part[1:].strip()
                if body.startswith("*"):
                    terms.append(("notname", body.lstrip("*").strip().lower()))
                else:
                    terms.append(("notkw", body))
            elif part.startswith("*"):
                terms.append(("name", part.lstrip("*").strip().lower()))
            else:
                terms.append(("kw", part))
        if terms:
            alts.append(terms)
    return alts


rules = []  # (line_no, kw, ftype, alts, field4)
for ln, raw in enumerate(open(KID_INI, encoding="utf-8", errors="ignore"), 1):
    s = raw.strip()
    if not s.startswith("Keyword"):
        continue
    parts = s.split("|")
    if len(parts) < 3:
        continue
    kw = parts[0].split("=", 1)[1].strip()
    ftype = parts[1].strip()
    alts = parse_terms(parts[2])
    field4 = parts[3].strip() if len(parts) > 3 else None
    if any(t[0] == "name" for alt in alts for t in alt):
        rules.append((ln, kw, ftype, alts, field4))
print(f"правил с wildcard-термами: {len(rules)}")

# ---------- 2. карты ключевиков ----------
kw_fid = {}
for p in (core, spears, shields):
    for fid, r in p.records.items():
        if r["type"] == "KYWD" and r["edid"]:
            kw_fid.setdefault(r["edid"], fid)


def kw_formid(edid):
    if edid in kw_fid:
        return kw_fid[edid]
    return VANILLA.get(edid)


def kwda_set(p, fid):
    r = p.records.get(fid)
    if not r:
        return set()
    out = set()
    for st, sd in r["subs"]:
        if st == "KWDA":
            for i in range(len(sd) // 4):
                out.add(struct.unpack_from("<I", sd, i * 4)[0])
    return out


def kw_in_baked(kw_edid, baked):
    f = kw_formid(kw_edid)
    if f is None:
        return None
    for cand in (f, 0x01000000 | (f & 0xFFFFFF), 0x06000000 | (f & 0xFFFFFF)):
        if cand in baked:
            return True
    return False


# ---------- 3. строгая симуляция EN-прогона ----------
d = json.load(open(EN_DUMP, encoding="utf-8"))
losses = {}          # (fid, edid, full, kind) -> [(kw, ftype, field4, line_no)]
unresolved = set()
notname_terms = set()  # сбор NOT-wildcard термов (для флип-скана)
for _ln, _kw, _ft, _alts, _f4 in rules:
    for alt in _alts:
        for k, v in alt:
            if k == "notname":
                notname_terms.add(v)

n_rules_used = set()
for r in d["records"]:
    t = r.get("t")
    if t not in TYPE_MAP:
        continue
    fid_s = r.get("fid", "")
    if len(fid_s) != 8:
        continue
    fid = int(fid_s, 16)
    s = r.get("s", {})
    if "FULL" not in s:
        continue
    full = s["FULL"][0] if isinstance(s["FULL"], list) else s["FULL"]
    if not full:
        continue
    fl = full.lower()
    edid = r.get("e") or ""
    el = edid.lower()
    if core.records.get(fid) is None:
        continue
    baked = kwda_set(core, fid)
    idx = fid >> 24
    kind = ("self" if idx >= 6 else
            f"ovr:{core.masters[idx] if idx < len(core.masters) else idx}")
    rec_type = TYPE_MAP[t]
    for ln, kw, ftype, alts, field4 in rules:
        if ftype != rec_type:               # СТРОГАЯ свера типов
            continue
        tgt = kw_fid.get(kw)
        if tgt is not None and (tgt in baked or
                                (0x01000000 | (tgt & 0xFFFFFF)) in baked):
            continue
        for alt in alts:
            name_dep = False
            ok = True
            for kind_t, val in alt:
                if kind_t == "name":
                    if val in el:
                        continue
                    if val not in fl:
                        ok = False
                        break
                    name_dep = True
                elif kind_t == "notname":
                    if val in fl or val in el:
                        ok = False
                        break
                elif kind_t == "kw":
                    hit = kw_in_baked(val, baked)
                    if hit is None:
                        unresolved.add(val)
                    elif not hit:
                        ok = False
                        break
                elif kind_t == "notkw":
                    hit = kw_in_baked(val, baked)
                    if hit:
                        ok = False
                        break
            if ok and name_dep:
                losses.setdefault(
                    (fid, edid, full, kind), []).append((kw, ftype, field4, ln))
                n_rules_used.add(ln)
                break

n_records = len(losses)
n_pairs = sum(len(v) for v in losses.values())
print(f"имя-зависимых потерь: записей {n_records}, пар (запись,ключ) {n_pairs}")
print(f"неразрешённых ключевиков: {sorted(unresolved)}")

# ---------- 4. генерация правил ----------
groups = OrderedDict()   # (kw, ftype, field4) -> [edid...]
src_lines = {}           # (kw, ftype, field4) -> [исходные строки ини]
for (fid, edid, full, kind), lst in sorted(losses.items()):
    for kw, ftype, field4, ln in lst:
        g = (kw, ftype, field4)
        if g not in groups:
            groups[g] = []
            src_lines[g] = []
        if edid not in groups[g]:
            groups[g].append(edid)
        if ln not in src_lines[g]:
            src_lines[g].append(ln)

header = """; PoE_RU_KID.ini - Russian translation companion for Paths of Empyrean
; Restores keywords lost when item names are translated to Russian.
;
; The original PathsOfEmpyrean_KID.ini distributes some keywords by matching
; ENGLISH substrings in item names (e.g. "Shrouded", "Ancient Nord", "Blades").
; Translated names no longer contain those substrings, so 37 records lose
; their keywords. This file re-assigns exactly those keywords by EditorID
; (translation-invariant), preserving the original form type and 4th field
; (biped slot / weight class / animation) of every source rule.
;
; Requires: Keyword Item Distributor (powerofthree, Nexus 55728), verified
; against 4.1.0. Loaded automatically: any *_KID.ini under Data\\ is picked
; up at game start. Safe to keep the original ini installed: keywords are
; additive, duplicates are harmless.
;
; Generated by scripts/kid_fix_build99.py (stage 99); rule source lines of
; PathsOfEmpyrean_KID.ini 1.4 are listed per block. Do not translate EDIDs.
"""

blocks = []
for (kw, ftype, field4), edids in groups.items():
    lines = ",".join(edids)
    f4 = f"|{field4}" if field4 is not None else ""
    blocks.append((kw, ftype, field4, edids, lines, f4))

out = [header, "; --- blocks ---"]
cur_kw = None
for kw, ftype, field4, edids, lines, f4 in blocks:
    if kw != cur_kw:
        out.append("")
        out.append(f"; {kw}")
        cur_kw = kw
    out.append(f"Keyword = {kw}|{ftype}|{lines}{f4}")
content = "\r\n".join(out) + "\r\n"
# нормализация: шапка-трипл-строка содержит LF — приводим всё к CRLF
content = content.replace("\r\n", "\n").replace("\n", "\r\n")

with open(OUT_INI, "w", encoding="ascii", newline="") as f:
    f.write(content)
print(f"\nзаписано: {OUT_INI} ({len(blocks)} правил, ASCII+CRLF)")

# ---------- 5. NOT-терм флип-скан (обратный риск) ----------
print("\n=== NOT-терм флип-скан (оверх-матчинг после перевода) ===")
print(f"NOT-wildcard термов в ини: {sorted(notname_terms)}")
flips = []
for r in d["records"]:
    t = r.get("t")
    if t not in TYPE_MAP:
        continue
    s = r.get("s", {})
    if "FULL" not in s:
        continue
    full = s["FULL"][0] if isinstance(s["FULL"], list) else s["FULL"]
    if not full:
        continue
    fl = full.lower()
    hit = [tok for tok in notname_terms if tok in fl]
    if hit:
        fid_s = r.get("fid", "")
        cur = core.records.get(int(fid_s, 16)) if len(fid_s) == 8 else None
        if cur is not None:
            flips.append((fid_s, r.get("e") or "", full, hit))
if flips:
    for fid_s, e, full, hit in flips:
        print(f"  ФЛИП {fid_s} [{e}] «{full}» термы={hit}")
else:
    print("  флипов нет: в EN-дампе ни одно имя-терм-отрицание не "
          "становится истинным после перевода (риск теоретический)")

# ---------- 6. 1.5-новые записи без EN-источника ----------
print("\n=== границы аудита: записи ядра вне EN-дампа 1.4 ===")
en_fids = {r.get("fid", "") for r in d["records"]}
new145 = []
for fid, r in core.records.items():
    if r["type"] not in ("WEAP", "ARMO"):
        continue
    if r["edid"] and f"{fid:08X}" not in en_fids:
        new145.append((fid, r["type"], r["edid"]))
print(f"WEAP/ARMO ядра без записи в EN-дампе 1.4: {len(new145)}")
for fid, t, e in new145[:15]:
    print(f"  {fid:08X} {t} {e}")
if len(new145) > 15:
    print(f"  ... и ещё {len(new145) - 15}")

# ---------- 7. таблица для отчёта ----------
print("\n=== соответствие: блок нашей ини <- строки оригинала ===")
for (kw, ftype, field4), edids in groups.items():
    f4s = field4 if field4 is not None else "-"
    print(f"  {kw}|{ftype}|{f4s}  <- строки {src_lines[(kw, ftype, field4)]}"
          f"  ({len(edids)} EDID)")
