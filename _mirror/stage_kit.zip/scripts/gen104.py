#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 104: перегенерация справочного слоя handoff/06_код-истина_перевода/
из истины — выпущенного пакета v1.5.9 (download/), + эталон перков v149/v150 ->
v151 (handoff/04_эталоны_игрока/perks_v151.jsonl) + CC-копии в 10_.

Образец — gen103.py. Отличия:
- зеркала v1.5.8 уходят в _архив_мастер-эры/ под версионированными именами
  (desc_ru_v158.py, corpus57_v158.json) с guard'ом;
- свежий полный дамп 39 ESP из выпускного zip (work/qa104/dump_v159_full.jsonl);
- эталон v150 не трогается, perks_v151.jsonl создаётся рядом;
- INI-копии 06_ и CC-копии 10_ обновляются байтами из нового zip.
"""
import io, json, os, shutil, zipfile, sys
from collections import defaultdict

sys.path.insert(0, '/home/z/my-project/upload/poe_pack/scripts')
from dump150 import dump_esp

ROOT = '/home/z/my-project/upload/poe_pack'
DL = '/home/z/my-project/download/Paths of Empyrean RU 1.5.zip'
DIR06 = f'{ROOT}/handoff/06_код-истина_перевода'
ARC = f'{DIR06}/_архив_мастер-эры'
PERKS_DIR = f'{ROOT}/handoff/04_эталоны_игрока'
DIR10 = f'{ROOT}/handoff/10_наш_перевод_CC_патчей'
REL = f'{ROOT}/work/qa104/release159'
DUMP = f'{ROOT}/work/qa104/dump_v159_full.jsonl'

# ---------- 0) распаковка выпускного zip и полный дамп 39 ESP ----------
if not os.path.isdir(REL):
    with zipfile.ZipFile(DL) as z:
        z.extractall(REL)
with io.open(DUMP, 'w', encoding='utf-8') as out:
    total = 0
    jobs = [(f'{REL}/00 Core/PathsOfEmpyrean.esp', 'main'),
            (f'{REL}/10 Missing Shields/PoE-Addon-MissingShields.esp', 'ms'),
            (f'{REL}/20 Spears/PoE-Addon-Spears.esp', 'sp')]
    import glob
    for path in sorted(glob.glob(f'{REL}/30 CC Patches/*/*.esp')):
        tag = 'cc:' + os.path.basename(path).replace('PoE-CC', '').replace('-Patch.esp', '')
        jobs.append((path, tag))
    for path, tag in jobs:
        p = dump_esp(path, tag, out)
        total += len(p.records)
print(f'дамп v1.5.9: {DUMP}')
fields = [json.loads(l) for l in io.open(DUMP, encoding='utf-8')]
print(f'полей текста: {len(fields)} (ожидалось 12 323)')
assert len(fields) == 12323

# ---------- 1) архив зеркал v1.5.8 (ДО генерации, guard) ----------
moved = []
for name, arcname in [('desc_ru.py', 'desc_ru_v158.py'),
                      ('corpus57.json', 'corpus57_v158.json')]:
    src = f'{DIR06}/{name}'
    dst = f'{ARC}/{arcname}'
    if os.path.isfile(src) and not os.path.exists(dst):
        shutil.move(src, dst)
        moved.append(f'{name} -> {arcname}')
print('заархивировано:', moved or 'ничего (guard: уже в архиве)')

# ---------- 2) свежий desc_ru.py (v1.5.9) ----------
perk_desc = [r for r in fields if r['rtype'] == 'PERK' and r['field'] == 'DESC']
by_file_edid = defaultdict(dict)
for r in perk_desc:
    by_file_edid[r['file']].setdefault(r['edid'], r['text'])
edid_files = defaultdict(set)
for f, d in by_file_edid.items():
    for e in d:
        edid_files[e].add(f)
conflict = {e: fs for e, fs in edid_files.items() if len(fs) > 1}
items = []
for f, d in by_file_edid.items():
    for e, t in d.items():
        key = f'{e}@{f}' if e in conflict else e
        items.append((key, t))
print(f'PERK DESC: {len(perk_desc)} записей -> {len(items)} ключей; '
      f'конфликтов EDID между файлами: {len(conflict)}')


def group(key):
    if key.startswith('PoE_PERK_'):
        return 'PoE: деревья перков'
    if key.startswith('GRIM_PERK_'):
        return 'Grimoire (GRIM): перки'
    if key.startswith(('ISP_', 'IWP_')):
        return 'Надстройки/патчи (ISP/IWP)'
    return 'Ванильные перки (офиц. стиль)'


groups = defaultdict(list)
for k, t in items:
    groups[group(k)].append((k, t))
for g in groups:
    groups[g].sort()

hdr = '''# -*- coding: utf-8 -*-
"""
Свежее зеркало PERK DESC выпущенного пакета v1.5.9 (Этап 104).
Источник: дамп истины work/qa104/dump_v159_full.jsonl (39 ESP), генератор
scripts/gen104.py; дата: 04.11.2026. Ключ = EDID; для EDID, совпадающих
в разных ESP, ключ = 'EDID@file' (file как в дампе: main/ms/sp/cc:...).
Правило проекта: истина = выпущенный ESP (02_конвейер_и_сборка.md), урок [T37]:
предыдущие зеркала заархивированы в _архив_мастер-эры/ под версионированными
именами (desc_ru_v158.py, corpus57_v158.json). При выпуске v1.5.10+ перегенерировать
(шаг 11 в 02_конвейер_и_сборка.md).
Стиль текстов — сам ESP; правки вносятся только через этапный fixlist.
"""

DESC_RU = {
'''
parts = [hdr]
for g in ['PoE: деревья перков', 'Grimoire (GRIM): перки',
          'Надстройки/патчи (ISP/IWP)', 'Ванильные перки (офиц. стиль)']:
    parts.append(f'    # ===== {g} =====\n')
    for k, t in groups[g]:
        parts.append(f'    {k!r}: {t!r},\n')
    parts.append('\n')
parts.append('}\n')
io.open(f'{DIR06}/desc_ru.py', 'w', encoding='utf-8').write(''.join(parts))
print(f'desc_ru.py перезаписан (v1.5.9): {len(items)} ключей')

# ---------- 3) свежий corpus57.json (v1.5.9) ----------
c56 = json.load(io.open(f'{ARC}/corpus56.json', encoding='utf-8'))
en_map = {}
for e in c56:
    en = e.get('en')
    if en is not None:
        en_map.setdefault((e['fid'], e['type'], e['field']), en)
corpus = []
en_n = 0
for r in fields:
    e = {'fid': r['formid'], 'edid': r['edid'], 'type': r['rtype'],
         'field': r['field'], 'occ': r.get('occ', 1), 'file': r['file'],
         'ru': r['text']}
    en = en_map.get((r['formid'], r['rtype'], r['field']))
    if en is not None:
        e['en'] = en
        en_n += 1
    corpus.append(e)
with io.open(f'{DIR06}/corpus57.json', 'w', encoding='utf-8') as f:
    json.dump(corpus, f, ensure_ascii=False, indent=1)
print(f'corpus57.json (v1.5.9): {len(corpus)} записей, en-пар: {en_n}')

# ---------- 4) README архива + слоя ----------
arc_readme = '''# Архив (06_код-истина_перевода)

Исторические справочные слои. НЕ читать как истину — урок [T37] (Этап 100):
слой desc_ru.py мастер-эры совпадал с ESP лишь в 78 из 482 ключей; corpus56.json
(корпус Этапа 56, сборка v1.13/14) — в 6 111 из 9 718 записей.

АКТУАЛЬНЫЕ зеркала истины: `../desc_ru.py` и `../corpus57.json` (v1.5.9,
Этап 104). Терминология (не зеркало ESP): `../spell_names_ru.py`,
`../official_terms42.py`.

Состав архива:
- desc_ru.py / corpus56.json / full_names_ru.py / patch_log.json / patch_log14.json
  — слои каскада master47–76 (пересборка «из EN») + README данных;
- desc_ru_v157.py / corpus57_v157.json — зеркала выпущенного v1.5.7 (Этап 101);
- desc_ru_v158.py / corpus57_v158.json — зеркала выпущенного v1.5.8 (Этап 103).
'''
io.open(f'{ARC}/README.md', 'w', encoding='utf-8').write(arc_readme)
print(f'README архива записан: {ARC}/README.md')

layer_readme = '''# 06_код-истина_перевода — справочный слой (обновлён Этапом 104)

Истина проекта — выпущенный пакет `Paths of Empyrean RU 1.5.zip` (корень пака),
с Этапа 104 — **v1.5.9** (итерация скрытности: «скрытой атаки/атакой» ->
«скрытной» ×98; директива игрока + корпус SoftClub).
Дамп истины: `work/qa104/dump_v159_full.jsonl` (39 ESP, 12 323 текстовых поля).

СВЕЖЕЕ (сгенерировано Этапом 104 из дампа v1.5.9, генератор scripts/gen104.py):
- `desc_ru.py`    — зеркало всех 566 PERK DESC (ключ = EDID, конфликты — EDID@file);
- `corpus57.json` — зеркало всех текстовых полей (FULL/DESC/ITXT/NNAM/DNAM/GMST),
                    12 323 записи; en-пары из corpus56 (архив);
- `PathsOfEmpyrean_DESC.ini`, `ShortbowNames_ru.ini` — байтовые копии файлов
                    выпущенного пакета (00 Core), обновлены из zip v1.5.9;

ТЕРМИНОЛОГИЯ (актуальна, не зеркало ESP):
- `spell_names_ru.py` — род. падежи имён заклинаний («Свиток X»);
- `official_terms42.py` — таблица офиц. терминов SoftClub с доказательствами.

АРХИВ (историческая ценность, НЕ читать как истину — урок [T37]):
- `_архив_мастер-эры/` — слои каскада master47–76 + зеркала v1.5.7/v1.5.8
  (desc_ru_v157.py, corpus57_v157.json, desc_ru_v158.py, corpus57_v158.json) + README.

Правило: при выпуске v1.5.10+ перегенерировать зеркала из нового дампа
(шаг 11 в 02_конвейер_и_сборка.md).
'''
io.open(f'{DIR06}/README.md', 'w', encoding='utf-8').write(layer_readme)
print(f'README слоя записан: {DIR06}/README.md')

# ---------- 5) INI-копии 06_ + CC-копии 10_ из zip v1.5.9 ----------
with zipfile.ZipFile(DL) as z:
    for arc, local in [('00 Core/PathsOfEmpyrean_DESC.ini', 'PathsOfEmpyrean_DESC.ini'),
                       ('00 Core/SKSE/Plugins/POE/Weapon/PathsOfEmpyrean_ShortbowNames.ini',
                        'ShortbowNames_ru.ini')]:
        data = z.read(arc)
        io.open(f'{DIR06}/{local}', 'wb').write(data)
        print(f'INI 06_ обновлён из zip: {local} ({len(data)} Б)')
    for arc in ['30 CC Patches/Advanced Crossbows/PoE-CCAdvancedCrossbows-Patch_DESC.ini',
                '30 CC Patches/Expanded Crossbow Pack/PoE-CCExpandedCrossbowPack-Patch_DESC.ini']:
        data = z.read(arc)
        io.open(f'{DIR10}/{os.path.basename(arc)}', 'wb').write(data)
        print(f'CC-копия 10_ обновлена из zip: {os.path.basename(arc)} ({len(data)} Б)')

# ---------- 6) эталон перков v150 -> v151 (v149/v150 не трогаем) ----------
perk = {}
for r in fields:
    if r['rtype'] != 'PERK':
        continue
    key = (r['file'], r['formid'])
    d = perk.setdefault(key, {'file': r['file'], 'formid': r['formid'],
                              'edid': r['edid'], 'full': '', 'desc': ''})
    if r['field'] == 'FULL' and not d['full']:
        d['full'] = r['text']
    elif r['field'] == 'DESC' and not d['desc']:
        d['desc'] = r['text']
rows = list(perk.values())
rows.sort(key=lambda x: (x['file'], x['formid']))
out = f'{PERKS_DIR}/perks_v151.jsonl'
with io.open(out, 'w', encoding='utf-8') as f:
    for d in rows:
        f.write(json.dumps(d, ensure_ascii=False) + '\n')
print(f'эталон: {out}: {len(rows)} перков (v149/v150 не тронуты)')

# контроль: ключевые строки этапа в эталоне и зеркалах
chk = {d['formid']: d for d in rows}
assert 'смертельной скрытной атаки' in chk['060C64F9']['desc']
assert 'скрытой атаки' not in chk['060C64F9']['desc']
assert 'сильнее' in chk['000D7999']['desc'] and 'эффективнее' not in chk['000D7999']['desc']
assert 'на 50% сильнее' in chk['06000BC0']['desc']
assert 'эффективнее' in chk['06014C65']['desc']  # DragonbloodMasterwork — санкция
print('контроль эталона: 104-а (Reaper скрытной) применен, 102-а на месте, санкция Dragonblood на месте — OK')

# контроль corpus57.json
blob = json.dumps(corpus, ensure_ascii=False)
assert 'смертельной скрытной атаки' in blob
assert 'урон скрытной атаки <10>x' in blob
assert 'урон скрытой атак' not in blob
print('контроль corpus57.json: 104-а (сфера-убийца) и 104-б (0 старых вхождений) — OK')
print('OK')
