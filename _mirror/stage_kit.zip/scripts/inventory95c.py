#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 95, часть 3: таксономия классов (KYWD), природа правок FLOR/TREE/AVIF/SCRL/ARMO/WEAP."""
import sys, re, struct, json
from collections import defaultdict

sys.path.insert(0, '/home/z/my-project/upload/poe_pack/scripts')
from parse_tes4 import Plugin

BASE = '/home/z/my-project/work/v156'
p = Plugin(f'{BASE}/00 Core/PathsOfEmpyrean.esp')
NM = len(p.masters)

def is_new(f):
    return (f >> 24) >= NM

# 1. Полная таксономия KYWD (новые)
kywd_new = [r['edid'] for f, r in p.records.items() if r['type'] == 'KYWD' and is_new(f) and r['edid']]
fams = defaultdict(list)
for e in kywd_new:
    # семейство: PoE_K_WeapType -> PoE_K_WeapType; PoE_K_X -> PoE_K_X; MAG_ -> MAG; иначе корень
    m = re.match(r'^(PoE_K_[A-Za-z]+?)(?:1H|2H|Rank\d+)?$', e) or re.match(r'^([A-Za-z]+?)_?', e)
    fams[m.group(1) if m else '?'].append(e)
print(f'### KYWD новых: {len(kywd_new)}; семейства:')
for k, v in sorted(fams.items(), key=lambda x: -len(x[1])):
    print(f'  {k}: {len(v)}')
    if len(v) <= 12:
        for e in v:
            print(f'     {e}')

# 2. FLOR/TREE: PFIG (ingredient) — куда указывает
flor = [p.records[f] for f in p.by_type['FLOR']]
tree = [p.records[f] for f in p.by_type['TREE']]
def pfig_target(r):
    for st, sd in r['subs']:
        if st == 'PFIG':
            v = struct.unpack_from('<I', sd)[0]
            if v == 0:
                return 'NULL'
            return p.label(v) if v in p.records or (v >> 24) < NM else f'new0x{v:08X}'
    return '-'
print(f'\n### FLOR правок: {len(flor)}; PFIG-цели (ингредиент при сборе):')
cnt = defaultdict(int)
for r in flor:
    cnt[pfig_target(r)] += 1
for k, v in sorted(cnt.items(), key=lambda x: -x[1])[:25]:
    print(f'  {k}: {v}')
print(f'### TREE правок: {len(tree)}; PFIG-цели:')
cnt = defaultdict(int)
for r in tree:
    cnt[pfig_target(r)] += 1
for k, v in sorted(cnt.items(), key=lambda x: -x[1])[:25]:
    print(f'  {k}: {v}')
# PNAM (сезоны) у FLOR: битовая маска
pn = defaultdict(int)
for r in flor:
    for st, sd in r['subs']:
        if st == 'PNAM':
            pn[struct.unpack_from('<I', sd)[0]] += 1
print('PNAM (маска сезонов) FLOR:', dict(pn))

# 3. AVIF: что за 18 правок
print('\n### AVIF-правки (18):')
for f in p.by_type['AVIF']:
    r = p.records[f]
    desc = next((sd.rstrip(b'\x00').decode('utf-8', 'replace') for st, sd in r['subs'] if st == 'DESC'), '')
    print(f"  {r['edid']}: FULL=«{r['full']}» DESC[{len(desc)}]: {desc[:90]}")

# 4. SCRL-правки (164): образцы
scrl = [p.records[f] for f in p.by_type['SCRL'] if not is_new(f)]
print(f'\n### SCRL правок: {len(scrl)}; образцы имён:')
for r in scrl[:20]:
    print(f"  {r['edid']} → «{r['full']}»")

# 5. WEAP-правки (12)
print('\n### WEAP правок ванильных:')
for f in p.by_type['WEAP']:
    if not is_new(f):
        r = p.records[f]
        print(f"  {p.label(f)} → «{r['full']}»")

# 6. ARMO-правки (205): образцы
armo = [p.records[f] for f in p.by_type['ARMO'] if not is_new(f)]
print(f'\n### ARMO правок: {len(armo)}; образцы:')
for r in armo[:25]:
    print(f"  {r['edid']} → «{r['full']}»")

# 7. MGEF-правки по мастерам
mm = defaultdict(int)
for f in p.by_type['MGEF']:
    if not is_new(f):
        mm[p.masters[f >> 24]] += 1
print('\n### MGEF-правки по мастерам:', dict(mm))

# 8. GLOB (200): образцы конфигов
globs = [r['edid'] for f, r in p.records.items() if r['type'] == 'GLOB' and r['edid']]
print(f'\n### GLOB: {len(globs)}; образцы:', globs[:25])

# 9. MESG (139): образцы интерфейсных сообщений
msgs = [r['full'] for f, r in p.records.items() if r['type'] == 'MESG' and r['full']]
print(f'\n### MESG: {len(msgs)}; образцы:')
for m in msgs[:18]:
    print(f'  {m}')
