#!/usr/bin/env python3
"""Complete SPID type-model dump from PDB TPI: all structs/enums with resolved member type names."""
import struct, re, sys

PDB = "/home/z/my-project/spid_work/spid_extracted/SKSE/Plugins/po3_SpellPerkItemDistributor.pdb"
data = open(PDB, "rb").read()
MAGIC = b"Microsoft C/C++ MSF 7.00\r\n\x1aDS\x00\x00\x00"
bs, fm, nb, ds, unk, bma = struct.unpack_from("<IIIIII", data, len(MAGIC))
nd = (ds + bs - 1) // bs
db = struct.unpack_from(f"<{nd}I", data, bma * bs)
directory = b"".join(data[b * bs: b * bs + bs] for b in db)[:ds]
pos = 0
ns = struct.unpack_from("<I", directory, pos)[0]; pos += 4
sizes = [struct.unpack_from("<I", directory, pos + 4 * i)[0] for i in range(ns)]
pos += 4 * ns
streams = []
for i, sz in enumerate(sizes):
    if sz in (0, 0xFFFFFFFF):
        streams.append(b""); continue
    nbk = (sz + bs - 1) // bs
    blks = struct.unpack_from(f"<{nbk}I", directory, pos); pos += 4 * nbk
    streams.append(b"".join(data[b * bs: b * bs + bs] for b in blks)[:sz])
tpi = streams[2]
ver, hsize, imin, imax = struct.unpack_from("<IIII", tpi, 0)

offsets = {}
i = hsize; idx = imin
while i < len(tpi) - 4 and idx < imax:
    reclen = struct.unpack_from("<H", tpi, i)[0]
    offsets[idx] = i
    i = (i + 2 + reclen + 3) & ~3
    idx += 1

LF_MEMBER = 0x150D; LF_STMEMBER = 0x150E; LF_METHOD = 0x150F; LF_ONEMETHOD = 0x1511
LF_ENUMERATE = 0x1502; LF_NESTTYPE = 0x1510; LF_BCLASS = 0x1400; LF_INDEX = 0x1404
LF_VFUNCTAB = 0x1409

def rec_at(tidx):
    o = offsets.get(tidx)
    if o is None:
        return None
    reclen = struct.unpack_from("<H", tpi, o)[0]
    return tpi[o:o + 2 + reclen]

PRIMS = {0x03: "int", 0x74: "unsigned", 0x08: "void*", 0x43: "__int64", 0x75: "unsigned __int64",
         0x68: "bool", 0x11: "char", 0x21: "short", 0x41: "long", 0x70: "float", 0x40: "double",
         0x04: "void", 0x73: "unsigned char", 0x12: "unsigned char"}

def typename(tidx):
    r = rec_at(tidx)
    if r is None:
        return f"t{tidx}"
    leaf = struct.unpack_from("<H", r, 2)[0]
    if leaf in PRIMS:
        return PRIMS[leaf]
    if leaf == 0x1502:  # pointer
        ptr, t = struct.unpack_from("<IH", r, 4)
        return f"{typename(t)}*"
    if leaf in (0x1505, 0x1504, 0x1506, 0x1507, 0x1508, 0x1509, 0x150A, 0x150B, 0x150C):
        try:
            if leaf in (0x1505, 0x1504, 0x1506):
                name_off = 20
            else:
                name_off = 16
            e = r.index(b"\x00", name_off)
            return r[name_off:e].decode("latin1")
        except ValueError:
            return f"t{tidx}"
    if leaf == 0x1002:  # LF_MODIFIER
        m, t = struct.unpack_from("<IH", r, 4)
        return f"const {typename(t)}"
    if leaf in (0x1500,):  # LF_ARRAY
        atype = struct.unpack_from("<I", r, 4)[0]
        return f"{typename(atype)}[]"
    if leaf == 0x1515:  # LF_ALIAS? (LF_ENUMERATE...) actually 0x1515 = LF_ALIAS? no, skip
        pass
    if leaf == 0x1001:  # LF_MODIFIER? no 0x1001 = LF_MODIFIER is 0x1001? keep
        m, t = struct.unpack_from("<IH", r, 4)
        return f"mod {typename(t)}"
    return f"t{tidx}:{leaf:#x}"

# index: tidx -> (name, leaf, prop, fieldlist, members)
types = {}
for tidx in offsets:
    r = rec_at(tidx)
    if r is None or len(r) < 10:
        continue
    leaf = struct.unpack_from("<H", r, 2)[0]
    try:
        if leaf in (0x1505, 0x1504, 0x1506):
            count, prop = struct.unpack_from("<HH", r, 4)
            fl, derived, vshape = struct.unpack_from("<III", r, 8)
            e = r.index(b"\x00", 20)
            name = r[20:e].decode("latin1", "ignore")
            types[tidx] = (name, leaf, prop, fl)
        elif leaf == 0x1507:
            count, prop = struct.unpack_from("<HH", r, 4)
            fl = struct.unpack_from("<I", r, 12)[0]
            utype = struct.unpack_from("<I", r, 8)[0]
            e = r.index(b"\x00", 16)
            name = r[16:e].decode("latin1", "ignore")
            types[tidx] = (name, leaf, prop, fl)
    except (ValueError, struct.error):
        continue

def members_of(fl, depth=0):
    if depth > 8:
        return []
    flr = rec_at(fl)
    if flr is None:
        return []
    out = []
    p = 4
    plen = len(flr)
    while p < plen - 2:
        if flr[p] >= 0xF0:
            p += flr[p] & 0x0F
            continue
        mleaf = struct.unpack_from("<H", flr, p)[0]; p += 2
        try:
            if mleaf == LF_MEMBER:
                attrs = struct.unpack_from("<H", flr, p)[0]; p += 2
                t2 = struct.unpack_from("<I", flr, p)[0]; p += 4
                v16 = struct.unpack_from("<H", flr, p)[0]
                if v16 >= 0x8000:
                    off = -1
                    if v16 in (0x8003, 0x8004): p += 6
                    elif v16 in (0x8001, 0x8002): p += 4
                    elif v16 == 0x8000: p += 3
                    else: p += 2
                else:
                    off = v16; p += 2
                e = flr.index(b"\x00", p)
                nm = flr[p:e].decode("latin1", "ignore"); p = e + 1
                out.append(("member", nm, off, t2))
            elif mleaf == LF_ENUMERATE:
                attrs = struct.unpack_from("<H", flr, p)[0]; p += 2
                v16 = struct.unpack_from("<H", flr, p)[0]
                if v16 >= 0x8000:
                    val = None
                    if v16 in (0x8003, 0x8004): p += 6
                    elif v16 in (0x8001, 0x8002): p += 4
                    elif v16 == 0x8000: p += 3
                    else: p += 2
                else:
                    val = v16; p += 2
                e = flr.index(b"\x00", p)
                nm = flr[p:e].decode("latin1", "ignore"); p = e + 1
                out.append(("enum", nm, val, 0))
            elif mleaf == LF_STMEMBER:
                p += 2
                t2 = struct.unpack_from("<I", flr, p)[0]; p += 4
                e = flr.index(b"\x00", p)
                out.append(("static", flr[p:e].decode("latin1", "ignore"), -1, t2)); p = e + 1
            elif mleaf in (LF_ONEMETHOD, LF_METHOD, LF_NESTTYPE, LF_INDEX, LF_BCLASS, LF_VFUNCTAB):
                # skip: not needed for data model
                if mleaf == LF_ONEMETHOD:
                    attrs = struct.unpack_from("<H", flr, p)[0]; p += 2
                    p += 4
                    e = flr.index(b"\x00", p); p = e + 1
                    if attrs & 0x40: p += 4
                elif mleaf == LF_METHOD:
                    cnt = struct.unpack_from("<H", flr, p)[0]; p += 2
                    e = flr.index(b"\x00", p); p = e + 1
                elif mleaf == LF_NESTTYPE:
                    p += 2 + 4
                    e = flr.index(b"\x00", p); p = e + 1
                elif mleaf == LF_INDEX:
                    # fieldlist continuation: leaf + pad2 + next fieldlist tidx
                    cont = struct.unpack_from("<I", flr, p + 2)[0]
                    p += 6
                    out.extend(members_of(cont, depth + 1))
                elif mleaf == LF_BCLASS:
                    p += 2 + 4
                    v16 = struct.unpack_from("<H", flr, p)[0]
                    if v16 >= 0x8000: p += 6
                    else: p += 2
                elif mleaf == LF_VFUNCTAB:
                    p += 2 + 4
            else:
                break
        except (ValueError, struct.error):
            break
    return out

# ---------- dump SPID data model ----------
INTEREST = re.compile(
    r"^(x?)(Distribution::INI::Data|Filter::|NPC::Data|Forms::(Data|Distributables|DistributionSet|Lookup)|"
    r"PCLevelMult::|Outfits::Manager|LinkedDistribution::(INI::|LinkedForms|Manager|DistributionType|Scope)|"
    r"DeathDistribution::|ExclusiveGroups::|KeywordDependencies::|Distribute::|Settings|"
    r"Forms?::Lookup|MergeMapper|Filters<|Range<|RECORD::TYPE|RawLinkedForm|RawExclusiveGroup|DeathData)"
)

name_to_idx = {}
for tidx, (name, leaf, prop, fl) in types.items():
    if prop & 0x80:  # skip fwdrefs
        continue
    name_to_idx.setdefault(name, []).append(tidx)

wanted = []
for tidx, (name, leaf, prop, fl) in types.items():
    if prop & 0x80:
        continue
    clean = name.lstrip("x\x00\x01`\x7f")
    if INTEREST.match(clean) or INTEREST.match(name):
        wanted.append(tidx)

print(f"# SPID type model: {len(wanted)} matching complete definitions")
for tidx in sorted(wanted):
    name, leaf, prop, fl = types[tidx]
    kind = "enum" if leaf == 0x1507 else "struct"
    print(f"\n=== [{tidx}] {name} ({kind}) ===")
    for m in members_of(fl):
        if m[0] == "member":
            _, nm, off, t2 = m
            print(f"    {nm:26s} @{off:<#6x} : {typename(t2)}")
        elif m[0] == "enum":
            _, nm, val, _ = m
            print(f"    {nm} = {val}")
        elif m[0] == "static":
            _, nm, _, t2 = m
            print(f"    static {nm:20s} : {typename(t2)}")
