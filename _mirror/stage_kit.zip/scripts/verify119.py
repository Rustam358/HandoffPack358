#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 119: независимая верификация v1.5.19.
1) CRC-регресс 63 файлов (изменены ровно 5: 3 ESP + ShortbowNames.ini +
info.xml); 2) побайтовый регресс записей трёх ESP (изменены ровно 58 форм,
только FULL); 3) dump-дифф (58 == fixlist, 0 новых/пропавших); 4) спот-чеки
семей 118-а…е + гигиена + FOMOD + zip.
"""
import struct, zlib, os, sys, json, zipfile, hashlib, io
import xml.dom.minidom

sys.path.insert(0, '/home/z/my-project/scripts')
from dump150 import dump_esp

SRC_ZIP = '/home/z/my-project/upload/Paths of Empyrean RU 1.5 (10).zip'
NEW = '/home/z/my-project/work/qa119/v119'
FIX = '/home/z/my-project/work/qa119/fixlist_v119.jsonl'
DUMP_OLD = '/home/z/my-project/work/qa117/dump_v118_full.jsonl'
DUMP_NEW = '/home/z/my-project/work/qa119/dump_v119_full.jsonl'
INI_REL = ('00 Core/SKSE/Plugins/POE/Weapon/'
           'PathsOfEmpyrean_ShortbowNames.ini')

FILES = {
    'main': '00 Core/PathsOfEmpyrean.esp',
    'cc:ExpandedCrossbowPack':
        '30 CC Patches/Expanded Crossbow Pack/'
        'PoE-CCExpandedCrossbowPack-Patch.esp',
    'cc:Fishing': '30 CC Patches/Fishing/PoE-CCFishing-Patch.esp',
}
INI_NEW = f'{NEW}/{INI_REL}'

FAILED = []


def check(cond, msg):
    if cond:
        print(f'  ✓ {msg}')
    else:
        print(f'  ✗ {msg}')
        FAILED.append(msg)


class Node:
    __slots__ = ('kind', 'label', 'tail', 'formid', 'data', 'children')


def parse(buf):
    root = []

    def walk(off, end, out):
        while off < end:
            t = buf[off:off+4]
            size = struct.unpack_from('<I', buf, off+4)[0]
            if t == b'GRUP':
                node = Node()
                node.kind = 'grup'
                node.tail = bytes(buf[off+8:off+24])
                node.children = []
                walk(off + 24, off + size, node.children)
                out.append(node)
                off += size
            else:
                node = Node()
                node.kind = 'rec'
                node.label = t
                node.tail = bytes(buf[off+8:off+24])
                node.formid = struct.unpack_from('<I', buf, off+12)[0]
                node.data = bytes(buf[off+24:off+24+size])
                out.append(node)
                off += 24 + size
    walk(0, len(buf), root)
    return root


def walk_recs(nodes):
    for n in nodes:
        if n.kind == 'grup':
            yield from walk_recs(n.children)
        else:
            yield n


def subrecords(rec):
    body = rec.data
    if struct.unpack_from('<I', rec.tail, 0)[0] & 0x00040000:
        usz = struct.unpack_from('<I', body, 0)[0]
        body = zlib.decompress(body[4:])
        assert len(body) == usz
    out = []
    off = 0
    while off < len(body):
        st = body[off:off+4].decode('ascii', 'replace')
        ssz = struct.unpack_from('<H', body, off+4)[0]
        out.append((st, bytes(body[off+6:off+6+ssz])))
        if st == 'XXXX':
            real = struct.unpack_from('<I', body, off+6)[0]
            off += 6 + ssz + 6 + real
            continue
        off += 6 + ssz
    return out


def main():
    fixes = [json.loads(l) for l in io.open(FIX, encoding='utf-8')]
    esp_fixes = [f for f in fixes if f['kind'] == 'esp']
    ini_fixes = [f for f in fixes if f['kind'] == 'ini']
    patch_ids = {scope: {int(f['formid'], 16) for f in esp_fixes
                         if f['file'] == scope} for scope in FILES}

    print('=== 1) CRC-регресс: дерево v119 и zip v1.5.19 ===')
    with zipfile.ZipFile(SRC_ZIP) as z:
        old_names = set(z.namelist())
        old_bytes = {n: z.read(n) for n in old_names}
    new_files = {}
    for dp, _, fns in os.walk(NEW):
        for fn in fns:
            rel = os.path.relpath(os.path.join(dp, fn), NEW).replace(os.sep, '/')
            new_files[rel] = open(os.path.join(dp, fn), 'rb').read()
    check(set(new_files) == old_names,
          f'состав: 63 файла, совпадение имён ({len(new_files)}/63)')
    changed = [n for n in old_names
               if hashlib.md5(new_files[n]).hexdigest()
               != hashlib.md5(old_bytes[n]).hexdigest()]
    # дерево v119 = патчи мастера (info.xml бампится только в zip, как в 117)
    expect_tree = sorted(list(FILES.values()) + [INI_REL])
    check(sorted(changed) == expect_tree,
          f'дерево v119: изменены ровно 4 записи '
          f'({[os.path.basename(c) for c in changed]})')
    for n in old_names - set(expect_tree):
        if new_files[n] != old_bytes[n]:
            check(False, f'НЕИЗВЕСТНОЕ ИЗМЕНЕНИЕ: {n}')
    print(f'  ✓ {len(old_names) - len(expect_tree)} файлов дерева '
          f'байт-в-байт идентичны v1.5.18')
    with zipfile.ZipFile(SRC_ZIP) as zo, \
            zipfile.ZipFile('/home/z/my-project/download/Paths of Empyrean '
                            'RU 1.5.zip') as zn:
        check(zn.testzip() is None and set(zn.namelist()) == old_names,
              'download zip: testzip OK, 63 записи, набор совпадает')
        zip_diff = [i.filename for i in zo.infolist()
                    if i.CRC != zn.getinfo(i.filename).CRC]
    check(sorted(zip_diff) == sorted(expect_tree + ['fomod/info.xml']),
          f'zip vs v1.5.18: изменены ровно 5 записей (4 + info.xml), '
          f'остальные {len(old_names) - 5} байт-в-байт')

    print('=== 2) побайтовый регресс записей трёх ESP ===')
    for scope, rel in FILES.items():
        old_root = parse(old_bytes[rel])
        new_root = parse(new_files[rel])
        old_map = {r.formid: r for r in walk_recs(old_root)}
        new_map = {r.formid: r for r in walk_recs(new_root)}
        check(len(old_map) == len(new_map),
              f'{scope}: записей {len(old_map)} == {len(new_map)}')
        ids = patch_ids[scope]
        extra = []
        for fid, old_r in old_map.items():
            new_r = new_map.get(fid)
            if new_r is None:
                extra.append((fid, 'ИСЧЕЗЛА'))
            elif (old_r.data != new_r.data
                  or old_r.tail[:4] != new_r.tail[:4]):
                if fid not in ids:
                    extra.append((fid, 'ПОСТОРОННЕЕ ИЗМЕНЕНИЕ'))
        check(not extra, f'{scope}: посторонних изменений нет ({len(extra)})')
        for fid, why in extra[:10]:
            print(f'    ! {fid:08X} {why}')
        check(all(f in new_map for f in ids),
              f'{scope}: все {len(ids)} patched-formid существуют')
        only_full = all(
            [(s, v) for s, v in subrecords(old_map[fid]) if s != 'FULL']
            == [(s, v) for s, v in subrecords(new_map[fid]) if s != 'FULL']
            for fid in ids)
        check(only_full, f'{scope}: у каждой patched-записи изменено ТОЛЬКО '
              f'поле FULL (EDID/VMAD/CTDA байт-в-байт)')

    print('=== 3) dump-дифф текстов ===')
    if os.path.isfile(DUMP_NEW):
        os.remove(DUMP_NEW)
    with io.open(DUMP_NEW, 'w', encoding='utf-8') as out:
        jobs = [(f'{NEW}/00 Core/PathsOfEmpyrean.esp', 'main'),
                (f'{NEW}/10 Missing Shields/PoE-Addon-MissingShields.esp', 'ms'),
                (f'{NEW}/20 Spears/PoE-Addon-Spears.esp', 'sp')]
        for dp, _, fns in os.walk(f'{NEW}/30 CC Patches'):
            for fn in sorted(fns):
                if fn.lower().endswith('.esp'):
                    tag = 'cc:' + fn.replace('PoE-CC', '').replace('-Patch.esp', '')
                    jobs.append((os.path.join(dp, fn), tag))
        for path, tag in jobs:
            dump_esp(path, tag, out)
    fields = [json.loads(l) for l in io.open(DUMP_NEW, encoding='utf-8')]
    old_fields = [json.loads(l) for l in io.open(DUMP_OLD, encoding='utf-8')]
    check(len(fields) == 12338, f'полей: {len(fields)} (ожидается 12 338)')
    om = {(r['file'], r['formid'], r['rtype'], r['field'], r.get('occ', 1)):
          r['text'] for r in old_fields}
    nm = {(r['file'], r['formid'], r['rtype'], r['field'], r.get('occ', 1)):
          r['text'] for r in fields}
    removed = [k for k in om if k not in nm]
    added = [k for k in nm if k not in om]
    check(not removed, f'ключей пропало: {len(removed)}')
    check(not added, f'ключей добавилось: {len(added)}')
    expect = {(f['file'], f['formid'], f['rtype'], f['field'], f['occ']):
              (f['old'], f['new']) for f in esp_fixes}
    changed_keys = [k for k in om if k in nm and om[k] != nm[k]]
    ok_changed = 0
    for k in changed_keys:
        exp = expect.get(k)
        if exp and om[k] == exp[0] and nm[k] == exp[1]:
            ok_changed += 1
        else:
            check(False, f'вне fixlist: {k}: {om[k]!r} -> {nm[k]!r}')
    check(ok_changed == 58 == len(changed_keys),
          f'изменённых полей ровно 58 == fixlist ({ok_changed})')
    by_file = {}
    for k in changed_keys:
        by_file[k[0]] = by_file.get(k[0], 0) + 1
    check(by_file == {'main': 31, 'cc:ExpandedCrossbowPack': 24,
                      'cc:Fishing': 3},
          f'разбивка: {by_file}')

    texts_new = [r['text'] for r in fields]
    texts_old = [r['text'] for r in old_fields]
    by_fid = {}
    for r in fields:
        by_fid.setdefault((r['file'], r['formid'], r['field']), []).append(r['text'])

    print('=== 4) спот-чеки семей ===')
    # 118-а: 24 арбалета ECP — материалы возвращены, коллизия снята
    mats = ['Даэдрический', 'Драконий костяной', 'Стеклянный', 'Имперский',
            'Нордский', 'Орочий', 'Серебряный', 'Сталгримовый']
    for suffix in ['с выгнутой ложей', 'с пружинным механизмом',
                   'с выгнутой ложей и пружинным механизмом']:
        want = {f'{m} арбалет {suffix}' for m in mats}
        got = [t for (fl, fid, fld), ts in by_fid.items()
               if fl == 'cc:ExpandedCrossbowPack' and fld == 'FULL'
               for t in ts if t in want]
        check(len(got) == 8 and set(got) == want,
              f'ECP «{suffix}»: ровно 8 имён — по одному на материал')
    bare = [t for (fl, fid, fld), ts in by_fid.items()
            if fl == 'cc:ExpandedCrossbowPack' and fld == 'FULL' for t in ts
            if t in ('Арбалет с выгнутой ложей',
                     'Арбалет с пружинным механизмом',
                     'Арбалет с выгнутой ложей и пружинным механизмом')]
    check(not bare, f'ECP: бессодержательных имён без материала = 0 ({bare})')
    check(any(t == 'Двемерский арбалет с выгнутой ложей'
              for (fl, fid, fld), ts in by_fid.items() if fl == 'main'
              and fld == 'FULL' for t in ts),
          'main: «Двемерский арбалет с выгнутой ложей» (DLC1) не тронут')

    # 118-б: склонение «орочий»
    check(sum('орочая' in t for t in texts_new) == 0
          and sum('орочие' in t for t in texts_new) == 0,
          '«орочая/орочие» = 0 по всем 12 338 полям')
    for fid, want in [('0608A251', 'Мастерские орочьи перчатки'),
                      ('0608A25B', 'Мастерские орочьи сапоги'),
                      ('0608A409', 'Мастерская орочья булава')]:
        got = by_fid.get(('main', fid, 'FULL'), [None])[0]
        check(got == want, f'118-б {fid}: {got!r}')

    # 118-в: Turn/Repel-глаголы
    check(sum('Прогнать' in t for t in texts_new) == 0,
          '«Прогнать» = 0 (было 5)')
    check(sum('Отпор' in t for t in texts_new) == 0,
          '«Отпор» = 0 (было 2)')
    check(sum('Отпор' in t for t in texts_old) == 2
          and sum('Прогнать' in t for t in texts_old) == 5,
          'старый дамп: «Прогнать» ×5 / «Отпор» ×2 (контроль базы)')
    for fid, want in [('0004B145', 'Отпугивание младшей нежити'),
                      ('0005DD5B', 'Отпугивание нежити'),
                      ('0005DD5C', 'Отпугивание старшей нежити'),
                      ('0008C1AA', 'Отпугивание старшей нежити'),
                      ('0004D3F7', 'Отталкивание младшей нежити'),
                      ('0005DD5F', 'Отталкивание нежити')]:
        got = by_fid.get(('main', fid, 'FULL'), [None])[0]
        check(got == want, f'118-в MGEF {fid}: {got!r}')
    check(by_fid.get(('main', '000B62E3', 'FULL'), [None])[0]
          == 'Отпугивание младшей нежити',
          '118-в ENCH 000B62E3: «Отпугивание младшей нежити»')

    # 118-г: Lucky-стрелы из офиц. баз
    for want, cnt in [('Счастливая солнечная эльфийская стрела', 2),
                      ('Счастливая эльфийская стрела кровавого проклятья', 2),
                      ('Счастливая нордская стрела героя', 2),
                      ('Счастливая нордская стрела героя (жетон)', 1)]:
        got = sum(t == want for t in texts_new)
        check(got == cnt, f'118-г: «{want}» ×{got} (ожидалось {cnt})')
    for bad in ['Счастливая освященная эльфийская стрела',
                'Счастливая проклятая кровью эльфийская стрела',
                'Счастливая стрела нордского героя']:
        check(sum(t == bad for t in texts_new) == 0, f'старой формы нет: {bad!r}')

    # 118-е: порядок слов
    check(sum('нордского героя' in t for t in texts_new) == 0,
          '«нордского героя» = 0 по дампу (было 13)')
    check(sum('Соловья' in t for t in texts_new) == 0,
          '«Соловья» = 0 по дампу (было 5)')
    for fid, want in [
        ('0608A199', 'Мастерский нордский лук героя'),
        ('0608A1E3', 'Мастерский нордский боевой топор героя'),
        ('0608A1E8', 'Мастерский нордский меч героя'),
        ('0608A1ED', 'Мастерский нордский двуручник героя'),
        ('0608A1F2', 'Мастерская нордская секира героя'),
        ('062D4161', 'Нордский длинный лук героя'),
        ('062D4166', 'Мастерский нордский длинный лук героя')]:
        got = by_fid.get(('main', fid, 'FULL'), [None])[0]
        check(got == want, f'118-е {fid}: {got!r}')
    check(sum(t == 'Соловьиный длинный лук' for t in texts_new) == 5,
          '«Соловьиный длинный лук» ×5 (NightingaleBow01–05_L)')
    for fid, want in [('0500088E', 'Мастерский нордский кинжал героя'),
                      ('05000893', 'Мастерская нордская булава героя'),
                      ('05000898', 'Мастерский нордский боевой молот героя')]:
        got = by_fid.get(('cc:Fishing', fid, 'FULL'), [None])[0]
        check(got == want, f'118-е cc:Fishing {fid}: {got!r}')
    check(by_fid.get(('sp', '0700081E', 'FULL'), [None])[0]
          == 'Нордское копье героя'
          and by_fid.get(('sp', '07000979', 'FULL'), [None])[0]
          == 'Мастерское нордское копье героя',
          'sp: копья Норда-героя уже были в верном порядке — не тронуты')

    print('=== 5) ShortbowNames.ini (слой DLL) ===')
    ini_new = open(INI_NEW, 'rb').read()
    ini_old = old_bytes[INI_REL]
    for r in ini_fixes:
        check(ini_new.count(r['new'].encode('utf-8')) == r['expect']
              and ini_new.count(r['old'].encode('utf-8')) == 0,
              f"INI: «{r['new'][10:-1]}» ×{r['expect']}, старой формы = 0")
    for keep, cnt in [('Короткий лук Карлии', 1), ('Короткий лук Анги', 1),
                      ('Короткий лук Фроки', 1), ('Короткий лук Дравина', 1),
                      ('Короткий лук Охотника', 1),
                      ('Короткий лук Ауриэля', 1)]:
        check(ini_new.count(keep.encode('utf-8')) == cnt
              and ini_old.count(keep.encode('utf-8')) == cnt,
              f'INI: «{keep}» не тронут')
    lines_new = len(ini_new.split(b'\n'))
    lines_old = len(ini_old.split(b'\n'))
    check(lines_new == lines_old == 305,
          f'INI: строк 305 (было {lines_old}, стало {lines_new})')
    check(ini_new.count(b'\r') == ini_old.count(b'\r') == 0,
          'INI: окончание строк LF (как в базе), CR-байтов = 0')
    check(not ini_new.startswith(b'\xef\xbb\xbf'),
          'INI: UTF-8 без BOM (как в базе)')
    delta = sum((len(r['new'].encode('utf-8'))
                 - len(r['old'].encode('utf-8'))) * r['expect']
                for r in ini_fixes)
    check(len(ini_new) - len(ini_old) == delta,
          f'INI: длина изменилась ровно на замены (+{delta} Б)')

    print('=== 6) гигиена и санкции ===')
    for frag in ['%%', 'ё', '—']:
        check(sum(t.count(frag) for t in texts_new)
              == sum(t.count(frag) for t in texts_old) == 0,
              f'паритет «{frag}» = 0 (как в v1.5.18)')
    lone_new = sum(t.count('\n') - t.count('\r\n') for t in texts_new)
    lone_old = sum(t.count('\n') - t.count('\r\n') for t in texts_old)
    check(lone_new == lone_old, f'lone \\n: {lone_new} == {lone_old} (регресса нет)')
    check(sum(t.count('«') for t in texts_new)
          == sum(t.count('»') for t in texts_new),
          'ёлочки сбалансированы')
    perk_desc = [r['text'] for r in fields
                 if r['rtype'] == 'PERK' and r['field'] == 'DESC']
    check(len(perk_desc) == 566 and max(map(len, perk_desc)) <= 290,
          f'PERK DESC: {len(perk_desc)} шт, max {max(map(len, perk_desc))} <= 290')
    check(sum('Орочья чешуйчатая' in t or 'Орочьи чешуйчатые' in t
              for t in texts_new) == 0, '«Ороч* чешуйчат*» = 0 (санкция 113)')
    check(sum('под талмора' in t for t in texts_new) == 0,
          '«под талмора» = 0 (санкция 115)')
    low_mask = sum('Маскировка - бандита' in t or 'Маскировка - имперца' in t
                   or 'Маскировка - культиста' in t for t in texts_new)
    check(low_mask == 0, 'lowercase «Маскировка - …» = 0 (вердикт 116-а держится)')
    check(sum('ламеллярн' in t for t in texts_new)
          == sum('ламеллярн' in t for t in texts_old),
          'ламелляр-серия (113/115) не тронута')

    print('=== 7) FOMOD и zip ===')
    mc = new_files['fomod/ModuleConfig.xml']
    check(mc == old_bytes['fomod/ModuleConfig.xml'],
          'ModuleConfig.xml байт-в-байт (изменений установщика нет)')
    for arc in ('fomod/ModuleConfig.xml', 'fomod/info.xml'):
        try:
            xml.dom.minidom.parseString(new_files[arc])
            ok = True
        except Exception:
            ok = False
        check(ok, f'{arc}: валидный XML')
    with zipfile.ZipFile('/home/z/my-project/download/Paths of Empyrean RU 1.5.zip') as z:
        check(z.testzip() is None and len(z.namelist()) == 63,
              'download zip: testzip OK, 63 записи')
        check('<Version>1.5.19</Version>' in z.read('fomod/info.xml').decode(),
              'download zip: info.xml = 1.5.19')
        for rel in list(FILES.values()) + [INI_REL]:
            check(hashlib.md5(z.read(rel)).hexdigest()
                  == hashlib.md5(open(f'{NEW}/{rel}', 'rb').read()).hexdigest(),
                  f'download zip: {os.path.basename(rel)} == v119')

    print('=== 8) итоговые md5 ===')
    for scope, rel in FILES.items():
        print(f'  {os.path.basename(rel)}: '
              f'{hashlib.md5(new_files[rel]).hexdigest()} '
              f'({len(new_files[rel])} Б)')
    print(f'  ShortbowNames.ini: '
          f'{hashlib.md5(new_files[INI_REL]).hexdigest()} '
          f'({len(new_files[INI_REL])} Б)')
    zmd5 = hashlib.md5(open('/home/z/my-project/download/Paths of Empyrean '
                            'RU 1.5.zip', 'rb').read()).hexdigest()
    print(f'  пакет v1.5.19: {zmd5}')

    print()
    if FAILED:
        print(f'ПРОВАЛОВ: {len(FAILED)}')
        for m in FAILED:
            print(f'  - {m}')
        sys.exit(1)
    print('ВСЕ ПРОВЕРКИ ПРОЙДЕНЫ')


if __name__ == '__main__':
    main()
