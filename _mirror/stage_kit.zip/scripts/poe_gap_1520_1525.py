#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 123: гэп-анализ v1.5.20 (пак истины пака v5.20) -> v1.5.24 ("(1)")
-> v1.5.25 ("(2)", текущий выпуск).

Восстановление межпаковой эры (отчёты 1.5.21–1.5.24 утеряны рециклом
песочницы, метод [D9]: совокупная истина правок — сам ESP выпущенной
версии). Дампы v1.5.20/v1.5.24 переняты из артефактов рабочей среды
прошлой сессии (work/qa123/dump_v1520.jsonl, dump_v1524.jsonl — формат
неизменен, строились тем же разборщиком scripts/parse_tes4.py).

Выход (work/qa123/):
  dump_v1525.jsonl            — дамп текстовых полей v1.5.25
  changed_20_25.jsonl/.txt    — кумулятивный дифф v1.5.20 -> v1.5.25
  changed_24_25.jsonl/.txt    — личные правки игрока в v1.5.25
  files_report.txt            — file-level CRC диффы по трём парам zip
  ini_report.txt              — диффы INI/TXT/XML v1.5.24 -> v1.5.25
"""
import sys, os, json, zipfile, difflib
sys.path.insert(0, '/home/z/my-project/scripts')

ROOT = '/home/z/my-project'
QA = f'{ROOT}/work/qa123'
P20 = f'{ROOT}/work/old_pack/Paths of Empyrean RU 1.5.zip'      # v1.5.20
P24 = f'{ROOT}/upload/Paths of Empyrean RU 1.5 (1).zip'         # v1.5.24
P25 = f'{ROOT}/upload/Paths of Empyrean RU 1.5 (2).zip'         # v1.5.25

TEXT_FIELDS = {'FULL', 'DESC', 'ITXT', 'NNAM'}


def decode(b):
    return b.rstrip(b'\x00').decode('utf-8', 'replace')


def dump_esp(path, tag, out):
    from parse_tes4 import Plugin
    p = Plugin(path)
    for formid, r in p.records.items():
        rtype = r['type']
        edid = r.get('edid') or ''
        occ = {}
        for st, sd in r['subs']:
            text = None
            if st in TEXT_FIELDS:
                if st == 'NNAM' and rtype == 'PERK':
                    continue
                text = decode(sd)
            elif st == 'DNAM' and rtype == 'MGEF':
                try:
                    cand = sd.rstrip(b'\x00').decode('utf-8')
                except UnicodeDecodeError:
                    cand = None
                if cand:
                    ctrl = sum(1 for c in cand if ord(c) < 32 and c != '\n')
                    letters = sum(1 for c in cand if c.isalpha())
                    spaces = cand.count(' ')
                    if ctrl == 0 and letters >= 4 and (spaces >= 1 or len(cand) <= 64):
                        text = cand
            elif st == 'DATA' and rtype == 'GMST':
                if edid.startswith('s'):
                    text = decode(sd)
            if text is None:
                continue
            key = (rtype, formid, st)
            occ[key] = occ.get(key, 0) + 1
            rec = {'file': tag, 'rtype': rtype, 'formid': f'{formid:08X}',
                   'edid': edid, 'field': st, 'occ': occ[key], 'text': text}
            out.write(json.dumps(rec, ensure_ascii=False) + '\n')


def dump_zip(zippath, outpath):
    z = zipfile.ZipFile(zippath)
    esp_list = []
    with open(outpath, 'w', encoding='utf-8') as out:
        for info in z.infolist():
            n = info.filename
            if n.lower().endswith('.esp'):
                esp_list.append(n)
                tag = os.path.basename(os.path.dirname(n)) + '/' + os.path.basename(n)
                tmp = '/tmp/_esp_extract.esp'
                with open(tmp, 'wb') as f:
                    f.write(z.read(n))
                dump_esp(tmp, tag, out)
    return esp_list


def load(fp):
    d = {}
    for line in open(fp, encoding='utf-8'):
        r = json.loads(line)
        k = (r['file'], r['rtype'], r['formid'], r['field'], r['occ'])
        d[k] = r['text']
    return d


def dump_diff(d_old, d_new, fp_jsonl, fp_txt, label):
    keys_old, keys_new = set(d_old), set(d_new)
    added = keys_new - keys_old
    removed = keys_old - keys_new
    changed = [k for k in keys_old & keys_new if d_old[k] != d_new[k]]
    rows = []
    for k in sorted(changed):
        rows.append({'key': list(k), 'old': d_old[k], 'new': d_new[k]})
    for k in sorted(added):
        rows.append({'key': list(k), 'old': None, 'new': d_new[k], 'ADDED': True})
    for k in sorted(removed):
        rows.append({'key': list(k), 'old': d_old[k], 'new': None, 'REMOVED': True})
    with open(fp_jsonl, 'w', encoding='utf-8') as fo:
        for r in rows:
            fo.write(json.dumps(r, ensure_ascii=False) + '\n')
    with open(fp_txt, 'w', encoding='utf-8') as fo:
        for k in sorted(changed):
            fo.write(f"{k[0]} | {k[1]:6s} {k[2]:8s} {k[3]:4s}#{k[4]} | "
                     f"{d_old[k]}  =>  {d_new[k]}\n")
        for k in sorted(added):
            fo.write(f"{k[0]} | {k[1]:6s} {k[2]:8s} {k[3]:4s}#{k[4]} | "
                     f"[NEW] {d_new[k]}\n")
        for k in sorted(removed):
            fo.write(f"{k[0]} | {k[1]:6s} {k[2]:8s} {k[3]:4s}#{k[4]} | "
                     f"[GONE] {d_old[k]}\n")
    byfile = {}
    for k in changed:
        byfile[k[0]] = byfile.get(k[0], 0) + 1
    print(f'{label}: изменено {len(changed)}, добавлено {len(added)}, '
          f'удалено {len(removed)}')
    for f, c in sorted(byfile.items()):
        print(f'   {f}: {c}')
    return changed, added, removed


def crc_names(z):
    return {i.filename: (i.CRC, i.file_size) for i in z.infolist()}


def main():
    os.makedirs(QA, exist_ok=True)
    # дамп v1.5.25 (20/24 — готовые из прошлой сессии)
    p25 = f'{QA}/dump_v1525.jsonl'
    if not os.path.exists(p25):
        esp25 = dump_zip(P25, p25)
        print('ESP v1.5.25:', len(esp25))
    d20 = load(f'{QA}/dump_v1520.jsonl')
    d24 = load(f'{QA}/dump_v1524.jsonl')
    d25 = load(p25)
    print('полей 20:', len(d20), '24:', len(d24), '25:', len(d25))

    print('--- кумулятив v1.5.20 -> v1.5.25 ---')
    dump_diff(d20, d25, f'{QA}/changed_20_25.jsonl', f'{QA}/changed_20_25.txt',
              '20->25')
    print('--- правки v1.5.24 -> v1.5.25 (слой игрока) ---')
    dump_diff(d24, d25, f'{QA}/changed_24_25.jsonl', f'{QA}/changed_24_25.txt',
              '24->25')

    # file-level CRC диффы по трём парам
    z20, z24, z25 = zipfile.ZipFile(P20), zipfile.ZipFile(P24), zipfile.ZipFile(P25)
    n20, n24, n25 = crc_names(z20), crc_names(z24), crc_names(z25)
    with open(f'{QA}/files_report.txt', 'w', encoding='utf-8') as fo:
        for a, b, la, lb, za, zb in ((z20, z24, '1.5.20', '1.5.24', n20, n24),
                                     (z24, z25, '1.5.24', '1.5.25', n24, n25),
                                     (z20, z25, '1.5.20', '1.5.25', n20, n25)):
            only_a = sorted(set(na) - set(nb) for na, nb in
                            ((a.namelist(), b.namelist()),))[0]
            only_b = sorted(set(b.namelist()) - set(a.namelist()))
            diff = sorted(f for f in set(a.namelist()) & set(b.namelist())
                          if na[f] != nb[f]) if False else \
                sorted(f for f in set(a.namelist()) & set(b.namelist())
                       if a.read(f) != b.read(f))
            fo.write(f'=== {la} -> {lb}: изменено файлов {len(diff)}, '
                     f'только в {la}: {only_a}, только в {lb}: {only_b} ===\n')
            for f in diff:
                fo.write(f'  {f}\n')
            fo.write('\n')
        # пофайловая сверка (1) и (2) против корневой истины
        print('file-level отчет: work/qa123/files_report.txt')

    # INI/TXT/XML диффы 24 -> 25 (слой игрока вне ESP)
    with open(f'{QA}/ini_report.txt', 'w', encoding='utf-8') as fo:
        for n in sorted(set(z24.namelist()) & set(z25.namelist())):
            if not n.lower().endswith(('.ini', '.txt', '.xml')):
                continue
            b24, b25 = z24.read(n), z25.read(n)
            if b24 == b25:
                continue
            enc = 'utf-16' if b24[:2] in (b'\xff\xfe', b'\xfe\xff') else 'utf-8'
            l24 = b24.decode(enc, 'replace').splitlines()
            l25 = b25.decode(enc, 'replace').splitlines()
            dl = list(difflib.unified_diff(l24, l25, lineterm='', n=1))
            fo.write(f'=== {n} ({len(dl)} строк) ===\n')
            for l in dl:
                fo.write(l + '\n')
            fo.write('\n')
    # новые/исчезнувшие файлы 24->25
    with open(f'{QA}/files_report.txt', 'a', encoding='utf-8') as fo:
        fo.write('=== 1.5.24 -> 1.5.25 (файлы) ===\n')
        fo.write('только в 24: ' + str(sorted(set(z24.namelist()) -
                                             set(z25.namelist()))) + '\n')
        fo.write('только в 25: ' + str(sorted(set(z25.namelist()) -
                                              set(z24.namelist()))) + '\n')
    print('INI/XML отчет: work/qa123/ini_report.txt')


if __name__ == '__main__':
    main()
