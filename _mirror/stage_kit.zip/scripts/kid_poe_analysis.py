#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 98: анализ зависимости KID-раздачи PoE от ИМЁН предметов (EN).

Вопрос: перевод FULL ломает ли name-wildcard правила PathsOfEmpyrean_KID.ini?

Метод:
1. Собираем реальные `*`-токены из KID-ини PoE (снимок 1.4). Токен с пробелом
   (` spear`) матчит ТОЛЬКО имя (EDID пробелов не содержит); CamelCase без
   пробела (`*ArmorOrcishHelmet`) = EDID-фильтр; строчный без пробела
   (`*ulfric`) — имя или EDID.
2. По EN-дампу базы 1.4 (v14_en.json) для self-записей (06xxxxxx) WEAP/ARMO
   считаем: имя содержит токен, а EDID — нет → классификация держится на имени.

Вывод этапа: PoE-self записи несут классификационные ключевики ЗАПЕЧЁННЫМИ
в KWDA (проверка scripts/kid_kwda_check.py), поэтому перевод таксономию не
роняет; name-правила дают только disguise/faction-ключи 25 клон-записям.
"""
import json
import re
from collections import Counter

KID_INI = ("/home/z/my-project/handoff/08_оригинал_1.4_EN/"
           "полный_разбор_1.4/PoE 1.4/PathsOfEmpyrean_KID.ini")
EN_DUMP = "/home/z/my-project/handoff/05_стринги_ESP/v14_en.json"

# 1) реальные wildcard-токены: всё, что идёт за '*' до разделителя | ,
# (после '*' может стоять пробел: «* spear», «*bandit »)
tok_re = re.compile(r"\*\s*([A-Za-z0-9_']+(?:\s[A-Za-z0-9_']+)*)")
spaced, unspaced = set(), set()
for line in open(KID_INI, encoding="utf-8", errors="ignore"):
    if not line.startswith("Keyword"):
        continue
    for m in tok_re.finditer(line):
        tok = m.group(1).strip().lower()
        if " " in tok:
            spaced.add(tok)
        else:
            unspaced.add(tok)

print(f"токенов с пробелом (матчат ТОЛЬКО имена): {len(spaced)}")
print(f"токенов без пробела (EDID и/или имя):     {len(unspaced)}")

# 2) EN-дамп: self-записи WEAP/ARMO
d = json.load(open(EN_DUMP, encoding="utf-8"))
recs = d["records"]
self_recs = []
for r in recs:
    if (r.get("t") in ("WEAP", "ARMO") and r.get("fid", "").startswith("06")
            and "FULL" in r.get("s", {}) and r.get("e")):
        full = r["s"]["FULL"][0] if isinstance(r["s"]["FULL"], list) else r["s"]["FULL"]
        self_recs.append((r["t"], r["fid"], r["e"], full))
print(f"self WEAP/ARMO с FULL и EDID: {len(self_recs)}")

# 3) риски: имя матчится, EDID нет
risky = []
for t, fid, edid, full in self_recs:
    fl, el = full.lower(), edid.lower()
    hits = [tok for tok in spaced if tok in fl]
    hits += [tok for tok in unspaced if tok in fl and tok not in el]
    if hits:
        risky.append((t, fid, edid, full, sorted(set(hits))))

print(f"\nзаписей, чья классификация держится ТОЛЬКО на имени: {len(risky)}")
for t, fid, edid, full, toks in risky:
    print(f"  {t} {fid} [{edid}] «{full}»  ← {', '.join(toks[:3])}")

cnt = Counter()
for _, _, _, _, toks in risky:
    for tok in toks:
        cnt[tok] += 1
print("\n=== топ токенов по числу записей ===")
for tok, n in cnt.most_common(15):
    print(f"  {n:4d}  {tok!r}")
