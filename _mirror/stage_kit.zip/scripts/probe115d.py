#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап-разведка 115d: расширенный brute-force грамматики VMAD TES5.
Проверяем гипотезы значения object/array на всех 14 маскировочных MGEF."""
import struct, zlib

ESP = '/home/z/my-project/work/qa114/release115/00 Core/PathsOfEmpyrean.esp'
REC_HDR = 24
MGEF_PREFIX = 'ISP_MGEF_SPEECH_Disguise'


class Node:
    __slots__ = ('kind', 'label', 'tail', 'formid', 'data', 'children')


def parse(buf):
    root = []

    def walk(off, end, out):
        while off < end:
            t = buf[off:off+4]
            size = struct.unpack_from('<I', buf, off+4)[0]
            if t == b'GRUP':
                node = Node(); node.kind = 'grup'; node.children = []
                walk(off + REC_HDR, off + size, node.children)
                out.append(node); off += size
            else:
                node = Node(); node.kind = 'rec'
                node.label = t
                node.tail = bytes(buf[off+8:off+24])
                node.formid = struct.unpack_from('<I', buf, off+12)[0]
                node.data = bytes(buf[off+REC_HDR:off+REC_HDR+size])
                out.append(node); off += REC_HDR + size
    walk(0, len(buf), root)
    return root


def walk_recs(nodes):
    for n in nodes:
        if n.kind == 'grup':
            yield from walk_recs(n.children)
        else:
            yield n


def subrecords(rec):
    body = rec.data
    if struct.unpack_from('<I', rec.tail, 0)[0] & 0x00040000:
        usz = struct.unpack_from('<I', body, 0)[0]
        body = zlib.decompress(body[4:])
        assert len(body) == usz
    out = []
    off = 0
    while off < len(body):
        st = body[off:off+4].decode('ascii', 'replace')
        ssz = struct.unpack_from('<H', body, off+4)[0]
        val = bytes(body[off+6:off+6+ssz])
        out.append((st, val))
        if st == 'XXXX':
            real = struct.unpack_from('<I', body, off+6)[0]
            off += 6 + ssz + 6 + real
            continue
        off += 6 + ssz
    return out


def edid_of(rec):
    for st, v in subrecords(rec):
        if st == 'EDID':
            return v.rstrip(b'\x00').decode('utf-8', 'replace')
    return ''


def wstr(b, off):
    n = struct.unpack_from('<H', b, off)[0]
    return b[off+2:off+2+n].decode('utf-8', 'replace'), off + 2 + n


# гипотезы: значение object-свойства (после type/flags)
OBJ_VARIANTS = [
    ('formid', 4),
    ('u8+formid', 5),
    ('u32+formid', 8),
    ('u16+u16+formid', 8),
    ('u8+u16+u16+formid', 9),
]
# гипотезы: элемент object-array
ARR_VARIANTS = [
    ('formid', 4),
    ('u8+formid', 5),
    ('u32+formid', 8),
    ('u16+u16+formid', 8),
    ('u8+u16+u16+formid', 9),
    ('u8+u32+formid', 9),
    ('u8+u8+u16+formid', 9),
]
# гипотезы: счётчик массива
CNT_VARIANTS = [('u32', 4), ('u16', 2)]


def try_parse(v, obj_v, arr_v, cnt_v):
    try:
        off = 0
        ver, objfmt, nscripts = struct.unpack_from('<HHH', v, off); off += 6
        lines = [f'ver={ver} objFmt={objfmt} scripts={nscripts}']
        hits = []
        for si in range(nscripts):
            name, off = wstr(v, off)
            unk = v[off]; off += 1          # u8-разделитель после имени скрипта
            nprops = struct.unpack_from('<H', v, off)[0]; off += 2
            lines.append(f'script[{si}] {name!r} unk={unk} props={nprops}')
            for pi in range(nprops):
                pname, off = wstr(v, off)
                ptype = v[off]; pflags = v[off+1]; off += 2
                tag = f'  {pname!r} t={ptype} f={pflags}'
                if ptype == 5:
                    b = v[off]; off += 1
                    lines.append(tag + f' bool={b}')
                elif ptype == 2:
                    x = struct.unpack_from('<I', v, off)[0]; off += 4
                    lines.append(tag + f' int={x}')
                elif ptype == 3:
                    f = struct.unpack_from('<f', v, off)[0]; off += 4
                    lines.append(tag + f' float={f:g}')
                elif ptype == 1:
                    desc, sz = obj_v
                    raw = v[off:off+sz]
                    fid = struct.unpack_from('<I', v, off+sz-4)[0]
                    off += sz
                    lines.append(tag + f' obj[{desc}] raw={raw.hex()} form={fid:08X}')
                    hits.append((name, pname, fid))
                elif ptype == 11:
                    dsz, asz = cnt_v, arr_v[1]
                    if cnt_v[0] == 'u32':
                        cnt = struct.unpack_from('<I', v, off)[0]; off += 4
                    else:
                        cnt = struct.unpack_from('<H', v, off)[0]; off += 2
                    parts = []
                    for k in range(cnt):
                        raw = v[off:off+asz]
                        fid = struct.unpack_from('<I', v, off+asz-4)[0]
                        off += asz
                        parts.append(f'{raw.hex()}->{fid:08X}')
                    lines.append(tag + f' arr[{cnt}][{arr_v[0]}]=' + ' '.join(parts))
                    hits.append((name, pname, parts))
                else:
                    return False, lines, hits
        if off != len(v):
            return False, lines, hits
        return True, lines, hits
    except (IndexError, struct.error):
        return False, [], []


def main():
    buf = open(ESP, 'rb').read()
    root = parse(buf)
    recs = list(walk_recs(root))
    vmads = {}
    for rec in recs:
        if rec.label != b'MGEF':
            continue
        edid = edid_of(rec)
        if not edid.startswith(MGEF_PREFIX):
            continue
        for st, v in subrecords(rec):
            if st == 'VMAD':
                vmads[edid] = (rec.formid, v)
    print(f'MGEF с VMAD: {len(vmads)}')

    found = None
    for oi, ov in enumerate(OBJ_VARIANTS):
        for ai, av in enumerate(ARR_VARIANTS):
            for ci, cv in enumerate(CNT_VARIANTS):
                oks = [try_parse(vv, ov, av, cv)[0] for _, vv in vmads.values()]
                if all(oks):
                    found = (ov, av, cv)
                    print(f'✓ согласовано: obj={ov} arr={av} cnt={cv}')
                    break
                else:
                    okn = sum(oks)
                    if okn > 0:
                        print(f'  obj={ov[0]} arr={av[0]} cnt={cv[0]}: {okn}/{len(vmads)}')
            if found:
                break
        if found:
            break
    if not found:
        print('!! согласованной гипотезы нет')
        return
    ov, av, cv = found
    for edid in sorted(vmads):
        fid, vv = vmads[edid]
        ok, lines, hits = try_parse(vv, ov, av, cv)
        print(f'--- {fid:08X} {edid} ---')
        print('\n'.join(lines))


if __name__ == '__main__':
    main()
