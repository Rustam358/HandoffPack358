#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 96, разведка B: декодеры PERK-секций, CTDA, VMAD, AVIF-звёзд, SPIT/EFIT/MGEF/PROJ.

Спецификации: UESP Mod File Format (PERK/MGEF/SPEL) + техбаза [T13]/[T30].
Цель — валидация декодеров по семантическим якорям перед генерацией md.
Аналитический скрипт: НИЧЕГО не правит.
"""
import sys, struct, json
from collections import defaultdict, Counter

sys.path.insert(0, '/home/z/my-project/upload/poe_pack/scripts')
from parse_tes4 import Plugin

BASE = '/home/z/my-project/work/v156'
p = Plugin(f'{BASE}/00 Core/PathsOfEmpyrean.esp')
NM = len(p.masters)

def u32(sd, off=0):
    return struct.unpack_from('<I', sd, off)[0]

def i32(sd, off=0):
    return struct.unpack_from('<i', sd, off)[0]

def f32(sd, off=0):
    return struct.unpack_from('<f', sd, off)[0]

def zstr(sd, off=0):
    e = sd.find(b'\x00', off)
    return sd[off:e if e >= 0 else len(sd)].decode('utf-8', 'replace')

# ================================================================ CTDA
def parse_ctda(sd):
    assert len(sd) == 32, len(sd)
    return {
        'b0': sd[0], 'b1': sd[1], 'b23': struct.unpack_from('<H', sd, 2)[0],
        'value': f32(sd, 4), 'func': u32(sd, 8), 'p1': u32(sd, 12),
        'p2': u32(sd, 16), 'w20': u32(sd, 20), 'w24': u32(sd, 24), 'ref': u32(sd, 28),
    }

# гистограмма byte0 по всем CTDA PERK
b0h = Counter()
for f in p.by_type['PERK']:
    for st, sd in p.records[f]['subs']:
        if st == 'CTDA':
            b0h[sd[0]] += 1
print('PERK CTDA byte0 гистограмма:', dict(sorted(b0h.items())))
b0h2 = Counter()
for f in p.by_type['MGEF']:
    for st, sd in p.records[f]['subs']:
        if st == 'CTDA':
            b0h2[sd[0]] += 1
print('MGEF CTDA byte0 гистограмма:', dict(sorted(b0h2.items())))
# гистограммы w20/w24/ref по MGEF
h20 = Counter(); h24 = Counter(); href = Counter()
for f in p.by_type['MGEF']:
    for st, sd in p.records[f]['subs']:
        if st == 'CTDA':
            c = parse_ctda(sd)
            h20[c['w20']] += 1; h24[c['w24']] += 1; href[c['ref']] += 1
print('MGEF CTDA w20:', dict(sorted(h20.items())[:8]), '| w24:', dict(sorted(h24.items())[:8]),
      '| ref top:', href.most_common(5))

# топ функций
funch = Counter()
func_p1_types = defaultdict(Counter)
for t in ('PERK', 'MGEF', 'SPEL'):
    for f in p.by_type.get(t, []):
        for st, sd in p.records[f]['subs']:
            if st == 'CTDA':
                c = parse_ctda(sd)
                funch[c['func']] += 1
                if c['p1'] in p.records:
                    func_p1_types[c['func']][p.records[c['p1']]['type']] += 1
print('\nтоп-25 функций CTDA (func, count, типы param1):')
for fn, n in funch.most_common(25):
    print(f'  {fn}: {n}  p1: {dict(func_p1_types[fn].most_common(4))}')

# примеры функций 448 и 560
print('\nпримеры CTDA func=448 и 560 и 530:')
shown = 0
for f in p.by_type['PERK']:
    for st, sd in p.records[f]['subs']:
        if st == 'CTDA':
            c = parse_ctda(sd)
            if c['func'] in (448, 560, 530) and shown < 12:
                p1 = p.label(c['p1']) if c['p1'] else '-'
                print(f"  [{p.records[f]['edid']}] b0={c['b0']} val={c['value']} fn={c['func']} "
                      f"p1={p1} p2={c['p2']:#x} w20={c['w20']} w24={c['w24']} ref={c['ref']:#x}")
                shown += 1

# перковые гейты навыков: Trainee/Student/Virtuoso — ищем перки с FULL содержащим 'Новобранец: Одноручное'
print('\nполный дамп PERK-условий гейта (Trainee/Student по Одноручному):')
for f in p.by_type['PERK']:
    r = p.records[f]
    if r['full'] and ('Новобранец: Одноручное' in r['full'] or 'Студент: Одноручное' in r['full']):
        print('==', r['full'], r['edid'])
        for st, sd in r['subs']:
            if st == 'CTDA':
                c = parse_ctda(sd)
                p1 = p.label(c['p1']) if c['p1'] else '-'
                print(f"   b0={c['b0']} b1={c['b1']} val={c['value']} fn={c['func']} p1={p1} "
                      f"p2={c['p2']:#x} w20={c['w20']} w24={c['w24']} ref={c['ref']:#x}")

# ================================================================ PERK секции: полный разбор одного перка
def dump_perk(edid_prefix):
    for f in p.by_type['PERK']:
        r = p.records[f]
        if (r['edid'] or '').startswith(edid_prefix):
            print('\n==== PERK', r['edid'], '|', r['full'], f'({f:#010x})')
            cur_sec = None
            for st, sd in r['subs']:
                if st == 'DATA' and len(sd) == 5:
                    print(f'  DATA(perk): trait={sd[0]} level={sd[1]} ranks={sd[2]} playable={sd[3]} hidden={sd[4]}')
                elif st == 'NNAM':
                    print(f'  NNAM(next): {p.label(u32(sd))}')
                elif st == 'PRKE':
                    print(f'  --- PRKE type={sd[0]} rank={sd[1]} prio={sd[2]}')
                elif st == 'DATA' and len(sd) == 8:
                    print(f'      DATA(quest): {p.label(u32(sd))} stage={sd[4]}')
                elif st == 'DATA' and len(sd) == 4:
                    print(f'      DATA(ability): {p.label(u32(sd))}')
                elif st == 'DATA' and len(sd) == 3:
                    print(f'      DATA(ep): EffectType={sd[0]:#04x} Function={sd[1]:#04x} CondCount={sd[2]}')
                elif st == 'PRKC':
                    print(f'      PRKC(group): {sd[0]}')
                elif st == 'EPFT':
                    print(f'      EPFT(datatype): {sd[0]:#04x}')
                elif st == 'EPFD':
                    if len(sd) == 4:
                        fv = f32(sd)
                        iv = u32(sd)
                        print(f'      EPFD: float={fv:.6g} / uint={iv} ({p.label(iv) if iv in p.records else hex(iv)})')
                    elif len(sd) == 8:
                        print(f'      EPFD[8]: AV={f32(sd)} FACTOR={f32(sd,4)}')
                    else:
                        print(f'      EPFD[{len(sd)}]: {zstr(sd)!r}')
                elif st == 'EPF2':
                    print(f'      EPF2[{len(sd)}]: {zstr(sd)!r} / hex={sd.hex()[:40]}')
                elif st == 'EPF3':
                    print(f'      EPF3: {u32(sd):#010x} ({p.label(u32(sd))})')
                elif st == 'CTDA':
                    c = parse_ctda(sd)
                    p1 = p.label(c['p1']) if c['p1'] else '-'
                    print(f'      CTDA b0={c["b0"]} val={c["value"]:.6g} fn={c["func"]} p1={p1} p2={c["p2"]:#x}')
                elif st == 'VMAD':
                    print(f'      VMAD[{len(sd)}] (скрипты см. ниже)')
                elif st in ('CIS1', 'CIS2'):
                    print(f'      {st}: {zstr(sd)!r}')
            return

dump_perk('PoE_PERK_1H_Trainee1')
dump_perk('BoneBreaker30')     # Костолом
dump_perk('PoE_PERK_1H_CrossCut')  # Крестообразный удар
dump_perk('PoE_PERK_1H_ExploitOpening')
# перк с VMAD
for f in p.by_type['PERK']:
    if any(st == 'VMAD' for st, _ in p.records[f]['subs']):
        dump_perk(p.records[f]['edid'])
        break
# перк с EPF3
for f in p.by_type['PERK']:
    if any(st == 'EPF3' for st, _ in p.records[f]['subs']):
        dump_perk(p.records[f]['edid'])
        break
# перк с Quest-секцией (PRKE type 0)
for f in p.by_type['PERK']:
    for st, sd in p.records[f]['subs']:
        if st == 'PRKE' and sd[0] == 0:
            dump_perk(p.records[f]['edid'])
            break
    else:
        continue
    break

# ================================================================ VMAD парсер + валидация
def parse_vmad(sd):
    out = {'scripts': []}
    off = 0
    ver, objfmt = struct.unpack_from('<HH', sd, off); off += 4
    out['ver'], out['objfmt'] = ver, objfmt
    scount, = struct.unpack_from('<H', sd, off); off += 2
    for _ in range(scount):
        nlen, = struct.unpack_from('<H', sd, off); off += 2
        name = sd[off:off + nlen].decode('ascii', 'replace'); off += nlen
        status = sd[off]; off += 1
        pcount, = struct.unpack_from('<H', sd, off); off += 2
        props = []
        for _ in range(pcount):
            plen, = struct.unpack_from('<H', sd, off); off += 2
            pn = sd[off:off + plen].decode('ascii', 'replace'); off += plen
            ptype = sd[off]; off += 1
            pstat = sd[off]; off += 1
            val = None
            if ptype == 1:  # object: 8Б = 0000FFFF + formid?
                pre = u32(sd, off)
                val = ('obj', hex(pre), p.label(u32(sd, off + 4)))
                off += 8
            elif ptype == 2:  # string zstr
                val = ('str', zstr(sd, off))
                off += len(val[1]) + 1
            elif ptype == 3:  # int
                val = ('int', i32(sd, off)); off += 4
            elif ptype == 4:  # float
                val = ('float', f32(sd, off)); off += 4
            elif ptype == 5:  # bool
                val = ('bool', sd[off]); off += 1
            elif ptype == 11:  # object array
                cnt = u32(sd, off); off += 4
                arr = []
                for _ in range(cnt):
                    arr.append(p.label(u32(sd, off + 4)))
                    off += 8
                val = ('objarr', arr)
            elif ptype == 12:  # string array?
                cnt = u32(sd, off); off += 4
                arr = []
                for _ in range(cnt):
                    s = zstr(sd, off); off += len(s) + 1
                    arr.append(s)
                val = ('strarr', arr)
            elif ptype == 13:  # int array?
                cnt = u32(sd, off); off += 4
                arr = list(struct.unpack_from(f'<{cnt}i', sd, off)); off += 4 * cnt
                val = ('intarr', arr)
            elif ptype == 14:  # float array?
                cnt = u32(sd, off); off += 4
                arr = list(struct.unpack_from(f'<{cnt}f', sd, off)); off += 4 * cnt
                val = ('floatarr', arr)
            elif ptype == 15:  # bool array?
                cnt = u32(sd, off); off += 4
                arr = list(sd[off:off + cnt]); off += cnt
                val = ('boolarr', arr)
            else:
                raise ValueError(f'ptype {ptype}')
            props.append((pn, ptype, val))
        out['scripts'].append({'name': name, 'status': status, 'props': props})
    if off != len(sd):
        raise ValueError(f'не дошли до конца: off={off} len={len(sd)} (осталось {len(sd)-off}Б: {sd[off:off+16].hex()})')
    return out

ok = fail = 0
fails = Counter()
for t in ('PERK', 'SPEL', 'MGEF', 'QUST', 'ACTI', 'NPC_'):
    for f in p.by_type.get(t, []):
        for st, sd in p.records[f]['subs']:
            if st == 'VMAD':
                try:
                    parse_vmad(sd)
                    ok += 1
                except Exception as e:
                    fail += 1
                    fails[str(e)[:60]] += 1
print(f'\nVMAD: ok={ok} fail={fail}')
for k, v in fails.most_common(10):
    print('  FAIL:', k, 'x', v)

# ================================================================ AVIF звёзды: raw
print('\n=== AVIF звёздная структура (AVOneHanded), raw:')
for f in p.by_type['AVIF']:
    r = p.records[f]
    if r['edid'] == 'AVOneHanded':
        seen = False
        for st, sd in r['subs']:
            if st == 'DESC':
                seen = True
                continue
            if not seen:
                continue
            if len(sd) == 4:
                print(f'  {st}: int={u32(sd)} float={f32(sd):.6g} hex={sd.hex()}')
            else:
                print(f'  {st}[{len(sd)}]: {sd.hex()[:48]}')
        break

# ================================================================ PROJ DATA распределение полей
print('\n=== PROJ DATA f32/u32 по смещениям (79 записей):')
offsets = defaultdict(Counter)
for f in p.by_type['PROJ']:
    for st, sd in p.records[f]['subs']:
        if st == 'DATA':
            for off in range(0, len(sd), 4):
                offsets[off][u32(sd, off)] += 1
for off in sorted(offsets):
    top = offsets[off].most_common(4)
    print(f'  @{off:#04x}: {top}')

# ================================================================ ванильные ссылки MGEF из SPEL
van = Counter()
for f in p.by_type['SPEL']:
    for st, sd in p.records[f]['subs']:
        if st == 'EFID':
            v = u32(sd)
            if v not in p.records:
                van[v] += 1
print(f'\nMGEF-ссылки вне ESP (ваниль/LG): {len(van)} уникальных, {sum(van.values())} использований')
for v, n in van.most_common(15):
    print(f'  {v:#010x} x{n}')

# сколько всего перков в деревьях (PNAM) vs 563
star_perks = set()
tree_map = {}
for f in p.by_type['AVIF']:
    r = p.records[f]
    perks = []
    for st, sd in r['subs']:
        if st == 'PNAM':
            v = u32(sd)
            if v:
                perks.append(v)
                star_perks.add(v)
    tree_map[r['edid']] = perks
print(f'\nPNAM-перков (уникальных): {len(star_perks)} из {len(p.by_type["PERK"])} PERK')
print('деревья:', {k: len(v) for k, v in tree_map.items()})
