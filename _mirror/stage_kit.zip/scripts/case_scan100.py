# -*- coding: utf-8 -*-
"""Этап 100 (аналитический): инвентаризация регистра по веткам навыков.

Вердикты игрока (66-а/б + мастерство алхимии) уже приняты; проверяется,
что корпус им соответствует: имена навыков/школ в именном употреблении —
с прописной, родовые/адъективные — со строчной. Отдельный фокус — ветка
Изменения. Только анализ, без правок.
"""
import json
import re
import sys
from pathlib import Path
from collections import defaultdict, Counter

ROOT = Path("/home/z/my-project")
V149 = ROOT / "handoff/04_эталоны_игрока/perks_v149.jsonl"
DESC_RU = ROOT / "handoff/06_код-истина_перевода/desc_ru.py"
QA96 = ROOT / "work/qa96/perkdump.jsonl"
ZIP = ROOT / "Paths of Empyrean RU 1.5.zip"
OUT = ROOT / "work/qa100/case_report.txt"
OUT.parent.mkdir(parents=True, exist_ok=True)

out = []

def emit(s=""):
    out.append(s)

# --- источники -----------------------------------------------------------
v149 = [json.loads(l) for l in open(V149, encoding="utf-8") if l.strip()]
q96 = [json.loads(l) for l in open(QA96, encoding="utf-8") if l.strip()]

# desc_ru.py — словарь EDID -> текст
dru_txt = DESC_RU.read_text(encoding="utf-8")
m = re.search(r"DESC\s*=\s*\{(.*?)\n\}", dru_txt, re.S)
desc_ru = {}
if m:
    for k, v in re.findall(r"'([^']+)'\s*:\s*'((?:[^'\\]|\\.)*)'", m.group(1)):
        desc_ru[k] = v.replace("\\'", "'").replace("\\n", "\n")

# MCM из пакета
mcm = ""
with __import__("zipfile").ZipFile(ZIP) as z:
    for n in z.namelist():
        if n.endswith("PathsOfEmpyrean_RUSSIAN.txt"):
            mcm = z.read(n).decode("utf-8", "replace")
            break

# --- словарь лексем навыков/школ ----------------------------------------
SCHOOL = ["колдовств", "иллюзи", "изменени", "разрушени", "восстановлени"]
SKILL = ["зачарован", "алхими", "красноречи", "кузнечн", "скрытност",
         "взлом", "карманных краж", "карманной кражи", "карманные кражи",
         "блокирован", "стрельб", "легкой брони", "тяжелой брони",
         "легкой брон", "тяжелой брон", "одноручн", "двуручн"]
TOKENS = SCHOOL + SKILL

def hits(text):
    """Все вхождения лексем: (токен, фрагмент с контекстом)."""
    res = []
    for tok in TOKENS:
        for mo in re.finditer(tok, text, re.I):
            a, b = max(0, mo.start() - 55), min(len(text), mo.end() + 55)
            frag = text[a:b].replace("\n", "⏎").replace("\r", "")
            res.append((mo.group(0), frag))
    return res

# --- A. DESC-слой: эталон v149 + desc_ru (v1.5.7) ------------------------
emit("=" * 76)
emit("A. РЕГИСТР В ОПИСАНИЯХ (эталон v1.4.9, 562 + desc_ru v1.5.7, %d)" % len(desc_ru))
emit("=" * 76)

# ключ desc_ru -> EDID: сопоставляем эталону по desc-тексту, если совпадает
v149_by_edid = {r["edid"]: r for r in v149}

def report_layer(title, items):
    """items: список (ключ, текст). Печатаем каждое вхождение с регистром."""
    emit()
    emit(f"--- {title}")
    upper = lower = 0
    lower_by_tok = defaultdict(list)
    upper_by_tok = Counter()
    for key, text in items:
        for w, frag in hits(text):
            if w[0].isupper():
                upper += 1
                upper_by_tok[w.lower()] += 1
            else:
                lower += 1
                lower_by_tok[w.lower()].append((key, frag))
    emit(f"вхождений: с прописной {upper}, со строчной {lower}")
    emit("с прописной по лексемам: " + ", ".join(
        f"{k}×{n}" for k, n in sorted(upper_by_tok.items(), key=lambda x: -x[1])))
    emit()
    emit("ВСЕ строчные вхождения (для триажа; именное употребление = дефект):")
    for tok in sorted(lower_by_tok, key=lambda k: -len(lower_by_tok[k])):
        emit(f"  [{tok}] — {len(lower_by_tok[tok])} шт.")
        for key, frag in lower_by_tok[tok]:
            emit(f"     {key[:34]:34} | …{frag}…")
    return lower_by_tok, upper_by_tok

low_v149, up_v149 = report_layer("эталон v1.4.9 (perks_v149.jsonl, поле desc)",
                                 [(r["edid"], r.get("desc") or "") for r in v149])

emit()
emit("=" * 76)
emit("B. РАСХОЖДЕНИЯ РЕГИСТРА desc_ru (v1.5.7) vs эталон v1.4.9")
emit("=" * 76)
drift = 0
for edid, r in v149_by_edid.items():
    new = desc_ru.get(edid)
    old = r.get("desc")
    if not new or not old:
        continue
    def case_sig(t):
        return tuple((h[0], h[0][0].isupper()) for h in hits(t))
    if case_sig(old) != case_sig(new):
        drift += 1
        emit(f"  {edid}:")
        emit(f"    v149:  {old[:200]}")
        emit(f"    v157:  {new[:200]}")
if drift == 0:
    emit("  расхождений регистра не найдено (0).")

emit()
emit("=" * 76)
emit("C. ИМЕНА ПЕРКОВ: лейбл-значения «X: Y» и лейбл-пары «X - Y»")
emit("=" * 76)
bad_label = ok_label = 0
for src, recs in (("деревья v1.5.7", q96), ("эталон v1.4.9", v149)):
    for r in recs:
        f = (r.get("full") or "").strip()
        if not f:
            continue
        mo = re.search(r":\s*(\S+)", f)
        if mo:
            v = mo.group(1)
            if v[:1].isalpha() and not v[:1].isupper():
                bad_label += 1
                emit(f"  ДЕФЕКТ-лейбл ({src}): {f}")
            else:
                ok_label += 1
        for mo in re.finditer(r"\s-\s(\S+)", f):
            v = mo.group(1)
            if v[:1].isalpha() and v[:1].isupper():
                emit(f"  лейбл-пара с прописной в хвосте ({src}): {f}")
emit(f"  лейбл-значений с прописной (норма): {ok_label}; со строчной (дефект): {bad_label}")

emit()
emit("=" * 76)
emit("D. ФОКУС: ВЕТКА ИЗМЕНЕНИЯ (22 перка дерева, v1.5.7)")
emit("=" * 76)
alt = [p for p in q96 if p["tree"] == "Изменение"]
emit(f"перков в дереве: {len(alt)}")
for p in alt:
    d = desc_ru.get(p["perk"]) or v149_by_edid.get(p["perk"], {}).get("desc", "")
    emit()
    emit(f"* {p['full']}  ({p['perk']}, {p['formid']})")
    if d:
        emit(f"    {d}")
    else:
        emit("    <desc не найден ни в desc_ru, ни в эталоне>")

# все вхождения «изменени*» по всему корпусу (оба слоя), с регистром
emit()
emit("--- вхождения «изменени*» во ВСЕХ описаниях (эталон + desc_ru), регистр помечен")
seen = set()
for src, items in (("v149", [(r["edid"], r.get("desc") or "") for r in v149]),
                   ("v157", list(desc_ru.items()))):
    for key, text in items:
        for mo in re.finditer("изменени", text, re.I):
            w = mo.group(0)
            a, b = max(0, mo.start() - 60), min(len(text), mo.end() + 60)
            frag = text[a:b].replace("\r", "").replace("\n", "⏎")
            sig = (src, key, mo.start())
            if sig in seen:
                continue
            seen.add(sig)
            tag = "ПРОПИС" if w[0].isupper() else "строчн"
            emit(f"  [{src}][{tag}] {key[:30]:30} | …{frag}…")

emit()
emit("=" * 76)
emit("E. MCM-строки (Interface/Translations/RUSSIAN.txt): навыки/школы")
emit("=" * 76)
mcm_hits = hits(mcm)
emit(f"вхождений: {len(mcm_hits)}")
for w, frag in mcm_hits:
    tag = "ПРОПИС" if w[0].isupper() else "строчн"
    emit(f"  [{tag}] | …{frag}…")

OUT.write_text("\n".join(out), encoding="utf-8")
print(f"отчёт: {OUT} ({len(out)} строк)")
