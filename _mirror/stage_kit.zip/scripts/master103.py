#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 103 (v1.5.8): структурный патчер по work/qa102/fixlist_v158.jsonl.
Источник: work/v157 (выпущенный v1.5.7). Приёмник: work/v158.
Затрагивает: только основной ESP (8 правок: 4×102-а «сильнее», 4×100-а регистр).
Машина байт-в-байт как в master94 (сжатые записи 0x40000/zlib, XXXX-субрекорды)."""
import struct, zlib, os, json

SRC = '/home/z/my-project/upload/poe_pack/work/v157'
DST = '/home/z/my-project/upload/poe_pack/work/v158'
FIX = '/home/z/my-project/upload/poe_pack/work/qa102/fixlist_v158.jsonl'

REC_HDR = 24


class Node:
    __slots__ = ('kind', 'label', 'tail', 'formid', 'data', 'children')


def parse(buf):
    root = []

    def walk(off, end, out):
        while off < end:
            t = buf[off:off+4]
            size = struct.unpack_from('<I', buf, off+4)[0]
            if t == b'GRUP':
                node = Node()
                node.kind = 'grup'
                node.label = t
                node.tail = bytes(buf[off+8:off+24])
                node.children = []
                walk(off + REC_HDR, off + size, node.children)
                out.append(node)
                off += size
            else:
                node = Node()
                node.kind = 'rec'
                node.label = t
                node.tail = bytes(buf[off+8:off+24])
                node.formid = struct.unpack_from('<I', buf, off+12)[0]
                node.data = bytes(buf[off+REC_HDR:off+REC_HDR+size])
                out.append(node)
                off += REC_HDR + size
    walk(0, len(buf), root)
    return root


def serialize_node(n, parts):
    if n.kind == 'grup':
        sub = []
        for c in n.children:
            serialize_node(c, sub)
        s = b''.join(sub)
        parts.append(b'GRUP' + struct.pack('<I', 24 + len(s)) + n.tail)
        parts.append(s)
    else:
        parts.append(n.label + struct.pack('<I', len(n.data)) + n.tail)
        parts.append(n.data)


def find_rec(nodes, formid):
    for n in nodes:
        if n.kind == 'grup':
            r = find_rec(n.children, formid)
            if r is not None:
                return r
        elif n.formid == formid:
            return n
    return None


def rec_flags(rec):
    return struct.unpack_from('<I', rec.tail, 0)[0]


def decode_body(rec):
    if rec_flags(rec) & 0x00040000:
        usz = struct.unpack_from('<I', rec.data, 0)[0]
        dec = zlib.decompress(rec.data[4:])
        assert len(dec) == usz
        return bytearray(dec), True
    return bytearray(rec.data), False


def encode_body(body, was_c):
    if was_c:
        return struct.pack('<I', len(body)) + zlib.compress(bytes(body))
    return bytes(body)


def apply_esp(src, dst, patches):
    """patches: [(formid_int, field, occ, old, new)]"""
    buf = open(src, 'rb').read()
    root = parse(buf)
    out = []
    for n in root:
        serialize_node(n, out)
    if b''.join(out) != buf:
        raise SystemExit(f'САМОТЕСТ ПРОВАЛЕН: {src}')
    print(f'  самотест OK: {os.path.basename(src)} ({len(buf)} B)')
    applied = 0
    for formid, field, occ, old, new in patches:
        rec = find_rec(root, formid)
        if rec is None:
            raise SystemExit(f'{src}: запись {formid:08X} не найдена')
        body, was_c = decode_body(rec)
        off, seen, done = 0, 0, False
        while off < len(body):
            if off + 6 > len(body):
                break
            st = body[off:off+4].decode('ascii', 'replace')
            ssz = struct.unpack_from('<H', body, off+4)[0]
            if st == 'XXXX':
                real = struct.unpack_from('<I', body, off+6)[0]
                off += 6 + ssz + 6 + real
                continue
            cur_sz = ssz
            if st == field:
                seen += 1
                cur = bytes(body[off+6:off+6+ssz]).rstrip(b'\x00').decode('utf-8', 'replace')
                if seen == occ:
                    assert cur == old, f'{formid:08X} {field}#{occ}: old не совпал: {cur[:80]!r} != {old[:80]!r}'
                    newb = new.encode('utf-8') + b'\x00'
                    body[off+6:off+6+ssz] = newb
                    struct.pack_into('<H', body, off+4, len(newb))
                    done = True
                    applied += 1
                    cur_sz = len(newb)
            off += 6 + cur_sz
        if not done:
            raise SystemExit(f'{src}: патч {formid:08X} {field}#{occ} не применён')
        rec.data = encode_body(body, was_c)
    out = []
    for n in root:
        serialize_node(n, out)
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    open(dst, 'wb').write(b''.join(out))
    print(f'  -> {dst} ({os.path.getsize(dst)} B), патчей: {applied}')
    return applied


def main():
    esp_patches = {}
    for line in open(FIX, encoding='utf-8'):
        r = json.loads(line)
        if r.get('kind') == 'sbow':
            raise SystemExit('sbow-патчи в этом этапе не ожидались')
        esp_patches.setdefault(r['scope'], []).append(
            (int(r['formid'], 16), r['field'], r['occ'], r['old'], r['new']))

    esp_paths = {
        'main': f'{SRC}/00 Core/PathsOfEmpyrean.esp',
        'ms': f'{SRC}/10 Missing Shields/PoE-Addon-MissingShields.esp',
        'sp': f'{SRC}/20 Spears/PoE-Addon-Spears.esp',
    }
    for root, _d, files in os.walk(f'{SRC}/30 CC Patches'):
        for f in files:
            if f.endswith('.esp'):
                esp_paths[f[:-4]] = os.path.join(root, f)

    tot = 0
    for scope, ps in sorted(esp_patches.items()):
        assert scope in esp_paths, scope
        tot += apply_esp(esp_paths[scope], esp_paths[scope].replace(SRC, DST), ps)
    print(f'ИТОГО применено: {tot}')


if __name__ == '__main__':
    main()
