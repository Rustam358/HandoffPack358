#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 114, шаг: сборка пакета v1.5.15.
База = user zip «Paths of Empyrean RU 1.5 (6).zip» = байт-в-байт наш v1.5.14
(63/63 CRC). Замены ровно 2 записи: ESP (1 патч 114) + info.xml 1.5.14→1.5.15.
"""
import zipfile, os, hashlib, shutil

SRC_ZIP = '/home/z/my-project/upload/Paths of Empyrean RU 1.5 (6).zip'
DST = '/home/z/my-project/download/Paths of Empyrean RU 1.5.zip'
V115 = '/home/z/my-project/work/qa114/v115'
ARC_ESP = '00 Core/PathsOfEmpyrean.esp'
RU15 = '/home/z/my-project/work/ru15'


def main():
    esp = open(f'{V115}/{ARC_ESP}', 'rb').read()
    md5_esp = hashlib.md5(esp).hexdigest()

    zsrc = zipfile.ZipFile(SRC_ZIP)
    names = zsrc.namelist()
    orig_crc = {i.filename: i.CRC for i in zsrc.infolist()}
    print('источник: user zip v1.5.14 (%d записей)' % len(names))

    info_src = zsrc.read('fomod/info.xml').decode('utf-8')
    assert '<Version>1.5.14</Version>' in info_src
    info_new = info_src.replace('<Version>1.5.14</Version>', '<Version>1.5.15</Version>')
    assert '<Version>1.5.15</Version>' in info_new and '1.5.14' not in info_new
    print('info.xml: Version 1.5.14 -> 1.5.15')

    repl = {ARC_ESP: esp, 'fomod/info.xml': info_new.encode('utf-8')}
    zout = zipfile.ZipFile(DST, 'w')
    for item in zsrc.infolist():
        arc = item.filename
        zout.writestr(item, repl[arc] if arc in repl else zsrc.read(arc))
    zout.close()
    print('zip собран')

    print()
    print('=== ВЕРИФИКАЦИЯ ПАКЕТА v1.5.15 ===')
    z2 = zipfile.ZipFile(DST)
    names2 = z2.namelist()
    assert z2.testzip() is None
    assert len(names2) == 63 and set(names2) == set(names)
    print('testzip: OK, записей: %d (набор совпадает)' % len(names2))

    diff = [n for n in names if orig_crc[n] != z2.getinfo(n).CRC]
    assert set(diff) == set(repl), 'CRC-дифф: %s' % diff
    print('CRC vs v1.5.14: изменены ровно 2 записи (ESP, info.xml), остальные %d байт-в-байт'
          % (len(names) - 2))

    assert hashlib.md5(z2.read(ARC_ESP)).hexdigest() == md5_esp
    print('ESP: md5 == work/qa114/v115 (%s)' % md5_esp)

    ver = z2.read('fomod/info.xml').decode('utf-8')
    assert '<Version>1.5.15</Version>' in ver
    cfg = z2.read('fomod/ModuleConfig.xml').decode('utf-8')
    assert '<moduleName>Paths of Empyrean</moduleName>' in cfg
    print('версии: info.xml = 1.5.15; moduleName не тронут')

    shutil.copyfile(f'{V115}/{ARC_ESP}', os.path.join(RU15, '00 Core', 'PathsOfEmpyrean.esp'))
    open(os.path.join(RU15, 'fomod', 'info.xml'), 'w', encoding='utf-8', newline='').write(info_new)
    print('зеркало work/ru15: ESP + info.xml обновлены')

    print()
    print('ПАКЕТ:', DST, '(%d Б)' % os.path.getsize(DST))
    print('md5 пакета: %s' % hashlib.md5(open(DST, 'rb').read()).hexdigest())


if __name__ == '__main__':
    main()
