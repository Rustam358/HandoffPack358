#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 118 («Великая» проверка тиров): дамп EN 1.4 всех 39 ESP из
handoff/08_оригинал_1.4_EN/полный_разбор_1.4 — для выравнивания с RU v1.5.18.

Выход: work/qa118/dump_en14.jsonl
Тэги файлов — те же, что в дамповом слое проекта (main/ms/sp/cc:XXX).
Аналитический скрипт: НИЧЕГО не правит.
"""
import sys, json, glob, os

sys.path.insert(0, '/home/z/my-project/scripts')
from dump150 import dump_esp

BASE = '/home/z/my-project/handoff/08_оригинал_1.4_EN/полный_разбор_1.4/PoE 1.4'
OUT = '/home/z/my-project/work/qa118/dump_en14.jsonl'

os.makedirs(os.path.dirname(OUT), exist_ok=True)

jobs = [
    (f'{BASE}/PathsOfEmpyrean.esp', 'main'),
    (f'{BASE}/PoE-Addon-MissingShields.esp', 'ms'),
    (f'{BASE}/PoE-Addon-Spears.esp', 'sp'),
]
for path in sorted(glob.glob(f'{BASE}/PoE-CC*-Patch.esp')):
    tag = 'cc:' + os.path.basename(path).replace('PoE-CC', '').replace('-Patch.esp', '')
    jobs.append((path, tag))

total = 0
with open(OUT, 'w', encoding='utf-8') as out:
    for path, tag in jobs:
        p = dump_esp(path, tag, out)
        total += len(p.records)
        print(f'{tag}: records={len(p.records)}')
print('total records:', total)
print('OK ->', OUT)
