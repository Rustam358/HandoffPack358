#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 118: разведка #2 — вариантные тиры WEAP/ARMO с RU-стороной."""
import json
from collections import defaultdict, Counter

A = json.load(open('/home/z/my-project/work/qa118/aligned.json', encoding='utf-8'))


def show(prefix_filter, rtype='WEAP', limit=100):
    print(f'\n=== {rtype} FULL: EN начинается с {prefix_filter} ===')
    rows = []
    for r in A:
        if r['rtype'] != rtype or r['field'] != 'FULL' or not r['en_text']:
            continue
        en = r['en_text']
        w = en.split()
        if w and w[0] in prefix_filter:
            rows.append((r['file'], r['formid'], r['edid'], en, r['ru_text']))
    print(f'всего: {len(rows)}')
    for row in rows[:limit]:
        print(f'  [{row[0]} {row[1]}] {row[2][:40]:40} EN: {row[3][:55]:55} RU: {row[4][:55]}')
    return rows


# варианты арбалетов/луков
for pf in [{'Silenced'}, {'Light-Weight'}, {'Spring-Loaded'}, {'Recurve'}, {'Hunting'}]:
    show(pf)

# Turn-лестница на оружии
show({'Blessed', 'Sanctified', 'Reverent', 'Hallowed', 'Virtuous', 'Holy'})

# Quality-броня
show({'Quality'}, 'ARMO', 30)
