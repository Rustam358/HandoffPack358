#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап-разведка 115.
A) Где хранятся formid MESG-маскировок (носители-ссылки) в каждом ESP релиза.
B) Сырые сабрекорды MGEF 06060E75 (bandit) — DATA/SNAM/VMAD/hex.
C) Носители записей 113-а (05000800/01/02, 09000910/15/1A) по всем ESP.
"""
import struct, zlib, os, sys

REL = '/home/z/my-project/work/qa114/release115'
REC_HDR = 24

MESG_IDS = [0x06060EA6, 0x06060E9A, 0x06060E93, 0x06060EA0, 0x06060E79,
            0x06060E78, 0x06024563, 0x06024570, 0x06024572, 0x06024571,
            0x06060E88, 0x06060E8B, 0x06024573]
FIX113 = [0x05000800, 0x05000801, 0x05000802, 0x09000910, 0x09000915, 0x0900091A]


class Node:
    __slots__ = ('kind', 'label', 'tail', 'formid', 'data', 'children')


def parse(buf):
    root = []

    def walk(off, end, out):
        while off < end:
            t = buf[off:off+4]
            size = struct.unpack_from('<I', buf, off+4)[0]
            if t == b'GRUP':
                node = Node(); node.kind = 'grup'; node.children = []
                walk(off + REC_HDR, off + size, node.children)
                out.append(node); off += size
            else:
                node = Node(); node.kind = 'rec'
                node.label = t
                node.tail = bytes(buf[off+8:off+24])
                node.formid = struct.unpack_from('<I', buf, off+12)[0]
                node.data = bytes(buf[off+REC_HDR:off+REC_HDR+size])
                out.append(node); off += REC_HDR + size
    walk(0, len(buf), root)
    return root


def walk_recs(nodes):
    for n in nodes:
        if n.kind == 'grup':
            yield from walk_recs(n.children)
        else:
            yield n


def subrecords(rec):
    body = rec.data
    if struct.unpack_from('<I', rec.tail, 0)[0] & 0x00040000:
        usz = struct.unpack_from('<I', body, 0)[0]
        body = zlib.decompress(body[4:])
        assert len(body) == usz
    out = []
    off = 0
    while off < len(body):
        st = body[off:off+4].decode('ascii', 'replace')
        ssz = struct.unpack_from('<H', body, off+4)[0]
        val = bytes(body[off+6:off+6+ssz])
        out.append((st, val))
        if st == 'XXXX':
            real = struct.unpack_from('<I', body, off+6)[0]
            off += 6 + ssz + 6 + real
            continue
        off += 6 + ssz
    return out


def edid_of(rec):
    for st, v in subrecords(rec):
        if st == 'EDID':
            return v.rstrip(b'\x00').decode('utf-8', 'replace')
    return ''


def iter_esp(root):
    for dirpath, dirnames, filenames in os.walk(root):
        for fn in sorted(filenames):
            if fn.lower().endswith('.esp'):
                yield os.path.join(dirpath, fn)


def main():
    esps = list(iter_esp(REL))
    print(f'=== ESP в релизе: {len(esps)} ===')
    for p in esps:
        print(' ', os.path.relpath(p, REL))

    targets_bytes = {i: struct.pack('<I', i) for i in MESG_IDS + FIX113}
    print()
    print('=== A) носители ссылок на MESG-маскировки / записи 113-а ===')
    for p in esps:
        buf = open(p, 'rb').read()
        root = parse(buf)
        for rec in walk_recs(root):
            rl = rec.label.decode('ascii', 'replace')
            # сырой поиск: тело+TAIL не сканируем целиком бездумно —
            # но для носителей достаточно всего data
            for fid, pat in targets_bytes.items():
                if rec.formid == fid:
                    continue
                cnt = rec.data.count(pat)
                if cnt:
                    kind = 'MESG' if fid in MESG_IDS else 'FIX113'
                    # найдём смещения в терминах сабрекордов
                    subs = subrecords(rec)
                    hits = []
                    for st, v in subs:
                        if pat in v:
                            hits.append(st)
                    print(f'{os.path.basename(p)}: {rl} {rec.formid:08X} '
                          f'{edid_of(rec)} — содержит {fid:08X} ({kind}) '
                          f'x{cnt} в полях {sorted(set(hits))}')

    print()
    print('=== B) MGEF 06060E75 bandit: сырые сабрекорды ===')
    buf = open(os.path.join(REL, '00 Core/PathsOfEmpyrean.esp'), 'rb').read()
    root = parse(buf)
    for rec in walk_recs(root):
        if rec.formid == 0x06060E75:
            for st, v in subrecords(rec):
                if st in ('EDID', 'FULL', 'DNAM'):
                    print(f'  {st}: {v.rstrip(chr(0).encode()).decode("utf-8", "replace")}')
                else:
                    hx = v.hex()
                    print(f'  {st} [{len(v)}]: {hx[:160]}{"..." if len(hx) > 160 else ""}')
            break

    print()
    print('=== B2) VMAD-разбор (если есть) для всех MGEF-маскировок ===')
    for rec in walk_recs(root):
        rl = rec.label.decode('ascii', 'replace')
        if rl != 'MGEF':
            continue
        subs = subrecords(rec)
        edid = edid_of(rec)
        if not edid.startswith('ISP_MGEF_SPEECH_Disguise'):
            continue
        for st, v in subs:
            if st == 'VMAD':
                print(f'{rec.formid:08X} {edid}: VMAD {len(v)} Б: {v[:80].hex()}')
            if st == 'SNAM':
                print(f'{rec.formid:08X} {edid}: SNAM {v.hex()}')


if __name__ == '__main__':
    main()
