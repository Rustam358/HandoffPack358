#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 118: генерация ФИКСЛИСТ-ПРОЕКТА (НЕ применён; ждёт вердиктов игрока).

work/qa118/fixlist_project_118.jsonl — 44 поля, 4 проекта (118-а/б/в/г).
Каждая запись: {project, file, formid, field, occ, edid, old, new, why}.
old сверяются байт-в-байт с дампом v1.5.18.
"""
import json

RU = [json.loads(l) for l in open('/home/z/my-project/work/qa117/dump_v118_full.jsonl', encoding='utf-8')]
ru_map = {(r['file'], r['formid'], r['rtype'], r['field'], r.get('occ', 1)): r for r in RU}

fixes = []

# ---- 118-а: арбалеты ECP, потеря материала (24) ----
MAT = {
    'Daedric': 'Даэдрический', 'Dragonbone': 'Драконий костяной', 'Glass': 'Стеклянный',
    'Imperial': 'Имперский', 'Nordic': 'Нордский', 'Orcish': 'Орочий',
    'Silver': 'Серебряный', 'Stalhrim': 'Сталгримовый',
}
OLD = {
    'R': 'Арбалет с выгнутой ложей',
    'SL': 'Арбалет с пружинным механизмом',
    'RSL': 'Арбалет с выгнутой ложей и пружинным механизмом',
}
NEW = {
    'R': '{m} арбалет с выгнутой ложей',
    'SL': '{m} арбалет с пружинным механизмом',
    'RSL': '{m} арбалет с выгнутой ложей и пружинным механизмом',
}
for mat, ru_m in MAT.items():
    for suf in ('R', 'SL', 'RSL'):
        edid = f'PoE_ccFFBSSE002_{mat}Crossbow_{suf}'
        # ищем запись в дампе по edid
        rec = None
        for r in RU:
            if r['file'] == 'cc:ExpandedCrossbowPack' and r['rtype'] == 'WEAP' and r['field'] == 'FULL' and r['edid'] == edid:
                rec = r
                break
        assert rec is not None, edid
        assert rec['text'] == OLD[suf], (edid, rec['text'])
        fixes.append({
            'project': '118-а', 'file': 'cc:ExpandedCrossbowPack', 'formid': rec['formid'],
            'rtype': 'WEAP', 'field': 'FULL', 'occ': rec.get('occ', 1), 'edid': edid,
            'old': OLD[suf], 'new': NEW[suf].format(m=ru_m),
            'why': f'EN "…{mat} Crossbow": в RU потеряно слово материала; 8 материалов делят одно имя (коллизия в инвентаре); образец — соседние Enhanced-варианты и main DLC1DwarvenCrossBow_R/SL',
        })

# ---- 118-б: орочая/орочие (5) ----
for fid, edid, old, new in [
    ('0608A251', 'ArmorOrcishGauntlets_M', 'Мастерские орочие перчатки', 'Мастерские орочьи перчатки'),
    ('0608A25B', 'ArmorOrcishBoots_M', 'Мастерские орочие сапоги', 'Мастерские орочьи сапоги'),
    ('0608A409', 'OrcishMace_M', 'Мастерская орочая булава', 'Мастерская орочья булава'),
    ('06193D35', 'OrcishArrow_lucky', 'Счастливая орочая стрела', 'Счастливая орочья стрела'),
    ('06193D36', 'ArrowOrcishProjectile_lucky', 'Счастливая орочая стрела', 'Счастливая орочья стрела'),
]:
    rec = None
    for r in RU:
        if r['formid'] == fid and r['field'] == 'FULL':
            rec = r
            break
    assert rec is not None, fid
    assert rec['text'] == old, (fid, rec['text'])
    fixes.append({
        'project': '118-б', 'file': rec['file'], 'formid': fid, 'rtype': rec['rtype'],
        'field': 'FULL', 'occ': rec.get('occ', 1), 'edid': edid,
        'old': old, 'new': new,
        'why': 'смешанное склонение «орочий»: ж=орочья, мн=орочьи (офиц. «Орочья стрела»/«Орочий лук»;DESC Journeyman «орочьи доспехи»); «орочая/орочие» — нестандартная форма',
    })

# ---- 118-в: Turn/Repel глагольный разнобой (7) ----
for fid, rtype, edid, old, new in [
    ('0004B145', 'MGEF', 'TurnUndeadFFAimed25', 'Прогнать слабую нежить', 'Отпугивание младшей нежити'),
    ('0005DD5B', 'MGEF', 'TurnUndeadFFAimed50', 'Прогнать нежить', 'Отпугивание нежити'),
    ('0005DD5C', 'MGEF', 'TurnUndeadFFAimed75', 'Прогнать сильную нежить', 'Отпугивание старшей нежити'),
    ('0008C1AA', 'MGEF', 'TurnUndeadFFMassSelfArea', 'Прогнать сильную нежить', 'Отпугивание старшей нежити'),
    ('0004D3F7', 'MGEF', 'TurnUndeadFFAimedArea50', 'Отпор слабой нежити', 'Отталкивание младшей нежити'),
    ('0005DD5F', 'MGEF', 'TurnUndeadFFAimedArea75', 'Отпор нежити', 'Отталкивание нежити'),
    ('000B62E3', 'ENCH', 'StaffEnchTurnLesserUndead', 'Прогнать слабую нежить', 'Отпугивание младшей нежити'),
]:
    rec = None
    for r in RU:
        if r['formid'] == fid and r['rtype'] == rtype and r['field'] == 'FULL':
            rec = r
            break
    assert rec is not None, fid
    assert rec['text'] == old, (fid, rec['text'])
    verb = 'Отпугивание' if 'Turn' in edid else 'Отталкивание'
    fixes.append({
        'project': '118-в', 'file': rec['file'], 'formid': fid, 'rtype': rtype,
        'field': 'FULL', 'occ': rec.get('occ', 1), 'edid': edid,
        'old': old, 'new': new,
        'why': f'офиц. серии: Turn=«{verb}…» (skyrim#1974/3293/7434), Repel=«Отталкивание…»; «Прогнать»=0 и «Отпор»=0 в офиц. корпусе; соседние SPEL/SCRL/ENCH уже официальные',
    })

# ---- 118-г: Lucky-стрелы vs офиц. база (6 записей: AMMO + PROJ) ----
for fid, edid, old, new, why in [
    ('06193D41', 'DLC1ElvenArrowBlessed_lucky', 'Счастливая освященная эльфийская стрела',
     'Счастливая солнечная эльфийская стрела', 'офиц. база Sunhallowed Elven Arrow = «Солнечная эльфийская стрела»'),
    ('06193D42', 'DLC1ArrowElvenProjectileExplode_lucky', 'Счастливая освященная эльфийская стрела',
     'Счастливая солнечная эльфийская стрела', 'PROJ-зеркало 06193D41'),
    ('06193D3E', 'DLC1ElvenArrowBlood_lucky', 'Счастливая проклятая кровью эльфийская стрела',
     'Счастливая эльфийская стрела кровавого проклятья', 'офиц. база Bloodcursed Elven Arrow = «Эльфийская стрела кровавого проклятья»'),
    ('06193D3F', 'DLC1AurielsBloodDippedProjectile_lucky', 'Счастливая проклятая кровью эльфийская стрела',
     'Счастливая эльфийская стрела кровавого проклятья', 'PROJ-зеркало 06193D3E'),
    ('06193D32', 'NordHeroArrow_lucky', 'Счастливая стрела нордского героя',
     'Счастливая нордская стрела героя', 'офиц. база Nord Hero Arrow = «Нордская стрела героя» (000EAFDF)'),
    ('06193D33', 'ArrowNordHeroProjectile_lucky', 'Счастливая стрела нордского героя',
     'Счастливая нордская стрела героя', 'PROJ-зеркало 06193D32'),
]:
    rec = None
    for r in RU:
        if r['formid'] == fid and r['field'] == 'FULL':
            rec = r
            break
    assert rec is not None, fid
    assert rec['text'] == old, (fid, rec['text'])
    fixes.append({
        'project': '118-г', 'file': rec['file'], 'formid': fid, 'rtype': rec['rtype'],
        'field': 'FULL', 'occ': rec.get('occ', 1), 'edid': edid,
        'old': old, 'new': new, 'why': why,
    })

out = '/home/z/my-project/work/qa118/fixlist_project_118.jsonl'
with open(out, 'w', encoding='utf-8') as f:
    for fx in fixes:
        f.write(json.dumps(fx, ensure_ascii=False) + '\n')
from collections import Counter
print('записей:', len(fixes), dict(Counter(x['project'] for x in fixes)))
print('OK ->', out)
