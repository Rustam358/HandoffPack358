#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 119, шаг: сборка пакета v1.5.19.
База = аплоад игрока «Paths of Empyrean RU 1.5 (10).zip» (байт-в-байт наш
v1.5.18, md5 f55ce29f5fb6682d72a129486ab16de8; вход upload/ только читается).
Замены ровно 5 записей: main ESP (118-б/в/г/е), cc:ExpandedCrossbowPack ESP
(118-а), cc:Fishing ESP (118-е), ShortbowNames.ini (118-е), info.xml
1.5.18→1.5.19. Выход: download/Paths of Empyrean RU 1.5.zip + копия в корне
репо (истина для пака передачи, сборщик build_handoff_pack_v5.py).
Зеркало work/ru15 не обновляется (дерево утрачено при рецикле песочницы;
истина = выпущенный zip, [T49]).
"""
import zipfile, os, hashlib

SRC_ZIP = '/home/z/my-project/upload/Paths of Empyrean RU 1.5 (10).zip'
V118_ZIP_MD5 = 'f55ce29f5fb6682d72a129486ab16de8'
DST = '/home/z/my-project/download/Paths of Empyrean RU 1.5.zip'
ROOT_COPY = '/home/z/my-project/Paths of Empyrean RU 1.5.zip'
V119 = '/home/z/my-project/work/qa119/v119'

MAIN = '00 Core/PathsOfEmpyrean.esp'
ECP = ('30 CC Patches/Expanded Crossbow Pack/'
       'PoE-CCExpandedCrossbowPack-Patch.esp')
FISH = '30 CC Patches/Fishing/PoE-CCFishing-Patch.esp'
INI = ('00 Core/SKSE/Plugins/POE/Weapon/'
       'PathsOfEmpyrean_ShortbowNames.ini')


def main():
    assert hashlib.md5(open(SRC_ZIP, 'rb').read()).hexdigest() == V118_ZIP_MD5
    repl = {}
    for arc in (MAIN, ECP, FISH, INI):
        repl[arc] = open(f'{V119}/{arc}', 'rb').read()

    zsrc = zipfile.ZipFile(SRC_ZIP)
    names = zsrc.namelist()
    orig_crc = {i.filename: i.CRC for i in zsrc.infolist()}
    print('источник: аплоад игрока = v1.5.18 (%d записей)' % len(names))

    info_src = zsrc.read('fomod/info.xml').decode('utf-8')
    assert '<Version>1.5.18</Version>' in info_src
    info_new = info_src.replace('<Version>1.5.18</Version>',
                                '<Version>1.5.19</Version>')
    assert '<Version>1.5.19</Version>' in info_new and '1.5.18' not in info_new
    repl['fomod/info.xml'] = info_new.encode('utf-8')
    print('info.xml: Version 1.5.18 -> 1.5.19')

    zout = zipfile.ZipFile(DST, 'w')
    for item in zsrc.infolist():
        arc = item.filename
        zout.writestr(item, repl[arc] if arc in repl else zsrc.read(arc))
    zout.close()
    print('zip собран')

    print()
    print('=== ВЕРИФИКАЦИЯ ПАКЕТА v1.5.19 ===')
    z2 = zipfile.ZipFile(DST)
    names2 = z2.namelist()
    assert z2.testzip() is None
    assert len(names2) == 63 and set(names2) == set(names)
    print('testzip: OK, записей: %d (набор совпадает)' % len(names2))

    diff = [n for n in names if orig_crc[n] != z2.getinfo(n).CRC]
    assert set(diff) == set(repl), 'CRC-дифф: %s' % diff
    print('CRC vs v1.5.18: изменены ровно 5 записей (main ESP, ECP ESP, '
          'Fishing ESP, ShortbowNames.ini, info.xml), остальные %d '
          'байт-в-байт' % (len(names) - 5))

    for arc in (MAIN, ECP, FISH, INI):
        got = hashlib.md5(z2.read(arc)).hexdigest()
        want = hashlib.md5(open(f'{V119}/{arc}', 'rb').read()).hexdigest()
        assert got == want, arc
    print('md5 4 изменённых файлов == work/qa119/v119')

    ver = z2.read('fomod/info.xml').decode('utf-8')
    assert '<Version>1.5.19</Version>' in ver
    print('версия пакета: 1.5.19')

    # копия истины в корень репо (для build_handoff_pack_v5.py, [S8])
    data = open(DST, 'rb').read()
    open(ROOT_COPY, 'wb').write(data)
    assert hashlib.md5(open(ROOT_COPY, 'rb').read()).hexdigest() == \
        hashlib.md5(data).hexdigest()
    print('копия истины в корне репо обновлена (v1.5.19)')

    print()
    print('ПАКЕТ:', DST, '(%d Б)' % os.path.getsize(DST))
    print('md5 пакета: %s' % hashlib.md5(open(DST, 'rb').read()).hexdigest())


if __name__ == '__main__':
    main()
