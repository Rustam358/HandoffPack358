#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 112, шаг 5: сборка пакета v1.5.13.

База = user zip (upload/Paths of Empyrean RU 1.5 (4).zip) — байт-в-байт наш
v1.5.12 (63/63 CRC равны, diff_zip_112.py). Замены ровно 2 записи:
  1. 00 Core/PathsOfEmpyrean.esp  <- work/qa112/v113 (9 патчей, master112)
  2. fomod/info.xml: Version 1.5.12 -> 1.5.13
Выход: download/Paths of Empyrean RU 1.5.zip + зеркало work/ru15.
"""
import zipfile, os, hashlib, shutil

SRC_ZIP = '/home/z/my-project/upload/Paths of Empyrean RU 1.5 (4).zip'
DST = '/home/z/my-project/download/Paths of Empyrean RU 1.5.zip'
V113 = '/home/z/my-project/work/qa112/v113'
ARC_ESP = '00 Core/PathsOfEmpyrean.esp'
RU15 = '/home/z/my-project/work/ru15'


def main():
    esp = open(f'{V113}/{ARC_ESP}', 'rb').read()
    md5_esp = hashlib.md5(esp).hexdigest()

    zsrc = zipfile.ZipFile(SRC_ZIP)
    names = zsrc.namelist()
    orig_crc = {i.filename: i.CRC for i in zsrc.infolist()}
    print('источник: user zip v1.5.12 (%d записей)' % len(names))

    # --- санити источника ---
    info_src = zsrc.read('fomod/info.xml').decode('utf-8')
    assert '<Version>1.5.12</Version>' in info_src
    print('санити: info = 1.5.12')

    info_new = info_src.replace('<Version>1.5.12</Version>', '<Version>1.5.13</Version>')
    assert '<Version>1.5.13</Version>' in info_new and '1.5.12' not in info_new
    print('info.xml: Version 1.5.12 -> 1.5.13')

    # --- сборка zip ---
    repl = {ARC_ESP: esp, 'fomod/info.xml': info_new.encode('utf-8')}
    zout = zipfile.ZipFile(DST, 'w')
    for item in zsrc.infolist():
        arc = item.filename
        if arc in repl:
            zout.writestr(item, repl[arc])
        else:
            zout.writestr(item, zsrc.read(arc))
    zout.close()
    print('zip собран')

    # ================= ВЕРИФИКАЦИЯ =================
    print()
    print('=== ВЕРИФИКАЦИЯ ПАКЕТА v1.5.13 ===')
    z2 = zipfile.ZipFile(DST)
    names2 = z2.namelist()
    assert z2.testzip() is None
    assert len(names2) == 63 and set(names2) == set(names)
    print('testzip: OK, записей: %d (набор совпадает)' % len(names2))

    diff = [n for n in names if orig_crc[n] != z2.getinfo(n).CRC]
    assert set(diff) == set(repl), 'CRC-дифф: %s' % diff
    print('CRC: изменены ровно 2 записи (ESP, info.xml), остальные %d байт-в-байт'
          % (len(names) - 2))

    got_esp = z2.read(ARC_ESP)
    assert hashlib.md5(got_esp).hexdigest() == md5_esp
    print('ESP: md5 == work/qa112/v113 (%s)' % md5_esp)

    ver = z2.read('fomod/info.xml').decode('utf-8')
    assert '<Version>1.5.13</Version>' in ver
    cfg = z2.read('fomod/ModuleConfig.xml').decode('utf-8')
    assert '<moduleName>Paths of Empyrean</moduleName>' in cfg
    print('версии: info.xml = 1.5.13; moduleName = «Paths of Empyrean»; FOMOD не тронут')

    # --- зеркало work/ru15 ---
    shutil.copyfile(f'{V113}/{ARC_ESP}', os.path.join(RU15, '00 Core', 'PathsOfEmpyrean.esp'))
    open(os.path.join(RU15, 'fomod', 'info.xml'), 'w', encoding='utf-8', newline='').write(info_new)
    print('зеркало work/ru15: ESP + info.xml обновлены')

    print()
    print('ПАКЕТ:', DST, '(%d B)' % os.path.getsize(DST))
    print('md5 пакета: %s' % hashlib.md5(open(DST, 'rb').read()).hexdigest())


if __name__ == '__main__':
    main()
