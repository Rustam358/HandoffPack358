# -*- coding: utf-8 -*-
"""Этап 107: KID/SkyPatcher name-зависимости в PT-сборке + слои вне ESP.
work/qa107/kid_name_dep_107.txt, layers_107.txt"""
import json, re, os, hashlib, collections

OUT = '/home/z/my-project/work/handoff/work/qa107'
EN14 = '/home/z/my-project/work/handoff/handoff/08_оригинал_1.4_EN'
RU = '/home/z/my-project/work/ru15'
PT = '/home/z/my-project/work/ptbr/PathsOfEmpyrean_FOMODSetup'

def load_jsonl(path):
    return [json.loads(l) for l in open(path, encoding='utf-8')]
en14 = load_jsonl(f'{OUT}/dump_en14.jsonl')
pt = load_jsonl(f'{OUT}/dump_pt.jsonl')

# ---------- 1) KID name-правила автора ----------
kid = open(f'{EN14}/полный_разбор_1.4/PoE 1.4/PathsOfEmpyrean_KID.ini', encoding='utf-8', errors='replace').read()
rules = []
for line in kid.splitlines():
    line = line.strip()
    if not line or line.startswith(';'):
        continue
    m = re.match(r'Keyword\s*=\s*([^|]+)\|([^|]+)\|(.*)$', line)
    if not m:
        continue
    kw, rtype, filt = m.groups()
    rules.append((kw.strip(), rtype.strip(), filt.strip()))
name_rules = [r for r in rules if '*' in r[2]]
print(f'KID правил всего: {len(rules)}, с *-токенами (name-правила): {len(name_rules)}')

# FULL-поля по записям (EN14)
full_by_rec = {}
for r in en14:
    if r['field'] == 'FULL':
        k = (r['file'], r['rtype'], r['fid'])
        full_by_rec.setdefault(k, []).append(r['text'])
edid_by_rec = {}
for r in en14:
    k = (r['file'], r['rtype'], r['fid'])
    edid_by_rec.setdefault(k, r.get('edid') or '')

name_dep = {}
for kw, rtype, filt in name_rules:
    toks = [t.strip().lstrip('*+,-') for t in filt.split(',') if '*' in t]
    for tok in toks:
        tok_l = tok.lower()
        if not tok_l:
            continue
        for k, fulls in full_by_rec.items():
            if rtype and rtype not in ('Weapon', 'Armor', 'Ammo', 'Book', 'MagicEffect', 'Spell', 'Enchantment', 'Scroll', 'Outfit', 'NPC', 'Ingestible', 'Misc') and False:
                pass
            edid = edid_by_rec.get(k, '')
            for full in fulls:
                if tok_l in (full or '').lower() and tok_l not in (edid or '').lower():
                    name_dep.setdefault(k, []).append((kw, tok))

print(f'Записей с name-зависимостью (EN14, FULL матчится, EDID нет): {len(name_dep)}')
by_type = collections.Counter(k[1] for k in name_dep)
print(' по типам:', dict(by_type))

# PT-состояние этих записей
pt_full = {}
for r in pt:
    if r['field'] == 'FULL':
        pt_full[(r['file'], r['rtype'], r['fid'])] = r['text']
lost = kept = nodata = 0
samples = []
for k, toks in sorted(name_dep.items()):
    en_full = full_by_rec[k][0]
    ptv = pt_full.get(k)
    if ptv is None:
        nodata += 1
    elif ptv != en_full:
        lost += 1
        if len(samples) < 12:
            samples.append((k, en_full, ptv, toks[0][1]))
    else:
        kept += 1
print(f'PT: переведено (=> потеря ключевиков) {lost}, оставлено EN {kept}, поля нет {nodata}')
for s in samples:
    print(f'   LOSS {s[0][0]}/{s[0][1]}/{s[0][2]} {s[3]!r}: EN={s[1]!r} PT={s[2]!r}')

# наш компенсатор: EDID-фильтры PoE_RU_KID.ini
our_kid = open(f'{RU}/00 Core/PoE_RU_KID.ini', encoding='utf-8').read()
our_edids = set(re.findall(r'\b([A-Za-z_][A-Za-z0-9_]{4,})\b', our_kid))
covered = sum(1 for k in name_dep if edid_by_rec.get(k, '') in our_edids or any(e in our_edids for e in [edid_by_rec.get(k,'')]))
print(f'Наш PoE_RU_KID.ini покрывает (по EDID-вхождению): {covered}/{len(name_dep)}')

with open(f'{OUT}/kid_name_dep_107.txt', 'w', encoding='utf-8') as f:
    f.write(f'KID правил: {len(rules)}, name-правил (*): {len(name_rules)}\n')
    f.write(f'name-зависимых записей (EN14): {len(name_dep)}\n')
    f.write(f'PT: потеря ключевиков (переведено) {lost}, EN {kept}, нет поля {nodata}\n')
    for s in samples:
        f.write(f'LOSS {s[0]}\n')

# ---------- 2) SkyPatcher weapon name-правила (ShortbowNames и др.) ----------
sp_files = []
for dp, _, fns in os.walk(f'{EN14}/дистрибутив_1.4/SKSE/Plugins/SkyPatcher'):
    for fn in fns:
        sp_files.append(os.path.join(dp, fn))
name_lines = 0
for p in sp_files:
    txt = open(p, encoding='utf-8', errors='replace').read()
    for line in txt.splitlines():
        if '*' in line and not line.strip().startswith(';'):
            name_lines += 1
print(f'SkyPatcher ini автора: {len(sp_files)} файлов, строк с *-фильтрами (по именам): {name_lines}')

# ---------- 3) Слои вне ESP ----------
rep = ['=== Этап 107: слои вне ESP ===']
# 3a. SkyPatcher/CDF байт-сверка PT vs EN14
pt_files = {}
for dp, _, fns in os.walk(PT):
    for fn in fns:
        pt_files.setdefault(fn, []).append(os.path.join(dp, fn))
def find_en(rel_end):
    hits = []
    for dp, _, fns in os.walk(EN14):
        for fn in fns:
            if fn == rel_end:
                hits.append(os.path.join(dp, fn))
    return hits
checks = [
    'ccbgssse025-advdsgs.esm.ini', 'ccbgssse001-fish.esm.json',
    'ccbgssse037-curios.esl.ini', 'cctwbsse001-puzzledungeon.esm.ini',
    'ccbgssse067-daedinv.esm.ini',
]
rep.append('--- SkyPatcher/CDF: PT vs EN14 (md5) ---')
for fn in checks:
    ens = find_en(fn)
    pts = pt_files.get(fn, [])
    e_md5 = hashlib.md5(open(ens[0], 'rb').read()).hexdigest() if ens else 'NO_EN14'
    p_md5 = hashlib.md5(open(pts[0], 'rb').read()).hexdigest() if pts else 'NO_PT'
    rep.append(f'    {fn}: {"IDENT" if e_md5 == p_md5 else "DIFF"} en={e_md5[:8]} pt={p_md5[:8]}')

# 3b. SKSE plugin ini: PT vs EN14 (содержимое отличается?)
for fn in ('PathsOfEmpyrean.ini', 'ArcheryLocationalDamage.ini'):
    ens = find_en(fn)
    pts = pt_files.get(fn, [])
    if ens and pts:
        a = open(ens[0], encoding='utf-8', errors='replace').read()
        b = open(pts[0], encoding='utf-8', errors='replace').read()
        rep.append(f'--- {fn}: EN14 {len(a)} B vs PT {len(b)} B, {"IDENTICAL" if a == b else "DIFFERS"}')
        if a != b:
            la, lb = a.splitlines(), b.splitlines()
            diffs = [(x, y) for x, y in zip(la, lb) if x != y][:12]
            for x, y in diffs:
                rep.append(f'    EN: {x!r}\n    PT: {y!r}')
            rep.append(f'    строк EN/PT: {len(la)}/{len(lb)}')

# 3c. DESC.ini: ключи/переводы
def ini_keys(path):
    d = {}
    sec = None
    for line in open(path, encoding='utf-8', errors='replace'):
        line = line.strip()
        if not line or line.startswith(';'):
            continue
        m = re.match(r'\[(.+)\]$', line)
        if m:
            sec = m.group(1); continue
        m = re.match(r'([^=]+)=(.*)$', line)
        if m:
            d[(sec, m.group(1).strip())] = m.group(2)
    return d
desc_trip = {}
for tag, rel in (('EN14', f'{EN14}/полный_разбор_1.4/PoE 1.4/PathsOfEmpyrean_DESC.ini'),
                 ('PT', f'{PT}/_Main/PathsOfEmpyrean_DESC.ini'),
                 ('RU', f'{RU}/00 Core/PathsOfEmpyrean_DESC.ini')):
    desc_trip[tag] = ini_keys(rel)
ke, kp, kr = set(desc_trip['EN14']), set(desc_trip['PT']), set(desc_trip['RU'])
rep.append(f'--- DESC.ini main: ключей EN14={len(ke)}, PT={len(kp)}, RU={len(kr)}')
rep.append(f'    PT отсутствует ключей из EN14: {len(ke - kp)}; RU отсутствует: {len(ke - kr)}')
pt_tr = sum(1 for k in ke & kp if desc_trip['PT'][k] != desc_trip['EN14'][k])
ru_tr = sum(1 for k in ke & kr if desc_trip['RU'][k] != desc_trip['EN14'][k])
rep.append(f'    переведено: PT {pt_tr}/{len(ke & kp)}, RU {ru_tr}/{len(ke & kr)}')
# PT DESC.ini EN-остатки (первые 5)
pt_en_left = [k for k in ke & kp if desc_trip['PT'][k] == desc_trip['EN14'][k]]
rep.append(f'    PT=EN вхождений: {len(pt_en_left)} (примеры: {[k[1] for k in pt_en_left[:5]]})')
for cc in ('PoE-CCAdvancedCrossbows-Patch_DESC.ini', 'PoE-CCExpandedCrossbowPack-Patch_DESC.ini'):
    cc_trip = {}
    for tag, root in (('EN14', f'{EN14}/полный_разбор_1.4/PoE 1.4'),
                      ('PT', f'{PT}/Patches'),
                      ('RU', f'{RU}/30 CC Patches')):
        hits = []
        for dp, _, fns in os.walk(root):
            for fn in fns:
                if fn == cc:
                    hits.append(os.path.join(dp, fn))
        cc_trip[tag] = ini_keys(hits[0]) if hits else {}
    k1, k2, k3 = set(cc_trip['EN14']), set(cc_trip['PT']), set(cc_trip['RU'])
    t_pt = sum(1 for k in k1 & k2 if cc_trip['PT'][k] != cc_trip['EN14'][k])
    t_ru = sum(1 for k in k1 & k3 if cc_trip['RU'][k] != cc_trip['EN14'][k])
    rep.append(f'--- {cc}: ключей EN14={len(k1)}, PT={len(k2)}, RU={len(k3)}; переведено PT {t_pt}, RU {t_ru}')

# 3d. Interface/Translations
tr = {}
for tag, p in (('EN14', f'{EN14}/дистрибутив_1.4/Interface/Translations/PathsOfEmpyrean_ENGLISH.txt'),
               ('PT', f'{PT}/_Main/Interface/Translations/PathsOfEmpyrean_PORTUGUESE.txt'),
               ('RU', f'{RU}/00 Core/Interface/Translations/PathsOfEmpyrean_RUSSIAN.txt')):
    d = {}
    for line in open(p, encoding='utf-8', errors='replace'):
        line = line.strip().rstrip(';').strip()
        if not line:
            continue
        m = re.match(r'\$([^=\t]+)[=\t](.*)$', line)
        if m:
            d[m.group(1).strip()] = m.group(2).strip()
    tr[tag] = d
ke, kp, kr = set(tr['EN14']), set(tr['PT']), set(tr['RU'])
pt_tr = sum(1 for k in ke & kp if tr['PT'][k] != tr['EN14'][k])
ru_tr = sum(1 for k in ke & kr if tr['RU'][k] != tr['EN14'][k])
rep.append(f'--- MCM Translations: ключей EN={len(ke)}, PT={len(kp)}, RU={len(kr)}; переведено PT {pt_tr}, RU {ru_tr}; PT=EN {len(ke & kp) - pt_tr}')
rep.append(f'    ключи PT сверх EN: {sorted(kp - ke)[:6]}; RU сверх EN: {sorted(kr - ke)[:6]}')

with open(f'{OUT}/layers_107.txt', 'w', encoding='utf-8') as f:
    f.write('\n'.join(rep) + '\n')
print('\n'.join(rep))
