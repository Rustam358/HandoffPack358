#!/usr/bin/env python3
"""Extract SPID function/class names from the PDB debug symbols.
PDB MSF streams contain names as C strings / in the /names stream (DBI).
We collect candidate symbols via regex over raw bytes, then dedupe & classify."""
import re, collections

PDB = "/home/z/my-project/spid_work/spid_extracted/SKSE/Plugins/po3_SpellPerkItemDistributor.pdb"
data = open(PDB, "rb").read()
print(f"PDB size: {len(data)/1e6:.1f} MB")

# collect ascii strings >= 6 chars
strs = set()
for m in re.finditer(rb"[\x20-\x7e]{6,400}", data):
    s = m.group().decode("ascii", "ignore")
    strs.add(s)
print(f"Unique strings: {len(strs)}")

# SPID-specific namespaces
spid_pat = re.compile(
    r"(Distribution|Distribute|Forms?|Filter|NPC|PCLevelMult|Outfits?|LinkedDistribution|"
    r"DeathDistribution|ExclusiveGroups|KeywordDependencies|MergeMapper|INI|FormData|Settings)\b"
)

# Function signatures (appear as __cdecl strings in PDB too)
funcs = [s for s in strs if "__cdecl" in s or "::" in s]
spid_funcs = [s for s in funcs if spid_pat.search(s) and "std::" not in s.split("(")[0][:60]]
# also mangled names starting with ? and containing our namespaces
mangled = [s for s in strs if s.startswith("?") and re.search(r"(Distribution|PCLevelMult|Outfit|LinkedForm|ExclusiveGroup|Distribut)", s)]

print(f"Function-like strings: {len(funcs)}, SPID-specific: {len(spid_funcs)}, mangled SPID: {len(mangled)}")

with open("/home/z/my-project/spid_work/pdb_spid_funcs.txt", "w") as f:
    for s in sorted(set(spid_funcs)):
        f.write(s + "\n")
with open("/home/z/my-project/spid_work/pdb_all_names.txt", "w") as f:
    for s in sorted(strs):
        f.write(s + "\n")

# Classify by namespace
buckets = collections.defaultdict(set)
for s in set(spid_funcs):
    m = re.match(r"([A-Za-z_][A-Za-z0-9_]*(?:::[A-Za-z_][A-Za-z0-9_]*)*)", s)
    if m:
        ns = m.group(1)
        # top 2 components
        parts = ns.split("::")
        buckets["::".join(parts[:2])].add(s)

print("\n=== TOP NAMESPACE BUCKETS ===")
for k in sorted(buckets, key=lambda k: -len(buckets[k]))[:45]:
    print(f"{len(buckets[k]):4d}  {k}")
