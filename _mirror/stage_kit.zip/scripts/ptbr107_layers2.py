# -*- coding: utf-8 -*-
"""Этап 107 v2: слои вне ESP (DESC.ini, Translations, SKSE-ini, ModuleConfig, TES4 DESC) + наши победы."""
import json, re, os, collections, hashlib
import xml.etree.ElementTree as ET

OUT = '/home/z/my-project/work/handoff/work/qa107'
EN14 = '/home/z/my-project/work/handoff/handoff/08_оригинал_1.4_EN'
RU = '/home/z/my-project/work/ru15'
PT = '/home/z/my-project/work/ptbr/PathsOfEmpyrean_FOMODSetup'
rep = []

# ---------- DESC.ini (формат 0xHEX~Plugin|text) ----------
def desc_parse(path):
    d = {}
    for line in open(path, encoding='utf-8-sig', errors='replace'):
        line = line.rstrip('\n').strip()
        if not line:
            continue
        m = re.match(r'([^|]+)\|(.*)$', line)
        if m:
            d[m.group(1).strip()] = m.group(2)
    return d

def walk_files(root):
    for dp, _, fns in os.walk(root):
        for fn in fns:
            yield os.path.join(dp, fn)

def find_by_name(root, fn_target):
    return [p for p in walk_files(root) if os.path.basename(p) == fn_target]

rep.append('--- DESC.ini (формат 0xHEX~Plugin|text) ---')
for cc, cc_dirs in (
    ('PathsOfEmpyrean_DESC.ini', None),
    ('PoE-CCAdvancedCrossbows-Patch_DESC.ini', None),
    ('PoE-CCExpandedCrossbowPack-Patch_DESC.ini', None)):
    tri = {}
    tri['EN14'] = find_by_name(f'{EN14}/полный_разбор_1.4', cc)
    tri['PT'] = find_by_name(PT, cc)
    tri['RU'] = find_by_name(RU, cc)
    D = {t: desc_parse(paths[0]) for t, paths in tri.items() if paths}
    keys = set(D.get('EN14', {})) | set(D.get('PT', {})) | set(D.get('RU', {}))
    if 'EN14' in D and 'PT' in D:
        common = set(D['EN14']) & set(D['PT'])
        pt_tr = sum(1 for k in common if D['PT'][k] != D['EN14'][k])
        pt_miss = len(set(D['EN14']) - set(D['PT']))
        pt_en_left = len(common) - pt_tr
    else:
        pt_tr = pt_miss = pt_en_left = '?'
    if 'EN14' in D and 'RU' in D:
        common_r = set(D['EN14']) & set(D['RU'])
        ru_tr = sum(1 for k in common_r if D['RU'][k] != D['EN14'][k])
        ru_miss = len(set(D['EN14']) - set(D['RU']))
    else:
        ru_tr = ru_miss = '?'
    rep.append(f'    {cc}: ключей EN14={len(D.get("EN14", {}))}, PT={len(D.get("PT", {}))}, RU={len(D.get("RU", {}))}; '
               f'переведено PT={pt_tr} (нет ключей {pt_miss}, PT=EN {pt_en_left}), RU={ru_tr} (нет ключей {ru_miss})')

# ---------- Interface/Translations ----------
def tr_parse(path):
    d = {}
    for line in open(path, encoding='utf-8', errors='replace'):
        line = line.strip()
        if not line or line.startswith(';'):
            continue
        parts = re.split(r'[\t=;]', line, maxsplit=1)
        if len(parts) == 2 and parts[0].strip().startswith('$'):
            d[parts[0].strip()[1:]] = parts[1].strip()
        else:
            m = re.match(r'\$([^\s]+)\s+(.*)$', line)
            if m:
                d[m.group(1)] = m.group(2).strip()
    return d
rep.append('--- Interface/Translations (MCM) ---')
tri = {'EN14': f'{EN14}/дистрибутив_1.4/Interface/Translations/PathsOfEmpyrean_ENGLISH.txt',
       'PT': f'{PT}/_Main/Interface/Translations/PathsOfEmpyrean_PORTUGUESE.txt',
       'RU': f'{RU}/00 Core/Interface/Translations/PathsOfEmpyrean_RUSSIAN.txt'}
T = {t: tr_parse(p) for t, p in tri.items()}
ke, kp, kr = set(T['EN14']), set(T['PT']), set(T['RU'])
pt_tr = sum(1 for k in ke & kp if T['PT'][k] != T['EN14'][k])
ru_tr = sum(1 for k in ke & kr if T['RU'][k] != T['EN14'][k])
rep.append(f'    ключей EN={len(ke)}, PT={len(kp)}, RU={len(kr)}; переведено PT={pt_tr}, RU={ru_tr}; PT=EN={len(ke & kp)-pt_tr}')
rep.append(f'    ключи только в PT: {sorted(kp - ke)[:5]} | только в RU: {sorted(kr - ke)[:5]} | только в EN: {len(ke - kp - kr)}')
rep.append(f'    примеры PT: ' + '; '.join(f'{k}={T["PT"][k][:28]!r}' for k in sorted(kp)[:3]))

# ---------- SKSE ini: изменились ли не-комментарии ----------
rep.append('--- SKSE ini: не-комментарийное содержимое ---')
for fn in ('PathsOfEmpyrean.ini', 'ArcheryLocationalDamage.ini'):
    e = find_by_name(f'{EN14}/дистрибутив_1.4', fn)
    p = find_by_name(PT, fn)
    if e and p:
        ae = [l.strip() for l in open(e[0], encoding='utf-8', errors='replace') if l.strip() and not l.strip().startswith(';')]
        ap = [l.strip() for l in open(p[0], encoding='utf-8', errors='replace') if l.strip() and not l.strip().startswith(';')]
        rep.append(f'    {fn}: не-коммент. строк EN={len(ae)} PT={len(ap)}, {"IDENT" if ae == ap else "DIFFERS (значения изменены!)"}')

# ---------- ModuleConfig.xml: текстовые узлы ----------
def xml_texts(path):
    tree = ET.parse(path)
    nodes = []
    for el in tree.iter():
        for attr in ('name', 'description'):
            v = el.get(attr)
            if v and v.strip():
                nodes.append((el.tag, attr, v))
        if el.tag in ('text', 'moduleName') and el.text and el.text.strip():
            nodes.append((el.tag, 'text', el.text))
    return nodes
CYR = re.compile('[А-Яа-яЁё]')
PTD = re.compile('[ãáâàçéêíóôõúüÃÁÂÀÇÉÊÍÓÔÕÚÜ]')
def lang_of(s):
    if CYR.search(s): return 'RU'
    if PTD.search(s): return 'PT'
    return 'EN'
rep.append('--- ModuleConfig.xml: текстовые узлы по языкам ---')
for tag, p in (('PT', f'{PT}/fomod/ModuleConfig.xml'), ('RU', f'{RU}/fomod/ModuleConfig.xml')):
    nodes = xml_texts(p)
    cnt = collections.Counter(lang_of(v) for _, _, v in nodes)
    imgs = sum(1 for _, _, v in nodes if False)
    rep.append(f'    {tag}: узлов={len(nodes)} RU={cnt["RU"]} PT={cnt["PT"]} EN={cnt["EN"]}')
PTN = [v for _, _, v in xml_texts(f'{PT}/fomod/ModuleConfig.xml')]
RUN = [v for _, _, v in xml_texts(f'{RU}/fomod/ModuleConfig.xml')]
en_nodes = [v for v in RUN if lang_of(v) == 'EN']
rep.append(f'    RU: EN-узлов {len(en_nodes)} (канон «имена опций по оригиналу»); примеры: {en_nodes[:5]}')
pt_en = [v for v in PTN if lang_of(v) == 'EN']
rep.append(f'    PT: EN-узлов {len(pt_en)} (EN-остатки бразильцев): {pt_en[:5]}')
# image-ссылки
img_pt = [v for _, a, v in xml_texts(f'{PT}/fomod/ModuleConfig.xml') if a == 'name' and v.endswith(('.png', '.jpg'))]
img_el = [el.tag for el in ET.parse(f'{PT}/fomod/ModuleConfig.xml').iter() if el.tag.endswith('image')]
rep.append(f'    PT image-узлов: {len(img_el)} {img_el[:6]}')

# ---------- TES4 DESC (описание плагина) ----------
def tes4_desc(path):
    buf = open(path, 'rb').read()
    size = int.from_bytes(buf[4:8], 'little')
    off = 24
    end = 24 + size
    while off < end:
        st = buf[off:off+4]; ssz = int.from_bytes(buf[off+4:off+6], 'little')
        if st == b'DESC':
            data = buf[off+6:off+6+ssz].rstrip(b'\x00')
            try:
                return data.decode('utf-8')
            except UnicodeDecodeError:
                return data.decode('cp1252', 'replace')
        off += 6 + ssz
    return None
rep.append('--- TES4 DESC (описание плагина в мод-менеджере) ---')
main_paths = {'EN14': f'{EN14}/полный_разбор_1.4/PoE 1.4/PathsOfEmpyrean.esp',
              'PT': f'{PT}/_Main/PathsOfEmpyrean.esp',
              'RU': f'{RU}/00 Core/PathsOfEmpyrean.esp'}
for t, p in main_paths.items():
    d = tes4_desc(p)
    rep.append(f'    {t}: {None if d is None else d[:110]!r}')
n_pt = n_ru = n_en = 0
for dp, _, fns in os.walk(f'{EN14}/полный_разбор_1.4/PoE 1.4'):
    for fn in fns:
        if fn.endswith('.esp'):
            d = tes4_desc(os.path.join(dp, fn))
            if d: n_en += 1
for dp, _, fns in os.walk(PT):
    for fn in fns:
        if fn.endswith('.esp'):
            d = tes4_desc(os.path.join(dp, fn))
            if d and (PTD.search(d) or CYR.search(d)): n_pt += 1
for dp, _, fns in os.walk(RU):
    for fn in fns:
        if fn.endswith('.esp'):
            d = tes4_desc(os.path.join(dp, fn))
            if d and CYR.search(d): n_ru += 1
rep.append(f'    ESP с непустым DESC: EN14 {n_en}/39, PT с PT/RU-текстом {n_pt}/39, RU с RU-текстом {n_ru}/39')

# ---------- Наши победы (состав 17) ----------
def load_jsonl(path):
    return [json.loads(l) for l in open(path, encoding='utf-8')]
en14 = load_jsonl(f'{OUT}/dump_en14.jsonl')
pt = load_jsonl(f'{OUT}/dump_pt.jsonl')
ru = json.load(open(f'{EN14.replace("/08_оригинал_1.4_EN", "")}/../../handoff/handoff/06_код-истина_перевода/corpus57.json', encoding='utf-8')) if False else json.load(open('/home/z/my-project/work/handoff/handoff/06_код-истина_перевода/corpus57.json', encoding='utf-8'))
E = {(r['file'], r['rtype'], r['fid'], r['field'], r['occ']): r['text'] for r in en14}
P = {(r['file'], r['rtype'], r['fid'], r['field'], r['occ']): r['text'] for r in pt}
R = {(r['file'], r['type'], r['fid'], r['field'], r['occ']): (r.get('ru'), r.get('en')) for r in ru}
wins = []
for k, en in E.items():
    if k in P and k in R and P[k] == en and en.strip():
        ruv, ru_en_val = R[k]
        if ru_en_val is not None and ru_en_val != en: continue
        if ruv is not None and ruv != en:
            wins.append((k, en, ruv))
rep.append(f'--- Наши победы (RU перевел, PT=EN): {len(wins)} ---')
fam = collections.Counter((k[1], k[3]) for k, *_ in wins)
rep.append(f'    семьи: {dict(fam)}')
for k, en, ruv in wins[:6]:
    rep.append(f'    {k[0]}/{k[1]}/{k[2]} {k[3]}: EN={en[:32]!r} RU={ruv[:32]!r}')

with open(f'{OUT}/layers_107.txt', 'w', encoding='utf-8') as f:
    f.write('\n'.join(rep) + '\n')
print('\n'.join(rep))
