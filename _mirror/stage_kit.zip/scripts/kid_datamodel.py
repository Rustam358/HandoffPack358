#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 98: полная модель типов KID из PDB TPI (SE-вариант).

Адаптация scripts/pdb_datamodel.py (Этап 97) под Keyword Item Distributor 4.1.0.
Выход: kid_work/datamodel.txt
"""
import re
import struct

PDB = ("/home/z/my-project/kid_work/kid_extracted/"
       "Keyword Item Distributor FOMOD Installer/SE/SKSE/Plugins/"
       "po3_KeywordItemDistributor.pdb")
OUT = "/home/z/my-project/kid_work/datamodel.txt"

data = open(PDB, "rb").read()
MAGIC = b"Microsoft C/C++ MSF 7.00\r\n\x1aDS\x00\x00\x00"
bs, fm, nb, ds, unk, bma = struct.unpack_from("<IIIIII", data, len(MAGIC))
nd = (ds + bs - 1) // bs
db = struct.unpack_from(f"<{nd}I", data, bma * bs)
directory = b"".join(data[b * bs: b * bs + bs] for b in db)[:ds]
pos = 0
ns = struct.unpack_from("<I", directory, pos)[0]; pos += 4
sizes = [struct.unpack_from("<I", directory, pos + 4 * i)[0] for i in range(ns)]
pos += 4 * ns
streams = []
for i, sz in enumerate(sizes):
    if sz in (0, 0xFFFFFFFF):
        streams.append(b""); continue
    nbk = (sz + bs - 1) // bs
    blks = struct.unpack_from(f"<{nbk}I", directory, pos); pos += 4 * nbk
    streams.append(b"".join(data[b * bs: b * bs + bs] for b in blks)[:sz])
tpi = streams[2]
ver, hsize, imin, imax = struct.unpack_from("<IIII", tpi, 0)
print(f"TPI ver={ver} header={hsize:#x} indices {imin}..{imax}")

offsets = {}
i = hsize
idx = imin
while i < len(tpi) - 4 and idx < imax:
    reclen = struct.unpack_from("<H", tpi, i)[0]
    offsets[idx] = i
    i = (i + 2 + reclen + 3) & ~3
    idx += 1
print(f"TPI records: {len(offsets)}")

LF_MEMBER = 0x150D; LF_STMEMBER = 0x150E; LF_METHOD = 0x150F; LF_ONEMETHOD = 0x1511
LF_ENUMERATE = 0x1502; LF_NESTTYPE = 0x1510; LF_BCLASS = 0x1400; LF_INDEX = 0x1404
LF_VFUNCTAB = 0x1409


def rec_at(tidx):
    o = offsets.get(tidx)
    if o is None:
        return None
    reclen = struct.unpack_from("<H", tpi, o)[0]
    return tpi[o:o + 2 + reclen]


PRIMS = {0x03: "int", 0x74: "unsigned", 0x08: "void*", 0x43: "__int64",
         0x75: "unsigned __int64", 0x68: "bool", 0x11: "char", 0x21: "short",
         0x41: "long", 0x70: "float", 0x40: "double", 0x04: "void",
         0x73: "unsigned char", 0x12: "unsigned char"}


def typename(tidx):
    r = rec_at(tidx)
    if r is None:
        return f"t{tidx}"
    leaf = struct.unpack_from("<H", r, 2)[0]
    if leaf in PRIMS:
        return PRIMS[leaf]
    if leaf == 0x1502:  # pointer
        ptr, t = struct.unpack_from("<IH", r, 4)
        return f"{typename(t)}*"
    if leaf in (0x1505, 0x1504, 0x1506, 0x1507, 0x1508, 0x1509, 0x150A,
                0x150B, 0x150C):
        try:
            payload = r[4:]
            hdr = 16 if leaf in (0x1505, 0x1504, 0x1506) else 12
            nm = clean_name(payload, hdr)
            if nm:
                return nm
            return f"t{tidx}"
        except ValueError:
            return f"t{tidx}"
    if leaf == 0x1002:  # LF_MODIFIER
        m, t = struct.unpack_from("<IH", r, 4)
        return f"const {typename(t)}"
    if leaf in (0x1500,):  # LF_ARRAY
        atype = struct.unpack_from("<I", r, 4)[0]
        return f"{typename(atype)}[]"
    if leaf == 0x1001:
        m, t = struct.unpack_from("<IH", r, 4)
        return f"mod {typename(t)}"
    return f"t{tidx}:{leaf:#x}"


# index: tidx -> (name, leaf, prop, fieldlist)
# ВАЖНО (отличие от SPID-PDB Этапа 97): у этого PDB перед именем записи
# STRUCT/CLASS могут стоять 2-3 служебных байта (00 08 21 / 00 00 и т.п.),
# поэтому имя ищем сканом первого «чистого» zstr в payload, а не по
# фиксированному оффсету. Иначе имена читаются пустыми.
NAME_RE = re.compile(rb"[A-Za-z_`<\[][A-Za-z0-9_:<>,$@'.\- ]{1,200}\x00")


def clean_name(payload, hdr_len):
    for m in NAME_RE.finditer(payload, hdr_len):
        s = m.group()[:-1].decode("latin1", "ignore")
        if ".?A" in s[:4]:
            continue  # это unique-name, не имя
        return s
    return None


types = {}
for tidx in offsets:
    r = rec_at(tidx)
    if r is None or len(r) < 10:
        continue
    leaf = struct.unpack_from("<H", r, 2)[0]
    payload = r[4:]
    try:
        if leaf in (0x1505, 0x1504, 0x1506):
            count, prop = struct.unpack_from("<HH", payload, 0)
            fl, derived, vshape = struct.unpack_from("<III", payload, 4)
            name = clean_name(payload, 16)
            if name:
                types[tidx] = (name, leaf, prop, fl)
        elif leaf == 0x1507:
            count, prop = struct.unpack_from("<HH", payload, 0)
            utype = struct.unpack_from("<I", payload, 4)[0]
            fl = struct.unpack_from("<I", payload, 8)[0]
            name = clean_name(payload, 12)
            if name:
                types[tidx] = (name, leaf, prop, fl)
    except (ValueError, struct.error):
        continue


def members_of(fl, depth=0):
    if depth > 8:
        return []
    flr = rec_at(fl)
    if flr is None:
        return []
    out = []
    p = 4
    plen = len(flr)
    while p < plen - 2:
        if flr[p] >= 0xF0:
            p += flr[p] & 0x0F
            continue
        mleaf = struct.unpack_from("<H", flr, p)[0]; p += 2
        try:
            if mleaf == LF_MEMBER:
                attrs = struct.unpack_from("<H", flr, p)[0]; p += 2
                t2 = struct.unpack_from("<I", flr, p)[0]; p += 4
                v16 = struct.unpack_from("<H", flr, p)[0]
                if v16 >= 0x8000:
                    off = -1
                    if v16 in (0x8003, 0x8004): p += 6
                    elif v16 in (0x8001, 0x8002): p += 4
                    elif v16 == 0x8000: p += 3
                    else: p += 2
                else:
                    off = v16; p += 2
                e = flr.index(b"\x00", p)
                nm = flr[p:e].decode("latin1", "ignore"); p = e + 1
                out.append(("member", nm, off, t2))
            elif mleaf == LF_ENUMERATE:
                attrs = struct.unpack_from("<H", flr, p)[0]; p += 2
                v16 = struct.unpack_from("<H", flr, p)[0]
                if v16 >= 0x8000:
                    val = None
                    if v16 in (0x8003, 0x8004): p += 6
                    elif v16 in (0x8001, 0x8002): p += 4
                    elif v16 == 0x8000: p += 3
                    else: p += 2
                else:
                    val = v16; p += 2
                e = flr.index(b"\x00", p)
                nm = flr[p:e].decode("latin1", "ignore"); p = e + 1
                out.append(("enum", nm, val, 0))
            elif mleaf == LF_STMEMBER:
                p += 2
                t2 = struct.unpack_from("<I", flr, p)[0]; p += 4
                e = flr.index(b"\x00", p)
                out.append(("static", flr[p:e].decode("latin1", "ignore"),
                            -1, t2)); p = e + 1
            elif mleaf in (LF_ONEMETHOD, LF_METHOD, LF_NESTTYPE, LF_INDEX,
                           LF_BCLASS, LF_VFUNCTAB):
                if mleaf == LF_ONEMETHOD:
                    attrs = struct.unpack_from("<H", flr, p)[0]; p += 2
                    p += 4
                    e = flr.index(b"\x00", p); p = e + 1
                    if attrs & 0x40: p += 4
                elif mleaf == LF_METHOD:
                    # CodeView lfMethod: count(u16) + mList(4, ОДИН индекс
                    # списка перегрузок) + имя. Пропуск 4Б обязателен, иначе
                    # парсер уезжает в мусор (баг адаптации со SPID-версии).
                    cnt = struct.unpack_from("<H", flr, p)[0]; p += 2
                    p += 4
                    e = flr.index(b"\x00", p); p = e + 1
                elif mleaf == LF_NESTTYPE:
                    p += 2 + 4
                    e = flr.index(b"\x00", p); p = e + 1
                elif mleaf == LF_INDEX:
                    cont = struct.unpack_from("<I", flr, p + 2)[0]
                    p += 6
                    out.extend(members_of(cont, depth + 1))
                elif mleaf == LF_BCLASS:
                    p += 2 + 4
                    v16 = struct.unpack_from("<H", flr, p)[0]
                    if v16 >= 0x8000: p += 6
                    else: p += 2
                elif mleaf == LF_VFUNCTAB:
                    p += 2 + 4
            else:
                break
        except (ValueError, struct.error):
            break
    return out


# ---------- dump KID data model ----------
INTEREST = re.compile(
    r"^(Keyword::Distributable|Keyword::Data|Keyword::Dependencies|"
    r"DistributableFilterSet|FilterRule|FilterSet|ItemData|RawForm|"
    r"RawKeyword|RawExclusiveGroup|ExclusiveGroups::(INI::|Manager)|"
    r"DependencyResolver|INI::(Data|Settings)|Settings|FormData|Distribute::|"
    r"Forms::|Hooks::|Range<|ComponentParser|Criteria|ConfigFilterSet|"
    r"ResolvedFilter|Filters<|DISTRIBUTION::)")

# точные имена, которые нужны независимо от INTEREST
TARGETS = {
    "Keyword::Data", "Keyword::Dependencies", "ItemData", "Settings",
    "INI::Data", "INI::Settings", "RawForm", "RawKeyword", "FormData",
    "Criteria", "ConfigFilterSet", "ResolvedFilter",
    "ExclusiveGroups::INI::RawExclusiveGroup", "ExclusiveGroups::Manager",
    "DISTRIBUTION::TYPES::TYPE", "Hooks::InitItemImpl",
    "Keyword::Dependencies::keyword_less",
}


def is_clean(name):
    if "@" in name or "<lambda_" in name or "::__l" in name:
        return False
    return True


lines = []
n = 0
for tidx in sorted(types):
    name, leaf, prop, fl = types[tidx]
    if prop & 0x80:  # fwdrefs skip
        continue
    clean = name.lstrip("x\x00\x01`\x7f")
    if not is_clean(name):
        continue
    if (INTEREST.match(clean) or INTEREST.match(name)
            or clean in TARGETS or name in TARGETS):
        n += 1
        kind = "enum" if leaf == 0x1507 else "struct"
        lines.append(f"\n=== [{tidx}] {name} ({kind}) ===")
        for m in members_of(fl):
            if m[0] == "member":
                _, nm, off, t2 = m
                lines.append(f"    {nm:26s} @{off:<#6x} : {typename(t2)}")
            elif m[0] == "enum":
                _, nm, val, _ = m
                lines.append(f"    {nm} = {val}")
            elif m[0] == "static":
                _, nm, _, t2 = m
                lines.append(f"    static {nm:20s} : {typename(t2)}")

print(f"KID type model: {n} matching complete definitions")
with open(OUT, "w") as f:
    f.write("\n".join(lines) + "\n")
print(f"written {OUT}")
