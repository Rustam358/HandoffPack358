#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Этап 103: верификация собранного пакета download/Paths of Empyrean RU 1.5.zip (v1.5.8).

1. Распаковка архива -> work/v158_check
2. Дамп текстов (39 ESP)
3. Дифф v1.5.7 -> v1.5.8 == work/qa102/fixlist_v158.jsonl (ровно, без лишних/недостающих)
4. Наборы (file, rtype, formid) не изменились (A1/A2)
5. Паритет B3 (%%, ё, —, lone \\n, ёлочки) + B4 (PERK DESC <= 290) по всему дампу
6. Спот-чек правок 102-а/100-а + регресс-пробы (MageWard/Dragonblood/Trainee/Steel)"""
import json, os, sys, zipfile, shutil
from collections import Counter

sys.path.insert(0, '/home/z/my-project/upload/poe_pack/scripts')
from dump150 import dump_esp  # noqa: E402

DST = '/home/z/my-project/download/Paths of Empyrean RU 1.5.zip'
CHECK = '/home/z/my-project/upload/poe_pack/work/v158_check'
QA = '/home/z/my-project/upload/poe_pack/work/qa103'
FIX = '/home/z/my-project/upload/poe_pack/work/qa102/fixlist_v158.jsonl'

# --- 1. распаковка ---
if os.path.isdir(CHECK):
    shutil.rmtree(CHECK)
os.makedirs(CHECK)
with zipfile.ZipFile(DST) as z:
    assert z.testzip() is None
    z.extractall(CHECK)
print('распаковано:', len(os.listdir(CHECK)), 'каталогов верхнего уровня')

# --- 2. дамп v158 ---
JOBS = [
    (f'{CHECK}/00 Core/PathsOfEmpyrean.esp', 'main'),
    (f'{CHECK}/10 Missing Shields/PoE-Addon-MissingShields.esp', 'ms'),
    (f'{CHECK}/20 Spears/PoE-Addon-Spears.esp', 'sp'),
]
import glob
for path in sorted(glob.glob(f'{CHECK}/30 CC Patches/*/*.esp')):
    tag = 'cc:' + os.path.basename(path).replace('PoE-CC', '').replace('-Patch.esp', '')
    JOBS.append((path, tag))

with open(f'{QA}/dump_v158.jsonl', 'w', encoding='utf-8') as out:
    for path, tag in JOBS:
        p = dump_esp(path, tag, out)
        print(f'  {tag}: записей={len(p.records)}')

after = {}
for line in open(f'{QA}/dump_v158.jsonl', encoding='utf-8'):
    r = json.loads(line)
    k = (r['file'], r['rtype'], r['formid'], r['field'], r['occ'])
    after[k] = (r['text'], r.get('edid', ''))
print('текстовых полей v1.5.8:', len(after))

# --- дамп v157 (истина до) ---
before = {}
for line in open('/home/z/my-project/upload/poe_pack/work/qa100/dump_v157.jsonl', encoding='utf-8'):
    r = json.loads(line)
    k = (r['file'], r['rtype'], r['formid'], r['field'], r['occ'])
    before[k] = (r['text'], r.get('edid', ''))

# --- 3. дифф ---
diffs = []
for k in sorted(set(before) | set(after), key=str):
    t_old = before.get(k, (None,))[0]
    t_new = after.get(k, (None,))[0]
    if t_old != t_new:
        diffs.append((k, t_old, t_new))
print('изменений текстов v1.5.7 -> v1.5.8:', len(diffs))

expected = {}
for line in open(FIX, encoding='utf-8'):
    r = json.loads(line)
    assert r['kind'] == 'esp' and r['scope'] == 'main'
    k = ('main', 'PERK', r['formid'], r['field'], r['occ'])
    expected[k] = (r['old'], r['new'])
print('ожидаемых правок:', len(expected))
assert len(expected) == 8, f'fixlist развернулся в {len(expected)}'

actual = {k: (o, n) for k, o, n in diffs}
missing = {k for k in expected if k not in actual}
extra = {k for k in actual if k not in expected}
assert not missing, f'НЕ ПРИМЕНЕНЫ: {[k for k in missing]}'
assert not extra, f'ЛИШНИЕ ИЗМЕНЕНИЯ: {[k for k in extra]}'
for k, (o, n) in expected.items():
    assert actual[k] == (o, n), f'{k}: {actual[k]!r} != {(o, n)!r}'
print('ДИФФ РОВНО = ФИКСЛИСТ: 8/8, 0 лишних, 0 недостающих')

# --- 4. наборы formid (A1) ---
set_before = {(k[0], k[1], k[2]) for k in before}
set_after = {(k[0], k[1], k[2]) for k in after}
assert set_before == set_after, f'наборы записей изменились: +{set_after - set_before} -{set_before - set_after}'
print('A1: наборы (file, rtype, formid) не изменились')

# --- 5. паритет B3 + B4 по всему дампу ---
cnt = Counter()
long_desc = []
mismatch_quotes = []
for k, (text, _edid) in after.items():
    if not text:
        continue
    if '%%' in text:
        cnt['%%'] += 1
    if 'ё' in text or 'Ё' in text:
        cnt['ё'] += 1
    if '—' in text:
        cnt['—'] += 1
    if '\n' in text.replace('\r\n', ''):
        cnt['lone_\\n'] += 1
    if text.count('«') != text.count('»'):
        mismatch_quotes.append(k)
    if k[1] == 'PERK' and k[3] == 'DESC' and len(text) > 290:
        long_desc.append((k, len(text)))
assert not cnt, f'B3 провален: {dict(cnt)}'
print('B3: %%=0, ё=0, —=0, lone \\n=0; ёлочки сбалансированы')
assert not long_desc, f'B4 провален: {long_desc}'
print('B4: PERK DESC <= 290 символов по всем 39 ESP')
assert not mismatch_quotes, f'ёлочки не сбалансированы: {mismatch_quotes[:5]}'

# --- 6. спот-чек + регресс-пробы ---
print()
print('=== СПОТ-ЧЕК (правки этапа) ===')


def get(f, rt, fid, fld, occ=1):
    hit = after[(f, rt, fid, fld, occ)]
    return hit[0]


want_map = {
    ('main', 'PERK', '000D7999', 'DESC', 1):
        'Заклинания плоти (напр., «Каменная плоть») на 30% сильнее. Если вы не носите броню, их сила возрастает до 100%.',
    ('main', 'PERK', '000D799A', 'DESC', 1):
        'Заклинания плоти на 50% сильнее. Если вы не носите броню, их сила возрастает до 150%.',
    ('main', 'PERK', '000D799B', 'DESC', 1):
        'Заклинания плоти на 70% сильнее. Если вы не носите броню, их сила возрастает до 200%.',
    ('main', 'PERK', '06000BC0', 'DESC', 1):
        'Заклинания огня и солнца наносят нежити на 25% больше урона. Заклинания отпугивания нежити становятся на 50% сильнее и поджигают цель святым огнем.',
    ('main', 'PERK', '000BE124', 'DESC', 1):
        'Карманные кражи облегчаются на 0,5% за каждый уровень навыка Карманной кражи. Вес и ценность предмета снижают шанс успеха.',
    ('main', 'PERK', '00018E6A', 'DESC', 1):
        'Карманные кражи облегчаются на 1% за каждый уровень навыка Карманной кражи. Вес и ценность предмета снижают шанс успеха.',
    ('main', 'PERK', '0600081E', 'DESC', 1):
        'Яды на оружии действуют на 1 попадание дольше за каждые 20 уровней навыка Алхимии. Яд существ можно дистиллировать в смертоносные яды.',
    ('main', 'PERK', '060290CE', 'DESC', 1):
        'Созданные вами капканы наносят на 1-2 единицы урона больше за каждый уровень навыка Кузнечного дела. Ежи вызывают кровотечение на 1 секунду дольше за каждые 10 уровней навыка Кузнечного дела.',
}
for k, want in want_map.items():
    got = after[k][0]
    assert got == want, f'{k}: {got!r} != {want!r}'
    print(f'  {k[2]} (occ {k[4]}): OK  [{len(got)} зн.]')

print()
print('=== РЕГРЕСС-ПРОБЫ (не должны были измениться) ===')
REGRESS = [
    # MageWard1/2 — «сильнее» уже канонно, не тронуты
    ('main', 'PERK', '06000BC2', 'DESC', 'PoE_PERK_RES_MageWard1'),
    ('main', 'PERK', '06000BC3', 'DESC', 'PoE_PERK_RES_MageWard2'),
    # DragonbloodMasterwork — отложенная сверка закрыта (оставлено «эффективнее»)
    ('main', 'PERK', '06014C65', 'DESC', 'PoE_PERK_SMITH_DragonbloodMasterwork'),
    # Trainee1 — офиц. прецедент Блокирования («эффективнее»)
    ('main', 'PERK', '06520176', 'DESC', 'PoE_PERK_BLOCK_Trainee1'),
    # SteelSmithing — семейный якорь, наблюдение §4 report_102
    ('main', 'PERK', '000CB40D', 'DESC', 'SteelSmithing'),
    # защита от дрейфа: копья/луки/сообщения из verify94
    ('sp', 'WEAP', '0700019E', 'FULL', 'Святое сталгримовое копье'),
    ('main', 'MESG', '06005DE4', 'DESC', 'Paths of Empyrean 1.5 загружается...'),
    ('main', 'MGEF', '063D17F0', 'DNAM', '**Восстановление Урагана**'),
]
for f, rt, fid, fld, want in REGRESS:
    hit = [k for k in after if k[0] == f and k[1] == rt and k[2] == fid and k[3] == fld]
    assert hit, f'{fid} не найден'
    got = after[hit[0]][0]
    if want.startswith(('PoE_PERK', 'SteelSmithing')):
        assert want in (after[hit[0]][1] or ''), f'{fid}: EDID {after[hit[0]][1]!r} не содержит {want!r}'
        print(f'  {f} {rt} {fid} ({want[:42]}…): на месте OK')
    else:
        assert got == want, f'РЕГРЕСС {f} {fid}: {got!r} != {want!r}'
        print(f'  {f} {rt} {fid} {fld}: {want!r} OK')

mw1 = after[('main', 'PERK', '06000BC2', 'DESC', 1)][0]
mw2 = after[('main', 'PERK', '06000BC3', 'DESC', 1)][0]
dbm = after[('main', 'PERK', '06014C65', 'DESC', 1)][0]
trn = after[('main', 'PERK', '06520176', 'DESC', 1)][0]
assert 'сильнее' in mw1 and 'сильнее' in mw2, 'MageWard потерял «сильнее»?!'
assert 'эффективнее' in dbm, 'DragonbloodMasterwork изменился?!'
assert 'эффективнее' in trn, 'Trainee изменился?!'
print('  MageWard1/2 = «сильнее» (канон), Dragonblood/Trainee = «эффективнее» (санкция): OK')

# --- версии FOMOD ---
xml = open(f'{CHECK}/fomod/ModuleConfig.xml', encoding='utf-8').read()
assert 'v1.5.8' in xml and 'v1.5.7' not in xml
ver = open(f'{CHECK}/fomod/info.xml', encoding='utf-8').read()
assert '<Version>1.5.8</Version>' in ver
print('  FOMOD: v1.5.8, readme-ссылок нет: OK')

print()
print('ВЕРИФИКАЦИЯ ЗАВЕРШЕНА: пакет v1.5.8 соответствует фикс-листу')
